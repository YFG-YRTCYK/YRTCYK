# YRTCYK Session 15 — Backend Snapshot (June 28, 2026)

This is a records/GitHub-archive snapshot of the BACKEND changes made in Session 15.
All of it is ALREADY LIVE in Supabase (project fdpcaqzwvophryosnmlh). It was deployed
directly via the Supabase MCP during the session.

>>> THIS IS NOT A NETLIFY DEPLOY. Do not drag this to Netlify. The React app was not
    touched this session, so the live app at action.yourfairygodfather.com is unchanged
    and already correct. <<<

If your GitHub archive tracks the Supabase backend (functions + migrations), add these
files to it. If your archive is React-only, you can disregard this; nothing here needs
to be uploaded anywhere because it is already running in production.

## What changed and is live

1. supabase/functions/process-referral-rewards/index.ts  (now version 16, "v11" logic)
   - Phase B resolves the referrer's Stripe customer ID-FIRST off members.stripe_customer_id,
     falls back to email only when null, and self-heals by writing the discovered id back
     onto the member.
   - Adds the permanent guardrail: refuses to credit a customer with no active/trialing
     subscription.
   - Unchanged: Stripe account assertion (acct_1TBNLvAqi5UIjRPy), dryRun, per-reward
     Idempotency-Key, Phase A month_2 detection, is_operator skip, earner email.
   - PROOF: dry-run returned correct account, 0 pending, 0 credits, 0 errors. It cannot
     re-issue the three already-applied rewards.

2. Five retired scaffolding functions, now inert 410 stubs (version 2 each):
   - widen-circle-issue-credits, backfill-member-stripe-ids, widen-circle-checkout-verify,
     widen-circle-customer-find, widen-circle-stripe-check.
   - (stripe-key-check was already a stub from a prior session.)
   - MCP has no hard-delete, so these slugs remain as harmless stubs. You may hard-delete
     them from the Supabase dashboard whenever convenient (Edge Functions list).

3. supabase/migrations/20260628_create_member_blocks_and_can_see_b1.sql  (Block feature foundation)
   - Table public.member_blocks + RLS (3 email-based policies) + function public.can_see().
   - Semantics: MUTUAL, SILENT, BLOCKER-CONTROLLED, ADMIN-EXEMPT, no self-block.
   - PROOF: tested with members #4/#5 — block produced mutual invisibility, admin exempt
     both ways, unrelated member unaffected, unblock restored visibility; table left empty.

## What is NOT in this snapshot (because it did not change this session)
   - The React app (action.yourfairygodfather.com) — untouched.
   - stripe-webhook (v27) — changed in a prior session, not this one.
   - The member-facing Block UI — NOT yet built. It ships in a future deploy-coupled pass
     together with live RLS enforcement across the community tables and your Netlify drag.
