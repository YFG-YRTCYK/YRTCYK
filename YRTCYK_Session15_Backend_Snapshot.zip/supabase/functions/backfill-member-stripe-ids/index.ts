// Decommissioned Session 15 scaffolding (retired 2026-06-28).
// Member->customer anchoring is now handled permanently by stripe-webhook on
// customer.subscription.created. This one-shot backfill slug is inert.
Deno.serve(() => new Response(JSON.stringify({ status: 'gone', note: 'Session 15 scaffolding retired. Safe to hard-delete from the Supabase dashboard.' }), { status: 410, headers: { 'Content-Type': 'application/json' } }))
