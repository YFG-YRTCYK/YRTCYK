// process-referral-rewards v11 — June 28, 2026 (Session 15 sweep)
// Permanent daily path for Widen-the-Circle referrer rewards.
// v11 changes vs v10:
//   (1) Phase B is now ID-FIRST: resolves the earner's Stripe customer via
//       members.stripe_customer_id; falls back to email lookup only when null,
//       and self-heals by writing the discovered id back onto the member.
//   (2) Adds the permanent guardrail: refuses to credit a customer with no
//       active/trialing subscription (no parked credit that never converts).
// Unchanged: Stripe account assertion (acct_1TBNLvAqi5UIjRPy), dryRun, per-reward
//   Idempotency-Key, Phase A month_2 detection, is_operator skip, earner email.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')!
const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY')!

const EXPECTED_ACCOUNT = 'acct_1TBNLvAqi5UIjRPy'   // YRTCYK / GPV Consulting LLC. Guardrail anchor.
const REWARD_AMOUNT_CENTS = 599                    // one free month at $5.99

const supabase = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

async function stripeGet(path: string): Promise<any> {
  const r = await fetch(`https://api.stripe.com/v1${path}`, {
    headers: { 'Authorization': `Bearer ${STRIPE_SECRET_KEY}` }
  })
  const j = await r.json()
  if (!r.ok) throw new Error(`Stripe GET ${path} ${r.status}: ${j?.error?.message || 'error'}`)
  return j
}

async function stripePostForm(path: string, params: Record<string, string>, idempotencyKey?: string): Promise<any> {
  const headers: Record<string, string> = {
    'Authorization': `Bearer ${STRIPE_SECRET_KEY}`,
    'Content-Type': 'application/x-www-form-urlencoded'
  }
  if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey
  const r = await fetch(`https://api.stripe.com/v1${path}`, {
    method: 'POST',
    headers,
    body: new URLSearchParams(params).toString()
  })
  const j = await r.json()
  if (!r.ok) throw new Error(`Stripe POST ${path} ${r.status}: ${j?.error?.message || 'error'}`)
  return j
}

async function customerHasActiveSub(customerId: string): Promise<boolean> {
  const subs = await stripeGet(`/subscriptions?customer=${customerId}&status=all&limit=10`)
  return (subs?.data || []).some((s: any) => s.status === 'active' || s.status === 'trialing')
}

function generateCouponCode(memberName: string): string {
  const clean = memberName.replace(/[^a-zA-Z0-9]/g, '').toUpperCase().slice(0, 8)
  const rand = Math.random().toString(36).substring(2, 7).toUpperCase()
  return `FREE1M-${clean}-${rand}`
}

async function sendRewardEmail(email: string, displayName: string, referredName: string) {
  const firstName = (displayName || 'Friend').split(' ')[0]
  const html = `<!DOCTYPE html><html><head><meta charset="utf-8"></head><body style="margin:0;padding:0;background:#01280e;font-family:Georgia,serif;"><table width="100%" cellpadding="0" cellspacing="0" style="background:#01280e;"><tr><td align="center" style="padding:40px 20px;"><table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;"><tr><td style="padding:0 0 32px 0;text-align:center;"><div style="font-family:system-ui,sans-serif;font-size:22px;font-weight:700;letter-spacing:6px;color:#FF1493;">YRTCYK</div><div style="font-size:12px;color:rgba(251,250,244,0.4);margin-top:4px;">You aRe The Company You Keep</div></td></tr><tr><td style="background:rgba(25,229,94,0.08);border:1px solid rgba(25,229,94,0.2);border-radius:8px;padding:36px 40px;"><p style="margin:0 0 8px 0;font-family:system-ui,sans-serif;font-size:13px;color:rgba(251,250,244,0.45);">Good news, ${firstName}</p><h1 style="margin:0 0 24px 0;font-size:28px;font-weight:400;color:#fbfaf4;">🎁 Your free month is applied</h1><p style="margin:0 0 24px 0;font-size:16px;line-height:1.8;color:rgba(251,250,244,0.75);"><strong style="color:#19e55e;">${referredName}</strong> stayed and grew with us, and so your reward for widening the circle is here.<br><br>A full month, on us, has been credited to your membership automatically. Nothing for you to do. Your next bill is already taken care of.</p><div style="background:rgba(255,20,147,0.08);border:2px solid #FF1493;border-radius:8px;padding:24px;text-align:center;margin:24px 0;"><div style="font-family:system-ui,sans-serif;font-size:13px;color:#FF1493;letter-spacing:0.04em;">🌈 One month free, applied to your account</div></div><p style="margin:0;font-size:14px;color:rgba(251,250,244,0.45);text-align:center;font-style:italic;">Keep sharing. Keep growing. Keep the company.</p></td></tr><tr><td style="padding:32px 0 0 0;text-align:center;"><p style="margin:0 0 8px 0;font-size:14px;color:rgba(251,250,244,0.5);font-style:italic;">With love,</p><p style="margin:0 0 24px 0;font-size:16px;color:#FF1493;">Your Fairy Godfather 🪄</p></td></tr></table></td></tr></table></body></html>`
  await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: 'Your Fairy Godfather <hello@yourfairygodfather.com>',
      to: [email],
      subject: `🎁 Your free month is applied — thank you for widening the circle`,
      html
    })
  })
}

Deno.serve(async (req) => {
  try {
    const url = new URL(req.url)
    let dryRun = url.searchParams.get('dryRun') === 'true'
    try {
      if (req.method === 'POST') {
        const body = await req.json().catch(() => ({}))
        if (body && body.dryRun === true) dryRun = true
      }
    } catch (_) { /* no body */ }

    const account = await stripeGet('/account')
    if (account.id !== EXPECTED_ACCOUNT) {
      return new Response(JSON.stringify({
        error: 'WRONG_STRIPE_ACCOUNT',
        message: `Refusing to run. STRIPE_SECRET_KEY is on ${account.id}, expected ${EXPECTED_ACCOUNT}.`,
        account_id: account.id
      }), { status: 403, headers: { 'Content-Type': 'application/json' } })
    }

    const results = {
      account_id: account.id,
      account_matches_yrtcyk: account.id === EXPECTED_ACCOUNT,
      dry_run: dryRun,
      phase_a_new_rewards_created: 0,
      phase_b_processed: 0,
      phase_b_credits_issued: 0,
      phase_b_skipped_no_customer: 0,
      phase_b_skipped_no_active_sub: 0,
      phase_b_resolved_by_id: 0,
      phase_b_resolved_by_email: 0,
      plan: [] as any[],
      skipped_operator: 0,
      errors: [] as string[]
    }

    const newRewardIds = new Set<string>()

    const { data: qualifying, error: qErr } = await supabase
      .from('referrals')
      .select(`id, referrer_id, referred_email, referred_member_id, status,
        members!referrals_referrer_id_fkey (id, email, display_name, is_operator),
        referred:members!referrals_referred_member_id_fkey (display_name)`)
      .eq('status', 'month_2')
      .is('rewarded_at', null)
    if (qErr) throw qErr

    for (const referral of qualifying || []) {
      try {
        const referrer = referral.members as any
        if (referrer?.is_operator) { results.skipped_operator++; continue }
        const couponCode = generateCouponCode(referrer.display_name || 'member')
        if (!dryRun) {
          const { data: ins, error: insErr } = await supabase.from('referral_rewards').insert({
            member_id: referral.referrer_id,
            referral_id: referral.id,
            reward_type: 'free_month',
            coupon_code: couponCode,
            applied: false
          }).select('id').single()
          if (insErr) throw insErr
          if (ins?.id) newRewardIds.add(ins.id)
          await supabase.from('referrals')
            .update({ status: 'rewarded', rewarded_at: new Date().toISOString(), coupon_code: couponCode })
            .eq('id', referral.id)
        }
        results.phase_a_new_rewards_created++
      } catch (err: any) {
        results.errors.push(`PhaseA referral ${referral.id}: ${err.message}`)
      }
    }

    const { data: pending, error: pErr } = await supabase
      .from('referral_rewards')
      .select(`id, member_id, referral_id, applied,
        earner:members!referral_rewards_member_id_fkey (email, display_name, is_operator, stripe_customer_id),
        referral:referrals!referral_rewards_referral_id_fkey (referred_email)`)
      .eq('applied', false)
    if (pErr) throw pErr

    for (const rw of pending || []) {
      results.phase_b_processed++
      try {
        const earner = (rw as any).earner
        const referredEmail = (rw as any).referral?.referred_email || 'a member'
        if (earner?.is_operator) { results.skipped_operator++; continue }
        const email = earner?.email
        if (!email) { results.errors.push(`PhaseB reward ${rw.id}: earner has no email`); continue }

        // ID-FIRST customer resolution
        let customerId: string | null = earner?.stripe_customer_id || null
        let resolvedBy = 'id'
        if (customerId) {
          try { await stripeGet(`/customers/${customerId}`) }
          catch (_) { customerId = null } // stale id -> fall back to email
        }
        if (!customerId) {
          const cust = await stripeGet(`/customers?email=${encodeURIComponent(email)}&limit=1`)
          const found = cust?.data?.[0]
          if (found) {
            customerId = found.id
            resolvedBy = 'email'
            if (!dryRun) { await supabase.from('members').update({ stripe_customer_id: customerId }).eq('id', rw.member_id) }
          }
        }
        if (!customerId) {
          results.phase_b_skipped_no_customer++
          results.plan.push({ reward_id: rw.id, earner_email: email, customer_id: null, amount_cents: -REWARD_AMOUNT_CENTS, action: 'SKIP_NO_CUSTOMER' })
          continue
        }
        if (resolvedBy === 'id') results.phase_b_resolved_by_id++; else results.phase_b_resolved_by_email++

        // GUARDRAIL: never credit a customer with no active/upcoming invoice
        if (!(await customerHasActiveSub(customerId))) {
          results.phase_b_skipped_no_active_sub++
          results.plan.push({ reward_id: rw.id, earner_email: email, customer_id: customerId, amount_cents: -REWARD_AMOUNT_CENTS, action: 'SKIP_NO_ACTIVE_SUB' })
          continue
        }

        if (dryRun) {
          results.plan.push({
            reward_id: rw.id, earner_email: email, customer_id: customerId,
            amount_cents: -REWARD_AMOUNT_CENTS, currency: 'usd',
            referred_email: referredEmail, resolved_by: resolvedBy, action: 'WOULD_CREDIT'
          })
          continue
        }

        const txn = await stripePostForm(
          `/customers/${customerId}/balance_transactions`,
          {
            amount: String(-REWARD_AMOUNT_CENTS),
            currency: 'usd',
            description: `YRTCYK Widen the Circle reward: one free month for referring ${referredEmail}`
          },
          `reward_${rw.id}`
        )

        await supabase.from('referral_rewards')
          .update({ applied: true, applied_at: new Date().toISOString(), stripe_balance_txn_id: txn.id })
          .eq('id', rw.id)

        results.phase_b_credits_issued++
        results.plan.push({ reward_id: rw.id, earner_email: email, customer_id: customerId, amount_cents: -REWARD_AMOUNT_CENTS, resolved_by: resolvedBy, action: 'CREDITED', txn_id: txn.id })

        if (newRewardIds.has(rw.id)) {
          try { await sendRewardEmail(email, earner.display_name || 'Friend', referredEmail) }
          catch (e: any) { results.errors.push(`PhaseB email reward ${rw.id}: ${e.message}`) }
        }
      } catch (err: any) {
        results.errors.push(`PhaseB reward ${rw.id}: ${err.message}`)
      }
    }

    return new Response(JSON.stringify(results), { status: 200, headers: { 'Content-Type': 'application/json' } })
  } catch (err: any) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500, headers: { 'Content-Type': 'application/json' } })
  }
})
