// Decommissioned Session 15 scaffolding (retired 2026-06-28). Read-only checkout verifier, no longer needed. Inert.
Deno.serve(() => new Response(JSON.stringify({ status: 'gone', note: 'Session 15 scaffolding retired. Safe to hard-delete from the Supabase dashboard.' }), { status: 410, headers: { 'Content-Type': 'application/json' } }))
