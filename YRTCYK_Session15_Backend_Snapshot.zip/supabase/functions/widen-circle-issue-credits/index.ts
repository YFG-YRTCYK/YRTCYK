// Decommissioned Session 15 scaffolding (retired 2026-06-28).
// Permanent paths now own this behavior: stripe-webhook auto-anchors new members;
// process-referral-rewards (v11+) issues referrer credits id-first. This slug is inert.
Deno.serve(() => new Response(JSON.stringify({ status: 'gone', note: 'Session 15 scaffolding retired. Safe to hard-delete from the Supabase dashboard.' }), { status: 410, headers: { 'Content-Type': 'application/json' } }))
