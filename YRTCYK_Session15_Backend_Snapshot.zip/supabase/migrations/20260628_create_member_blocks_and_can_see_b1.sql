-- B1 "Block" feature foundation (Session 15, June 28 2026)
-- Mutual, silent, blocker-controlled member blocking; admin (is_operator) exempt.

create table if not exists public.member_blocks (
  id uuid primary key default gen_random_uuid(),
  blocker_id uuid not null references public.members(id) on delete cascade,
  blocked_id uuid not null references public.members(id) on delete cascade,
  reason text,
  created_at timestamptz not null default now(),
  constraint member_blocks_no_self check (blocker_id <> blocked_id),
  constraint member_blocks_unique unique (blocker_id, blocked_id)
);

comment on table public.member_blocks is
  'B1 Block feature. One row per directional block (blocker_id blocks blocked_id). Enforcement via can_see() is MUTUAL: a block in either direction hides both members from each other. Silent (blocked party not notified). Admin (is_operator) is exempt both ways.';

create index if not exists member_blocks_blocker_idx on public.member_blocks(blocker_id);
create index if not exists member_blocks_blocked_idx on public.member_blocks(blocked_id);

alter table public.member_blocks enable row level security;

-- Members see only the blocks THEY created (silent for the blocked party); admin sees all.
create policy member_blocks_select on public.member_blocks for select
using (
  blocker_id in (select id from public.members where email = (auth.jwt() ->> 'email'))
  or exists (select 1 from public.members where email = (auth.jwt() ->> 'email') and is_operator)
);

-- A member may only create a block as themselves.
create policy member_blocks_insert on public.member_blocks for insert
with check (
  blocker_id in (select id from public.members where email = (auth.jwt() ->> 'email'))
);

-- A member may remove their own block (unblock); admin may remove any.
create policy member_blocks_delete on public.member_blocks for delete
using (
  blocker_id in (select id from public.members where email = (auth.jwt() ->> 'email'))
  or exists (select 1 from public.members where email = (auth.jwt() ->> 'email') and is_operator)
);

-- Visibility oracle. Returns false only when a block exists in EITHER direction
-- and neither party is the admin. Used by community-table RLS and the UI.
create or replace function public.can_see(viewer uuid, target uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select case
    when viewer is null or target is null then true
    when viewer = target then true
    when exists (select 1 from public.members m where m.id = viewer and m.is_operator) then true
    when exists (select 1 from public.members m where m.id = target and m.is_operator) then true
    when exists (
      select 1 from public.member_blocks b
      where (b.blocker_id = viewer and b.blocked_id = target)
         or (b.blocker_id = target and b.blocked_id = viewer)
    ) then false
    else true
  end
$$;

comment on function public.can_see(uuid, uuid) is
  'B1 Block feature visibility oracle. TRUE if viewer may see target. Mutual block enforcement; admin (is_operator) always sees and is always seen.';

grant execute on function public.can_see(uuid, uuid) to authenticated;
