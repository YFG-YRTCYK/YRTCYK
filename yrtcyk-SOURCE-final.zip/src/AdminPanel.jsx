import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function AdminPanel({ user, onClose }) {
  const [tab, setTab] = useState('members')
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(()=>{ loadAll() },[])

  async function loadAll() {
    const { data } = await supabase.from('members').select('*').order('created_at',{ascending:false})
    setMembers(data||[])
    setLoading(false)
  }

  async function toggleModerator(id, current) {
    await supabase.from('members').update({is_moderator:!current}).eq('id',id)
    loadAll()
  }
  async function toggleActive(id, current) {
    await supabase.from('members').update({is_active:!current}).eq('id',id)
    loadAll()
  }

  return (
    <div style={{paddingTop:20,paddingBottom:40}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:400}}>⚙️ Admin</h2>
        <button onClick={onClose} style={{color:'rgba(251,250,244,.5)',fontSize:13,fontFamily:'system-ui'}}>← Back</button>
      </div>
      <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',letterSpacing:1,marginBottom:16}}>MEMBER MANAGEMENT</p>
      {loading&&<div className="spinner"/>}
      {members.map(m=>(
        <div key={m.id} className="card" style={{marginBottom:10}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
            <div>
              <p style={{fontSize:14,fontWeight:500}}>{m.display_name||m.email.split('@')[0]}</p>
              <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'system-ui'}}>{m.email}</p>
            </div>
            <span style={{fontSize:10,fontFamily:'system-ui',padding:'2px 8px',borderRadius:20,background:m.is_active?'rgba(25,229,94,.12)':'rgba(255,255,255,.07)',color:m.is_active?'var(--lime)':'rgba(251,250,244,.4)',border:'1px solid '+(m.is_active?'rgba(25,229,94,.25)':'rgba(255,255,255,.1)')}}>
              {m.is_active?'Active':'Inactive'}
            </span>
          </div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <button onClick={()=>toggleActive(m.id,m.is_active)} style={{fontSize:11,fontFamily:'system-ui',padding:'5px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.12)',color:'rgba(251,250,244,.6)',cursor:'pointer'}}>
              {m.is_active?'Deactivate':'Activate'}
            </button>
            {m.email!==user.email&&<button onClick={()=>toggleModerator(m.id,m.is_moderator)} style={{fontSize:11,fontFamily:'system-ui',padding:'5px 10px',borderRadius:8,background:m.is_moderator?'rgba(25,229,94,.1)':'rgba(255,255,255,.07)',border:'1px solid '+(m.is_moderator?'rgba(25,229,94,.2)':'rgba(255,255,255,.1)'),color:m.is_moderator?'var(--lime)':'rgba(251,250,244,.5)',cursor:'pointer'}}>
              {m.is_moderator?'Remove Mod':'Make Mod'}
            </button>}
          </div>
        </div>
      ))}
    </div>
  )
}
