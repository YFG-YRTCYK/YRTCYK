import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function CommunityBlog({ user, isAdmin }) {
  const [view, setView] = useState('feed') // feed | write | post | moderate
  const [posts, setPosts] = useState([])
  const [pendingPosts, setPendingPosts] = useState([])
  const [selectedPost, setSelectedPost] = useState(null)
  const [comments, setComments] = useState([])
  const [loading, setLoading] = useState(true)
  const [title, setTitle] = useState('')
  const [body, setBody] = useState('')
  const [commentText, setCommentText] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [msg, setMsg] = useState('')
  const [member, setMember] = useState(null)

  useEffect(()=>{ init() },[])

  async function init() {
    const { data:m } = await supabase.from('members').select('id,is_moderator').eq('email',user.email).single()
    setMember(m)
    loadPosts()
  }

  async function loadPosts() {
    const { data } = await supabase.from('blog_posts').select('*,members(display_name,email)').eq('status','approved').order('created_at',{ascending:false})
    setPosts(data||[])
    if (isAdmin) {
      const { data:p } = await supabase.from('blog_posts').select('*,members(display_name,email)').eq('status','submitted').order('created_at',{ascending:false})
      setPendingPosts(p||[])
    }
    setLoading(false)
  }

  async function loadComments(postId) {
    const { data } = await supabase.from('blog_comments').select('*,members(display_name,email)').eq('post_id',postId).eq('status','approved').order('created_at')
    setComments(data||[])
  }

  async function submitPost() {
    if (!title.trim()||!body.trim()) { setMsg('Please add a title and body.'); return }
    setSubmitting(true)
    const { error } = await supabase.from('blog_posts').insert({ author_id:member?.id, title:title.trim(), body:body.trim(), status:'submitted' })
    setSubmitting(false)
    if (error) setMsg('Error: '+error.message)
    else { setMsg('Post submitted! It will appear once reviewed.'); setTitle(''); setBody('') }
  }

  async function submitComment() {
    if (!commentText.trim()) return
    setSubmitting(true)
    await supabase.from('blog_comments').insert({ post_id:selectedPost.id, author_id:member?.id, body:commentText.trim(), status:isAdmin?'approved':'submitted' })
    setCommentText('')
    setSubmitting(false)
    loadComments(selectedPost.id)
  }

  async function reviewPost(id, status) {
    await supabase.from('blog_posts').update({status,reviewed_at:new Date().toISOString()}).eq('id',id)
    loadPosts()
  }

  if (view==='post'&&selectedPost) return (
    <div style={{paddingTop:20}}>
      <button onClick={()=>{setView('feed');setSelectedPost(null);setComments([])}} style={{color:'rgba(251,250,244,.5)',fontSize:13,fontFamily:'system-ui',marginBottom:20}}>← Back to Blog</button>
      <div className="card" style={{marginBottom:16}}>
        <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',marginBottom:8}}>{selectedPost.members?.display_name||'A member'} · {new Date(selectedPost.created_at).toLocaleDateString('en-US',{month:'long',day:'numeric'})}</p>
        <h2 style={{fontSize:20,fontWeight:400,marginBottom:14}}>{selectedPost.title}</h2>
        <p style={{fontSize:14,lineHeight:1.85,color:'rgba(251,250,244,.8)',whiteSpace:'pre-wrap'}}>{selectedPost.body}</p>
      </div>
      <div style={{marginBottom:16}}>
        <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',letterSpacing:1,marginBottom:12}}>RESPONSES {comments.length>0&&`(${comments.length})`}</p>
        {comments.map(c=>(
          <div key={c.id} className="card" style={{marginBottom:10}}>
            <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'system-ui',marginBottom:6}}>{c.members?.display_name||'Member'}</p>
            <p style={{fontSize:13,lineHeight:1.7}}>{c.body}</p>
          </div>
        ))}
        <textarea rows={3} value={commentText} onChange={e=>setCommentText(e.target.value)} placeholder="Add your response…" style={{marginBottom:8}}/>
        <button className="btn-pink" style={{fontSize:13,padding:'8px 16px'}} onClick={submitComment} disabled={submitting||!commentText.trim()}>
          {submitting?'Sending…':isAdmin?'Post Response':'Submit Response'}
        </button>
        {!isAdmin&&<p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',marginTop:6}}>Responses are reviewed before appearing.</p>}
      </div>
    </div>
  )

  return (
    <div style={{paddingTop:20}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:400}}>Blog 📝</h2>
        <div style={{display:'flex',gap:8}}>
          {isAdmin&&<button onClick={()=>setView(view==='moderate'?'feed':'moderate')} style={{fontSize:12,fontFamily:'system-ui',padding:'6px 12px',borderRadius:8,background:view==='moderate'?'rgba(25,229,94,.15)':'rgba(255,255,255,.07)',border:'1px solid '+(view==='moderate'?'rgba(25,229,94,.3)':'rgba(255,255,255,.1)'),color:view==='moderate'?'var(--lime)':'rgba(251,250,244,.6)'}}>
            Moderate {pendingPosts.length>0&&`(${pendingPosts.length})`}
          </button>}
          <button onClick={()=>setView(view==='write'?'feed':'write')} className="btn-pink" style={{fontSize:12,padding:'6px 12px'}}>+ Write</button>
        </div>
      </div>

      {view==='write'&&(
        <div className="card" style={{marginBottom:20}}>
          <p style={{fontSize:15,fontWeight:500,marginBottom:4}}>Share Your Story</p>
          <p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'system-ui',marginBottom:16,lineHeight:1.6}}>All posts are reviewed before publishing. This is a safe space.</p>
          <input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Title" style={{marginBottom:10}}/>
          <textarea rows={8} value={body} onChange={e=>setBody(e.target.value)} placeholder="Write your story…" style={{resize:'vertical',marginBottom:10}}/>
          {msg&&<p style={{fontSize:13,fontFamily:'system-ui',color:msg.startsWith('Error')?'var(--pink)':'var(--lime)',marginBottom:10}}>{msg}</p>}
          <button className="btn-pink" style={{width:'100%'}} onClick={submitPost} disabled={submitting}>{submitting?'Submitting…':'Submit Post'}</button>
        </div>
      )}

      {view==='moderate'&&isAdmin&&(
        <div style={{marginBottom:20}}>
          <p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'system-ui',marginBottom:14}}>{pendingPosts.length} post{pendingPosts.length!==1?'s':''} pending review</p>
          {pendingPosts.length===0&&<p style={{color:'rgba(251,250,244,.3)',fontFamily:'system-ui',fontSize:14,textAlign:'center',padding:20}}>All caught up! ✓</p>}
          {pendingPosts.map(p=>(
            <div key={p.id} className="card" style={{marginBottom:12}}>
              <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',marginBottom:4}}>{p.members?.display_name||'Member'} · {new Date(p.created_at).toLocaleDateString()}</p>
              <p style={{fontSize:15,fontWeight:500,marginBottom:6}}>{p.title}</p>
              <p style={{fontSize:13,color:'rgba(251,250,244,.6)',marginBottom:12,lineHeight:1.6}}>{p.body.slice(0,200)}…</p>
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>reviewPost(p.id,'approved')} style={{flex:1,padding:'8px',borderRadius:8,background:'rgba(25,229,94,.12)',border:'1px solid rgba(25,229,94,.25)',color:'var(--lime)',fontFamily:'system-ui',fontSize:13,cursor:'pointer'}}>✓ Approve</button>
                <button onClick={()=>reviewPost(p.id,'rejected')} style={{flex:1,padding:'8px',borderRadius:8,background:'rgba(255,20,147,.08)',border:'1px solid rgba(255,20,147,.18)',color:'var(--pink)',fontFamily:'system-ui',fontSize:13,cursor:'pointer'}}>✕ Reject</button>
              </div>
            </div>
          ))}
        </div>
      )}

      {loading&&<div className="spinner"/>}
      {!loading&&posts.length===0&&view==='feed'&&(
        <div className="card" style={{textAlign:'center',padding:40}}>
          <p style={{fontSize:32,marginBottom:12}}>📝</p>
          <p style={{color:'rgba(251,250,244,.4)',fontFamily:'system-ui',fontSize:14,lineHeight:1.6}}>No posts yet.<br/>Be the first to share your story.</p>
        </div>
      )}
      {view==='feed'&&posts.map(p=>(
        <div key={p.id} onClick={()=>{setSelectedPost(p);loadComments(p.id);setView('post')}} className="card" style={{marginBottom:14,cursor:'pointer'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',marginBottom:6}}>{p.members?.display_name||'A member'} · {new Date(p.created_at).toLocaleDateString('en-US',{month:'long',day:'numeric'})}</p>
          <h3 style={{fontSize:17,fontWeight:500,marginBottom:8,lineHeight:1.4}}>{p.title}</h3>
          <p style={{fontSize:13,color:'rgba(251,250,244,.6)',lineHeight:1.7}}>{p.body.slice(0,180)}{p.body.length>180?'…':''}</p>
          <p style={{fontSize:12,color:'var(--pink)',fontFamily:'system-ui',marginTop:10}}>Read more →</p>
        </div>
      ))}
    </div>
  )
}
