import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

// v18 exact schema: hero_showcases table
// Fields: member_id, hero_type, hero_name, tagline, answers(json),
//         visibility, social_links(json), photos(array), thumbnail_index,
//         member_display_name, status, admin_notes, resubmission_count

const HERO_QUESTIONS = {
  person: [
    { key:'who',     label:'Who are they?',                              hint:'First name or "my sponsor" — you protect their privacy' },
    { key:'met',     label:'How did you meet or come to know them?' },
    { key:'changed', label:'What did they do or say that changed everything?' },
    { key:'without', label:'What would your recovery look like without them?' },
    { key:'world',   label:'What do you want the world to know about them?' },
  ],
  place: [
    { key:'what',     label:'What is this place?' },
    { key:'when',     label:'When did you first go there?' },
    { key:'happened', label:'What happened there that mattered?' },
    { key:'feels',    label:'What does this place feel like when you\'re there?' },
    { key:'why',      label:'Why does it deserve to be someone\'s Hero?' },
  ],
  thing: [
    { key:'what',    label:'What is it?',                                 hint:'A book, a meeting, a piece of music, an object — anything' },
    { key:'when',    label:'When did it come into your life?' },
    { key:'changed', label:'How did it change you?' },
    { key:'say',     label:'What would you say to someone who hasn\'t discovered it yet?' },
    { key:'why',     label:'Why does it deserve a place in someone\'s recovery?' },
  ],
}

const TYPE_ICONS  = { person:'👤', place:'📍', thing:'✨' }
const TYPE_LABELS = { person:'Person', place:'Place', thing:'Thing' }

export default function HeroGallery({ user, isAdmin }) {
  const [view, setView]       = useState('gallery') // gallery | submit | detail | admin
  const [heroes, setHeroes]   = useState([])
  const [pending, setPending] = useState([])
  const [myHeroes, setMyHeroes] = useState([])
  const [selected, setSelected] = useState(null)
  const [loading, setLoading]   = useState(true)
  const [member, setMember]     = useState(null)

  // Submit form state
  const [step, setStep]         = useState(0) // 0=type, 1=name, 2=story, 3=photos, 4=visibility
  const [heroType, setHeroType] = useState('')
  const [heroName, setHeroName] = useState('')
  const [tagline, setTagline]   = useState('')
  const [answers, setAnswers]   = useState({})
  const [photos, setPhotos]     = useState([])
  const [thumbnailIdx, setThumbIdx] = useState(0)
  const [visibility, setVisibility] = useState('members')
  const [submitting, setSubmitting] = useState(false)
  const [submitMsg, setSubmitMsg]   = useState('')
  const [youtube, setYoutube]       = useState('')
  const [instagram, setInstagram]   = useState('')
  const [facebook, setFacebook]     = useState('')
  const [dragPhoto, setDragPhoto]   = useState(false)

  // Admin state
  const [adminNotes, setAdminNotes] = useState({})
  const [reviewing, setReviewing]   = useState({})
  const [typeFilter, setTypeFilter] = useState('all')

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    const { data: m } = await supabase.from('members').select('id, display_name, email').eq('email', user.email).single()
    if (m) setMember(m)

    const { data: approved } = await supabase
      .from('hero_showcases')
      .select('*, members:member_id(display_name, email)')
      .eq('status', 'approved')
      .order('created_at', { ascending: false })
    setHeroes(approved || [])

    if (m) {
      const { data: mine } = await supabase
        .from('hero_showcases')
        .select('*')
        .eq('member_id', m.id)
        .order('created_at', { ascending: false })
      setMyHeroes(mine || [])
    }

    if (isAdmin) {
      const { data: pend } = await supabase
        .from('hero_showcases')
        .select('*, members:member_id(display_name, email)')
        .eq('status', 'submitted')
        .order('created_at', { ascending: false })
      setPending(pend || [])
    }
    setLoading(false)
  }

  async function adminReview(id, status) {
    setReviewing(p => ({ ...p, [id]: true }))
    await supabase.from('hero_showcases').update({
      status,
      admin_notes: adminNotes[id] || null,
      reviewed_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    }).eq('id', id)
    setReviewing(p => ({ ...p, [id]: false }))
    loadAll()
  }

  async function uploadPhoto(file) {
    if (!member) return null
    const ext = file.name.split('.').pop()
    const path = `${member.id}/${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`
    const { error } = await supabase.storage.from('hero-photos').upload(path, file, { upsert: false })
    if (error) { console.error(error); return null }
    const { data: { publicUrl } } = supabase.storage.from('hero-photos').getPublicUrl(path)
    return publicUrl
  }

  async function handlePhotoFiles(e) {
    const files = Array.from(e.target.files || []).slice(0, 5 - photos.length)
    if (!files.length) return
    const urls = []
    for (const f of files) {
      const url = await uploadPhoto(f)
      if (url) urls.push(url)
    }
    setPhotos(p => [...p, ...urls])
    e.target.value = ''
  }

  async function submitHero() {
    if (!member || !heroType || !heroName.trim()) return
    setSubmitting(true)
    try {
      const { error } = await supabase.from('hero_showcases').insert({
        member_id: member.id,
        hero_type: heroType,
        hero_name: heroName.trim(),
        tagline: tagline.trim(),
        answers,
        visibility,
        social_links: { youtube: youtube||undefined, instagram: instagram||undefined, facebook: facebook||undefined },
        photos,
        thumbnail_index: thumbnailIdx,
        member_display_name: member.display_name || 'A Member',
        status: 'submitted',
        resubmission_count: 0,
      })
      if (error) throw error
      setSubmitMsg('Your Hero has been submitted! We review each one with care.')
      setView('gallery')
      setStep(0); setHeroType(''); setHeroName(''); setTagline(''); setAnswers({}); setPhotos([]); setVisibility('members')
      setYoutube(''); setInstagram(''); setFacebook('')
      loadAll()
    } catch (e) {
      setSubmitMsg('Error: ' + e.message)
    }
    setSubmitting(false)
  }

  // ── DETAIL VIEW ──
  if (selected) {
    const h = selected
    const questions = HERO_QUESTIONS[h.hero_type] || []
    const thumb = h.photos?.[h.thumbnail_index] || h.photos?.[0]
    return (
      <div style={{ paddingTop:20, paddingBottom:40 }}>
        <button onClick={() => setSelected(null)} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:20 }}>← Back to Heroes</button>

        {thumb && <img src={thumb} alt="" style={{ width:'100%', height:260, objectFit:'cover', objectPosition:'center center', borderRadius:10, marginBottom:20 }}/>}

        <div className="card" style={{ marginBottom:16, background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.1)' }}>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
            <span style={{ fontSize:20 }}>{TYPE_ICONS[h.hero_type]||'🌟'}</span>
            <span style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1 }}>{(TYPE_LABELS[h.hero_type]||'HERO').toUpperCase()}</span>
          </div>
          <h2 style={{ fontSize:22, fontWeight:400, marginBottom:6 }}>{h.hero_name}</h2>
          {h.tagline && <p style={{ fontSize:14, color:'rgba(251,250,244,.6)', fontStyle:'italic', lineHeight:1.65 }}>"{h.tagline}"</p>}
          <p style={{ fontSize:12, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', marginTop:8 }}>
            Honored by {h.member_display_name || h.members?.display_name || 'A Member'}
          </p>
        </div>

        {/* Social links */}
        {(h.social_links?.youtube || h.social_links?.instagram || h.social_links?.facebook) && (
          <div style={{ display:'flex', gap:10, marginBottom:16, flexWrap:'wrap' }}>
            {h.social_links.youtube && (
              <a href={h.social_links.youtube} target="_blank" rel="noopener noreferrer"
                style={{ padding:'8px 14px', borderRadius:8, background:'rgba(255,0,0,.12)', border:'1px solid rgba(255,0,0,.2)', color:'#ff4444', fontSize:13, fontFamily:'var(--font-ui)' }}>
                ▶ YouTube
              </a>
            )}
            {h.social_links.instagram && (
              <a href={h.social_links.instagram} target="_blank" rel="noopener noreferrer"
                style={{ padding:'8px 14px', borderRadius:8, background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontSize:13, fontFamily:'var(--font-ui)' }}>
                📷 Instagram
              </a>
            )}
            {h.social_links.facebook && (
              <a href={h.social_links.facebook} target="_blank" rel="noopener noreferrer"
                style={{ padding:'8px 14px', borderRadius:8, background:'rgba(66,103,178,.15)', border:'1px solid rgba(66,103,178,.3)', color:'#6b8cce', fontSize:13, fontFamily:'var(--font-ui)' }}>
                Facebook
              </a>
            )}
          </div>
        )}

        {/* Photo grid */}
        {h.photos?.length > 1 && (
          <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:6, marginBottom:16 }}>
            {h.photos.map((url, i) => (
              <img key={i} src={url} alt="" style={{ width:'100%', aspectRatio:'1', objectFit:'cover', borderRadius:6, border: i === h.thumbnail_index ? '2px solid var(--pink)' : '2px solid transparent' }}/>
            ))}
          </div>
        )}

        {/* Answers */}
        {questions.map(q => {
          const ans = h.answers?.[q.key]
          if (!ans) return null
          return (
            <div key={q.key} className="card" style={{ marginBottom:12 }}>
              <p style={{ fontSize:11, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom:8 }}>{q.label}</p>
              <p style={{ fontSize:14, lineHeight:1.85, color:'rgba(251,250,244,.85)', whiteSpace:'pre-wrap' }}>{ans}</p>
            </div>
          )
        })}
      </div>
    )
  }

  // ── ADMIN REVIEW VIEW ──
  if (view === 'admin' && isAdmin) return (
    <div style={{ paddingTop:20, paddingBottom:40 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>⚙️ Review Queue</h2>
        <button onClick={() => setView('gallery')} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)' }}>← Gallery</button>
      </div>
      {pending.length === 0 && <p style={{ color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', textAlign:'center', padding:30 }}>All caught up! ✓</p>}
      {pending.map(h => (
        <div key={h.id} className="card" style={{ marginBottom:16 }}>
          <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
            <span style={{ fontSize:16 }}>{TYPE_ICONS[h.hero_type]||'🌟'}</span>
            <span style={{ fontSize:15, fontWeight:500 }}>{h.hero_name}</span>
            <span style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>by {h.member_display_name || h.members?.display_name}</span>
          </div>
          {h.tagline && <p style={{ fontSize:13, color:'rgba(251,250,244,.6)', fontStyle:'italic', marginBottom:8 }}>"{h.tagline}"</p>}
          {h.photos?.[0] && <img src={h.photos[h.thumbnail_index||0]} alt="" style={{ width:'100%', maxHeight:160, objectFit:'cover', borderRadius:6, marginBottom:8 }}/>}
          {Object.entries(HERO_QUESTIONS[h.hero_type]||[]).slice(0,2).map(([, q]) =>
            h.answers?.[q.key] ? (
              <div key={q.key} style={{ marginBottom:8 }}>
                <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:3 }}>{q.label}</p>
                <p style={{ fontSize:13, color:'rgba(251,250,244,.7)', lineHeight:1.6 }}>{h.answers[q.key].slice(0,200)}{h.answers[q.key].length > 200 ? '…' : ''}</p>
              </div>
            ) : null
          )}
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginTop:10, marginBottom:6 }}>NOTES FOR MEMBER (required for Return/Deny)</p>
          <textarea rows={2} value={adminNotes[h.id]||''} onChange={e => setAdminNotes(p => ({ ...p, [h.id]: e.target.value }))}
            placeholder="Optional note to member…" style={{ resize:'none', marginBottom:10 }}/>
          <div style={{ display:'flex', gap:8 }}>
            <button onClick={() => adminReview(h.id, 'approved')} disabled={reviewing[h.id]}
              style={{ flex:1, padding:'9px', borderRadius:8, background:'rgba(25,229,94,.12)', border:'1px solid rgba(25,229,94,.25)', color:'var(--lime)', fontFamily:'var(--font-ui)', fontSize:13, cursor:'pointer' }}>
              ✓ Approve
            </button>
            <button onClick={() => adminReview(h.id, 'denied')} disabled={reviewing[h.id] || !adminNotes[h.id]?.trim()}
              style={{ flex:1, padding:'9px', borderRadius:8, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.18)', color:'var(--pink)', fontFamily:'var(--font-ui)', fontSize:13, cursor:'pointer' }}>
              🚫 Deny
            </button>
            <button onClick={() => adminReview(h.id, 'returned')} disabled={reviewing[h.id] || !adminNotes[h.id]?.trim()}
              style={{ flex:1, padding:'9px', borderRadius:8, background:'rgba(255,255,255,.06)', border:'1px solid var(--border)', color:'rgba(251,250,244,.6)', fontFamily:'var(--font-ui)', fontSize:13, cursor:'pointer' }}>
              ↩ Return
            </button>
          </div>
        </div>
      ))}
    </div>
  )

  // ── SUBMIT VIEW ──
  if (view === 'submit') {
    const questions = HERO_QUESTIONS[heroType] || []
    return (
      <div style={{ paddingTop:20, paddingBottom:40 }}>
        <button onClick={() => { setView('gallery'); setStep(0) }} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:16 }}>← Back</button>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', marginBottom:4 }}>
          <h2 style={{ fontSize:20, fontWeight:400 }}>Submit a Hero</h2>
          <span style={{ fontSize:11, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.35)' }}>3 per month</span>
        </div>
        <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:20 }}>Step {step+1} of 4</p>

        {/* Step 0: Choose type */}
        {step === 0 && <>
          <p style={{ fontSize:15, marginBottom:20 }}>What kind of Hero is this?</p>
          {(['person','place','thing']).map(t => (
            <button key={t} onClick={() => { setHeroType(t); setStep(1) }}
              style={{ display:'flex', gap:12, alignItems:'center', width:'100%', padding:'16px', borderRadius:10, background: heroType===t ? 'rgba(255,20,147,.12)' : 'rgba(255,255,255,.05)', border:`1px solid ${heroType===t ? 'rgba(255,20,147,.3)' : 'var(--border)'}`, color:'var(--cream)', cursor:'pointer', marginBottom:10, textAlign:'left' }}>
              <span style={{ fontSize:24 }}>{TYPE_ICONS[t]}</span>
              <div>
                <div style={{ fontSize:14, fontWeight:600, fontFamily:'var(--font-ui)' }}>{TYPE_LABELS[t]}</div>
                <div style={{ fontSize:12, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginTop:2 }}>
                  {t==='person' ? 'Someone who changed your life' : t==='place' ? 'A place that holds meaning in your recovery' : 'A book, meeting, song, or object'}
                </div>
              </div>
            </button>
          ))}
        </>}

        {/* Step 1: Name & tagline */}
        {step === 1 && <>
          <p style={{ fontSize:15, marginBottom:20 }}>Name your Hero</p>
          <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:6 }}>
            Give them a title and a one-line description.
          </p>
          <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6, marginTop:14 }}>NAME</p>
          <input value={heroName} onChange={e => setHeroName(e.target.value)} placeholder={heroType==='person'?'First name or nickname…':heroType==='place'?'What is this place called?':'What is it called?'} style={{ marginBottom:12 }}/>
          <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6 }}>ONE-LINE TAGLINE</p>
          <input value={tagline} onChange={e => setTagline(e.target.value)} placeholder="The one sentence that captures why this changed your life." style={{ marginBottom:20 }}/>
          <div style={{ display:'flex', gap:10 }}>
            <button onClick={() => setStep(0)} style={{ flex:1 }} className="btn-secondary">← Back</button>
            <button onClick={() => setStep(2)} className="btn-primary" style={{ flex:2 }} disabled={!heroName.trim()}>Continue →</button>
          </div>
        </>}

        {/* Step 2: Story questions */}
        {step === 2 && <>
          <p style={{ fontSize:15, marginBottom:4 }}>Tell their story</p>
          <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:20 }}>Answer honestly. This is the showcase.</p>
          {questions.map(q => (
            <div key={q.key} style={{ marginBottom:14 }}>
              <p style={{ fontSize:13, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.8)', marginBottom:q.hint?4:6 }}>{q.label}</p>
              {q.hint && <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:6, fontStyle:'italic' }}>{q.hint}</p>}
              <textarea rows={3} value={answers[q.key]||''} onChange={e => setAnswers(p => ({ ...p, [q.key]: e.target.value }))} style={{ resize:'vertical' }}/>
            </div>
          ))}
          <div style={{ display:'flex', gap:10, marginTop:8 }}>
            <button onClick={() => setStep(1)} style={{ flex:1 }} className="btn-secondary">← Back</button>
            <button onClick={() => setStep(3)} className="btn-primary" style={{ flex:2 }}>Continue →</button>
          </div>
        </>}

        {/* Step 3: Photos */}
        {step === 3 && <>
          <p style={{ fontSize:15, marginBottom:4 }}>Add photos <span style={{ fontSize:13, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>(optional, up to 5)</span></p>
          <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:16 }}>A photo of them, their book cover, a place — whatever feels right.</p>
          {photos.length > 0 && (
            <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:6, marginBottom:12 }}>
              {photos.map((url, i) => (
                <div key={i} style={{ position:'relative', aspectRatio:'1' }}>
                  <img src={url} alt="" style={{ width:'100%', height:'100%', objectFit:'cover', borderRadius:6, border: i===thumbnailIdx ? '2px solid var(--pink)' : '2px solid transparent', cursor:'pointer' }} onClick={() => setThumbIdx(i)}/>
                  <button onClick={() => { const p=photos.filter((_,j)=>j!==i); setPhotos(p); if(thumbnailIdx>=p.length) setThumbIdx(0) }}
                    style={{ position:'absolute', top:4, right:4, width:20, height:20, borderRadius:'50%', background:'rgba(0,0,0,.6)', color:'#fff', fontSize:10, display:'flex', alignItems:'center', justifyContent:'center', cursor:'pointer', border:'none' }}>✕</button>
                  {i===thumbnailIdx && <div style={{ position:'absolute', bottom:4, left:4, fontSize:9, background:'var(--pink)', color:'#fff', padding:'1px 5px', borderRadius:4, fontFamily:'var(--font-ui)' }}>COVER</div>}
                </div>
              ))}
            </div>
          )}
          {photos.length < 5 && (
            <label
              style={{ display:'block', padding:'20px', borderRadius:8, border:`2px dashed ${dragPhoto ? 'var(--lime)' : 'rgba(255,255,255,.2)'}`, textAlign:'center', cursor:'pointer', marginBottom:16, background: dragPhoto ? 'rgba(25,229,94,.05)' : 'transparent', transition:'all .2s', transform: dragPhoto ? 'scale(1.02)' : 'scale(1)' }}
              onDragOver={e => { e.preventDefault(); e.stopPropagation(); setDragPhoto(true) }}
              onDragEnter={e => { e.preventDefault(); e.stopPropagation(); setDragPhoto(true) }}
              onDragLeave={e => { e.preventDefault(); e.stopPropagation(); setDragPhoto(false) }}
              onDrop={e => {
                e.preventDefault(); e.stopPropagation(); setDragPhoto(false)
                const files = Array.from(e.dataTransfer.files).filter(f => f.type.startsWith('image/'))
                if (files.length) handlePhotoFiles({ target: { files } })
              }}
            >
              <span style={{ fontSize:13, fontFamily:'var(--font-ui)', color: dragPhoto ? 'var(--lime)' : 'rgba(251,250,244,.5)' }}>
                {dragPhoto ? '✅ Drop photos now!' : `+ Add Photos (${5 - photos.length} remaining) · tap or drag & drop`}
              </span>
              <input type="file" accept="image/*" multiple style={{ display:'none' }} onChange={handlePhotoFiles}/>
            </label>
          )}

          {/* Social links */}
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10, marginTop:8 }}>SOCIAL LINKS <span style={{ color:'rgba(251,250,244,.2)' }}>(optional)</span></p>
          <div style={{ marginBottom:8 }}>
            <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginBottom:5 }}>▶ YouTube Link</p>
            <input value={youtube} onChange={e=>setYoutube(e.target.value)} placeholder="https://youtube.com/watch?v=…" type="url"/>
          </div>
          <div style={{ marginBottom:8 }}>
            <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginBottom:5 }}>📷 Instagram Link</p>
            <input value={instagram} onChange={e=>setInstagram(e.target.value)} placeholder="https://instagram.com/…" type="url"/>
          </div>
          <div style={{ marginBottom:16 }}>
            <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginBottom:5 }}>Facebook Link</p>
            <input value={facebook} onChange={e=>setFacebook(e.target.value)} placeholder="https://facebook.com/…" type="url"/>
          </div>
          <div style={{ display:'flex', gap:10 }}>
            <button onClick={() => setStep(2)} style={{ flex:1 }} className="btn-secondary">← Back</button>
            <button onClick={() => setStep(4)} className="btn-primary" style={{ flex:2 }}>Continue →</button>
          </div>
        </>}

        {/* Step 4: Visibility + Submit */}
        {step === 4 && <>
          <p style={{ fontSize:15, marginBottom:16 }}>Who can see this?</p>
          {[
            { val:'members', icon:'👥', label:'YRTCYK Members Only', desc:'Only members who are signed in can see this showcase.' },
            { val:'public',  icon:'🌍', label:'Public',              desc:'Anyone with the link can see this showcase.' },
          ].map(opt => (
            <button key={opt.val} onClick={() => setVisibility(opt.val)}
              style={{ display:'flex', gap:12, alignItems:'flex-start', width:'100%', padding:'14px', borderRadius:10, background: visibility===opt.val ? 'rgba(255,20,147,.1)' : 'rgba(255,255,255,.04)', border:`1px solid ${visibility===opt.val ? 'rgba(255,20,147,.3)' : 'var(--border)'}`, color:'var(--cream)', cursor:'pointer', marginBottom:10, textAlign:'left' }}>
              <span style={{ fontSize:20, flexShrink:0 }}>{opt.icon}</span>
              <div>
                <div style={{ fontSize:14, fontWeight:600, fontFamily:'var(--font-ui)', marginBottom:3 }}>{opt.label}</div>
                <div style={{ fontSize:12, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)' }}>{opt.desc}</div>
              </div>
            </button>
          ))}
          {submitMsg && <p style={{ fontSize:13, fontFamily:'var(--font-ui)', color:submitMsg.startsWith('Error')?'var(--pink)':'var(--lime)', marginBottom:10 }}>{submitMsg}</p>}
          <div style={{ display:'flex', gap:10, marginTop:8 }}>
            <button onClick={() => setStep(3)} style={{ flex:1 }} className="btn-secondary">← Back</button>
            <button onClick={submitHero} className="btn-primary" style={{ flex:2 }} disabled={submitting}>
              {submitting ? 'Submitting…' : 'Submit My Hero'}
            </button>
          </div>
        </>}
      </div>
    )
  }

  // ── GALLERY VIEW ──
  const filteredHeroes = typeFilter === 'all' ? heroes : heroes.filter(h => h.hero_type === typeFilter)

  return (
    <div style={{ paddingTop:20, paddingBottom:40 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>Heroes 🌟</h2>
        <div style={{ display:'flex', gap:8 }}>
          {isAdmin && (
            <button onClick={() => setView('admin')}
              style={{ fontSize:12, fontFamily:'var(--font-ui)', padding:'7px 12px', borderRadius:8, background: pending.length > 0 ? 'rgba(255,20,147,.12)' : 'rgba(255,255,255,.07)', border:`1px solid ${pending.length > 0 ? 'rgba(255,20,147,.25)' : 'var(--border)'}`, color: pending.length > 0 ? 'var(--pink)' : 'rgba(251,250,244,.55)', cursor:'pointer' }}>
              Review {pending.length > 0 ? `(${pending.length})` : ''}
            </button>
          )}
          <button onClick={() => setView('submit')} className="btn-primary" style={{ fontSize:12, padding:'7px 14px' }}>
            + Submit a Hero
          </button>
        </div>
      </div>

      {/* Type filter tabs */}
      <div style={{ display:'flex', gap:6, marginBottom:20, overflowX:'auto' }}>
        {[['all','All'],['person','👤 Persons'],['place','📍 Places'],['thing','✨ Things']].map(([val, label]) => (
          <button key={val} onClick={() => setTypeFilter(val)}
            style={{ padding:'6px 14px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:12, whiteSpace:'nowrap', cursor:'pointer',
              background: typeFilter===val ? 'var(--pink)' : 'rgba(255,255,255,.07)',
              color: typeFilter===val ? '#fff' : 'rgba(251,250,244,.55)',
              border: `1px solid ${typeFilter===val ? 'var(--pink)' : 'rgba(255,255,255,.1)'}` }}>
            {label}
          </button>
        ))}
      </div>

      {loading && <div className="spinner"/>}

      {!loading && filteredHeroes.length === 0 && (
        <div className="card" style={{ textAlign:'center', padding:40 }}>
          <p style={{ fontSize:36, marginBottom:12 }}>🌟</p>
          <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14, lineHeight:1.7 }}>No Heroes yet.<br/>Be the first to honor someone who changed your life.</p>
        </div>
      )}

      <div style={{ display:'flex', flexDirection:'column', gap:12 }}>
        {filteredHeroes.map(h => {
          const thumb = h.photos?.[h.thumbnail_index] || h.photos?.[0]
          const firstAnswer = h.answers ? Object.values(h.answers).find(v => v?.trim()) : null
          return (
            <div key={h.id} onClick={() => setSelected(h)} className="card" style={{ cursor:'pointer', overflow:'hidden', padding:0 }}>
              {thumb && (
                <div style={{ width:'100%', height:160, overflow:'hidden', background:'rgba(255,255,255,.05)' }}>
                  <img src={thumb} alt="" style={{ width:'100%', height:'100%', objectFit:'cover', objectPosition:'center center' }}/>
                </div>
              )}
              <div style={{ padding:'14px 16px' }}>
                <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:4 }}>
                  <span style={{ fontSize:14 }}>{TYPE_ICONS[h.hero_type]||'🌟'}</span>
                  <span style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:.5, textTransform:'uppercase' }}>A {TYPE_LABELS[h.hero_type]||'Hero'}</span>
                </div>
                <h3 style={{ fontSize:17, fontWeight:500, marginBottom:4 }}>{h.hero_name}</h3>
                {h.tagline && <p style={{ fontSize:13, color:'rgba(251,250,244,.6)', fontStyle:'italic', marginBottom:6 }}>"{h.tagline}"</p>}
                {firstAnswer && !h.tagline && <p style={{ fontSize:13, color:'rgba(251,250,244,.55)', lineHeight:1.6 }}>{firstAnswer.slice(0,120)}…</p>}
                <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', marginTop:8 }}>Honored by {h.member_display_name || h.members?.display_name || 'A Member'}</p>
              </div>
            </div>
          )
        })}
      </div>

      {/* My submissions */}
      {myHeroes.filter(h => h.status !== 'approved').length > 0 && (
        <div style={{ marginTop:28 }}>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.5, marginBottom:12 }}>MY SUBMISSIONS</p>
          {myHeroes.filter(h => h.status !== 'approved').map(h => (
            <div key={h.id} className="card" style={{ marginBottom:10, display:'flex', justifyContent:'space-between', alignItems:'center' }}>
              <div>
                <p style={{ fontSize:14, fontWeight:500 }}>{h.hero_name}</p>
                <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginTop:2 }}>
                  {new Date(h.created_at).toLocaleDateString()}
                </p>
              </div>
              <span style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'3px 10px', borderRadius:20,
                background: h.status==='returned' ? 'rgba(255,165,0,.12)' : h.status==='denied' ? 'rgba(255,20,147,.1)' : 'rgba(255,255,255,.07)',
                color: h.status==='returned' ? '#FFA500' : h.status==='denied' ? 'var(--pink)' : 'rgba(251,250,244,.45)',
                border: `1px solid ${h.status==='returned' ? 'rgba(255,165,0,.25)' : h.status==='denied' ? 'rgba(255,20,147,.2)' : 'var(--border)'}`
              }}>
                {h.status === 'submitted' ? '⏳ Under Review' : h.status === 'returned' ? '↩ Returned' : '🚫 Denied'}
              </span>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
