import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function CommunityCalendar({ user }) {
  const [events, setEvents] = useState([])
  const [weekOffset, setWeekOffset] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(()=>{ loadEvents() },[weekOffset])

  async function loadEvents() {
    setLoading(true)
    const today = new Date(); today.setHours(0,0,0,0)
    const weekStart = new Date(today); weekStart.setDate(today.getDate() - today.getDay() + weekOffset*7)
    const weekEnd = new Date(weekStart); weekEnd.setDate(weekStart.getDate()+6)

    const { data:members } = await supabase
      .from('members')
      .select('id,display_name,email,birth_date,show_birthday,show_birth_year,program_1,program_1_date,program_2,program_2_date,program_3,program_3_date,cal_sobriety_program,show_sobriety_years')
      .or('is_active.eq.true,is_active.is.null')

    const evts = []
    if (members) {
      for (const m of members) {
        const name = m.display_name || m.email.split('@')[0]
        const year = weekStart.getFullYear()

        if (m.birth_date && m.show_birthday) {
          const bd = new Date(m.birth_date+'T00:00:00')
          const bday = new Date(year, bd.getMonth(), bd.getDate())
          if (bday >= weekStart && bday <= weekEnd)
            evts.push({ date:bday, type:'birthday', label:`${name}'s Birthday 🎂`, sub:'Happy Birthday!' })
          // also check next year if near year end
          const bdayNext = new Date(year+1, bd.getMonth(), bd.getDate())
          if (bdayNext >= weekStart && bdayNext <= weekEnd)
            evts.push({ date:bdayNext, type:'birthday', label:`${name}'s Birthday 🎂`, sub:'Happy Birthday!' })
        }

        // cal_sobriety_program is "1", "2", or "3" — which program to show on calendar
        if (m.cal_sobriety_program) {
          const n = m.cal_sobriety_program
          const sd = m[`program_${n}_date`]
          const prog = m[`program_${n}`]
          if (sd) {
            const s = new Date(sd+'T00:00:00')
            const anniv = new Date(year, s.getMonth(), s.getDate())
            if (anniv >= weekStart && anniv <= weekEnd) {
              const years = year - s.getFullYear()
              const sub = m.show_sobriety_years ? `${years} year${years!==1?'s':''} sober` : (prog||'Sobriety') + ' Anniversary'
              evts.push({ date:anniv, type:'anniversary', label:`${name}'s ${prog||'Sobriety'} Anniversary 🏅`, sub })
            }
            // check next year too
            const annivNext = new Date(year+1, s.getMonth(), s.getDate())
            if (annivNext >= weekStart && annivNext <= weekEnd) {
              const years = year+1 - s.getFullYear()
              const sub = m.show_sobriety_years ? `${years} year${years!==1?'s':''} sober` : (prog||'Sobriety') + ' Anniversary'
              evts.push({ date:annivNext, type:'anniversary', label:`${name}'s ${prog||'Sobriety'} Anniversary 🏅`, sub })
            }
          }
        }
      }
    }

    evts.sort((a,b)=>a.date-b.date)
    setEvents(evts)
    setLoading(false)
  }

  const today = new Date(); today.setHours(0,0,0,0)
  const weekStart = new Date(today); weekStart.setDate(today.getDate() - today.getDay() + weekOffset*7)
  const days = Array.from({length:7},(_,i)=>{ const d=new Date(weekStart); d.setDate(weekStart.getDate()+i); return d })

  const weekLabel = weekOffset===0 ? 'This Week'
    : weekOffset===1 ? 'Next Week'
    : weekOffset===-1 ? 'Last Week'
    : weekStart.toLocaleDateString('en-US',{month:'short',day:'numeric'}) + ' – ' + new Date(weekStart.getTime()+6*86400000).toLocaleDateString('en-US',{month:'short',day:'numeric'})

  return (
    <div style={{paddingTop:20}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:400}}>Calendar 📅</h2>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <button onClick={()=>setWeekOffset(p=>p-1)} style={{padding:'6px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)',fontFamily:'system-ui',fontSize:13}}>‹</button>
          <span style={{fontSize:12,fontFamily:'system-ui',color:'rgba(251,250,244,.5)',minWidth:80,textAlign:'center'}}>{weekLabel}</span>
          <button onClick={()=>setWeekOffset(p=>p+1)} style={{padding:'6px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)',fontFamily:'system-ui',fontSize:13}}>›</button>
        </div>
      </div>

      {/* Week strip */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:4,marginBottom:24}}>
        {days.map(d=>{
          const isToday = d.getTime()===today.getTime()
          const hasEvent = events.some(e=>e.date.getTime()===d.getTime())
          return (
            <div key={d.getTime()} style={{textAlign:'center',padding:'8px 4px',borderRadius:8,background:isToday?'rgba(255,20,147,.15)':'transparent',border:isToday?'1px solid rgba(255,20,147,.3)':'1px solid transparent'}}>
              <p style={{fontSize:9,fontFamily:'system-ui',color:'rgba(251,250,244,.35)',letterSpacing:.5,marginBottom:4}}>{['SUN','MON','TUE','WED','THU','FRI','SAT'][d.getDay()]}</p>
              <p style={{fontSize:15,fontFamily:'system-ui',fontWeight:isToday?700:400,color:isToday?'var(--pink)':'var(--cream)'}}>{d.getDate()}</p>
              {hasEvent&&<div style={{width:6,height:6,borderRadius:'50%',background:'var(--lime)',margin:'4px auto 0'}}/>}
            </div>
          )
        })}
      </div>

      {loading&&<div className="spinner"/>}
      {!loading&&events.length===0&&(
        <div className="card" style={{textAlign:'center',padding:32}}>
          <p style={{color:'rgba(251,250,244,.3)',fontFamily:'system-ui',fontSize:14}}>No celebrations this week. 🌱</p>
          <p style={{color:'rgba(251,250,244,.25)',fontFamily:'system-ui',fontSize:12,marginTop:8}}>Members can add birthdays & sobriety anniversaries in their Profile.</p>
        </div>
      )}
      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        {events.map((e,i)=>(
          <div key={i} className="card" style={{display:'flex',gap:14,alignItems:'center'}}>
            <div style={{fontSize:28,flexShrink:0}}>{e.type==='birthday'?'🎂':'🏅'}</div>
            <div>
              <p style={{fontSize:15,marginBottom:2}}>{e.label}</p>
              <p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'system-ui'}}>{e.sub} · {e.date.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
