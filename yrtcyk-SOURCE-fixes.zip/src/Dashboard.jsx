import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

// v18 exact schema: member_id, day_number, section, item_key
// conflict: member_id,day_number,section,item_key

export default function Dashboard({ user }) {
  const [member, setMember]       = useState(null)
  const [dayContent, setDayContent] = useState(null)
  const [dayNum, setDayNum]       = useState(1)
  const [actions, setActions]     = useState({})
  const [kpi, setKpi]             = useState({ total_members:0, active_today:0, community_completion_pct:0, total_days_completed:0 })
  const [myStats, setMyStats]     = useState({ today_pct:0, month_pct:0, overall_pct:0, days_active:0 })
  const [practice, setPractice]   = useState(null)
  const [saving, setSaving]       = useState({})

  useEffect(() => { init() }, [])

  async function init() {
    const { data: m } = await supabase.from('members').select('*').eq('email', user.email).single()
    if (!m) return
    setMember(m)
    const start = new Date(m.membership_start_date + 'T00:00:00')
    const today = new Date(); start.setHours(0,0,0,0); today.setHours(0,0,0,0)
    const dn = Math.max(1, Math.min(365, Math.floor((today - start) / 86400000) + 1))
    setDayNum(dn)
    const [dcRes, daRes, kpiRes, statsRes] = await Promise.all([
      supabase.from('day_content').select('*').eq('day_number', dn).single(),
      supabase.from('daily_actions').select('*').eq('member_id', m.id).eq('day_number', dn),
      supabase.rpc('get_community_kpi'),
      supabase.rpc('get_my_stats'),
    ])
    if (dcRes.data) setDayContent(dcRes.data)
    if (daRes.data) {
      const a = {}
      daRes.data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    }
    if (kpiRes.data) setKpi(kpiRes.data)
    if (statsRes.data) setMyStats(statsRes.data)
  }

  async function save(section, itemKey, itemType, value) {
    if (!member) return
    const k = `${section}::${itemKey}`
    setSaving(p => ({ ...p, [k]: true }))
    const isCompleted = itemType === 'checkbox' ? value : !!value?.trim()
    const row = {
      member_id: member.id, day_number: dayNum,
      section, item_key: itemKey, item_type: itemType,
      is_checked: itemType === 'checkbox' ? value : false,
      text_value: itemType === 'text' ? value : null,
      is_completed: isCompleted,
      completed_at: isCompleted ? new Date().toISOString() : null,
      updated_at: new Date().toISOString()
    }
    await supabase.from('daily_actions').upsert(row, { onConflict: 'member_id,day_number,section,item_key' })
    setActions(p => ({ ...p, [k]: row }))
    setSaving(p => ({ ...p, [k]: false }))
  }

  const isChecked = (s, k) => !!actions[`${s}::${k}`]?.is_checked
  const textVal   = (s, k) => actions[`${s}::${k}`]?.text_value || ''
  const isSaving  = (s, k) => !!saving[`${s}::${k}`]

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const name = member?.display_name || user.email.split('@')[0]
  const dateStr = new Date().toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric', year:'numeric' })

  async function reloadActions() {
    if (!member) return
    const { data } = await supabase.from('daily_actions').select('*').eq('member_id', member.id).eq('day_number', dayNum)
    if (data) {
      const a = {}
      data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    }
  }

  if (practice) return (
    <PracticeView period={practice} dayNum={dayNum} dayContent={dayContent}
      memberId={member?.id}
      isChecked={isChecked} textVal={textVal} isSaving={isSaving} save={save}
      actions={actions} onBack={() => setPractice(null)} reloadActions={reloadActions} />
  )

  return (
    <div style={{ paddingTop: 20 }}>
      <div style={{ marginBottom: 24 }}>
        <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginBottom: 4 }}>{greeting}, {name} · {user.email}</p>
        <div style={{ fontSize: 42, fontWeight: 700, color: 'var(--pink)', fontFamily: 'var(--font-ui)', lineHeight: 1 }}>Day {dayNum}</div>
        <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginTop: 4 }}>{dateStr}</p>
      </div>

      {dayContent && (
        <div className="card" style={{ marginBottom: 20, background: 'rgba(255,20,147,.04)', border: '1px solid rgba(255,20,147,.1)' }}>
          <p className="section-label" style={{ marginBottom: 8 }}>Day {dayNum} — Today</p>
          <h3 style={{ fontSize: 18, fontWeight: 400, marginBottom: 6 }}>{dayContent.title}</h3>
          {dayContent.spiritual_principle && <p style={{ fontSize: 12, color: 'var(--pink)', fontFamily: 'var(--font-ui)', letterSpacing: .5 }}>{dayContent.spiritual_principle}</p>}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
        <button onClick={() => setPractice('morning')} style={{ background: 'rgba(255,20,147,.08)', border: '1px solid rgba(255,20,147,.2)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌅</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--pink)', fontSize: 14, marginBottom: 2 }}>Morning Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Upon awakening</div>
        </button>
        <button onClick={() => setPractice('evening')} style={{ background: 'rgba(25,229,94,.06)', border: '1px solid rgba(25,229,94,.15)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌙</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--lime)', fontSize: 14, marginBottom: 2 }}>Evening Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Before sleep</div>
        </button>
      </div>

      <p className="section-label">My Progress</p>
      <div className="kpi-grid" style={{ marginBottom: 28 }}>
        {[
          { val:`${Math.round(myStats.today_pct||0)}%`,   label:'Today' },
          { val:`${Math.round(myStats.month_pct||0)}%`,   label:'This Month' },
          { val:`${Math.round(myStats.overall_pct||0)}%`, label:'Overall' },
          { val:`${myStats.days_active||0}/365`,           label:'Days Active' },
        ].map(s => <div key={s.label} className="kpi-cell"><div className="kpi-value">{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>

      <p className="section-label">Our Community</p>
      <div className="kpi-grid" style={{ marginBottom: 8 }}>
        {[
          { val:kpi.total_members||0,                               label:'Members' },
          { val:`${Math.round(kpi.community_completion_pct||0)}%`,  label:'Avg Completion' },
          { val:kpi.active_today||0,                                label:'Active Today' },
          { val:kpi.total_days_completed||0,                        label:'Days Completed' },
        ].map(s => <div key={s.label} className="kpi-cell"><div className="kpi-value green">{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>
      <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.3)', fontStyle:'italic', marginBottom:28 }}>The company you keep is showing up. 🌈</p>

    </div>
  )
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function SectionBlock({ emoji, title, children }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,.06)' }}>
        <span style={{ fontSize: 18 }}>{emoji}</span>
        <h2 style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.85)' }}>{title}</h2>
      </div>
      {children}
    </div>
  )
}

function RichText({ text }) {
  if (!text) return null
  // Strip all markdown-style formatting stored in DB
  const cleaned = text
    .replace(/\*\*([^*]+)\*\*/g, '$1')  // **bold** -> bold
    .replace(/\*\*/g, '')                 // remaining **
    .replace(/\\\s*\n/g, '\n')            // backslash-newline -> newline
    .replace(/\\\n/g, '\n')               // same
    .replace(/\\n/g, '\n')                // literal \n -> newline
    .replace(/\\/g, '')                   // any remaining backslashes
    .trim()
  const lines = cleaned.split('\n')
  return (
    <div style={{ fontSize: 14, lineHeight: 1.85, color: 'rgba(251,250,244,.78)' }}>
      {lines.map((line, i) => {
        const t = line.trim()
        if (!t) return <div key={i} style={{ height: 6 }}/>
        if (t.startsWith('•') || t.startsWith('- ') || t.startsWith('* ')) {
          return <div key={i} style={{ paddingLeft: 16, marginBottom: 4 }}>{t.replace(/^[-•*]\s+/, '')}</div>
        }
        return <p key={i} style={{ marginBottom: 6 }}>{t}</p>
      })}
    </div>
  )
}
function TextQuestion({ label, section, itemKey, value, onSave, saving }) {
  const [local, setLocal] = useState(value)
  useEffect(() => setLocal(value), [value])
  return (
    <div className="card" style={{ marginBottom: 12 }}>
      <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.8)', marginBottom: 10 }}>{label}</p>
      <textarea rows={3} value={local} onChange={e => setLocal(e.target.value)} style={{ resize: 'vertical', marginBottom: 8 }} />
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="btn-primary" style={{ fontSize: 12, padding: '7px 14px' }}
          onClick={() => onSave(section, itemKey, 'text', local)} disabled={saving}>
          {saving ? 'Saving…' : value ? 'Update' : 'Save'}
        </button>
        {value && <span style={{ fontSize: 11, color: 'var(--lime)', fontFamily: 'var(--font-ui)' }}>✓ Saved</span>}
      </div>
    </div>
  )
}

function CheckRow({ label, section, itemKey, checked, onSave, saving }) {
  return (
    <div className="card" style={{ marginBottom: 10 }}>
      <label className="check-row">
        <input type="checkbox" checked={checked}
          onChange={e => onSave(section, itemKey, 'checkbox', e.target.checked)}
          style={{ width: 18, height: 18, accentColor: 'var(--pink)', flexShrink: 0 }} />
        <span className={`check-label${checked ? ' done' : ''}`}>{label}</span>
        {saving && <span style={{ fontSize: 11, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginLeft: 'auto' }}>…</span>}
      </label>
    </div>
  )
}

// ─── Full Practice View ───────────────────────────────────────────────────────

function PracticeView({ period, dayNum, dayContent: dc, memberId, isChecked, textVal, isSaving, save, actions, onBack, reloadActions }) {
  const isMorning = period === 'morning'

  // Reload actions from DB every time PracticeView opens
  useEffect(() => { reloadActions() }, [])

  // Count completion for progress %
  const checkKeys = isMorning
    ? [['morning_practice','completed'],['grounding','breathing'],['grounding','grounding'],['affirmation','spoken'],['act_of_service','completed']]
    : [['evening_step10','completed'],['act_of_service','completed']]
  const mqCount = (dc?.morning_questions||[]).length
  const eqCount = (dc?.evening_questions||[]).length
  const s10Count = (dc?.step10_items||[]).length
  const totalItems = checkKeys.length + (isMorning ? mqCount : eqCount + s10Count)
  const doneItems = checkKeys.filter(([s,k]) => isChecked(s,k)).length
    + (isMorning ? (dc?.morning_questions||[]).filter((_,i) => !!textVal('morning_practice',`q${i+1}`)?.trim()).length
                 : (dc?.evening_questions||[]).filter((_,i) => !!textVal('evening_step10',`q${i+1}`)?.trim()).length
                   + (dc?.step10_items||[]).filter((_,i) => isChecked('evening_step10',`s10_${i}`)).length)
  const pct = totalItems > 0 ? Math.round(doneItems / totalItems * 100) : 0

  return (
    <div style={{ paddingTop: 20, paddingBottom: 48 }}>
      <button onClick={onBack} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:20 }}>← Back</button>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>{isMorning ? '🌅 Morning Practice' : '🌙 Evening Practice'}</h2>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:22, fontWeight:700, fontFamily:'var(--font-ui)', color:pct===100?'var(--lime)':'var(--pink)' }}>{pct}%</div>
          <div style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>{doneItems}/{totalItems}</div>
        </div>
      </div>

      {/* Day header */}
      {dc && (
        <div className="card" style={{ marginBottom:24, background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.1)' }}>
          <p className="section-label">Day {dayNum}</p>
          <h3 style={{ fontSize:18, fontWeight:400, marginBottom:6 }}>{dc.title}</h3>
          {dc.spiritual_principle && <p style={{ fontSize:12, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom: dc.pattern ? 8 : 0 }}>{dc.spiritual_principle}</p>}
          {dc.pattern && <p style={{ fontSize:13, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>Pattern: {dc.pattern}</p>}
        </div>
      )}

      {isMorning && dc && <>

        {/* Sources */}
        {(dc.source_big_book || dc.source_twelve_twelve || dc.source_drop_rock || dc.source_ripple_effect) && (
          <SectionBlock emoji="📚" title="Today's Sources">
            {dc.source_big_book && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📖 BIG BOOK</p><RichText text={dc.source_big_book}/></div>}
            {dc.source_twelve_twelve && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📗 TWELVE STEPS & TRADITIONS</p><RichText text={dc.source_twelve_twelve}/></div>}
            {dc.source_drop_rock && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📘 DROP THE ROCK</p><RichText text={dc.source_drop_rock}/></div>}
            {dc.source_ripple_effect && <div><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📙 RIPPLE EFFECT</p><RichText text={dc.source_ripple_effect}/></div>}
          </SectionBlock>
        )}

        {/* Pattern */}
        {dc.pattern_detail && (
          <SectionBlock emoji="🔍" title="Today's Pattern">
            <RichText text={dc.pattern_detail}/>
          </SectionBlock>
        )}

        {/* Opposite Action */}
        {dc.opposite_action && (
          <SectionBlock emoji="⚡" title="Opposite Action">
            <RichText text={dc.opposite_action}/>
          </SectionBlock>
        )}

        {/* Step 7 Prayer */}
        {dc.step && (
          <SectionBlock emoji="🙏" title="Step 7 Prayer">
            <div style={{ background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.1)', borderRadius:8, padding:16 }}>
              <RichText text={dc.step}/>
            </div>
          </SectionBlock>
        )}

        {/* Morning Practice */}
        <SectionBlock emoji="☀️" title="Morning Practice">
          <CheckRow label="Completed morning practice" section="morning_practice" itemKey="completed"
            checked={isChecked('morning_practice','completed')} onSave={save} saving={isSaving('morning_practice','completed')}/>
          {(dc.morning_questions||[]).map((q, i) => (
            <TextQuestion key={i} label={`${i+1}. ${q.replace(/\*\*/g,'').replace(/\\/g,'')}`} section="morning_practice" itemKey={`q${i+1}`}
              value={textVal('morning_practice',`q${i+1}`)} onSave={save} saving={isSaving('morning_practice',`q${i+1}`)}/>
          ))}
          {dc.morning_intention && (
            <div className="card" style={{ marginTop:8, background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.06)' }}>
              <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom:6 }}>INTENTION</p>
              <p style={{ fontSize:14, fontStyle:'italic', color:'rgba(251,250,244,.7)', lineHeight:1.7 }}>"{dc.morning_intention}"</p>
            </div>
          )}
        </SectionBlock>

        {/* Breathing */}
        {dc.breathing && (
          <SectionBlock emoji="💨" title="Breathing Exercise">
            <RichText text={dc.breathing}/>
            <CheckRow label="Completed breathing exercise" section="grounding" itemKey="breathing"
              checked={isChecked('grounding','breathing')} onSave={save} saving={isSaving('grounding','breathing')}/>
          </SectionBlock>
        )}

        {/* Grounding */}
        {dc.grounding && (
          <SectionBlock emoji="🌳" title="Grounding Exercise">
            <RichText text={dc.grounding}/>
            <CheckRow label="Completed grounding exercise" section="grounding" itemKey="grounding"
              checked={isChecked('grounding','grounding')} onSave={save} saving={isSaving('grounding','grounding')}/>
          </SectionBlock>
        )}

        {/* Affirmation */}
        {dc.affirmation && (
          <SectionBlock emoji="🌈" title="Affirmation">
            <div style={{ textAlign:'center', padding:'12px 16px', background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.12)', borderRadius:8, marginBottom:12 }}>
              <p style={{ fontSize:17, fontStyle:'italic', color:'var(--pink)', lineHeight:1.65 }}>"{dc.affirmation}"</p>
            </div>
            <CheckRow label="Spoke this affirmation aloud" section="affirmation" itemKey="spoken"
              checked={isChecked('affirmation','spoken')} onSave={save} saving={isSaving('affirmation','spoken')}/>
          </SectionBlock>
        )}

        {/* Meditation */}
        {dc.meditation && (
          <SectionBlock emoji="🧘" title="Meditation">
            <RichText text={dc.meditation}/>
          </SectionBlock>
        )}

      </>}

      {!isMorning && dc && <>

        {/* Evening Practice */}
        <SectionBlock emoji="✏️" title="Evening Practice">
          {(dc.evening_questions||['How did today go?','Where was I selfish, dishonest, or afraid?','Do I owe anyone an amends?','What am I grateful for tonight?']).map((q, i) => (
            <TextQuestion key={i} label={`${i+1}. ${q.replace(/\*\*/g,'').replace(/\\/g,'')}`} section="evening_step10" itemKey={`q${i+1}`}
              value={textVal('evening_step10',`q${i+1}`)} onSave={save} saving={isSaving('evening_step10',`q${i+1}`)}/>
          ))}
        </SectionBlock>

        {/* Step 10 */}
        <SectionBlock emoji="📘" title="Step 10 Mini-Inventory">
          {(dc.step10_items||[]).map((item, i) => (
            <CheckRow key={i} label={item.replace(/\*\*/g,'').replace(/\\/g,'')} section="evening_step10" itemKey={`s10_${i}`}
              checked={isChecked('evening_step10',`s10_${i}`)} onSave={save} saving={isSaving('evening_step10',`s10_${i}`)}/>
          ))}
          <CheckRow label="Step 10 complete ✓" section="evening_step10" itemKey="completed"
            checked={isChecked('evening_step10','completed')} onSave={save} saving={isSaving('evening_step10','completed')}/>
        </SectionBlock>

        {/* Act of Service (evening) */}
        {dc.act_of_service && (
          <SectionBlock emoji="🌟" title="Act of Service">
            <RichText text={dc.act_of_service}/>
            <CheckRow label="Completed act of service" section="act_of_service" itemKey="completed"
              checked={isChecked('act_of_service','completed')} onSave={save} saving={isSaving('act_of_service','completed')}/>
          </SectionBlock>
        )}

        {/* Bonus Challenge */}
        {dc.bonus_challenge && (
          <SectionBlock emoji="🎯" title="Bonus Challenge">
            <RichText text={dc.bonus_challenge}/>
          </SectionBlock>
        )}

        {/* Visualization */}
        {dc.visualization && (
          <SectionBlock emoji="✨" title="Visualization">
            <RichText text={dc.visualization}/>
          </SectionBlock>
        )}

        {/* Daily Attestation */}
        <SectionBlock emoji="✅" title="Daily Attestation">
          <div style={{ background:'rgba(25,229,94,.04)', border:'1px solid rgba(25,229,94,.1)', borderRadius:8, padding:16 }}>
            <p style={{ fontSize:13, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', marginBottom:12, fontStyle:'italic' }}>My Contract with HP & Myself</p>
            {[
              'Morning assignment completed',
              'Opposite action practiced',
              'Evening assignment completed',
              'Step 7 prayer said',
              'I showed up for my recovery today',
            ].map((item, i) => (
              <CheckRow key={i} label={item} section="attestation" itemKey={`a${i}`}
                checked={isChecked('attestation',`a${i}`)} onSave={save} saving={isSaving('attestation',`a${i}`)}/>
            ))}
          </div>
        </SectionBlock>

      </>}

      {pct === 100 && (
        <div className="card" style={{ textAlign:'center', marginTop:16, background:'rgba(25,229,94,.06)', border:'1px solid rgba(25,229,94,.15)' }}>
          <p style={{ fontSize:24, marginBottom:8 }}>🌈</p>
          <p style={{ fontFamily:'var(--font-ui)', fontWeight:600, color:'var(--lime)' }}>{isMorning ? 'Morning practice complete!' : 'Evening practice complete!'}</p>
          <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginTop:4 }}>You aRe The Company You Keep.</p>
        </div>
      )}
    </div>
  )
}
