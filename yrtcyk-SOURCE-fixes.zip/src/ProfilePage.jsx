import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

const TIMEZONES = [
  ['America/Los_Angeles','Pacific Time (LA, SF, Seattle)'],
  ['America/Denver','Mountain Time (Denver, Phoenix)'],
  ['America/Chicago','Central Time (Chicago, Dallas)'],
  ['America/New_York','Eastern Time (NYC, Miami, Boston)'],
  ['America/Anchorage','Alaska Time (UTC-9)'],
  ['Pacific/Honolulu','Hawaii Time (UTC-10)'],
  ['Europe/London','London / Dublin'],
  ['Europe/Paris','Central Europe — Paris, Berlin, Rome'],
  ['Europe/Athens','Eastern Europe — Athens, Helsinki'],
  ['Asia/Dubai','Gulf Time — Dubai, Abu Dhabi'],
  ['Asia/Kolkata','India Standard Time'],
  ['Asia/Tokyo','Japan / Korea'],
  ['Australia/Sydney','Eastern Australia — Sydney, Melbourne'],
  ['Pacific/Auckland','New Zealand'],
  ['UTC','UTC'],
]
const PRONOUNS     = ['He/Him','She/Her','They/Them','He/They','She/They','Ze/Zir','Any/All','Prefer not to say']
const ORIENTATIONS = ['Gay','Lesbian','Bisexual','Pansexual','Queer','Straight/Heterosexual','Asexual','Prefer not to say']
const GENDERS      = ['Man','Woman','Non-binary','Genderqueer','Genderfluid','Transgender Man','Transgender Woman','Two-Spirit','Prefer not to say']
const ETHNICITIES  = ['Asian/Pacific Islander','Black/African American','Hispanic/Latino','Indigenous/Native American','Middle Eastern/North African','Multiracial','White/Caucasian','Prefer not to say']
const LANGUAGES    = ['English','Spanish','French','Portuguese','German','Italian','Mandarin','Cantonese','Japanese','Korean','Arabic','Hindi','Russian','Other']
const PET_TYPES    = ['Dog','Cat','Bird','Fish','Rabbit','Hamster/Guinea Pig','Reptile','Horse','Other']
const PROGRAMS     = ['AA','NA','Al-Anon','OA','SLAA','GA','SMART Recovery','Refuge Recovery','Other']
const DAYS         = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
const FORMATS      = ['In-Person','Online (Zoom)','Hybrid']

const WELLNESS_AREAS = [
  { key:'physical',     label:'Physical Health',          icon:'💪', desc:'Your body is the vessel. Movement, rest, and nourishment are acts of self-respect.',
    topics:['Walking / Hiking','Running / Jogging','Weight Training','Yoga','Pilates','Swimming','Cycling','Team Sports','Dance','Martial Arts','Sleep Hygiene','Nutrition & Eating Well','Sober Fitness','Weight Management','Chronic Pain Management'] },
  { key:'emotional',    label:'Emotional Wellbeing',      icon:'💙', desc:'Learning to feel without being consumed. The work of a lifetime.',
    topics:['Therapy / Counseling','Journaling','Emotional Regulation','Grief & Loss','Trauma Recovery','Anger Management','Self-Compassion','Boundaries','Anxiety Management','Depression Support','Mindfulness','Meditation','Breathwork','Inner Child Work','Somatic Work'] },
  { key:'spiritual',    label:'Spiritual Growth',         icon:'✨', desc:'Whatever your Higher Power looks like — connecting to something larger than yourself.',
    topics:['Step Work','Prayer','Meditation','Nature Connection','Religious Practice','Buddhism / Mindfulness','Gratitude Practice','Service Work','Spiritual Literature','Retreats','12-Step Community','SMART Recovery','Faith Community','Purpose & Meaning','Forgiveness Work'] },
  { key:'social',       label:'Relationships & Community',icon:'🌈', desc:'Connection is the antidote to addiction. We are not built for isolation.',
    topics:['Rebuilding Family Relationships','Friendships in Recovery','Dating in Sobriety','LGBTQ+ Community','Sponsorship','Finding a Home Group','Social Anxiety','Healthy Boundaries','Communication Skills','Conflict Resolution','Parenting in Recovery','Rebuilding Trust','Overcoming Loneliness','Making Amends','Community Involvement'] },
  { key:'financial',    label:'Financial & Occupational', icon:'🌱', desc:'Security and purpose. Money and work are spiritual matters in recovery.',
    topics:['Debt Recovery','Budgeting Basics','Saving & Investing','Career Development','Job Search','Work-Life Balance','Entrepreneurship','Education & Retraining','Gambling Recovery','Financial Amends','Credit Rebuilding','Housing Stability','Benefits Navigation','Retirement Planning','Workplace Relationships'] },
  { key:'intellectual', label:'Intellectual & Creative',  icon:'🎨', desc:'Your mind was numbed. Now it gets to wake up and create.',
    topics:['Reading','Writing','Music','Visual Arts','Photography','Cooking','Gardening','Learning New Skills','Online Courses','Podcasts & Audiobooks','Theater / Performance','Film & Cinema','Crafts & Hobbies','Language Learning','Technology'] },
  { key:'fun',          label:'Fun, Play & Adventure',    icon:'🎭', desc:'"We absolutely insist on enjoying life." Joy is not a luxury — it\'s the point.',
    topics:['Travel','Camping & Outdoors','Live Music & Concerts','Comedy Shows','Gaming','Cooking Adventures','Day Trips','Trying New Restaurants','Sober Nightlife','Volunteering','Pets & Animals','Sports & Games','Theme Parks','Collecting','Sober Travel'] },
  { key:'environmental',label:'Home & Environment',       icon:'🏡', desc:'Your external world reflects and shapes your internal one.',
    topics:['Decluttering & Organization','Creating a Safe Space','Home Improvement','Sustainability','Urban Gardening','Minimalism','Interior Design','Digital Detox','Nature Immersion','Animal Welfare','Sacred Space Creation','Neighborhood Community','Moving to a Sober Environment','Climate Consciousness','Intentional Living'] },
]

function parseList(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  try { const p = JSON.parse(val); if (Array.isArray(p)) return p } catch {}
  return val.split(',').map(s => s.trim()).filter(Boolean)
}

function parsePets(val) {
  if (!val) return []
  try {
    const p = JSON.parse(val)
    if (Array.isArray(p)) {
      if (p.length === 0) return []
      if (typeof p[0] === 'object' && p[0].type) return p
      return p.map(v => ({ type: v, name: '' }))
    }
  } catch {}
  if (typeof val === 'string' && val.trim()) return [{ type:'Dog', name: val }]
  return []
}

function formatPhone(val) {
  const d = (val||'').replace(/\D/g,'').slice(0,10)
  if (d.length <= 3) return d
  if (d.length <= 6) return `(${d.slice(0,3)}) ${d.slice(3)}`
  return `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}`
}

function WellnessArea({ area, selectedTopics, onToggle }) {
  const [open, setOpen] = useState(false)
  const selected = selectedTopics.filter(t => area.topics.includes(t))
  return (
    <div style={{ border:`1px solid ${selected.length > 0 ? 'rgba(255,20,147,.3)' : 'var(--border)'}`, borderRadius:8, marginBottom:10, overflow:'hidden', background: selected.length > 0 ? 'rgba(255,20,147,.04)' : 'rgba(255,255,255,.03)' }}>
      <button onClick={() => setOpen(o => !o)} style={{ width:'100%', background:'none', border:'none', padding:'14px 16px', display:'flex', alignItems:'center', gap:12, cursor:'pointer', textAlign:'left' }}>
        <span style={{ fontSize:22, flexShrink:0 }}>{area.icon}</span>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:600, color:'var(--cream)', fontFamily:'var(--font-ui)' }}>{area.label}</div>
          <div style={{ fontSize:12, color:'rgba(251,250,244,.45)', marginTop:2 }}>
            {selected.length > 0 ? `${selected.length} topic${selected.length!==1?'s':''} selected` : area.desc}
          </div>
        </div>
        <span style={{ fontSize:16, color:'rgba(251,250,244,.3)', transform:open?'rotate(180deg)':'none', transition:'transform .2s' }}>▾</span>
      </button>
      {open && (
        <div style={{ padding:'0 16px 16px' }}>
          <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', lineHeight:1.6, marginBottom:12, fontStyle:'italic' }}>{area.desc}</p>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {area.topics.map(t => {
              const sel = selectedTopics.includes(t)
              return (
                <button key={t} onClick={() => onToggle(t)} style={{ padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background: sel?'rgba(255,20,147,.2)':'rgba(255,255,255,.06)', border:`1px solid ${sel?'rgba(255,20,147,.4)':'rgba(255,255,255,.1)'}`, color:sel?'var(--pink)':'rgba(251,250,244,.6)', cursor:'pointer' }}>
                  {t}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}

// Visibility toggle button — shows/hides a field on the member profile card
function VisToggle({ k, P, set }) {
  const on = P[k] !== false // default = visible (true or undefined = show)
  return (
    <button onClick={() => set(k, !on)}
      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'3px 10px', borderRadius:20, cursor:'pointer', marginBottom:6, flexShrink:0,
        background: on ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.06)',
        border: `1px solid ${on ? 'rgba(25,229,94,.3)' : 'rgba(255,255,255,.12)'}`,
        color: on ? 'var(--lime)' : 'rgba(251,250,244,.35)' }}>
      {on ? '👁 Visible' : '🚫 Hidden'}
    </button>
  )
}

export default function ProfilePage({ user, isAdmin, onClose }) {
  const [tab, setTab]       = useState('basics')
  const [member, setMember] = useState(null)
  const [P, setP]           = useState({})
  const [pets, setPets]     = useState([]) // [{type, name}]
  const [referrals, setReferrals] = useState([])
  const [avatarUrl, setAvatarUrl] = useState('')
  const [avatarUploading, setAvatarUploading] = useState(false)
  const [dragOver, setDragOver] = useState(false)
  const [loading, setLoading] = useState(true)
  const [saving, setSaving]   = useState(false)
  const [msg, setMsg]         = useState('')
  const [dirty, setDirty]     = useState(false)

  useEffect(() => { load() }, [])

  async function load() {
    const { data } = await supabase.from('members').select('*').eq('email', user.email).single()
    if (data) {
      setMember(data)
      const parsed = {
        ...data,
        spoken_languages:  parseList(data.spoken_languages),
        written_languages: parseList(data.written_languages),
        wellness_topics:   parseList(data.wellness_topics),
      }
      setP(parsed)
      setPets(parsePets(data.pets))
      setAvatarUrl(data.avatar_url || '')
      // Load referrals for account tab
      const { data: refs } = await supabase.from('referrals').select('*').eq('referrer_id', data.id).order('created_at', { ascending:false })
      setReferrals(refs || [])
    }
    setLoading(false)
  }

  function set(key, val) { setP(p => ({ ...p, [key]: val })); setDirty(true) }
  function toggleList(key, val) {
    const cur = P[key] || []
    set(key, cur.includes(val) ? cur.filter(v => v !== val) : [...cur, val])
  }
  function setPet(i, field, val) { const p=[...pets]; p[i]={...p[i],[field]:val}; setPets(p); setDirty(true) }
  function removePet(i) { setPets(pets.filter((_,j)=>j!==i)); setDirty(true) }
  function addPet() { setPets([...pets,{type:'Dog',name:''}]); setDirty(true) }

  async function save() {
    if (!member) return
    setSaving(true)
    const payload = {
      ...P,
      spoken_languages:  (P.spoken_languages||[]).join(', '),
      written_languages: (P.written_languages||[]).join(', '),
      wellness_topics:   JSON.stringify(P.wellness_topics||[]),
      pets:              JSON.stringify(pets),
      updated_at:        new Date().toISOString(),
    }
    ;['birth_date','program_1_date','program_2_date','program_3_date'].forEach(k => {
      if (!payload[k] || String(payload[k]).trim() === '') payload[k] = null
    })
    // Remove array copies
    delete payload.spoken_languages_arr
    delete payload.written_languages_arr
    const { error } = await supabase.from('members').update(payload).eq('id', member.id)
    setSaving(false)
    if (error) setMsg('Error: ' + error.message)
    else { setMsg('Saved ✓'); setDirty(false); setTimeout(() => setMsg(''), 2500) }
  }

  async function uploadAvatar(file) {
    if (!member || !file) return
    const ok = ['image/jpeg','image/png','image/gif','image/webp'].includes(file.type)
    if (!ok) return
    setAvatarUploading(true)
    try {
      const ext = file.name.split('.').pop()
      const path = `${member.id}/avatar.${ext}`
      const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert: true })
      if (error) throw error
      const { data: { publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)
      await supabase.from('members').update({ avatar_url: publicUrl }).eq('id', member.id)
      setAvatarUrl(publicUrl)
    } catch(e) { console.error(e) }
    setAvatarUploading(false)
  }

  if (loading) return <div style={{ paddingTop:40 }}><div className="spinner"/></div>

  const TABS = ['basics','identity','recovery','goals','calendar','preview','account']
  const LABELS = { basics:'Basics', identity:'Identity', recovery:'Recovery', goals:'Goals', calendar:'Calendar', preview:'Preview', account:'Account' }

  // Helpers — all with consistent 16px horizontal padding
  const pad = { padding:'0 16px' }
  const Lbl = ({ t, sub }) => (
    <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:6, marginTop:16 }}>
      {t}{sub&&<span style={{ color:'rgba(251,250,244,.2)', marginLeft:6 }}>{sub}</span>}
    </p>
  )
  const Inp = ({ k, ...props }) => <input value={P[k]||''} onChange={e=>set(k,e.target.value)} {...props}/>
  const Sel = ({ k, opts, ph }) => (
    <select value={P[k]||''} onChange={e=>set(k,e.target.value)}>
      <option value="">{ph||'Select…'}</option>
      {opts.map(o=>Array.isArray(o)?<option key={o[0]} value={o[0]}>{o[1]}</option>:<option key={o} value={o}>{o}</option>)}
    </select>
  )
  const Chips = ({ k, opts }) => (
    <div style={{ display:'flex', flexWrap:'wrap', gap:8, marginTop:8 }}>
      {opts.map(o=>{
        const sel=(P[k]||[]).includes(o)
        return <button key={o} onClick={()=>toggleList(k,o)} style={{ padding:'6px 14px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:sel?'rgba(255,20,147,.18)':'rgba(255,255,255,.06)', border:`1px solid ${sel?'rgba(255,20,147,.35)':'rgba(255,255,255,.1)'}`, color:sel?'var(--pink)':'rgba(251,250,244,.6)', cursor:'pointer' }}>{o}</button>
      })}
    </div>
  )
  const Chk = ({ k, label }) => (
    <label style={{ display:'flex', gap:10, alignItems:'center', cursor:'pointer', marginTop:12 }}>
      <input type="checkbox" checked={!!P[k]} onChange={e=>set(k,e.target.checked)} style={{ width:18, height:18, accentColor:'var(--pink)', flexShrink:0 }}/>
      <span style={{ fontSize:13, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.65)' }}>{label}</span>
    </label>
  )

  const dayNum = Math.max(1, Math.floor((new Date() - new Date((member?.membership_start_date||new Date().toISOString().split('T')[0])+'T00:00:00')) / 86400000) + 1)

  const refStatusLabel = { invited:'Invited', joined:'Joined ✓', month_1:'Month 1 ✓', month_2:'Month 2 ✓ — Reward Pending', rewarded:'Rewarded 🎁' }
  const refStatusColor = { invited:'rgba(251,250,244,.35)', joined:'gold', month_1:'orange', month_2:'var(--lime)', rewarded:'var(--lime)' }

  return (
    <div style={{ paddingTop:20, paddingBottom:48 }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20, padding:'0 16px' }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>My Profile</h2>
        <button onClick={onClose} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)' }}>← Back</button>
      </div>

      <div className="tab-bar" style={{ marginBottom:20, padding:'0 16px' }}>
        {TABS.map(t=><button key={t} onClick={()=>setTab(t)} className={`tab-btn${tab===t?' active':''}`}>{LABELS[t]}</button>)}
      </div>

      <div style={{ padding:'0 16px' }}>

      {/* ── BASICS ── */}
      {tab==='basics' && <>
        {/* Avatar upload */}
        <div style={{ textAlign:'center', marginBottom:20 }}>
          <label
            style={{ position:'relative', display:'inline-block', cursor:'pointer' }}
            onDragOver={e => { e.preventDefault(); e.stopPropagation(); setDragOver(true) }}
            onDragEnter={e => { e.preventDefault(); e.stopPropagation(); setDragOver(true) }}
            onDragLeave={e => { e.preventDefault(); e.stopPropagation(); setDragOver(false) }}
            onDrop={e => {
              e.preventDefault(); e.stopPropagation(); setDragOver(false)
              const f = e.dataTransfer.files[0]
              if (f) uploadAvatar(f)
            }}
          >
            <div style={{ width:88, height:88, borderRadius:'50%', overflow:'hidden', border:`3px solid ${dragOver ? 'var(--lime)' : 'var(--pink)'}`, background:'rgba(255,20,147,.1)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:32, fontFamily:'var(--font-ui)', fontWeight:700, color:'var(--pink)', transition:'border-color .2s, transform .2s', transform: dragOver ? 'scale(1.08)' : 'scale(1)' }}>
              {avatarUploading
                ? <div className="spinner" style={{ margin:0, width:24, height:24, borderWidth:2 }}/>
                : avatarUrl
                  ? <img src={avatarUrl} alt="" style={{ width:88, height:88, objectFit:'cover' }}/>
                  : (P.display_name||user.email||'?')[0].toUpperCase()
              }
            </div>
            <div style={{ position:'absolute', bottom:2, right:2, background:'var(--pink)', borderRadius:'50%', width:24, height:24, display:'flex', alignItems:'center', justifyContent:'center', fontSize:12, boxShadow:'0 0 0 2px var(--bg)', pointerEvents:'none' }}>
              📷
            </div>
            <input type="file" accept="image/jpeg,image/png,image/gif,image/webp" style={{ display:'none' }} onChange={e => { const f=e.target.files?.[0]; if(f) uploadAvatar(f); e.target.value='' }}/>
          </label>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginTop:8 }}>
            {dragOver ? '✅ Drop now!' : avatarUploading ? 'Uploading…' : 'Tap photo or drag & drop to upload'}
          </p>
        </div>
        <Lbl t="DISPLAY NAME"/>
        <Inp k="display_name" placeholder="How you appear to other members"/>
        <Lbl t="PHONE" sub="(for reminders)"/>
        <input value={P.phone||''} onChange={e=>set('phone',formatPhone(e.target.value))} placeholder="(555) 555-5555" type="tel"/>
        <Lbl t="TIMEZONE"/>
        <Sel k="timezone" opts={TIMEZONES} ph="Select timezone…"/>
        <Lbl t="CITY" sub="(optional)"/>
        <Inp k="city" placeholder="Palm Springs, CA"/>
        <Chk k="show_location" label="Show my city on my member profile"/>
      </>}

      {/* ── IDENTITY ── */}
      {tab==='identity' && <>
        <Lbl t="PRONOUNS"/>
        <Sel k="pronouns" opts={PRONOUNS} ph="Select pronouns…"/>
        <Chk k="show_pronouns" label="Show pronouns on my member profile"/>
        <Lbl t="DATE OF BIRTH"/>
        <input type="date" value={P.birth_date||''} onChange={e=>set('birth_date',e.target.value||null)}/>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="SEXUAL ORIENTATION"/>
          <VisToggle k="show_sexual_orientation" P={P} set={set}/>
        </div>
        <Sel k="sexual_orientation" opts={ORIENTATIONS} ph="Select…"/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="GENDER IDENTITY"/>
          <VisToggle k="show_gender_identity" P={P} set={set}/>
        </div>
        <Sel k="gender_identity" opts={GENDERS} ph="Select…"/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="RACE / ETHNICITY"/>
          <VisToggle k="show_ethnicity" P={P} set={set}/>
        </div>
        <Sel k="ethnicity" opts={ETHNICITIES} ph="Select…"/>

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="SPOKEN LANGUAGES"/>
          <VisToggle k="show_languages" P={P} set={set}/>
        </div>
        <Chips k="spoken_languages" opts={LANGUAGES}/>
        <Lbl t="WRITTEN LANGUAGES"/>
        <Chips k="written_languages" opts={LANGUAGES}/>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="PETS" sub="(optional)"/>
          <VisToggle k="show_pets" P={P} set={set}/>
        </div>
        {pets.map((pet, i) => (
          <div key={i} style={{ display:'flex', gap:8, alignItems:'center', marginBottom:8, marginTop: i===0?8:0 }}>
            <select value={pet.type} onChange={e=>setPet(i,'type',e.target.value)} style={{ flex:'0 0 130px' }}>
              {PET_TYPES.map(t=><option key={t} value={t}>{t}</option>)}
            </select>
            <input value={pet.name} onChange={e=>setPet(i,'name',e.target.value)} placeholder="Pet's name" style={{ flex:1 }}/>
            <button onClick={()=>removePet(i)} style={{ background:'none', border:'none', color:'rgba(251,250,244,.35)', cursor:'pointer', fontSize:20, padding:'0 4px', flexShrink:0 }}>×</button>
          </div>
        ))}
        <button onClick={addPet} style={{ marginTop:8, padding:'8px 14px', borderRadius:8, background:'rgba(255,255,255,.06)', border:'1px solid var(--border)', color:'rgba(251,250,244,.6)', fontSize:13, fontFamily:'var(--font-ui)', cursor:'pointer' }}>+ Add a Pet</button>
      </>}

      {/* ── RECOVERY ── */}
      {tab==='recovery' && <>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', lineHeight:1.7, marginBottom:16 }}>
          Add up to 3 recovery programs. Your sobriety dates are private by default.
        </p>

        {/* Program 1 — then immediately Home Group */}
        <div className="card" style={{ marginBottom:12 }}>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1 }}>PROGRAM</p>
          <select value={P.program_1||''} onChange={e=>set('program_1',e.target.value)} style={{ marginTop:6, marginBottom:10 }}>
            <option value="">Select program…</option>
            {PROGRAMS.map(p=><option key={p} value={p}>{p}</option>)}
          </select>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6 }}>SOBRIETY DATE <span style={{ color:'rgba(251,250,244,.2)' }}>(private)</span></p>
          <input type="date" value={P.program_1_date||''} onChange={e=>set('program_1_date',e.target.value||null)}/>
        </div>

        {/* Home Group — right after Program 1 */}
        <div className="card" style={{ marginBottom:12 }}>
          <p style={{ fontSize:15, fontWeight:600, fontFamily:'var(--font-ui)', marginBottom:4 }}>🏠 Home Group</p>
          <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', lineHeight:1.65, marginBottom:8 }}>
            Your home group is the meeting you consider your primary community — where you have a service commitment, where people know your name.
          </p>
          <div style={{ display:'flex', gap:16, marginBottom:10 }}>
            <a href="https://www.aa.org/meeting-guide" target="_blank" rel="noreferrer" style={{ fontSize:13, color:'var(--pink)', fontFamily:'var(--font-ui)' }}>📱 Open Meeting Guide App →</a>
            <a href="https://www.aa.org/find-aa" target="_blank" rel="noreferrer" style={{ fontSize:13, color:'var(--pink)', fontFamily:'var(--font-ui)' }}>🔍 Find a Meeting on AA.org →</a>
          </div>
          <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:10 }}>Find your group there, then enter the details below.</p>
          <Lbl t="MEETING NAME"/>
          <Inp k="homegroup_name" placeholder="e.g. Sunday Serenity Group"/>
          <Lbl t="DAY"/>
          <Sel k="homegroup_day" opts={['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']} ph="Select day…"/>
          <Lbl t="TIME"/>
          <input type="time" value={P.homegroup_time||''} onChange={e=>set('homegroup_time',e.target.value)}/>
          <Lbl t="FORMAT"/>
          <Sel k="homegroup_format" opts={['In-Person','Online (Zoom)','Hybrid']} ph="Select…"/>
          {(P.homegroup_format==='Online (Zoom)'||P.homegroup_format==='Hybrid') ? <>
            <Lbl t="ZOOM LINK"/><Inp k="homegroup_location" placeholder="https://zoom.us/j/…"/>
          </> : <>
            <Lbl t="LOCATION / ADDRESS"/><Inp k="homegroup_location" placeholder="123 Main St, City, State"/>
          </>}
          <Lbl t="NOTES" sub="(optional)"/>
          <textarea rows={2} value={P.homegroup_notes||''} onChange={e=>set('homegroup_notes',e.target.value)} style={{ resize:'vertical' }}/>
        </div>

        {/* Programs 2 & 3 */}
        {[2,3].map(n=>(
          <div key={n} className="card" style={{ marginBottom:12 }}>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1 }}>PROGRAM {n} <span style={{ color:'rgba(251,250,244,.2)' }}>(optional)</span></p>
            <select value={P[`program_${n}`]||''} onChange={e=>set(`program_${n}`,e.target.value)} style={{ marginTop:6, marginBottom:10 }}>
              <option value="">Select program…</option>
              {PROGRAMS.map(p=><option key={p} value={p}>{p}</option>)}
            </select>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6 }}>SOBRIETY DATE <span style={{ color:'rgba(251,250,244,.2)' }}>(private)</span></p>
            <input type="date" value={P[`program_${n}_date`]||''} onChange={e=>set(`program_${n}_date`,e.target.value||null)}/>
          </div>
        ))}

        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-end', marginTop:16 }}>
          <Lbl t="RECOVERY BIO" sub="(optional, max 500 chars)"/>
          <VisToggle k="show_recovery_bio" P={P} set={set}/>
        </div>
        <textarea rows={5} value={P.recovery_bio||''} onChange={e=>set('recovery_bio',e.target.value)} placeholder="Share what brought you here, what keeps you going…" style={{ resize:'vertical' }}/>
        <p style={{ fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', textAlign:'right', marginTop:4 }}>{(P.recovery_bio||'').length}/500</p>
      </>}

      {/* ── GOALS ── */}
      {tab==='goals' && <>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.7, marginBottom:4 }}>
          Select the areas of your life you want to focus on in recovery.
        </p>
        <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', lineHeight:1.6, marginBottom:20 }}>
          Tap any area to expand it and choose specific topics. Select as many as feel true.
        </p>
        {WELLNESS_AREAS.map(area=>(
          <WellnessArea key={area.key} area={area} selectedTopics={P.wellness_topics||[]} onToggle={t=>toggleList('wellness_topics',t)}/>
        ))}
      </>}

      {/* ── CALENDAR ── */}
      {tab==='calendar' && <>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', lineHeight:1.7, marginBottom:16 }}>
          Control what the community sees on their calendar. Only members can see these celebrations.
        </p>
        <div className="card" style={{ marginBottom:12 }}>
          <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
            <span style={{ fontSize:14, color:'rgba(251,250,244,.75)' }}>🎂 Birthday</span>
            <button onClick={()=>set('show_birthday',!P.show_birthday)}
              style={{ fontSize:12, fontFamily:'var(--font-ui)', padding:'5px 14px', borderRadius:20, background:P.show_birthday?'rgba(255,20,147,.18)':'rgba(255,255,255,.07)', border:`1px solid ${P.show_birthday?'rgba(255,20,147,.35)':'rgba(255,255,255,.12)'}`, color:P.show_birthday?'var(--pink)':'rgba(251,250,244,.45)', cursor:'pointer' }}>
              {P.show_birthday?'Visible to Members':'Hidden'}
            </button>
          </div>
          <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginTop:4 }}>Show my birthday on the community calendar</p>
          {P.show_birthday&&(
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:12, paddingTop:12, borderTop:'1px solid rgba(255,255,255,.06)' }}>
              <span style={{ fontSize:13, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)' }}>Show my age on my birthday</span>
              <button onClick={()=>set('show_birth_year',!P.show_birth_year)}
                style={{ fontSize:12, fontFamily:'var(--font-ui)', padding:'5px 14px', borderRadius:20, background:P.show_birth_year?'rgba(255,20,147,.18)':'rgba(255,255,255,.07)', border:`1px solid ${P.show_birth_year?'rgba(255,20,147,.35)':'rgba(255,255,255,.12)'}`, color:P.show_birth_year?'var(--pink)':'rgba(251,250,244,.45)', cursor:'pointer' }}>
                {P.show_birth_year?'Showing Age':'Hidden'}
              </button>
            </div>
          )}
          {!P.birth_date&&<p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', marginTop:8, fontStyle:'italic' }}>Add your date of birth on the Identity tab first.</p>}
        </div>

        <div className="card" style={{ marginBottom:12 }}>
          <p style={{ fontSize:14, color:'rgba(251,250,244,.75)', marginBottom:6 }}>🏅 Sobriety Anniversary</p>
          {!P.program_1&&!P.program_1_date ? (
            <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>Add a recovery program on the Recovery tab first.</p>
          ) : <>
            <p style={{ fontSize:12, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:12 }}>
              Choose one program to celebrate. Members will see your name, program, and anniversary.
            </p>
            <select value={P.cal_sobriety_program||''} onChange={e=>set('cal_sobriety_program',e.target.value)}>
              <option value="">Don't show a sobriety anniversary</option>
              {[1,2,3].filter(n=>P[`program_${n}`]).map(n=>(
                <option key={n} value={String(n)}>{P[`program_${n}`]}</option>
              ))}
            </select>
            {P.cal_sobriety_program&&(
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginTop:12 }}>
                <span style={{ fontSize:13, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)' }}>Show years sober on calendar</span>
                <button onClick={()=>set('show_sobriety_years',!P.show_sobriety_years)}
                  style={{ fontSize:12, fontFamily:'var(--font-ui)', padding:'5px 14px', borderRadius:20, background:P.show_sobriety_years?'rgba(255,20,147,.18)':'rgba(255,255,255,.07)', border:`1px solid ${P.show_sobriety_years?'rgba(255,20,147,.35)':'rgba(255,255,255,.12)'}`, color:P.show_sobriety_years?'var(--pink)':'rgba(251,250,244,.45)', cursor:'pointer' }}>
                  {P.show_sobriety_years?'Showing Years':'Hidden'}
                </button>
              </div>
            )}
          </>}
        </div>

        <div className="card" style={{ background:'rgba(255,255,255,.02)' }}>
          <p style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', lineHeight:1.65 }}>
            Where is the community calendar? Tap the <span style={{ color:'var(--pink)' }}>📅 Calendar</span> tab in the main navigation to see all member celebrations.
          </p>
        </div>
      </>}

      {/* ── PREVIEW ── */}
      {tab==='preview' && (() => {
        const show = (k) => P[k] !== false
        const programs = [1,2,3].filter(n=>P[`program_${n}`]).map(n=>({ name:P[`program_${n}`], date:P[`program_${n}_date`] }))
        const pets = parsePets(P.pets)
        const langs = [...new Set([...(P.spoken_languages||[]), ...(P.written_languages||[])])]
        return (
          <div>
            <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', lineHeight:1.65, marginBottom:20, fontStyle:'italic' }}>
              This is what other members see when they tap your name in the Members directory.
            </p>

            {/* Profile card preview */}
            <div style={{ background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,20,147,.15)', borderRadius:14, padding:24, marginBottom:16 }}>

              {/* Avatar + name */}
              <div style={{ textAlign:'center', marginBottom:20 }}>
                <div style={{ width:72, height:72, borderRadius:'50%', background:'rgba(255,20,147,.12)', border:'2px solid rgba(255,20,147,.3)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:26, fontFamily:'var(--font-ui)', fontWeight:700, color:'var(--pink)', margin:'0 auto 12px', overflow:'hidden' }}>
                  {avatarUrl ? <img src={avatarUrl} alt="" style={{ width:72, height:72, objectFit:'cover' }}/> : (P.display_name||user.email||'?')[0].toUpperCase()}
                </div>
                <h3 style={{ fontSize:19, fontWeight:400, marginBottom:8 }}>{P.display_name || user.email.split('@')[0]}</h3>
                {show('show_pronouns') && P.pronouns && (
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', marginBottom:8 }}>{P.pronouns}</p>
                )}
                {show('show_location') && P.city && (
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)' }}>📍 {P.city}</p>
                )}
              </div>

              {/* Programs */}
              {programs.length > 0 && (
                <div style={{ marginBottom:14 }}>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>RECOVERY</p>
                  {programs.map((pg, i) => (
                    <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'8px 0', borderBottom:'1px solid rgba(255,255,255,.05)' }}>
                      <span style={{ fontSize:13, color:'rgba(251,250,244,.7)' }}>{pg.name}</span>
                      {pg.date && <span style={{ fontSize:12, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
                        Since {new Date(pg.date+'T00:00:00').toLocaleDateString('en-US',{month:'short',year:'numeric'})}
                      </span>}
                    </div>
                  ))}
                </div>
              )}

              {/* Recovery bio */}
              {show('show_recovery_bio') && P.recovery_bio && (
                <div style={{ marginBottom:14 }}>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>ABOUT</p>
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.7)', lineHeight:1.75, fontStyle:'italic' }}>"{P.recovery_bio}"</p>
                </div>
              )}

              {/* SOGI */}
              {(show('show_gender_identity') && P.gender_identity) || (show('show_sexual_orientation') && P.sexual_orientation) || (show('show_ethnicity') && P.ethnicity) ? (
                <div style={{ marginBottom:14 }}>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>IDENTITY</p>
                  <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
                    {show('show_gender_identity') && P.gender_identity && <span style={{ padding:'5px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)', color:'rgba(251,250,244,.7)' }}>{P.gender_identity}</span>}
                    {show('show_sexual_orientation') && P.sexual_orientation && <span style={{ padding:'5px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)', color:'rgba(251,250,244,.7)' }}>{P.sexual_orientation}</span>}
                    {show('show_ethnicity') && P.ethnicity && <span style={{ padding:'5px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.1)', color:'rgba(251,250,244,.6)' }}>{P.ethnicity}</span>}
                  </div>
                </div>
              ) : null}

              {/* Languages */}
              {show('show_languages') && langs.length > 0 && (
                <div style={{ marginBottom:14 }}>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>LANGUAGES</p>
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.6)' }}>{langs.join(' · ')}</p>
                </div>
              )}

              {/* Pets */}
              {show('show_pets') && pets.length > 0 && (
                <div style={{ marginBottom:14 }}>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>PETS</p>
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.6)' }}>{pets.map(p => p.name ? `${p.type} named ${p.name}` : p.type).join(', ')}</p>
                </div>
              )}

              {/* Member since */}
              {member?.membership_start_date && (
                <p style={{ fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', textAlign:'center', marginTop:8 }}>
                  Member since {new Date(member.membership_start_date).toLocaleDateString('en-US',{month:'long',year:'numeric'})}
                </p>
              )}
            </div>

            <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', textAlign:'center', lineHeight:1.7 }}>
              Toggle visibility for each field in the Basics, Identity, and Recovery tabs.
            </p>
          </div>
        )
      })()}

      {/* ── ACCOUNT ── */}
      {tab==='account' && <>
        <div style={{ marginBottom:24 }}>
          {[
            ['Email', user.email],
            ['Membership', member?.membership_tier==='web_app'?'Web + App':'Web'],
            ['Member of Our Community Since', member?.membership_start_date ? new Date(member.membership_start_date).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'}) : '—'],
            ['Status', '● Active'],
            ['Day', `${dayNum} of 365`],
          ].map(([label, value]) => (
            <div key={label} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'12px 0', borderBottom:'1px solid rgba(255,255,255,.06)' }}>
              <span style={{ fontSize:13, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.45)' }}>{label}</span>
              <span style={{ fontSize:13, fontFamily:'var(--font-ui)', color: label==='Status' ? 'var(--lime)' : 'var(--cream)' }}>{value}</span>
            </div>
          ))}
        </div>

        <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:12 }}>YOUR REFERRAL IMPACT</p>
        {referrals.length === 0 ? (
          <p style={{ fontSize:13, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', fontStyle:'italic', marginBottom:20 }}>
            No referrals yet. Share your invite link from the 🌈 Invite tab.
          </p>
        ) : (
          <div style={{ marginBottom:20 }}>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', marginBottom:10 }}>REFERRAL DETAILS</p>
            {referrals.map(r => (
              <div key={r.id} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'10px 0', borderBottom:'1px solid rgba(255,255,255,.05)' }}>
                <span style={{ fontSize:13, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.6)' }}>{r.referred_email||'Member'}</span>
                <span style={{ fontSize:12, fontFamily:'var(--font-ui)', color: refStatusColor[r.status]||'rgba(251,250,244,.4)' }}>
                  {refStatusLabel[r.status]||r.status}
                </span>
              </div>
            ))}
          </div>
        )}

        <button onClick={()=>supabase.auth.signOut()}
          style={{ width:'100%', padding:'12px', borderRadius:8, background:'rgba(255,255,255,.05)', border:'1px solid var(--border)', color:'rgba(251,250,244,.5)', fontSize:14, fontFamily:'var(--font-ui)', cursor:'pointer', marginTop:8 }}>
          Sign Out
        </button>
      </>}

      </div>{/* end padding wrapper */}

      {tab!=='account' && (
        <div style={{ padding:'24px 16px 0' }}>
          {msg&&<p style={{ fontSize:13, fontFamily:'var(--font-ui)', textAlign:'center', marginBottom:12, color:msg.startsWith('Error')?'var(--pink)':'var(--lime)' }}>{msg}</p>}
          <button className="btn-primary" style={{ width:'100%', padding:14 }} onClick={save} disabled={saving||!dirty}>
            {saving?'Saving…':'Save Changes'}
          </button>
        </div>
      )}
    </div>
  )
}
