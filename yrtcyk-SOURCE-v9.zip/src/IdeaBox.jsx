import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

// ─── Site Areas — the clickable "sitemap" ─────────────────────────────────────
const AREAS = [
  { id:'daily',     emoji:'✅', label:'The Daily Practice',       sub:'Attestation, check-ins, scoring, all 14 items' },
  { id:'heroes',    emoji:'⭐', label:'Heroes Gallery',           sub:'People, Places, Things — the wall of love' },
  { id:'blog',      emoji:'📝', label:'The Blog',                 sub:'Posts, comments, community voice' },
  { id:'members',   emoji:'👥', label:'Member Directory',         sub:'Who we are, how we show up' },
  { id:'calendar',  emoji:'📅', label:'Calendar & Meeting',       sub:'Events, Zoom widget, daily meeting' },
  { id:'invite',    emoji:'🌈', label:'Invite & Referral',        sub:'Bringing your people into the room' },
  { id:'wom',       emoji:'💋', label:'Word of Mouth',            sub:'Favorite businesses, places, recommendations' },
  { id:'profile',   emoji:'👤', label:'My Profile',               sub:'Who I am here, my story, my preferences' },
  { id:'emails',    emoji:'📧', label:'Email Reminders',          sub:'Morning, evening, and meeting nudges' },
  { id:'recovery',  emoji:'🔵', label:'Recovery Resources',       sub:'Meeting finder, homegroup, step work' },
  { id:'app',       emoji:'📱', label:'The iOS App (Future)',      sub:'Alerts, push notifications, the next chapter' },
  { id:'new',       emoji:'✨', label:'Something Entirely New',   sub:'A vision that doesn\'t fit any box above' },
]

const TYPES = [
  { id:'idea',    emoji:'💡', label:'I Have an Idea' },
  { id:'bug',     emoji:'🐛', label:'Something\'s Broken' },
  { id:'love',    emoji:'💗', label:'Love Note' },
  { id:'dream',   emoji:'🔮', label:'Wild Dream' },
]

export default function IdeaBox({ user }) {
  const [member, setMember]   = useState(null)
  const [area, setArea]       = useState(null)
  const [type, setType]       = useState(null)
  const [message, setMessage] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [submitted, setSubmitted]   = useState(false)
  const [myIdeas, setMyIdeas]       = useState([])
  const [view, setView]             = useState('submit') // submit | mine

  useEffect(() => { load() }, [])

  async function load() {
    const { data: m } = await supabase.from('members').select('id,display_name,email').eq('email', user.email).single()
    if (m) {
      setMember(m)
      const { data } = await supabase.from('feedback').select('*').eq('member_id', m.id).order('created_at', { ascending: false })
      setMyIdeas(data || [])
    }
  }

  async function submit(e) {
    e.preventDefault()
    if (!member || !area || !type || !message.trim()) return
    setSubmitting(true)
    const areaObj = AREAS.find(a => a.id === area)
    const typeObj = TYPES.find(t => t.id === type)
    await supabase.from('feedback').insert({
      member_id:           member.id,
      member_display_name: member.display_name || 'A Member',
      area:                areaObj?.label || area,
      type:                typeObj?.label || type,
      message:             message.trim(),
    })
    setSubmitting(false)
    setSubmitted(true)
    setArea(null); setType(null); setMessage('')
    load()
    setTimeout(() => setSubmitted(false), 4000)
  }

  return (
    <div style={{ paddingTop:20, paddingBottom:48 }}>

      {/* Header */}
      <div style={{ textAlign:'center', marginBottom:24 }}>
        <div style={{ fontSize:52, lineHeight:1, marginBottom:8 }}>🪄</div>
        <h2 style={{ fontSize:22, fontWeight:500, color:'var(--cream)', marginBottom:6 }}>The Idea Box</h2>
        <div style={{ width:40, height:2, background:'var(--pink)', margin:'0 auto 12px', borderRadius:2 }}/>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.7, maxWidth:420, margin:'0 auto' }}>
          This platform was built for you. If you dream it, write it here.
          Every single idea gets read — by a real person who genuinely cares.
        </p>
      </div>

      {/* Tab toggle */}
      <div style={{ display:'flex', gap:8, marginBottom:24 }}>
        <button onClick={() => setView('submit')}
          style={{ flex:1, padding:'10px', borderRadius:8, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer',
            background: view==='submit' ? 'var(--pink)' : 'rgba(255,255,255,.06)',
            color: view==='submit' ? '#fff' : 'rgba(251,250,244,.55)',
            border: `1px solid ${view==='submit' ? 'var(--pink)' : 'rgba(255,255,255,.1)'}` }}>
          ✍️ Submit an Idea
        </button>
        <button onClick={() => setView('mine')}
          style={{ flex:1, padding:'10px', borderRadius:8, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer',
            background: view==='mine' ? 'var(--pink)' : 'rgba(255,255,255,.06)',
            color: view==='mine' ? '#fff' : 'rgba(251,250,244,.55)',
            border: `1px solid ${view==='mine' ? 'var(--pink)' : 'rgba(255,255,255,.1)'}` }}>
          📬 My Submissions {myIdeas.length > 0 && `(${myIdeas.length})`}
        </button>
      </div>

      {/* ── MY SUBMISSIONS VIEW ── */}
      {view === 'mine' && (
        <div>
          {myIdeas.length === 0
            ? <div className="card" style={{ textAlign:'center', padding:40 }}>
                <p style={{ fontSize:32, marginBottom:12 }}>📭</p>
                <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14 }}>No ideas submitted yet.</p>
                <p style={{ color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', fontSize:12, marginTop:6 }}>Every big thing starts with one idea.</p>
              </div>
            : myIdeas.map(idea => (
                <div key={idea.id} className="card" style={{ marginBottom:10 }}>
                  <div style={{ display:'flex', gap:8, alignItems:'center', marginBottom:6 }}>
                    <span style={{ fontSize:12, background:'rgba(255,20,147,.12)', color:'var(--pink)', padding:'3px 8px', borderRadius:20, fontFamily:'var(--font-ui)' }}>{idea.type}</span>
                    <span style={{ fontSize:12, background:'rgba(25,229,94,.08)', color:'var(--lime)', padding:'3px 8px', borderRadius:20, fontFamily:'var(--font-ui)' }}>{idea.area}</span>
                  </div>
                  <p style={{ fontSize:13, color:'var(--cream)', lineHeight:1.6 }}>{idea.message}</p>
                  <p style={{ fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', marginTop:8 }}>
                    {new Date(idea.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                  </p>
                </div>
              ))
          }
        </div>
      )}

      {/* ── SUBMIT VIEW ── */}
      {view === 'submit' && (
        <form onSubmit={submit}>

          {/* Confirmation */}
          {submitted && (
            <div style={{ background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.3)', borderRadius:10, padding:'14px 16px', marginBottom:20, textAlign:'center' }}>
              <p style={{ fontSize:22, marginBottom:4 }}>🪄</p>
              <p style={{ fontSize:14, color:'var(--lime)', fontFamily:'var(--font-ui)' }}>Received. Thank you — this matters.</p>
            </div>
          )}

          {/* Step 1 — Area */}
          <div style={{ marginBottom:24 }}>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:12 }}>
              STEP 1 — WHERE IN THE PLATFORM?
            </p>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
              {AREAS.map(a => (
                <button type="button" key={a.id} onClick={() => setArea(a.id)}
                  style={{ padding:'12px', borderRadius:10, textAlign:'left', cursor:'pointer',
                    background: area===a.id ? 'rgba(255,20,147,.15)' : 'rgba(255,255,255,.04)',
                    border: `1px solid ${area===a.id ? 'rgba(255,20,147,.5)' : 'rgba(255,255,255,.08)'}`,
                    transition:'all .15s' }}>
                  <div style={{ fontSize:20, marginBottom:4 }}>{a.emoji}</div>
                  <p style={{ fontSize:12, fontWeight:600, color: area===a.id ? 'var(--pink)' : 'var(--cream)', marginBottom:2, lineHeight:1.3 }}>{a.label}</p>
                  <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', lineHeight:1.4 }}>{a.sub}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2 — Type */}
          <div style={{ marginBottom:20 }}>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10 }}>
              STEP 2 — WHAT KIND OF SUBMISSION IS THIS?
            </p>
            <div style={{ display:'flex', gap:8, flexWrap:'wrap' }}>
              {TYPES.map(t => (
                <button type="button" key={t.id} onClick={() => setType(t.id)}
                  style={{ padding:'9px 16px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer',
                    background: type===t.id ? 'rgba(255,20,147,.2)' : 'rgba(255,255,255,.06)',
                    color: type===t.id ? 'var(--pink)' : 'rgba(251,250,244,.6)',
                    border: `1px solid ${type===t.id ? 'rgba(255,20,147,.4)' : 'rgba(255,255,255,.1)'}` }}>
                  {t.emoji} {t.label}
                </button>
              ))}
            </div>
          </div>

          {/* Step 3 — The big idea */}
          {area && type && (
            <div style={{ marginBottom:20 }}>
              <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8 }}>
                STEP 3 — TELL ME EVERYTHING
              </p>
              <div style={{ fontSize:12, color:'rgba(255,20,147,.7)', fontFamily:'var(--font-ui)', marginBottom:8, padding:'8px 12px', background:'rgba(255,20,147,.06)', borderRadius:6, border:'1px solid rgba(255,20,147,.12)' }}>
                📍 {AREAS.find(a=>a.id===area)?.label} · {TYPES.find(t=>t.id===type)?.label}
              </div>
              <textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Don't hold back. What do you see? What would make this better? What's missing? What do you love? Give it to me straight..."
                rows={6}
                required
                style={{ width:'100%', resize:'vertical' }}
              />
              <p style={{ fontSize:11, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)', marginTop:5 }}>
                Every submission is read personally. No bots. No filters.
              </p>
            </div>
          )}

          {area && type && message.trim() && (
            <button type="submit" className="btn-primary" style={{ width:'100%' }} disabled={submitting}>
              {submitting ? 'Sending...' : '🪄 Submit My Idea'}
            </button>
          )}

        </form>
      )}
    </div>
  )
}
