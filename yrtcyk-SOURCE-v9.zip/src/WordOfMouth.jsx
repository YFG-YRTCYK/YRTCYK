import { useState, useEffect, useRef } from 'react'
import { supabase } from './supabaseClient'

// ─── Google Places Config ─────────────────────────────────────────────────────
const GOOGLE_MAPS_KEY = 'AIzaSyAh1IwlpWmi9DiKd2-HJRW_1rrhY3z1dzw'

// ─── Categories ───────────────────────────────────────────────────────────────
const CATEGORIES = [
  { id:'food',       label:'Food & Drink',        emoji:'🍔' },
  { id:'health',     label:'Health & Wellness',   emoji:'💆' },
  { id:'services',   label:'Services',            emoji:'✂️' },
  { id:'hotels',     label:'Hotels & Travel',     emoji:'🏨' },
  { id:'auto',       label:'Auto',                emoji:'🚗' },
  { id:'shopping',   label:'Shopping',            emoji:'🛍️' },
  { id:'entertainment', label:'Entertainment',    emoji:'🎭' },
  { id:'recovery',   label:'Recovery Resources',  emoji:'🔵' },
  { id:'other',      label:'Other',               emoji:'✨' },
]



export default function WordOfMouth({ user }) {
  const [recs, setRecs]           = useState([])
  const [loading, setLoading]     = useState(true)
  const [view, setView]           = useState('gallery') // gallery | submit
  const [catFilter, setCatFilter] = useState('all')
  const [member, setMember]       = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [submitMsg, setSubmitMsg]   = useState('')

  // Form state
  const [bizName, setBizName]     = useState('')
  const [category, setCategory]   = useState('')
  const [city, setCity]           = useState('')
  const [description, setDescription] = useState('')
  const [whyRec, setWhyRec]       = useState('')
  const [photoUrl, setPhotoUrl]   = useState('')
  const [websiteUrl, setWebsiteUrl] = useState('')
  const [address, setAddress]       = useState('')
  const [placeId, setPlaceId]       = useState('')
  const autocompleteRef             = useRef(null)
  const bizInputRef                 = useRef(null)
  const [uploading, setUploading] = useState(false)
  const fileRef = useRef()

  useEffect(() => { loadAll() }, [])

  // ── Google Places: init when submit view opens, clean up when it closes ──
  useEffect(() => {
    if (view !== 'submit') {
      // Clean up so it re-inits fresh next time
      if (autocompleteRef.current && window.google?.maps?.event) {
        window.google.maps.event.clearInstanceListeners(autocompleteRef.current)
      }
      autocompleteRef.current = null
      return
    }

    function attachAutocomplete() {
      if (!bizInputRef.current || autocompleteRef.current) return
      const ac = new window.google.maps.places.Autocomplete(bizInputRef.current, {
        types: ['establishment'],
        fields: ['name','formatted_address','website','address_components','place_id']
      })
      ac.addListener('place_changed', () => {
        const place = ac.getPlace()
        if (!place.name) return
        bizInputRef.current.value = place.name
        const cityComp  = place.address_components?.find(c => c.types.includes('locality') || c.types.includes('sublocality'))
        const stateComp = place.address_components?.find(c => c.types.includes('administrative_area_level_1'))
        if (cityComp) setCity(stateComp ? cityComp.long_name + ', ' + stateComp.short_name : cityComp.long_name)
        if (place.website)          setWebsiteUrl(place.website)
        if (place.formatted_address) setAddress(place.formatted_address)
        if (place.place_id)         setPlaceId(place.place_id)
      })
      autocompleteRef.current = ac
    }

    // If Places already loaded, attach immediately
    if (window.google?.maps?.places) {
      setTimeout(attachAutocomplete, 50)
      return
    }

    // If script already injected, wait for it
    if (document.getElementById('gmap-script')) {
      const poll = setInterval(() => {
        if (window.google?.maps?.places) { clearInterval(poll); attachAutocomplete() }
      }, 100)
      return
    }

    // First time — inject script
    const s = document.createElement('script')
    s.id  = 'gmap-script'
    s.src = 'https://maps.googleapis.com/maps/api/js?key=' + GOOGLE_MAPS_KEY + '&libraries=places'
    s.async = true
    s.onload = () => setTimeout(attachAutocomplete, 50)
    document.head.appendChild(s)
  }, [view])



  async function loadAll() {
    setLoading(true)
    const { data: m } = await supabase
      .from('members')
      .select('id, display_name, email')
      .eq('email', user.email)
      .single()
    if (m) setMember(m)

    const { data } = await supabase
      .from('word_of_mouth')
      .select('*')
      .order('created_at', { ascending: false })
    setRecs(data || [])
    setLoading(false)
  }

  async function uploadPhoto(file) {
    if (!member) return null
    const ext = file.name.split('.').pop()
    const path = `wom/${member.id}/${Date.now()}.${ext}`
    const { error } = await supabase.storage.from('hero-photos').upload(path, file, { upsert: false })
    if (error) { console.error(error); return null }
    const { data: { publicUrl } } = supabase.storage.from('hero-photos').getPublicUrl(path)
    return publicUrl
  }

  async function handlePhoto(e) {
    const file = e.target.files?.[0]
    if (!file) return
    setUploading(true)
    const url = await uploadPhoto(file)
    if (url) setPhotoUrl(url)
    setUploading(false)
    e.target.value = ''
  }

  async function submitRec(e) {
    e.preventDefault()
    const finalBizName = (bizInputRef.current?.value || '').trim() || bizName.trim()
    if (!member || !finalBizName || !category || !city.trim()) return
    setSubmitting(true)
    try {
      const { error } = await supabase.from('word_of_mouth').insert({
        member_id:            member.id,
        member_display_name:  member.display_name || 'A Member',
        business_name:        finalBizName,
        category,
        city:                 city.trim(),
        description:          description.trim(),
        why_recommend:        whyRec.trim(),
        photo_url:            photoUrl || null,
        website_url:          websiteUrl.trim() || null,
        address:              address.trim() || null,
        place_id:             placeId || null,
      })
      if (error) throw error
      setSubmitMsg('Added! Your recommendation is live.')
      setBizName(''); if (bizInputRef.current) bizInputRef.current.value = ''
      setCategory(''); setCity(''); setDescription('')
      setWhyRec(''); setPhotoUrl('')
      setWebsiteUrl('')
      setAddress('')
      setPlaceId('')
      setView('gallery')
      loadAll()
    } catch(err) {
      setSubmitMsg('Error: ' + err.message)
    }
    setSubmitting(false)
  }

  const filtered = catFilter === 'all' ? recs : recs.filter(r => r.category === catFilter)
  const catObj = (id) => CATEGORIES.find(c => c.id === id) || { emoji:'✨', label: id }

  // ── SUBMIT VIEW ──
  if (view === 'submit') {
    return (
      <div style={{ paddingTop: 20, paddingBottom: 48 }}>
        <button onClick={() => setView('gallery')}
          style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:20 }}>
          ← Back
        </button>
        <h2 style={{ fontSize:20, fontWeight:500, marginBottom:4 }}>Add a Recommendation</h2>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:24, lineHeight:1.6 }}>
          Share a business that has earned your trust. If it's good enough to tell a friend, it belongs here.
        </p>

        <form onSubmit={submitRec}>
          {/* Business Name */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>BUSINESS NAME *</label>
            <input ref={bizInputRef}
              placeholder="Start typing a business name…"
              style={{ width:'100%' }}
              autoComplete="new-password"
              defaultValue=""/>
            <p style={{ fontSize:11, color:'rgba(25,229,94,.45)', fontFamily:'var(--font-ui)', marginTop:5 }}>
              ✨ Google will suggest real businesses as you type — select one to auto-fill everything.
            </p>
          </div>

          {/* Category */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:8 }}>CATEGORY *</label>
            <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
              {CATEGORIES.map(c => (
                <button type="button" key={c.id} onClick={() => setCategory(c.id)}
                  style={{ padding:'7px 14px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer',
                    background: category === c.id ? 'rgba(255,20,147,.2)' : 'rgba(255,255,255,.06)',
                    color: category === c.id ? 'var(--pink)' : 'rgba(251,250,244,.55)',
                    border: `1px solid ${category === c.id ? 'rgba(255,20,147,.4)' : 'rgba(255,255,255,.1)'}` }}>
                  {c.emoji} {c.label}
                </button>
              ))}
            </div>
          </div>

          {/* City */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>CITY / NEIGHBORHOOD *</label>
            <input value={city} onChange={e=>setCity(e.target.value)}
              placeholder="e.g. Palm Springs, CA" required style={{ width:'100%' }}/>
          </div>

          {/* Website URL */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>WEBSITE URL (OPTIONAL)</label>
            <input value={websiteUrl} onChange={e=>setWebsiteUrl(e.target.value)}
              type="url" placeholder="https://www.example.com"
              style={{ width:'100%' }}/>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', marginTop:5 }}>
              When you add a link, members get a one-click button directly to this business.
            </p>
          </div>

          {/* Description */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>WHAT IS IT?</label>
            <textarea value={description} onChange={e=>setDescription(e.target.value)}
              placeholder="A quick description of the place..."
              rows={2} style={{ width:'100%', resize:'vertical' }}/>
          </div>

          {/* Why Recommend */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>WHY DO YOU RECOMMEND IT?</label>
            <textarea value={whyRec} onChange={e=>setWhyRec(e.target.value)}
              placeholder="What made this place earn a spot in your word of mouth..."
              rows={3} style={{ width:'100%', resize:'vertical' }}/>
          </div>

          {/* Photo */}
          <div style={{ marginBottom:24 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:8 }}>PHOTO (OPTIONAL)</label>
            {photoUrl
              ? <div style={{ position:'relative', width:'100%', height:140, borderRadius:10, overflow:'hidden', marginBottom:8 }}>
                  <img src={photoUrl} alt="" style={{ width:'100%', height:'100%', objectFit:'cover' }}/>
                  <button type="button" onClick={() => setPhotoUrl('')}
                    style={{ position:'absolute', top:8, right:8, background:'rgba(0,0,0,.6)', color:'#fff', border:'none', borderRadius:6, padding:'4px 8px', fontSize:11, cursor:'pointer' }}>
                    Remove
                  </button>
                </div>
              : <button type="button" onClick={() => fileRef.current?.click()}
                  style={{ width:'100%', padding:'20px', borderRadius:10, border:'1px dashed rgba(255,255,255,.15)', background:'rgba(255,255,255,.03)', color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:13, cursor:'pointer' }}>
                  {uploading ? 'Uploading…' : '📷 Add a photo'}
                </button>
            }
            <input ref={fileRef} type="file" accept="image/*" onChange={handlePhoto} style={{ display:'none' }}/>
          </div>

          {submitMsg && (
            <p style={{ fontSize:13, fontFamily:'var(--font-ui)', color: submitMsg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)', marginBottom:12 }}>
              {submitMsg}
            </p>
          )}
          <button type="submit" className="btn-primary" style={{ width:'100%' }} disabled={submitting || !category || !city.trim()}>
            {submitting ? 'Saving…' : 'Add Recommendation'}
          </button>
        </form>
      </div>
    )
  }

  // ── GALLERY VIEW ──
  return (
    <div style={{ paddingTop: 16, paddingBottom: 48 }}>

      {/* Header — Lips + Title */}
      <div style={{ textAlign:'center', marginBottom:8, paddingTop:8 }}>
        <div style={{ fontSize:64, lineHeight:1, marginBottom:4 }}>💋</div>
        <h2 style={{ fontSize:22, fontWeight:500, color:'var(--cream)', marginTop:10, marginBottom:4, letterSpacing:0.5 }}>
          By Word of Mouth
        </h2>
        <div style={{ width:48, height:2, background:'var(--pink)', margin:'0 auto 16px', borderRadius:2 }}/>
      </div>

      {/* Story paragraph */}
      <div className="card" style={{ marginBottom:20, background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.08)', padding:'16px 18px' }}>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.65)', lineHeight:1.8, fontStyle:'italic' }}>
          It started the way most good things do — with a group of people showing up for each other.
          On March 13, 2020, a meeting was born built entirely on one idea: <strong style={{ color:'var(--pink)', fontStyle:'normal' }}>You aRe The Company You Keep</strong>.
          That meeting hasn't missed a single day since. The people in that room — then and now — are living proof
          that recovery is not a solo sport. This platform grew from the same belief. Our Heroes gallery celebrates
          the people, places, and things that changed our lives. Our Recovery tab connects us to the meetings and
          communities that hold us. And our profiles let us show a little more of who we really are.
        </p>
        <p style={{ fontSize:13, color:'rgba(251,250,244,.65)', lineHeight:1.8, fontStyle:'italic', marginTop:10 }}>
          So it only makes sense that when you find a barber who gets it, a restaurant that feels like home,
          a hotel that treated you like family, or a doctor who actually listens — you share it here.
          Because the company we keep extends beyond the rooms. <strong style={{ color:'var(--lime)', fontStyle:'normal' }}>Support the businesses that support people like us.</strong>
        </p>
      </div>

      {/* Action bar */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:16 }}>
        <p style={{ fontSize:12, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>
          {recs.length} recommendation{recs.length !== 1 ? 's' : ''}
        </p>
        <button onClick={() => { setSubmitMsg(''); setView('submit') }} className="btn-primary" style={{ fontSize:12, padding:'7px 14px' }}>
          + Add a Place
        </button>
      </div>

      {/* Category filter */}
      <div style={{ display:'flex', gap:6, marginBottom:16, overflowX:'auto', paddingBottom:4 }}>
        <button onClick={() => setCatFilter('all')}
          style={{ padding:'6px 14px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:11, whiteSpace:'nowrap', cursor:'pointer',
            background: catFilter==='all' ? 'var(--pink)' : 'rgba(255,255,255,.07)',
            color: catFilter==='all' ? '#fff' : 'rgba(251,250,244,.55)',
            border: `1px solid ${catFilter==='all' ? 'var(--pink)' : 'rgba(255,255,255,.1)'}` }}>
          All
        </button>
        {CATEGORIES.map(c => (
          <button key={c.id} onClick={() => setCatFilter(c.id)}
            style={{ padding:'6px 14px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:11, whiteSpace:'nowrap', cursor:'pointer',
              background: catFilter===c.id ? 'var(--pink)' : 'rgba(255,255,255,.07)',
              color: catFilter===c.id ? '#fff' : 'rgba(251,250,244,.55)',
              border: `1px solid ${catFilter===c.id ? 'var(--pink)' : 'rgba(255,255,255,.1)'}` }}>
            {c.emoji} {c.label}
          </button>
        ))}
      </div>

      {loading && <div className="spinner"/>}

      {!loading && filtered.length === 0 && (
        <div className="card" style={{ textAlign:'center', padding:48 }}>
          <div style={{ fontSize:40, marginBottom:12 }}>💋</div>
          <p style={{ fontSize:15, color:'rgba(251,250,244,.5)', marginBottom:6 }}>
            {catFilter === 'all' ? 'No recommendations yet.' : `No ${catObj(catFilter).label} recommendations yet.`}
          </p>
          <p style={{ fontSize:13, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>
            Be the first to share a place worth knowing.
          </p>
        </div>
      )}

      {/* Cards */}
      <div style={{ display:'flex', flexDirection:'column', gap:10 }}>
        {filtered.map(r => {
          const cat = catObj(r.category)
          const mapsUrl = r.place_id
            ? `https://www.google.com/maps/place/?q=place_id:${r.place_id}`
            : `https://www.google.com/maps/search/${encodeURIComponent(r.business_name + ' ' + r.city)}`
          const hasWebsite = r.website_url && r.website_url.startsWith('http')
          const dateStr = r.created_at
            ? new Date(r.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })
            : ''
          return (
            <div key={r.id} className="card" style={{ overflow:'hidden', padding:0 }}>
              {/* Photo */}
              {r.photo_url && (
                <div style={{ width:'100%', aspectRatio:'16/9', overflow:'hidden', background:'rgba(255,255,255,.05)', borderRadius:'10px 10px 0 0' }}>
                  <img src={r.photo_url} alt="" style={{ width:'100%', height:'100%', objectFit:'cover', objectPosition:'center center' }}/>
                </div>
              )}
              <div style={{ padding:'14px 16px' }}>
                {/* Category badge */}
                <div style={{ display:'flex', alignItems:'center', gap:6, marginBottom:6 }}>
                  <span style={{ fontSize:14 }}>{cat.emoji}</span>
                  <span style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:.8, textTransform:'uppercase' }}>
                    {cat.label}
                  </span>
                  <span style={{ fontSize:10, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)' }}>·</span>
                  <span style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>{r.city}</span>
                  {r.address && (
                    <>
                      <span style={{ fontSize:10, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)' }}>·</span>
                      <span style={{ fontSize:10, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)' }}>{r.address}</span>
                    </>
                  )}
                </div>

                {/* Name */}
                <h3 style={{ fontSize:17, fontWeight:600, marginBottom: r.description ? 6 : 4 }}>
                  {r.business_name}
                </h3>

                {/* Website URL */}
          <div style={{ marginBottom:16 }}>
            <label style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, display:'block', marginBottom:6 }}>WEBSITE URL (OPTIONAL)</label>
            <input value={websiteUrl} onChange={e=>setWebsiteUrl(e.target.value)}
              type="url" placeholder="https://www.example.com"
              style={{ width:'100%' }}/>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', marginTop:5 }}>
              When you add a link, members get a one-click button directly to this business.
            </p>
          </div>

          {/* Description */}
                {r.description && (
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.55)', lineHeight:1.6, marginBottom:6 }}>
                    {r.description}
                  </p>
                )}

                {/* Why recommend */}
                {r.why_recommend && (
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.6)', fontStyle:'italic', lineHeight:1.6, marginBottom:8, borderLeft:'2px solid rgba(255,20,147,.3)', paddingLeft:10 }}>
                    "{r.why_recommend}"
                  </p>
                )}

                {/* Footer row */}
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginTop:10, gap:8 }}>
                  <p style={{ fontSize:11, color:'rgba(251,250,244,.28)', fontFamily:'var(--font-ui)', lineHeight:1.4 }}>
                    By word of mouth — <span style={{ color:'rgba(251,250,244,.4)' }}>{r.member_display_name}</span>
                    {dateStr && <span style={{ color:'rgba(251,250,244,.2)', marginLeft:6 }}>· {dateStr}</span>}
                  </p>
                  <div style={{ display:'flex', gap:6, flexShrink:0 }}>
                    {hasWebsite && (
                      <a href={r.website_url} target="_blank" rel="noopener noreferrer"
                        style={{ padding:'6px 12px', borderRadius:8, background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.25)', color:'var(--pink)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none', whiteSpace:'nowrap' }}>
                        🌐 Visit
                      </a>
                    )}
                    <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                      style={{ padding:'6px 12px', borderRadius:8, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.2)', color:'var(--lime)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none', whiteSpace:'nowrap' }}>
                      📍 Maps
                    </a>
                  </div>
                </div>
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}
