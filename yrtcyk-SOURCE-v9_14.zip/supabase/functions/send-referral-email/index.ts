// send-referral-email v5 — PRODUCTION (April 20, 2026 PM)
//
// v5 changes from v4: added a Tradition 6 / Tradition 10 disclosure block
// between the sign-off and the CAN-SPAM footer. Clarifies that YRTCYK the
// platform is a personal/commercial project under GPV Consulting, LLC and
// is not affiliated with AA or any AA fellowship. Text-only template change;
// handler logic unchanged from v4.
//
// Geo-only branded referral email sender.
// verify_jwt=false at the platform; auth is enforced ENTIRELY in this handler
// via JWT payload decode + hard email match against yourfairygodfather@me.com.
//
// Why verify_jwt=false: with verify_jwt=true, Supabase's platform-level JWT
// check was rejecting requests before this handler could run (see v1/v2).
// Moving the check into the handler both fixes that and gives us richer error
// responses when something goes wrong.
//
// Security layers (all in-handler):
//   1. Authorization header must contain a Bearer JWT
//   2. JWT payload must decode to JSON
//   3. JWT payload must contain an email claim
//   4. Email claim must equal yourfairygodfather@me.com (case-insensitive)
//   5. Rate limit: 20 successful sends per UTC calendar day
//
// NOTE on #2: we do NOT cryptographically verify the JWT signature here.
// Anyone could craft a JWT with a fake email claim. This is accepted for v9.13
// because: (a) the function URL is not public knowledge, (b) the handler does
// nothing dangerous with caller identity except gate access to Geo's own
// referral code and insert rows attributable to Geo, and (c) at worst a
// malicious caller sends invitation emails FROM Geo's domain to arbitrary
// addresses — which hurts Geo's domain reputation but doesn't compromise data.
// If this feature scales beyond 1 user, upgrade to real signature verification.

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!
const SUPABASE_SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const AUTHORIZED_EMAIL = 'yourfairygodfather@me.com'
const DAILY_SEND_LIMIT = 20

const supabaseAdmin = createClient(SUPABASE_URL, SUPABASE_SERVICE_KEY)

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  })
}

function isValidEmail(s: string): boolean {
  return typeof s === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s) && s.length <= 254
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#x27;')
}

function decodeJwtPayload(jwt: string): Record<string, unknown> | null {
  try {
    const parts = jwt.split('.')
    if (parts.length !== 3) return null
    let b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/')
    while (b64.length % 4 !== 0) b64 += '='
    return JSON.parse(atob(b64))
  } catch {
    return null
  }
}

function buildReferralEmailHtml(opts: { firstName: string; personalNote: string; referralLink: string }): string {
  const { firstName, personalNote, referralLink } = opts
  const safeFirstName = escapeHtml(firstName)
  const hasNote = personalNote.trim().length > 0
  const safeNote = hasNote ? escapeHtml(personalNote.trim()) : ''
  return [
    '<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>',
    '<body style="margin:0;padding:0;background:#01280e;font-family:Georgia,serif;">',
    '<table width="100%" cellpadding="0" cellspacing="0" style="background:#01280e;"><tr><td align="center" style="padding:40px 20px;">',
    '<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">',
    '<tr><td style="padding:0 0 32px 0;text-align:center;"><div style="font-family:system-ui,sans-serif;font-size:22px;font-weight:700;letter-spacing:6px;color:#FF1493;">YRTCYK</div><div style="font-size:12px;color:rgba(251,250,244,0.4);margin-top:4px;">You aRe The Company You Keep</div></td></tr>',
    '<tr><td style="padding:0 0 24px 0;text-align:center;"><span style="background:rgba(255,20,147,0.15);border:1px solid rgba(255,20,147,0.3);border-radius:20px;padding:6px 18px;font-family:system-ui,sans-serif;font-size:12px;font-weight:600;color:#FF1493;">🌈 A personal invitation</span></td></tr>',
    '<tr><td style="background:rgba(255,255,255,0.04);border:1px solid rgba(255,255,255,0.08);border-radius:8px;padding:36px 40px;">',
    '<p style="margin:0 0 8px 0;font-family:system-ui,sans-serif;font-size:13px;color:rgba(251,250,244,0.45);">Hello ' + safeFirstName + ' —</p>',
    '<h1 style="margin:0 0 24px 0;font-size:26px;font-weight:400;color:#fbfaf4;line-height:1.3;">Geo thought of you.</h1>',
    hasNote ? '<div style="border-left:4px solid #FF1493;padding:16px 20px;margin:0 0 24px 0;background:rgba(255,20,147,0.06);border-radius:0 6px 6px 0;"><p style="margin:0;font-size:15px;line-height:1.7;color:#fbfaf4;font-style:italic;">' + safeNote + '</p></div>' : '',
    '<p style="margin:0 0 16px 0;font-size:15px;line-height:1.75;color:rgba(251,250,244,0.8);">YRTCYK — "You aRe The Company You Keep" — is a private, LGBTQ+ affirming recovery community rooted in the 12 Steps. It\'s a paid membership, intentionally so. The people who show up have skin in the game.</p>',
    '<p style="margin:0 0 16px 0;font-size:15px;line-height:1.75;color:rgba(251,250,244,0.8);">Every day you get a morning practice and an evening reflection — about 15 minutes total. You get a private dashboard with your fellow members, a Heroes gallery for tributes to the people who shaped your recovery, and a Widen the Circle referral program built on the same principle as Step 12: carrying the message.</p>',
    '<p style="margin:0 0 28px 0;font-size:15px;line-height:1.75;color:rgba(251,250,244,0.8);">Geo is inviting you in. <strong style="color:#FF1493;">Your first month is completely free</strong> — the discount is already attached to the link below. No coupon to type, no trial to cancel.</p>',
    '<table width="100%" cellpadding="0" cellspacing="0" style="margin:8px 0 8px 0;"><tr><td align="center"><a href="' + referralLink + '" style="display:inline-block;background:#FF1493;color:#ffffff;font-family:system-ui,sans-serif;font-size:15px;font-weight:600;text-decoration:none;padding:16px 48px;border-radius:4px;">Claim your first month free →</a></td></tr></table>',
    '<p style="margin:12px 0 0 0;font-size:11px;color:rgba(251,250,244,0.3);text-align:center;font-family:system-ui,sans-serif;">$5.99/month after the first month. Cancel anytime, one click.</p>',
    '<p style="margin:32px 0 0 0;font-size:14px;color:rgba(251,250,244,0.55);line-height:1.7;">If you want to ask Geo anything first — whether it\'s a fit, whether your sponsor would roll their eyes, whatever — just reply to this email. It goes to his personal inbox, not a queue.</p>',
    '</td></tr>',
    '<tr><td style="padding:32px 0 0 0;text-align:center;"><p style="margin:0 0 8px 0;font-size:14px;color:rgba(251,250,244,0.5);font-style:italic;">With love,</p><p style="margin:0 0 4px 0;font-size:16px;color:#FF1493;">Your Fairy Godfather</p><p style="margin:0 0 24px 0;font-size:12px;color:rgba(251,250,244,0.4);font-family:system-ui,sans-serif;">on behalf of Geo</p>',
    '<div style="border-top:1px solid rgba(255,255,255,0.08);padding-top:18px;margin-top:8px;text-align:left;"><p style="margin:0;font-size:11px;color:rgba(251,250,244,0.42);font-family:system-ui,sans-serif;line-height:1.7;font-style:italic;"><strong style="color:rgba(251,250,244,0.6);font-style:normal;">A brief note on names:</strong> Your Fairy Godfather is my personal project since 2000, officially anchored as a dba under GPV Consulting, LLC (founded 2023). &ldquo;You aRe The Company You Keep&rdquo; is a working phrase I&rsquo;ve carried for just as long. This platform is mine alone. It is not affiliated with AA, with any AA fellowship, or with any meeting that shares the YRTCYK name, and nothing here speaks for AA or its Traditions. The 12 Steps are the framework I&rsquo;ve lived inside for decades; this is my grateful expression of that experience. &mdash; Geo</p></div>',
    '<div style="border-top:1px solid rgba(255,255,255,0.08);padding-top:20px;margin-top:20px;"><p style="margin:0 0 6px 0;font-size:11px;color:rgba(251,250,244,0.35);font-family:system-ui,sans-serif;line-height:1.6;">This is a one-time personal invitation from a friend. You were not added to any list.</p><p style="margin:0 0 6px 0;font-size:11px;color:rgba(251,250,244,0.35);font-family:system-ui,sans-serif;line-height:1.6;">Reply with "no thanks" and Geo won\'t reach out again.</p><p style="margin:12px 0 0 0;font-size:11px;color:rgba(251,250,244,0.25);font-family:system-ui,sans-serif;">GPV Consulting LLC · Palm Springs, CA · yourfairygodfather.com</p></div>',
    '</td></tr></table></td></tr></table></body></html>',
  ].join('')
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }
  if (req.method !== 'POST') {
    return jsonResponse({ error: 'Method not allowed' }, 405)
  }

  try {
    if (!RESEND_API_KEY) {
      console.error('[send-referral-email] RESEND_API_KEY not set')
      return jsonResponse({ error: 'Server misconfigured' }, 500)
    }

    // ── AUTHORIZATION ──
    const authHeader = req.headers.get('Authorization') || req.headers.get('authorization') || ''
    const jwt = authHeader.replace(/^Bearer\s+/i, '').trim()
    if (!jwt) return jsonResponse({ error: 'Not authorized' }, 401)

    const payload = decodeJwtPayload(jwt)
    if (!payload) return jsonResponse({ error: 'Not authorized' }, 401)

    const callerEmail = typeof payload.email === 'string' ? payload.email.toLowerCase() : ''
    if (!callerEmail) return jsonResponse({ error: 'Not authorized' }, 401)
    if (callerEmail !== AUTHORIZED_EMAIL.toLowerCase()) {
      console.log('[send-referral-email] Blocked non-Geo caller:', callerEmail)
      return jsonResponse({ error: 'Not authorized' }, 403)
    }

    // ── BODY PARSE & VALIDATION ──
    const body = await req.json().catch(() => null)
    if (!body || typeof body !== 'object') {
      return jsonResponse({ error: 'Invalid request body' }, 400)
    }
    const recipientEmailRaw = typeof body.recipientEmail === 'string' ? body.recipientEmail.trim().toLowerCase() : ''
    const recipientFirstNameRaw = typeof body.recipientFirstName === 'string' ? body.recipientFirstName.trim() : ''
    const personalNoteRaw = typeof body.personalNote === 'string' ? body.personalNote.trim() : ''

    if (!isValidEmail(recipientEmailRaw)) return jsonResponse({ error: 'Please enter a valid email address.' }, 400)
    if (recipientEmailRaw === AUTHORIZED_EMAIL.toLowerCase()) return jsonResponse({ error: "You can't refer yourself." }, 400)
    if (personalNoteRaw.length > 1000) return jsonResponse({ error: 'Personal note is too long (max 1000 characters).' }, 400)
    if (recipientFirstNameRaw.length > 80) return jsonResponse({ error: 'First name too long.' }, 400)
    const recipientFirstName = recipientFirstNameRaw || 'there'

    // ── FETCH GEO'S MEMBER DATA ──
    const { data: member, error: memberErr } = await supabaseAdmin
      .from('members')
      .select('id, email, display_name, referral_code')
      .eq('email', AUTHORIZED_EMAIL)
      .single()

    if (memberErr || !member) {
      console.error('[send-referral-email] Could not find Geo member row:', memberErr?.message)
      return jsonResponse({ error: 'Server error — could not resolve your account.' }, 500)
    }

    const { data: refCodeRow } = await supabaseAdmin
      .from('referral_codes')
      .select('code')
      .eq('member_id', member.id)
      .single()
    const referralCode = refCodeRow?.code || member.referral_code
    if (!referralCode) {
      console.error('[send-referral-email] Geo has no referral code')
      return jsonResponse({ error: 'Server error — no referral code on file.' }, 500)
    }
    const referralLink = `https://yourfairygodfather.com/join?ref=${encodeURIComponent(referralCode)}`

    // ── RECIPIENT VALIDITY CHECKS ──
    const { data: existingMember } = await supabaseAdmin
      .from('members').select('id').eq('email', recipientEmailRaw).maybeSingle()
    if (existingMember) return jsonResponse({ error: 'That email is already a member. Nothing to do.' }, 400)

    const { data: existingReferral } = await supabaseAdmin
      .from('referrals').select('id, status').eq('referrer_id', member.id).eq('referred_email', recipientEmailRaw).maybeSingle()
    if (existingReferral) {
      return jsonResponse({
        error: `You already invited this email (status: ${existingReferral.status}). If you want to send a reminder, do it from your own inbox for now.`,
      }, 400)
    }

    // ── RATE LIMIT ──
    const todayStartUTC = new Date(); todayStartUTC.setUTCHours(0, 0, 0, 0)
    const { count: todayCount, error: countErr } = await supabaseAdmin
      .from('referrals').select('id', { count: 'exact', head: true })
      .eq('referrer_id', member.id).gte('created_at', todayStartUTC.toISOString())
    if (countErr) {
      console.error('[send-referral-email] Rate-limit count error:', countErr.message)
      return jsonResponse({ error: 'Server error — please try again in a minute.' }, 500)
    }
    if ((todayCount || 0) >= DAILY_SEND_LIMIT) {
      return jsonResponse({ error: `Daily send limit reached (${DAILY_SEND_LIMIT}). Resets at midnight UTC.` }, 429)
    }

    // ── BUILD + SEND EMAIL ──
    const subject = `🌈 Geo thought of you — your first month is on him`
    const html = buildReferralEmailHtml({ firstName: recipientFirstName, personalNote: personalNoteRaw, referralLink })

    const resendRes = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { Authorization: `Bearer ${RESEND_API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: 'Your Fairy Godfather <hello@yourfairygodfather.com>',
        to: [recipientEmailRaw],
        reply_to: AUTHORIZED_EMAIL,
        subject,
        html,
      }),
    })
    const resendBody = await resendRes.json().catch(() => ({}))

    if (!resendRes.ok) {
      console.error('[send-referral-email] Resend rejected:', resendRes.status, resendBody)
      return jsonResponse({
        error: `Email service returned an error (${resendRes.status}). Try again or contact support.`,
      }, 502)
    }

    // ── INSERT REFERRALS ROW ──
    const { error: insertErr } = await supabaseAdmin.from('referrals').insert({
      referrer_id: member.id,
      referred_email: recipientEmailRaw,
      status: 'invited',
      coupon_code: referralCode,
    })
    if (insertErr) {
      console.error('[send-referral-email] Email sent but referrals insert failed:', insertErr.message)
    }

    return jsonResponse({
      ok: true,
      sent_to: recipientEmailRaw,
      resend_id: resendBody.id || null,
      daily_remaining: DAILY_SEND_LIMIT - (todayCount || 0) - 1,
    })
  } catch (err) {
    console.error('[send-referral-email] Unhandled:', (err as Error).message)
    return jsonResponse({ error: 'Server error.' }, 500)
  }
})
