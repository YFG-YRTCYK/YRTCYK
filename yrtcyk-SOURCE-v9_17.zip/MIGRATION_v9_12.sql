-- ═══════════════════════════════════════════════════════════════════════════
-- YRTCYK v9.12 migration — Word of Mouth: event_name for LGBT Recovery
-- Run this in Supabase SQL Editor BEFORE deploying the v9.12 build to Netlify.
-- Safe to run on existing data: adds nullable column, relaxes business_name
-- constraint. No data changes, no row modifications.
-- ═══════════════════════════════════════════════════════════════════════════

-- 1) Add event_name column — populated only for LGBT Recovery entries.
--    Null for all other categories (and for legacy LGBT rows pending Admin edit).
ALTER TABLE word_of_mouth
  ADD COLUMN IF NOT EXISTS event_name TEXT;

-- 2) Relax business_name to NULLABLE.
--    LGBT Recovery events can be submitted without a specific venue
--    (the event_name becomes the primary identifier in that case).
--    For all other categories the React form still requires it at the UI level.
ALTER TABLE word_of_mouth
  ALTER COLUMN business_name DROP NOT NULL;

-- 3) Sanity — verify both changes landed.
--    Expected: event_name visible, business_name is_nullable = YES.
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'word_of_mouth'
  AND column_name IN ('event_name', 'business_name')
ORDER BY column_name;

-- ═══════════════════════════════════════════════════════════════════════════
-- Notes:
-- • No CHECK constraint enforcing (category='lgbt_recovery' ⟹ event_name IS NOT NULL)
--   because existing LGBT Recovery rows have NULL event_name and Geo wants them
--   preserved as-is (Admin will backfill via the new inline edit UI).
--   The React form enforces this constraint for all new submissions.
-- • If you want DB-level enforcement later, add as NOT VALID:
--     ALTER TABLE word_of_mouth ADD CONSTRAINT wom_lgbt_has_event_name
--       CHECK (category <> 'lgbt_recovery' OR event_name IS NOT NULL) NOT VALID;
--   (NOT VALID = enforced on new rows, existing rows exempt.)
-- ═══════════════════════════════════════════════════════════════════════════
