import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

// v9.13: Only this email can access the branded-email-via-YFG flow.
// Hard-coded here AND checked again in the send-referral-email Edge Function.
const BRANDED_EMAIL_SENDER = 'yourfairygodfather@me.com'

export default function InviteFriends({ user }) {
  const [member, setMember]   = useState(null)
  const [code, setCode]       = useState('')
  const [referrals, setReferrals] = useState([])
  const [copied, setCopied]   = useState(false)

  // v9.13: branded-email form state
  const canSendBrandedEmail = (user?.email || '').toLowerCase() === BRANDED_EMAIL_SENDER
  const [brandedOpen, setBrandedOpen] = useState(false)
  const [recipientEmail, setRecipientEmail] = useState('')
  const [recipientFirstName, setRecipientFirstName] = useState('')
  const [personalNote, setPersonalNote] = useState('')
  const [sending, setSending] = useState(false)
  const [sendResult, setSendResult] = useState(null) // { ok, message, sentTo } | null

  useEffect(() => { load() }, [])

  async function load() {
    const { data: m } = await supabase.from('members').select('id').eq('email', user.email).single()
    if (!m) return
    setMember(m)
    // v18 uses referral_codes table
    const { data: rc } = await supabase.from('referral_codes').select('code').eq('member_id', m.id).single()
    if (rc) setCode(rc.code)
    const { data: r } = await supabase.from('referrals').select('*').eq('referrer_id', m.id).order('created_at', { ascending: false })
    setReferrals(r || [])
  }

  const link = code ? `https://yourfairygodfather.com/join?ref=${code}` : ''
  const emailBody = encodeURIComponent(`Hey,\n\nI've been using YRTCYK — "You aRe The Company You Keep" — a private LGBTQ+ affirming recovery community built around the 12 Steps.\n\nEvery day there's a morning and evening practice — about 15 minutes total. It keeps me connected and accountable.\n\nYour first month is completely free:\n${link}\n\nCome keep me company. 🪄`)

  function copy() {
    if (!link) return
    navigator.clipboard.writeText(link)
    setCopied(true); setTimeout(() => setCopied(false), 2500)
  }

  function resetBrandedForm() {
    setRecipientEmail('')
    setRecipientFirstName('')
    setPersonalNote('')
    setSendResult(null)
  }

  async function sendBranded() {
    if (!recipientEmail.trim()) return
    setSending(true)
    setSendResult(null)
    try {
      // Supabase Functions invoke automatically includes the auth JWT.
      const { data, error } = await supabase.functions.invoke('send-referral-email', {
        body: {
          recipientEmail: recipientEmail.trim().toLowerCase(),
          recipientFirstName: recipientFirstName.trim(),
          personalNote: personalNote.trim(),
        },
      })
      if (error) {
        // Supabase's functions.invoke wraps non-2xx responses in FunctionsHttpError
        // where the real server error body lives in error.context (a Response object).
        // The legacy `data.error` path is often null on errors — we must parse the
        // Response body ourselves to surface the specific message (rate limit hit,
        // duplicate recipient, validation error, etc.) instead of the generic
        // "Edge Function returned a non-2xx status code" fallback.
        let serverMsg = (data && typeof data === 'object' && data.error) || null
        if (!serverMsg && error.context && typeof error.context.json === 'function') {
          try {
            const body = await error.context.json()
            if (body && body.error) serverMsg = body.error
          } catch (_) { /* keep falling back */ }
        }
        if (!serverMsg) serverMsg = error.message || 'Something went wrong.'
        setSendResult({ ok: false, message: serverMsg })
      } else if (data && data.ok) {
        setSendResult({ ok: true, message: `Sent to ${data.sent_to}. You'll see them below as "Invited" once the page refreshes.`, sentTo: data.sent_to })
        load()
      } else {
        const msg = (data && data.error) || 'Unexpected response from server.'
        setSendResult({ ok: false, message: msg })
      }
    } catch (err) {
      setSendResult({ ok: false, message: err.message || 'Network error.' })
    }
    setSending(false)
  }

  const joined     = referrals.filter(r => r.status !== 'invited').length
  const freeMonths = referrals.filter(r => r.status === 'rewarded').length

  return (
    <div style={{ paddingTop: 20, paddingBottom: 40 }}>
      <h2 style={{ fontSize: 22, fontWeight: 400, marginBottom: 8 }}>🌈 Widen the Circle</h2>
      <p style={{ fontSize: 14, color: 'rgba(251,250,244,.6)', lineHeight: 1.75, marginBottom: 24, fontFamily: 'var(--font-ui)' }}>
        Share your personal link. Your friend gets their <span style={{ color: 'var(--pink)', fontStyle: 'italic' }}>first month free</span>. After they complete 2 paying months, you earn a free month. That's the company we keep.
      </p>

      {/* Link box */}
      <div className="card" style={{ marginBottom: 20, border: '1px solid rgba(255,20,147,.2)', background: 'rgba(255,20,147,.04)' }}>
        <p className="section-label" style={{ color: 'var(--pink)', marginBottom: 10 }}>Your Invite Link</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <input value={link || 'Loading…'} readOnly style={{ fontSize: 13, background: 'rgba(255,255,255,.06)', color: link ? 'var(--cream)' : 'rgba(251,250,244,.3)' }}/>
          <button className="btn-primary" onClick={copy} disabled={!link} style={{ whiteSpace: 'nowrap', padding: '10px 16px' }}>
            {copied ? '✓ Copied!' : 'Copy Link'}
          </button>
        </div>
        <p style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)', marginTop: 8 }}>Anyone who clicks this link gets their first month free.</p>
      </div>

      {/* Share buttons */}
      {link && (
        <div style={{ display: 'flex', gap: 8, marginBottom: canSendBrandedEmail ? 16 : 24 }}>
          <a href={`mailto:?subject=${encodeURIComponent('You should check this out')}&body=${emailBody}`}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(255,20,147,.1)', border: '1px solid rgba(255,20,147,.2)', color: 'var(--pink)', fontSize: 13, fontFamily: 'var(--font-ui)', textAlign: 'center', display: 'block' }}>
            ✉️ Email
          </a>
          <a href={`sms:?&body=${encodeURIComponent(`Join me in YRTCYK — first month free: ${link}`)}`}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(25,229,94,.08)', border: '1px solid rgba(25,229,94,.15)', color: 'var(--lime)', fontSize: 13, fontFamily: 'var(--font-ui)', textAlign: 'center', display: 'block' }}>
            💬 Text
          </a>
          <button onClick={() => navigator.share ? navigator.share({ url: link }) : copy()}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(255,255,255,.06)', border: '1px solid var(--border)', color: 'rgba(251,250,244,.6)', fontSize: 13, fontFamily: 'var(--font-ui)', cursor: 'pointer' }}>
            ↗ Share
          </button>
        </div>
      )}

      {/* v9.13 — Geo-only: Send a fully branded email via Your Fairy Godfather */}
      {canSendBrandedEmail && link && (
        <div className="card" style={{ marginBottom: 24, border: '1px solid rgba(255,20,147,.3)', background: 'linear-gradient(180deg, rgba(255,20,147,.08) 0%, rgba(255,20,147,.03) 100%)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: brandedOpen ? 14 : 0 }}>
            <div>
              <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)', color: 'var(--pink)', fontWeight: 600, letterSpacing: .5, textTransform: 'uppercase', marginBottom: 4 }}>🪄 Send via Your Fairy Godfather</p>
              <p style={{ fontSize: 12, color: 'rgba(251,250,244,.55)', fontFamily: 'var(--font-ui)', lineHeight: 1.5 }}>
                Sends a polished branded email from hello@yourfairygodfather.com. Replies come to your personal inbox.
              </p>
            </div>
            {!brandedOpen && (
              <button onClick={() => setBrandedOpen(true)} className="btn-primary" style={{ fontSize: 12, padding: '8px 14px', whiteSpace: 'nowrap', marginLeft: 12 }}>
                Start
              </button>
            )}
          </div>

          {brandedOpen && (
            <div>
              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 10, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: .8, display: 'block', marginBottom: 5 }}>RECIPIENT EMAIL *</label>
                <input type="email" value={recipientEmail} onChange={e => setRecipientEmail(e.target.value)}
                  placeholder="friend@example.com"
                  autoComplete="off"
                  style={{ width: '100%', fontSize: 13 }} />
              </div>

              <div style={{ marginBottom: 12 }}>
                <label style={{ fontSize: 10, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: .8, display: 'block', marginBottom: 5 }}>WHAT SHOULD I CALL THEM? (OPTIONAL)</label>
                <input type="text" value={recipientFirstName} onChange={e => setRecipientFirstName(e.target.value)}
                  placeholder='first name — defaults to "there"'
                  maxLength={80}
                  style={{ width: '100%', fontSize: 13 }} />
              </div>

              <div style={{ marginBottom: 14 }}>
                <label style={{ fontSize: 10, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: .8, display: 'block', marginBottom: 5 }}>A LINE FROM YOU (OPTIONAL)</label>
                <textarea value={personalNote} onChange={e => setPersonalNote(e.target.value)}
                  placeholder="Something personal. Renders as a pull quote in the email."
                  rows={3}
                  maxLength={1000}
                  style={{ width: '100%', fontSize: 13, resize: 'vertical' }} />
                <p style={{ fontSize: 10, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginTop: 3, textAlign: 'right' }}>{personalNote.length} / 1000</p>
              </div>

              {sendResult && (
                <div style={{ padding: '10px 12px', borderRadius: 6, marginBottom: 12,
                  background: sendResult.ok ? 'rgba(25,229,94,.1)' : 'rgba(255,20,147,.1)',
                  border: '1px solid ' + (sendResult.ok ? 'rgba(25,229,94,.3)' : 'rgba(255,20,147,.3)'),
                  color: sendResult.ok ? 'var(--lime)' : 'var(--pink)', fontSize: 12, fontFamily: 'var(--font-ui)', lineHeight: 1.5 }}>
                  {sendResult.ok ? '✓ ' : '⚠️ '}{sendResult.message}
                </div>
              )}

              <div style={{ display: 'flex', gap: 8 }}>
                <button onClick={sendBranded} disabled={sending || !recipientEmail.trim()} className="btn-primary"
                  style={{ flex: 1, fontSize: 13 }}>
                  {sending ? 'Sending…' : 'Send the Invitation 🌈'}
                </button>
                <button onClick={() => { setBrandedOpen(false); resetBrandedForm() }}
                  style={{ padding: '10px 16px', borderRadius: 8, background: 'rgba(255,255,255,.06)', border: '1px solid var(--border)', color: 'rgba(251,250,244,.55)', fontSize: 13, fontFamily: 'var(--font-ui)', cursor: 'pointer' }}>
                  Close
                </button>
              </div>

              {sendResult?.ok && (
                <button onClick={resetBrandedForm}
                  style={{ width: '100%', marginTop: 10, padding: '8px', borderRadius: 6, background: 'rgba(255,255,255,.04)', border: '1px dashed rgba(255,255,255,.12)', color: 'rgba(251,250,244,.5)', fontSize: 12, fontFamily: 'var(--font-ui)', cursor: 'pointer' }}>
                  Send another ✉️
                </button>
              )}
            </div>
          )}
        </div>
      )}

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 24 }}>
        {[
          { val: referrals.length, label: 'Total Invited' },
          { val: joined,           label: 'Joined' },
          { val: freeMonths,       label: 'Free Months Earned' },
        ].map(s => (
          <div key={s.label} className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 26, fontWeight: 700, color: 'var(--pink)', fontFamily: 'var(--font-ui)' }}>{s.val}</div>
            <div style={{ fontSize: 10, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginTop: 3, textTransform: 'uppercase', letterSpacing: .5 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Referral history */}
      {referrals.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <p className="section-label" style={{ marginBottom: 12 }}>Your Referrals</p>
          {referrals.map(r => (
            <div key={r.id} className="card" style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)' }}>{r.referred_email || 'Member'}</p>
                <p style={{ fontSize: 11, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginTop: 2 }}>{new Date(r.created_at).toLocaleDateString()}</p>
              </div>
              <span style={{ fontSize: 11, fontFamily: 'var(--font-ui)', padding: '3px 10px', borderRadius: 20, background: r.status === 'rewarded' ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.06)', color: r.status === 'rewarded' ? 'var(--lime)' : 'rgba(251,250,244,.45)', border: '1px solid ' + (r.status === 'rewarded' ? 'rgba(25,229,94,.25)' : 'var(--border)') }}>
                {r.status === 'rewarded' ? '🎁 Rewarded' : r.status === 'month_2' ? 'Month 2 ✓' : r.status === 'month_1' ? 'Month 1 ✓' : r.status === 'joined' ? 'Joined ✓' : 'Invited'}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* How it works */}
      <div style={{ marginTop: 8, background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)', borderRadius: 10, padding: 16 }}>
        <p className="section-label" style={{ marginBottom: 12 }}>How It Works</p>
        {[
          '1 Copy your link above and text or email it to someone.',
          '2 They click your link and get their first month free.',
          '3 After 2 paying months, you earn one free month.',
          "4 Your credit is applied automatically — next invoice $0.00, no coupon needed.",
        ].map((s, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: i < 3 ? 10 : 0 }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--pink)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontFamily: 'var(--font-ui)', fontWeight: 700, color: '#fff', flexShrink: 0, marginTop: 1 }}>{i+1}</div>
            <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.65)', lineHeight: 1.6 }}>{s.slice(2)}</p>
          </div>
        ))}
      </div>

      <p style={{ textAlign: 'center', fontSize: 14, color: 'var(--pink)', fontStyle: 'italic', marginTop: 28 }}>You aRe The Company You Keep.</p>
    </div>
  )
}
