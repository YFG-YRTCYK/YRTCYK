import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import './index.css'
import Dashboard from './Dashboard'
import HeroGallery from './HeroGallery'
import CommunityCalendar from './CommunityCalendar'
import InviteFriends from './InviteFriends'
import MemberDirectory from './MemberDirectory'
import CommunityBlog from './CommunityBlog'
import AdminPanel from './AdminPanel'
import ModeratorPanel from './ModeratorPanel'
import ProfilePage from './ProfilePage'
import WordOfMouth from './WordOfMouth'
import IdeaBox from './IdeaBox'

const ADMIN_EMAILS = ['gvitrano@icloud.com']

export default function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState('dashboard')
  const [overlay, setOverlay] = useState(null) // 'profile' | 'admin'
  const [email, setEmail] = useState('')
  const [authMsg, setAuthMsg] = useState('')
  const [sending, setSending] = useState(false)
  const [isMod, setIsMod] = useState(false)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => { setSession(session); setLoading(false) })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); setLoading(false) })
    return () => subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (session && !ADMIN_EMAILS.includes(session.user.email)) {
      supabase.from('members').select('is_moderator').eq('email', session.user.email).single()
        .then(({ data }) => { if (data?.is_moderator) setIsMod(true) })
    }
  }, [session])

  async function sendLink(e) {
    e.preventDefault(); setSending(true)
    const { error } = await supabase.auth.signInWithOtp({ email, options: { emailRedirectTo: 'https://action.yourfairygodfather.com' } })
    setSending(false)
    setAuthMsg(error ? 'Error: ' + error.message : 'Magic link sent! Check your inbox and spam folder.')
  }

  if (loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}><div className="spinner"/></div>

  if (!session) return (
    <div style={{minHeight:'100vh',display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',padding:'0 24px'}}>
      <div style={{textAlign:'center',marginBottom:40}}>
        <p style={{fontSize:13,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:3,marginBottom:12}}>YRTCYK</p>
        <h1 style={{fontSize:26,fontWeight:400,color:'var(--pink)'}}>Your Fairy Godfather</h1>
      </div>
      <form onSubmit={sendLink} style={{width:'100%',maxWidth:340}}>
        <input value={email} onChange={e=>setEmail(e.target.value)} type="email" placeholder="your@email.com" style={{marginBottom:10}} required/>
        <button type="submit" className="btn-primary" style={{width:'100%'}} disabled={sending}>{sending?'Sending…':'Send Magic Link'}</button>
      </form>
      {authMsg && <p style={{fontSize:13,fontFamily:'var(--font-ui)',textAlign:'center',marginTop:14,color:authMsg.startsWith('Error')?'var(--pink)':'var(--lime)',lineHeight:1.6}}>{authMsg}</p>}
    </div>
  )

  const user = session.user
  const isAdmin = ADMIN_EMAILS.includes(user.email)
  const canModerate = isAdmin || isMod

  if (overlay === 'profile') return <ProfilePage user={user} isAdmin={isAdmin} onClose={()=>setOverlay(null)}/>
  if (overlay === 'admin')   return <AdminPanel  user={user} onClose={()=>setOverlay(null)}/>
  if (overlay === 'moderate') return <ModeratorPanel user={user} onClose={()=>setOverlay(null)}/>

  const TABS = [
    { id:'dashboard', label:'Home',    emoji:'🏠' },
    { id:'heroes',    label:'Heroes',  emoji:'🌟' },
    { id:'blog',      label:'Reflections', emoji:'📝' },
    { id:'members',   label:'Members', emoji:'👥' },
    { id:'calendar',  label:'Calendar',emoji:'📅' },
    { id:'invite',    label:'Widen the Circle', emoji:'🌈' },
    { id:'wordofmouth', label:'Word of Mouth', emoji:'💋' },
    { id:'ideabox',    label:'Idea Box',      emoji:'🪄' },
  ]

  return (
    <div style={{minHeight:'100vh',display:'flex',flexDirection:'column'}}>
      {/* Header */}
      <div style={{background:'rgba(1,40,14,.97)',borderBottom:'1px solid var(--border)',padding:'8px 16px',position:'sticky',top:0,zIndex:100}}>
        <div style={{maxWidth:700,margin:'0 auto',display:'flex',alignItems:'center',justifyContent:'space-between',gap:8}}>
          <div style={{flexShrink:0,background:'#ffffff',borderRadius:6,padding:'4px 6px',display:'flex',alignItems:'center'}}>
            <img src="/fairy_godfather.jpg" alt="Your Fairy Godfather" style={{height:36,width:'auto',display:'block'}}/>
          </div>
          <nav style={{display:'flex',gap:2,overflowX:'auto',flexShrink:1}}>
            {TABS.map(t=>(
              <button key={t.id} onClick={()=>setView(t.id)} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:7,fontSize:9,fontFamily:'var(--font-ui)',color:view===t.id?'var(--pink)':'rgba(251,250,244,.45)',background:view===t.id?'rgba(255,20,147,.1)':'transparent',border:view===t.id?'1px solid rgba(255,20,147,.2)':'1px solid transparent',whiteSpace:'nowrap',fontWeight:view===t.id?700:400,cursor:'pointer'}}>
                <span style={{fontSize:15}}>{t.emoji}</span><span>{t.label}</span>
              </button>
            ))}
            {isAdmin && (
              <button onClick={()=>setOverlay('admin')} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:7,fontSize:9,fontFamily:'var(--font-ui)',color:'var(--lime)',background:'rgba(25,229,94,.1)',border:'1px solid rgba(25,229,94,.2)',whiteSpace:'nowrap',fontWeight:700,cursor:'pointer'}}>
                <span style={{fontSize:15}}>⚙️</span><span>Admin</span>
              </button>
            )}
            {!isAdmin && isMod && (
              <button onClick={()=>setOverlay('moderate')} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:7,fontSize:9,fontFamily:'var(--font-ui)',color:'var(--pink)',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.25)',whiteSpace:'nowrap',fontWeight:700,cursor:'pointer'}}>
                <span style={{fontSize:15}}>🛡️</span><span>Moderate</span>
              </button>
            )}
            <button onClick={()=>setOverlay('profile')} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:7,fontSize:9,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.45)',border:'1px solid var(--border)',whiteSpace:'nowrap',cursor:'pointer'}}>
              <span style={{fontSize:15}}>👤</span><span>Profile</span>
            </button>
            <button onClick={()=>supabase.auth.signOut()} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:2,padding:'4px 7px',borderRadius:7,fontSize:9,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.3)',whiteSpace:'nowrap',cursor:'pointer'}}>
              <span style={{fontSize:15}}>🚪</span><span>Sign Out</span>
            </button>
          </nav>
        </div>
        <div style={{maxWidth:700,margin:'4px auto 0',textAlign:'center'}}>
          <span style={{fontSize:10,color:'rgba(251,250,244,.25)',fontFamily:'var(--font-ui)'}}>{user.email}</span>
        </div>
      </div>

      {/* Content */}
      <div style={{flex:1,maxWidth:700,margin:'0 auto',width:'100%',padding:'0 16px 48px'}}>
        {view==='dashboard' && <Dashboard user={user} isAdmin={isAdmin}/>}
        {view==='heroes'    && <HeroGallery user={user} isAdmin={isAdmin}/>}
        {view==='blog'      && <CommunityBlog user={user} isAdmin={canModerate}/>}
        {view==='members'   && <MemberDirectory user={user} isAdmin={isAdmin}/>}
        {view==='calendar'  && <CommunityCalendar user={user}/>}
        {view==='invite'    && <InviteFriends user={user}/>}
        {view==='wordofmouth' && <WordOfMouth user={user} isAdmin={isAdmin}/>}
        {view==='ideabox'    && <IdeaBox user={user}/>}
      </div>
    </div>
  )
}
