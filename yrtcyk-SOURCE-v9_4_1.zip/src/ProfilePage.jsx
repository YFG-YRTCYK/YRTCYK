import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

const DEFAULT_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88" viewBox="0 0 88 88"><circle cx="44" cy="44" r="44" fill="#01280e"/><circle cx="44" cy="44" r="42" fill="none" stroke="#FF1493" stroke-width="2"/><text x="44" y="52" text-anchor="middle" font-family="Georgia,serif" font-size="28" font-weight="700" fill="#FF1493">YFG</text></svg>')}`

const TIMEZONES = [
  ['America/Los_Angeles','Pacific Time (LA, SF, Seattle)'],
  ['America/Denver','Mountain Time (Denver, Phoenix)'],
  ['America/Chicago','Central Time (Chicago, Dallas)'],
  ['America/New_York','Eastern Time (NYC, Miami, Boston)'],
  ['America/Anchorage','Alaska Time'],
  ['Pacific/Honolulu','Hawaii Time'],
  ['Europe/London','London / Dublin'],
  ['Europe/Paris','Central Europe — Paris, Berlin, Rome'],
  ['Europe/Athens','Eastern Europe — Athens, Helsinki'],
  ['Asia/Dubai','Gulf Time — Dubai, Abu Dhabi'],
  ['Asia/Kolkata','India Standard Time'],
  ['Asia/Tokyo','Japan / Korea'],
  ['Australia/Sydney','Eastern Australia'],
  ['Pacific/Auckland','New Zealand'],
  ['UTC','UTC'],
]
const PRONOUNS     = ['He/Him','She/Her','They/Them','He/They','She/They','Ze/Zir','Any/All','Prefer not to say']
const ORIENTATIONS = ['Gay','Lesbian','Bisexual','Pansexual','Queer','Straight/Heterosexual','Asexual','Prefer not to say']
const GENDERS      = ['Man','Woman','Non-binary','Genderqueer','Genderfluid','Transgender Man','Transgender Woman','Two-Spirit','Prefer not to say']
const ETHNICITIES  = ['Asian/Pacific Islander','Black/African American','Hispanic/Latino','Indigenous/Native American','Middle Eastern/North African','Multiracial','White/Caucasian','Prefer not to say']
const LANGUAGES    = ['English','Spanish','French','Portuguese','German','Italian','Mandarin','Cantonese','Japanese','Korean','Arabic','Hindi','Russian','Other']
const PET_TYPES    = ['Dog','Cat','Bird','Fish','Rabbit','Hamster/Guinea Pig','Reptile','Horse','Other']
const PROGRAMS     = ['AA','NA','Al-Anon','OA','SLAA','GA','SMART Recovery','Refuge Recovery','Other']

const WELLNESS_AREAS = [
  { key:'physical',     label:'Physical Health',          icon:'💪', topics:['Walking / Hiking','Running / Jogging','Weight Training','Yoga','Pilates','Swimming','Cycling','Team Sports','Dance','Martial Arts','Sleep Hygiene','Nutrition & Eating Well','Sober Fitness','Weight Management','Chronic Pain Management'] },
  { key:'emotional',    label:'Emotional Wellbeing',      icon:'💙', topics:['Therapy / Counseling','Journaling','Emotional Regulation','Grief & Loss','Trauma Recovery','Anger Management','Self-Compassion','Boundaries','Anxiety Management','Depression Support','Mindfulness','Meditation','Breathwork','Inner Child Work','Somatic Work'] },
  { key:'spiritual',    label:'Spiritual Growth',         icon:'✨', topics:['Step Work','Prayer','Meditation','Nature Connection','Religious Practice','Buddhism / Mindfulness','Gratitude Practice','Service Work','Spiritual Literature','Retreats','12-Step Community','SMART Recovery','Faith Community','Purpose & Meaning','Forgiveness Work'] },
  { key:'social',       label:'Relationships & Community',icon:'🌈', topics:['Rebuilding Family Relationships','Friendships in Recovery','Dating in Sobriety','LGBTQ+ Community','Sponsorship','Finding a Home Group','Social Anxiety','Healthy Boundaries','Communication Skills','Conflict Resolution','Parenting in Recovery','Rebuilding Trust','Overcoming Loneliness','Making Amends','Community Involvement'] },
  { key:'financial',    label:'Financial & Occupational', icon:'🌱', topics:['Debt Recovery','Budgeting Basics','Saving & Investing','Career Development','Job Search','Work-Life Balance','Entrepreneurship','Education & Retraining','Gambling Recovery','Financial Amends','Credit Rebuilding','Housing Stability','Benefits Navigation','Retirement Planning','Workplace Relationships'] },
  { key:'intellectual', label:'Intellectual & Creative',  icon:'🎨', topics:['Reading','Writing','Music','Visual Arts','Photography','Cooking','Gardening','Learning New Skills','Online Courses','Podcasts & Audiobooks','Theater / Performance','Film & Cinema','Crafts & Hobbies','Language Learning','Technology'] },
  { key:'fun',          label:'Fun, Play & Adventure',    icon:'🎭', topics:['Travel','Camping & Outdoors','Live Music & Concerts','Comedy Shows','Gaming','Cooking Adventures','Day Trips','Trying New Restaurants','Sober Nightlife','Volunteering','Pets & Animals','Sports & Games','Theme Parks','Collecting','Sober Travel'] },
  { key:'environmental',label:'Home & Environment',       icon:'🏡', topics:['Decluttering & Organization','Creating a Safe Space','Home Improvement','Sustainability','Urban Gardening','Minimalism','Interior Design','Digital Detox','Nature Immersion','Animal Welfare','Sacred Space Creation','Neighborhood Community','Moving to a Sober Environment','Climate Consciousness','Intentional Living'] },
]

function parseList(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  try { const p = JSON.parse(val); if (Array.isArray(p)) return p } catch {}
  return val.split(',').map(s => s.trim()).filter(Boolean)
}
function parsePets(val) {
  if (!val) return []
  try {
    const p = JSON.parse(val)
    if (Array.isArray(p)) {
      if (p.length === 0) return []
      if (typeof p[0] === 'object' && p[0].type) return p
      return p.map(v => ({ type: v, name: '' }))
    }
  } catch {}
  if (typeof val === 'string' && val.trim()) return [{ type:'Dog', name: val }]
  return []
}
function formatPhone(val) {
  const d = (val||'').replace(/\D/g,'').slice(0,10)
  if (d.length <= 3) return d
  if (d.length <= 6) return `(${d.slice(0,3)}) ${d.slice(3)}`
  return `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}`
}
function sobrietyStats(dateStr) {
  if (!dateStr) return null
  const start = new Date(dateStr + 'T00:00:00')
  const now = new Date()
  const diffMs = now - start
  if (diffMs < 0) return null
  const days = Math.floor(diffMs / 86400000)
  const years = days / 365.25
  let label = ''
  if (days < 30) label = `${days} day${days !== 1 ? 's' : ''}`
  else if (days < 365) label = `${Math.floor(days/30)} month${Math.floor(days/30)!==1?'s':''}`
  else {
    const y = Math.floor(years)
    const rem = days - Math.floor(y * 365.25)
    const m = Math.floor(rem / 30)
    label = `${y} yr${y!==1?'s':''}${m>0?` ${m} mo`:''}`
  }
  return { days, years: parseFloat(years.toFixed(1)), label }
}
async function lookupZip(zip) {
  try {
    const res = await fetch(`https://api.zippopotam.us/us/${zip}`)
    if (!res.ok) return null
    const data = await res.json()
    const place = data.places?.[0]
    if (!place) return null
    return `${place['place name']}, ${place['state abbreviation']}`
  } catch { return null }
}


// ── Field helpers — defined OUTSIDE component to prevent focus loss on re-render ──
function Lbl({ t, sub, req }) {
  return <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:6,marginTop:16}}>{t}{req&&<span style={{color:'var(--pink)',marginLeft:4}}>*</span>}{sub&&<span style={{color:'rgba(251,250,244,.2)',marginLeft:6}}>{sub}</span>}</p>
}
function Inp({ fieldKey, P, set, ...props }) {
  return <input value={P[fieldKey]||''} onChange={e=>set(fieldKey,e.target.value)} {...props}/>
}
function Sel({ fieldKey, P, set, opts, ph }) {
  return <select value={P[fieldKey]||''} onChange={e=>set(fieldKey,e.target.value)}><option value="">{ph||'Select…'}</option>{opts.map(o=>Array.isArray(o)?<option key={o[0]} value={o[0]}>{o[1]}</option>:<option key={o} value={o}>{o}</option>)}</select>
}
function Chips({ fieldKey, P, set, opts }) {
  return <div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:8}}>{opts.map(o=>{const sel=(P[fieldKey]||[]).includes(o);return<button key={o} onClick={()=>set(fieldKey,(P[fieldKey]||[]).includes(o)?(P[fieldKey]||[]).filter(v=>v!==o):[...(P[fieldKey]||[]),o])} style={{padding:'6px 14px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:sel?'rgba(255,20,147,.18)':'rgba(255,255,255,.06)',border:`1px solid ${sel?'rgba(255,20,147,.35)':'rgba(255,255,255,.1)'}`,color:sel?'var(--pink)':'rgba(251,250,244,.6)',cursor:'pointer'}}>{o}</button>})}</div>
}
function Chk({ fieldKey, P, set, label }) {
  return <label style={{display:'flex',gap:10,alignItems:'center',cursor:'pointer',marginTop:12}}><input type="checkbox" checked={!!P[fieldKey]} onChange={e=>set(fieldKey,e.target.checked)} style={{width:18,height:18,accentColor:'var(--pink)',flexShrink:0}}/><span style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.65)'}}>{label}</span></label>
}

function WellnessArea({ area, selectedTopics, onToggle }) {
  const [open, setOpen] = useState(false)
  const selected = selectedTopics.filter(t => area.topics.includes(t))
  return (
    <div style={{ border:`1px solid ${selected.length>0?'rgba(255,20,147,.3)':'var(--border)'}`, borderRadius:8, marginBottom:10, overflow:'hidden', background:selected.length>0?'rgba(255,20,147,.04)':'rgba(255,255,255,.03)' }}>
      <button onClick={() => setOpen(o=>!o)} style={{ width:'100%', background:'none', border:'none', padding:'14px 16px', display:'flex', alignItems:'center', gap:12, cursor:'pointer', textAlign:'left' }}>
        <span style={{ fontSize:22, flexShrink:0 }}>{area.icon}</span>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:600, color:'var(--cream)', fontFamily:'var(--font-ui)' }}>{area.label}</div>
          <div style={{ fontSize:12, color:'rgba(251,250,244,.45)', marginTop:2 }}>{selected.length>0?`${selected.length} topic${selected.length!==1?'s':''} selected`:'Tap to expand'}</div>
        </div>
        <span style={{ fontSize:16, color:'rgba(251,250,244,.3)', transform:open?'rotate(180deg)':'none', transition:'transform .2s' }}>▾</span>
      </button>
      {open && (
        <div style={{ padding:'0 16px 16px' }}>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {area.topics.map(t => {
              const sel = selectedTopics.includes(t)
              return <button key={t} onClick={()=>onToggle(t)} style={{ padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:sel?'rgba(255,20,147,.2)':'rgba(255,255,255,.06)', border:`1px solid ${sel?'rgba(255,20,147,.4)':'rgba(255,255,255,.1)'}`, color:sel?'var(--pink)':'rgba(251,250,244,.6)', cursor:'pointer' }}>{t}</button>
            })}
          </div>
        </div>
      )}
    </div>
  )
}

export default function ProfilePage({ user, isAdmin, onClose }) {
  const [tab, setTab]       = useState('basics')
  const [member, setMember] = useState(null)
  const [P, setP]           = useState({})
  const [pets, setPets]     = useState([])
  const [referrals, setReferrals]       = useState([])
  const [contributions, setContributions] = useState(null)
  const [womPlaces, setWomPlaces]           = useState([])
  const [approvedHeroes, setApprovedHeroes]   = useState([])
  const [avatarUrl, setAvatarUrl]       = useState(DEFAULT_AVATAR)
  const [avatarUploading, setAvatarUploading] = useState(false)
  const [dragOver, setDragOver]         = useState(false)
  const [zipLooking, setZipLooking]     = useState(false)
  const [loading, setLoading]           = useState(true)
  const [saving, setSaving]             = useState(false)
  const [msg, setMsg]                   = useState('')
  const [dirty, setDirty]               = useState(false)

  useEffect(() => { load() }, [])

  async function load() {
    const { data } = await supabase.from('members').select('*').eq('email', user.email).single()
    if (data) {
      setMember(data)
      setP({ ...data, spoken_languages: parseList(data.spoken_languages), written_languages: parseList(data.written_languages), wellness_topics: parseList(data.wellness_topics) })
      setPets(parsePets(data.pets))
      setAvatarUrl(data.avatar_url || DEFAULT_AVATAR)

      const { data: refs } = await supabase.from('referrals').select('*').eq('referrer_id', data.id).order('created_at', { ascending:false })
      setReferrals(refs || [])

      const [heroRes, blogRes, commentRes] = await Promise.all([
        supabase.from('hero_showcases').select('id,hero_name,hero_type,tagline,photos,thumbnail_index,status').eq('member_id', data.id),
        supabase.from('blog_posts').select('id').eq('member_id', data.id),
        supabase.from('blog_comments').select('id').eq('member_id', data.id),
      ])
      // Approved heroes for profile display
      setApprovedHeroes((heroRes.data||[]).filter(h=>h.status==='approved'))
      const { data: womData } = await supabase.from('word_of_mouth').select('id,business_name,category,city,website_url,place_id').eq('member_id', data.id).order('created_at', { ascending: false })
      setWomPlaces(womData || [])
      const heroes = heroRes.data || []
      setContributions({
        referred:      (refs||[]).length,
        joined:        (refs||[]).filter(r=>r.status!=='invited').length,
        heroes_person: heroes.filter(h=>h.hero_type==='person').length,
        heroes_place:  heroes.filter(h=>h.hero_type==='place').length,
        heroes_thing:  heroes.filter(h=>h.hero_type==='thing').length,
        blog_posts:    (blogRes.data||[]).length,
        blog_comments: (commentRes.data||[]).length,
      })
    }
    setLoading(false)
  }

  function set(key, val) { setP(p=>({...p,[key]:val})); setDirty(true) }
  function toggleList(key, val) { const cur=P[key]||[]; set(key, cur.includes(val)?cur.filter(v=>v!==val):[...cur,val]) }
  function setPet(i,f,v){const p=[...pets];p[i]={...p[i],[f]:v};setPets(p);setDirty(true)}
  function removePet(i){setPets(pets.filter((_,j)=>j!==i));setDirty(true)}
  function addPet(){setPets([...pets,{type:'Dog',name:''}]);setDirty(true)}

  async function handleZipChange(zip) {
    set('zip_code', zip)
    if (zip.length >= 5 && /^\d{5}/.test(zip)) {
      setZipLooking(true)
      const city = await lookupZip(zip.slice(0,5))
      if (city) set('city', city)
      setZipLooking(false)
    }
  }

  async function save() {
    if (!member) return
    if (!P.display_name?.trim()) { setMsg('Display name is required.'); return }
    if (!P.first_name?.trim())   { setMsg('First name is required.'); return }
    if (!P.last_name?.trim())    { setMsg('Last name is required.'); return }
    if (!P.zip_code?.trim())     { setMsg('Zip code is required.'); return }
    if (!P.timezone)             { setMsg('Timezone is required.'); return }
    setSaving(true)
    const payload = {
      ...P,
      spoken_languages:  (P.spoken_languages||[]).join(', '),
      written_languages: (P.written_languages||[]).join(', '),
      wellness_topics:   JSON.stringify(P.wellness_topics||[]),
      pets:              JSON.stringify(pets),
      updated_at:        new Date().toISOString(),
    }
    ;['birth_date','program_1_date','program_2_date','program_3_date'].forEach(k=>{
      if (!payload[k]||String(payload[k]).trim()==='') payload[k]=null
    })
    const { error } = await supabase.from('members').update(payload).eq('id', member.id)
    setSaving(false)
    if (error) setMsg('Error: '+error.message)
    else { setMsg('Saved ✓'); setDirty(false); setTimeout(()=>setMsg(''),2500) }
  }

  async function uploadAvatar(file) {
    if (!member||!file) return
    if (!['image/jpeg','image/png','image/gif','image/webp'].includes(file.type)) return
    setAvatarUploading(true)
    try {
      const ext = file.name.split('.').pop()
      const path = `${member.id}/avatar.${ext}`
      const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert:true })
      if (error) throw error
      const { data:{ publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)
      await supabase.from('members').update({ avatar_url: publicUrl }).eq('id', member.id)
      setAvatarUrl(publicUrl)
    } catch(e){ console.error(e) }
    setAvatarUploading(false)
  }

  if (loading) return <div style={{paddingTop:40}}><div className="spinner"/></div>

  const TABS   = ['basics','identity','recovery','goals','preview','account']
  const LABELS = { basics:'Basics', identity:'Identity', recovery:'Recovery', goals:'Goals', preview:'Preview', account:'Account' }

  const dayNum = Math.max(1,Math.floor((new Date()-new Date((member?.membership_start_date||new Date().toISOString().split('T')[0])+'T00:00:00'))/86400000)+1)
  const programs = [1,2,3].filter(n=>P[`program_${n}`]).map(n=>({ name:P[`program_${n}`], date:P[`program_${n}_date`], stats:sobrietyStats(P[`program_${n}_date`]) }))

  return (
    <div style={{paddingTop:20,paddingBottom:48}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20,padding:'0 16px'}}>
        <h2 style={{fontSize:20,fontWeight:400}}>My Profile</h2>
        <button onClick={onClose} style={{color:'rgba(251,250,244,.45)',fontSize:13,fontFamily:'var(--font-ui)'}}>← Back</button>
      </div>

      <div className="tab-bar" style={{marginBottom:20,padding:'0 16px'}}>
        {TABS.map(t=><button key={t} onClick={()=>setTab(t)} className={`tab-btn${tab===t?' active':''}`}>{LABELS[t]}</button>)}
      </div>

      <div style={{padding:'0 16px'}}>

      {/* ── BASICS ── */}
      {tab==='basics' && <>
        {/* Avatar */}
        <div style={{textAlign:'center',marginBottom:20}}>
          <label style={{position:'relative',display:'inline-block',cursor:'pointer'}}
            onDragOver={e=>{e.preventDefault();e.stopPropagation();setDragOver(true)}}
            onDragEnter={e=>{e.preventDefault();e.stopPropagation();setDragOver(true)}}
            onDragLeave={e=>{e.preventDefault();e.stopPropagation();setDragOver(false)}}
            onDrop={e=>{e.preventDefault();e.stopPropagation();setDragOver(false);const f=e.dataTransfer.files[0];if(f)uploadAvatar(f)}}>
            <div style={{width:88,height:88,borderRadius:'50%',overflow:'hidden',border:`3px solid ${dragOver?'var(--lime)':'var(--pink)'}`,background:'rgba(255,20,147,.1)',transition:'border-color .2s',transform:dragOver?'scale(1.08)':'scale(1)'}}>
              {avatarUploading?<div className="spinner" style={{margin:'auto',marginTop:28,width:24,height:24,borderWidth:2}}/>:<img src={avatarUrl} alt="" style={{width:88,height:88,objectFit:'cover'}}/>}
            </div>
            <div style={{position:'absolute',bottom:2,right:2,background:'var(--pink)',borderRadius:'50%',width:24,height:24,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,boxShadow:'0 0 0 2px var(--bg)',pointerEvents:'none'}}>📷</div>
            <input type="file" accept="image/jpeg,image/png,image/gif,image/webp" style={{display:'none'}} onChange={e=>{const f=e.target.files?.[0];if(f)uploadAvatar(f);e.target.value=''}}/>
          </label>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:8}}>{dragOver?'✅ Drop now!':avatarUploading?'Uploading…':'Tap to upload your photo'}</p>
        </div>

        <Lbl t="DISPLAY NAME" req={true} sub="(shown to all members)"/>
        <Inp fieldKey="display_name" P={P} set={set} placeholder="Your community name"/>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginTop:4}}>
          <div><Lbl t="FIRST NAME" req={true}/><Inp fieldKey="first_name" P={P} set={set} placeholder="First"/></div>
          <div><Lbl t="LAST NAME" req={true}/><Inp fieldKey="last_name" P={P} set={set} placeholder="Last"/></div>
        </div>
        <Chk fieldKey="show_full_name" P={P} set={set} label="Show my full name on my member profile"/>

        <Lbl t="ZIP CODE" req={true}/>
        <div style={{display:'flex',gap:10,alignItems:'center'}}>
          <input value={P.zip_code||''} onChange={e=>handleZipChange(e.target.value)} placeholder="90210" maxLength={10} style={{flex:'0 0 120px'}}/>
          {zipLooking&&<span style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>Looking up…</span>}
          {P.city&&!zipLooking&&<span style={{fontSize:13,color:'var(--lime)',fontFamily:'var(--font-ui)'}}>📍 {P.city}</span>}
        </div>
        <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginTop:4}}>City auto-fills. Only your city is shown to members — never your zip.</p>

        <Lbl t="TIMEZONE" req={true}/>
        <Sel fieldKey="timezone" P={P} set={set} opts={TIMEZONES} ph="Select timezone…"/>

        <Lbl t="PHONE" sub="(for reminders)"/>
        <input value={P.phone||''} onChange={e=>set('phone',formatPhone(e.target.value))} placeholder="(555) 555-5555" type="tel"/>
        <Chk fieldKey="show_phone" P={P} set={set} label="Show my phone number on my member profile"/>

        <Lbl t="EMAIL" sub="(your login email — cannot be changed)"/>
        <p style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',padding:'10px 12px',borderRadius:8,background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.07)',marginBottom:4}}>{user.email}</p>
        <Chk fieldKey="show_email" P={P} set={set} label="Show my email address on my member profile"/>

        <Lbl t="DATE OF BIRTH"/>
        <input type="date" value={P.birth_date||''} onChange={e=>set('birth_date',e.target.value||null)}/>
        <Chk fieldKey="show_age" P={P} set={set} label="Show my age on my member profile"/>
        <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginTop:6,lineHeight:1.6}}>
          Your birthday (month &amp; day) always appears on the community calendar. Only your age is optional.
        </p>
      </>}

      {/* ── IDENTITY ── */}
      {tab==='identity' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:16}}>
          All fields are optional. Whatever you fill in will appear on your member profile. Leave blank anything you prefer to keep private.
        </p>
        <Lbl t="PRONOUNS"/><Sel fieldKey="pronouns" P={P} set={set} opts={PRONOUNS} ph="Select pronouns…"/>
        <Lbl t="SEXUAL ORIENTATION"/><Sel fieldKey="sexual_orientation" P={P} set={set} opts={ORIENTATIONS} ph="Select…"/>
        <Lbl t="GENDER IDENTITY"/><Sel fieldKey="gender_identity" P={P} set={set} opts={GENDERS} ph="Select…"/>
        <Lbl t="RACE / ETHNICITY"/><Sel fieldKey="ethnicity" P={P} set={set} opts={ETHNICITIES} ph="Select…"/>
        <Lbl t="SPOKEN LANGUAGES"/><Chips fieldKey="spoken_languages" P={P} set={set} opts={LANGUAGES}/>
        <Lbl t="WRITTEN LANGUAGES"/><Chips fieldKey="written_languages" P={P} set={set} opts={LANGUAGES}/>
        <Lbl t="PETS" sub="(optional)"/>
        {pets.map((pet,i)=>(
          <div key={i} style={{display:'flex',gap:8,alignItems:'center',marginBottom:8,marginTop:i===0?8:0}}>
            <select value={pet.type} onChange={e=>setPet(i,'type',e.target.value)} style={{flex:'0 0 130px'}}>{PET_TYPES.map(t=><option key={t} value={t}>{t}</option>)}</select>
            <input value={pet.name} onChange={e=>setPet(i,'name',e.target.value)} placeholder="Pet's name" style={{flex:1}}/>
            <button onClick={()=>removePet(i)} style={{background:'none',border:'none',color:'rgba(251,250,244,.35)',cursor:'pointer',fontSize:20,padding:'0 4px'}}>×</button>
          </div>
        ))}
        <button onClick={addPet} style={{marginTop:8,padding:'8px 14px',borderRadius:8,background:'rgba(255,255,255,.06)',border:'1px solid var(--border)',color:'rgba(251,250,244,.6)',fontSize:13,fontFamily:'var(--font-ui)',cursor:'pointer'}}>+ Add a Pet</button>
      </>}

      {/* ── RECOVERY ── */}
      {tab==='recovery' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:16}}>
          Everything you fill in here will appear on your member profile. Add up to 3 programs.
        </p>
        {[1,2,3].map(n=>(
          <div key={n} className="card" style={{marginBottom:12}}>
            <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1}}>PROGRAM {n} {n>1&&<span style={{color:'rgba(251,250,244,.2)' }}>(optional)</span>}</p>
            <select value={P[`program_${n}`]||''} onChange={e=>set(`program_${n}`,e.target.value)} style={{marginTop:6,marginBottom:10}}>
              <option value="">Select program…</option>
              {PROGRAMS.map(p=><option key={p} value={p}>{p}</option>)}
            </select>
            {P[`program_${n}`]&&<>
              <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:6}}>SOBRIETY / EFFECTIVE DATE</p>
              <input type="date" value={P[`program_${n}_date`]||''} onChange={e=>set(`program_${n}_date`,e.target.value||null)}/>
              {sobrietyStats(P[`program_${n}_date`])&&(
                <div style={{marginTop:8,padding:'8px 12px',borderRadius:8,background:'rgba(25,229,94,.08)',border:'1px solid rgba(25,229,94,.15)'}}>
                  <span style={{fontSize:13,color:'var(--lime)',fontFamily:'var(--font-ui)'}}>🌱 {sobrietyStats(P[`program_${n}_date`]).label} · {sobrietyStats(P[`program_${n}_date`]).days.toLocaleString()} days</span>
                </div>
              )}
              {P[`program_${n}_date`]&&(
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginTop:10,paddingTop:10,borderTop:'1px solid rgba(255,255,255,.06)'}}>
                  <span style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)'}}>Show years on community calendar</span>
                  <button onClick={()=>set(`show_years_${n}`,P[`show_years_${n}`]===false?true:false)}
                    style={{fontSize:11,fontFamily:'var(--font-ui)',padding:'4px 12px',borderRadius:20,cursor:'pointer',
                      background:P[`show_years_${n}`]!==false?'rgba(25,229,94,.12)':'rgba(255,255,255,.06)',
                      border:`1px solid ${P[`show_years_${n}`]!==false?'rgba(25,229,94,.3)':'rgba(255,255,255,.12)'}`,
                      color:P[`show_years_${n}`]!==false?'var(--lime)':'rgba(251,250,244,.35)'}}>
                    {P[`show_years_${n}`]!==false?'Showing Years':'Years Hidden'}
                  </button>
                </div>
              )}
            </>}
          </div>
        ))}

        <div className="card" style={{marginBottom:12}}>
          <p style={{fontSize:15,fontWeight:600,fontFamily:'var(--font-ui)',marginBottom:4}}>🏠 Home Group</p>
          <p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',lineHeight:1.65,marginBottom:10}}>
            Find your meeting, then enter the details below.
          </p>
          <div style={{display:'flex',gap:12,marginBottom:14,flexWrap:'wrap'}}>
            <a href="https://www.aa.org/meeting-guide" target="_blank" rel="noreferrer"
              style={{fontSize:13,color:'var(--pink)',fontFamily:'var(--font-ui)',textDecoration:'none',padding:'8px 14px',borderRadius:8,background:'rgba(255,20,147,.08)',border:'1px solid rgba(255,20,147,.2)'}}>
              📱 Open Meeting Guide App →
            </a>
            <a href="https://www.aa.org/find-aa" target="_blank" rel="noreferrer"
              style={{fontSize:13,color:'var(--pink)',fontFamily:'var(--font-ui)',textDecoration:'none',padding:'8px 14px',borderRadius:8,background:'rgba(255,20,147,.08)',border:'1px solid rgba(255,20,147,.2)'}}>
              🔍 Find a Meeting on AA.org →
            </a>
          </div>
          <Lbl t="MEETING NAME"/><Inp fieldKey="homegroup_name" P={P} set={set} placeholder="e.g. Sunday Serenity Group"/>
          <Lbl t="DAY"/><Sel fieldKey="homegroup_day" P={P} set={set} opts={['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']} ph="Select day…"/>
          <Lbl t="TIME"/><input type="time" value={P.homegroup_time||''} onChange={e=>set('homegroup_time',e.target.value)}/>
          <Lbl t="FORMAT"/><Sel fieldKey="homegroup_format" P={P} set={set} opts={['In-Person','Online (Zoom)','Hybrid']} ph="Select…"/>
          {(P.homegroup_format==='Online (Zoom)'||P.homegroup_format==='Hybrid')?<><Lbl t="ZOOM LINK"/><Inp fieldKey="homegroup_location" P={P} set={set} placeholder="https://zoom.us/j/…"/></>:<><Lbl t="LOCATION / ADDRESS"/><Inp fieldKey="homegroup_location" P={P} set={set} placeholder="123 Main St, City, State"/></>}
          <Lbl t="NOTES" sub="(optional)"/><textarea rows={2} value={P.homegroup_notes||''} onChange={e=>set('homegroup_notes',e.target.value)} style={{resize:'vertical'}}/>
        </div>

        <Lbl t="RECOVERY BIO" sub="(max 500 chars)"/>
        <textarea rows={5} value={P.recovery_bio||''} onChange={e=>set('recovery_bio',e.target.value)} placeholder="Share what brought you here, what keeps you going…" style={{resize:'vertical'}}/>
        <p style={{fontSize:11,color:'rgba(251,250,244,.25)',fontFamily:'var(--font-ui)',textAlign:'right',marginTop:4}}>{(P.recovery_bio||'').length}/500</p>
      </>}

      {/* ── GOALS ── */}
      {tab==='recovery' && <>
        {/* ── Meeting Reminder Notification ── */}
        <div className="card" style={{marginBottom:12, background:'rgba(25,229,94,.04)', border:'1px solid rgba(25,229,94,.1)'}}>
          <div style={{display:'flex', gap:10, alignItems:'flex-start', marginBottom:8}}>
            <span style={{fontSize:20, flexShrink:0}}>🎙</span>
            <div>
              <p style={{fontSize:14, fontWeight:600, color:'var(--cream)', marginBottom:4}}>Daily Meeting Reminder</p>
              <p style={{fontSize:12, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.6}}>
                Receive an email 30 minutes before the daily YRTCYK Zoom meeting (5:30 PM PT) with a one-click join link.
              </p>
            </div>
          </div>
          <Chk fieldKey="meeting_reminder" P={P} set={set} label="Send me a 30-minute heads-up before each meeting"/>
        </div>
      </>}

      {tab==='goals' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:4}}>Select the areas of your life you want to focus on in recovery.</p>
        <p style={{fontSize:12,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:20}}>Your selected topics will appear on your member profile.</p>
        {WELLNESS_AREAS.map(area=><WellnessArea key={area.key} area={area} selectedTopics={P.wellness_topics||[]} onToggle={t=>toggleList('wellness_topics',t)}/>)}
      </>}

      {/* ── PREVIEW ── */}
      {tab==='preview' && (()=>{
        const pets_ = parsePets(P.pets)
        const langs = [...new Set([...(P.spoken_languages||[]),...(P.written_languages||[])])]
        const wellness = P.wellness_topics||[]
        return (
          <div>
            <p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',lineHeight:1.65,marginBottom:20,fontStyle:'italic'}}>This is what other members see when they tap your name.</p>
            <div style={{background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,20,147,.15)',borderRadius:14,padding:24,marginBottom:16}}>

              {/* Avatar + name */}
              <div style={{textAlign:'center',marginBottom:20}}>
                <div style={{width:72,height:72,borderRadius:'50%',overflow:'hidden',border:'2px solid rgba(255,20,147,.3)',margin:'0 auto 12px'}}>
                  <img src={avatarUrl} alt="" style={{width:72,height:72,objectFit:'cover'}}/>
                </div>
                <h3 style={{fontSize:19,fontWeight:400,marginBottom:4}}>{P.display_name||user.email.split('@')[0]}</h3>
                {P.show_full_name&&P.first_name&&<p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom:4}}>{P.first_name} {P.last_name}</p>}
                {P.pronouns&&<p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',marginBottom:4}}>{P.pronouns}</p>}
                {P.city&&<p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)'}}>📍 {P.city}</p>}
                {P.timezone&&<p style={{fontSize:12,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginTop:4}}>🕐 {P.timezone.split('/').pop().replace('_',' ')}</p>}
                {P.show_age&&P.birth_date&&<p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',marginTop:4}}>Age {Math.floor((new Date()-new Date(P.birth_date+'T00:00:00'))/(365.25*86400000))}</p>}
                {P.show_phone&&P.phone&&<p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',marginTop:4}}>📱 {P.phone}</p>}
              </div>

              {/* Programs with full sobriety stats */}
              {programs.length>0&&(
                <div style={{marginBottom:16}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>RECOVERY</p>
                  {programs.map((pg,i)=>(
                    <div key={i} style={{padding:'12px',borderRadius:10,background:'rgba(25,229,94,.06)',border:'1px solid rgba(25,229,94,.15)',marginBottom:8}}>
                      <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                        <span style={{fontSize:14,color:'rgba(251,250,244,.85)',fontWeight:600}}>{pg.name}</span>
                        {pg.stats&&<span style={{fontSize:13,color:'var(--lime)',fontFamily:'var(--font-ui)',fontWeight:700}}>{pg.stats.label}</span>}
                      </div>
                      {pg.stats&&(
                        <div style={{display:'flex',gap:16,marginTop:6}}>
                          <span style={{fontSize:11,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>{pg.stats.days.toLocaleString()} days</span>
                          {pg.date&&<span style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)'}}>Since {new Date(pg.date+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</span>}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Recovery bio */}
              {P.recovery_bio&&(
                <div style={{marginBottom:16}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:8}}>ABOUT</p>
                  <p style={{fontSize:13,color:'rgba(251,250,244,.7)',lineHeight:1.8,fontStyle:'italic'}}>"{P.recovery_bio}"</p>
                </div>
              )}

              {/* SOGI */}
              {(P.gender_identity||P.sexual_orientation||P.ethnicity)&&(
                <div style={{marginBottom:16}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>IDENTITY</p>
                  <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
                    {P.gender_identity&&<span style={{padding:'5px 12px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.2)',color:'rgba(251,250,244,.75)'}}>{P.gender_identity}</span>}
                    {P.sexual_orientation&&<span style={{padding:'5px 12px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.2)',color:'rgba(251,250,244,.75)'}}>{P.sexual_orientation}</span>}
                    {P.ethnicity&&<span style={{padding:'5px 12px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)'}}>{P.ethnicity}</span>}
                  </div>
                </div>
              )}

              {/* Languages */}
              {langs.length>0&&<div style={{marginBottom:12}}><p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:6}}>LANGUAGES</p><p style={{fontSize:13,color:'rgba(251,250,244,.65)'}}>{langs.join(' · ')}</p></div>}

              {/* Pets */}
              {pets_.length>0&&<div style={{marginBottom:12}}><p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:6}}>PETS 🐾</p><p style={{fontSize:13,color:'rgba(251,250,244,.65)'}}>{pets_.map(p=>p.name?`${p.type} named ${p.name}`:p.type).join(', ')}</p></div>}

              {/* Wellness */}
              {wellness.length>0&&(
                <div style={{marginBottom:12}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:8}}>RECOVERY FOCUS</p>
                  <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
                    {wellness.map(t=><span key={t} style={{padding:'4px 10px',borderRadius:20,fontSize:11,fontFamily:'var(--font-ui)',background:'rgba(25,229,94,.08)',border:'1px solid rgba(25,229,94,.18)',color:'rgba(251,250,244,.6)'}}>{t}</span>)}
                  </div>
                </div>
              )}

              {/* Homegroup */}
              {P.homegroup_name&&(
                <div style={{marginTop:16,paddingTop:16,borderTop:'1px solid rgba(255,255,255,.07)',marginBottom:12}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>🏠 HOME GROUP</p>
                  <div style={{padding:'12px 14px',borderRadius:10,background:'rgba(25,229,94,.05)',border:'1px solid rgba(25,229,94,.12)'}}>
                    <p style={{fontSize:14,fontWeight:600,color:'var(--cream)',marginBottom:4}}>{P.homegroup_name}</p>
                    <p style={{fontSize:12,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.7}}>
                      {[P.homegroup_day, P.homegroup_time ? new Date('1970-01-01T'+P.homegroup_time).toLocaleTimeString('en-US',{hour:'numeric',minute:'2-digit'}) : null, P.homegroup_format].filter(Boolean).join('  ·  ')}
                    </p>
                    {P.homegroup_notes&&<p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:4,fontStyle:'italic'}}>{P.homegroup_notes}</p>}
                    {(P.homegroup_format==='Online (Zoom)'||P.homegroup_format==='Hybrid')&&P.homegroup_location&&(
                      <a href={P.homegroup_location} target="_blank" rel="noopener noreferrer"
                        style={{display:'inline-block',marginTop:8,fontSize:11,fontFamily:'var(--font-ui)',color:'var(--lime)',textDecoration:'none'}}>
                        🎥 Join meeting →
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Get in touch */}
              {(P.show_email||P.show_phone)&&(P.email||P.phone)&&(
                <div style={{marginTop:16,paddingTop:16,borderTop:'1px solid rgba(255,255,255,.07)',marginBottom:12}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>💌 GET IN TOUCH</p>
                  <div style={{display:'flex',flexDirection:'column',gap:6}}>
                    {P.show_email&&P.email&&(
                      <a href={'mailto:'+P.email} style={{fontSize:13,color:'var(--pink)',textDecoration:'none',fontFamily:'var(--font-ui)'}}>
                        ✉️ {P.email}
                      </a>
                    )}
                    {P.show_phone&&P.phone&&(
                      <a href={'tel:'+P.phone} style={{fontSize:13,color:'var(--pink)',textDecoration:'none',fontFamily:'var(--font-ui)'}}>
                        📱 {P.phone}
                      </a>
                    )}
                  </div>
                </div>
              )}

              {/* Approved Heroes */}
              {approvedHeroes.length>0&&(
                <div style={{marginTop:16,paddingTop:16,borderTop:'1px solid rgba(255,255,255,.07)',marginBottom:12}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>⭐ MY HEROES</p>
                  <div style={{display:'flex',flexDirection:'column',gap:8}}>
                    {approvedHeroes.map(h=>{
                      const thumb=h.photos?.[h.thumbnail_index]||h.photos?.[0]
                      const typeIcon=h.hero_type==='person'?'🧑':h.hero_type==='place'?'📍':'✨'
                      const typeLabel=h.hero_type==='person'?'Person':h.hero_type==='place'?'Place':'Thing'
                      return(
                        <div key={h.id} style={{display:'flex',alignItems:'center',gap:12,padding:'10px 12px',borderRadius:10,background:'rgba(255,20,147,.05)',border:'1px solid rgba(255,20,147,.1)'}}>
                          {thumb&&<img src={thumb} alt="" style={{width:40,height:40,borderRadius:8,objectFit:'cover',flexShrink:0}}/>}
                          {!thumb&&<span style={{fontSize:24,flexShrink:0}}>{typeIcon}</span>}
                          <div style={{flex:1,minWidth:0}}>
                            <p style={{fontSize:13,fontWeight:600,color:'var(--cream)',marginBottom:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{h.hero_name}</p>
                            <p style={{fontSize:10,color:'rgba(255,20,147,.6)',fontFamily:'var(--font-ui)',letterSpacing:.5}}>{typeIcon} {typeLabel.toUpperCase()}</p>
                          </div>
                          <span style={{fontSize:10,color:'rgba(251,250,244,.2)',fontFamily:'var(--font-ui)',flexShrink:0}}>see gallery →</span>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {/* Community Contributions */}
              {contributions&&(
                <div style={{marginTop:16,paddingTop:16,borderTop:'1px solid rgba(255,255,255,.07)'}}>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:12}}>COMMUNITY CONTRIBUTIONS</p>
                  <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
                    {[
                      ['Friends Referred', contributions.referred],
                      ['Friends Joined',   contributions.joined],
                      ['Heroes — Person',  contributions.heroes_person],
                      ['Heroes — Place',   contributions.heroes_place],
                      ['Heroes — Thing',   contributions.heroes_thing],
                      ['Blog Posts',       contributions.blog_posts],
                      ['Blog Responses',   contributions.blog_comments],
                    ].map(([label,val])=>(
                      <div key={label} style={{padding:'10px 12px',borderRadius:8,background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.07)'}}>
                        <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:.5,marginBottom:4}}>{label}</p>
                        <p style={{fontSize:20,fontWeight:700,color:val>0?'var(--pink)':'rgba(251,250,244,.2)',fontFamily:'var(--font-ui)'}}>{val}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ── Word of Mouth: places this member loves ── */}
              {womPlaces.length > 0 && (
                <div style={{marginTop:16, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.07)'}}>
                  <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:12}}>💋 WORD OF MOUTH</p>
                  <div style={{display:'flex', flexDirection:'column', gap:8}}>
                    {womPlaces.map(p => {
                      const mapsUrl = p.place_id
                        ? 'https://www.google.com/maps/place/?q=place_id:' + p.place_id
                        : 'https://www.google.com/maps/search/' + encodeURIComponent(p.business_name + ' ' + p.city)
                      const visitUrl = p.website_url && p.website_url.startsWith('http') ? p.website_url : null
                      return (
                        <div key={p.id} style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 12px', borderRadius:8, background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.07)'}}>
                          <div>
                            <p style={{fontSize:13, fontWeight:600, color:'var(--cream)', marginBottom:2}}>{p.business_name}</p>
                            <p style={{fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)'}}>{p.city}</p>
                          </div>
                          <div style={{display:'flex', gap:6, flexShrink:0}}>
                            {visitUrl && (
                              <a href={visitUrl} target="_blank" rel="noopener noreferrer"
                                style={{padding:'5px 10px', borderRadius:6, background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.25)', color:'var(--pink)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none'}}>
                                🌐
                              </a>
                            )}
                            <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                              style={{padding:'5px 10px', borderRadius:6, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.2)', color:'var(--lime)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none'}}>
                              📍
                            </a>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </div>
              )}

              {member?.membership_start_date&&<p style={{fontSize:11,color:'rgba(251,250,244,.2)',fontFamily:'var(--font-ui)',textAlign:'center',marginTop:16}}>Member since {new Date(member.membership_start_date).toLocaleDateString('en-US',{month:'long',year:'numeric'})}</p>}
            </div>
          </div>
        )
      })()}

      {/* ── ACCOUNT ── */}
      {tab==='account' && <>

        {/* Member Number Card */}
        {member?.member_number && (
          <div style={{background:'linear-gradient(135deg,rgba(255,20,147,.08),rgba(25,229,94,.05))',border:'1px solid rgba(255,20,147,.25)',borderRadius:14,padding:'24px 20px',marginBottom:24,textAlign:'center'}}>
            <p style={{fontSize:11,letterSpacing:3,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',textTransform:'uppercase',marginBottom:10}}>Your Place in the Story</p>
            <p style={{fontSize:52,fontWeight:700,color:'var(--pink)',fontFamily:'var(--font-ui)',lineHeight:1,marginBottom:6}}>#{member.member_number}</p>
            <p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom: member.member_number <= 10 ? 12 : 0}}>
              You are Member #{member.member_number} of YRTCYK.
            </p>
            {member.member_number <= 100 && (
              <div style={{display:'inline-block',background:'rgba(25,229,94,.12)',border:'1px solid rgba(25,229,94,.3)',borderRadius:20,padding:'4px 14px',marginTop:4}}>
                <span style={{fontSize:11,color:'var(--lime)',fontFamily:'var(--font-ui)',fontWeight:700,letterSpacing:1}}>🌈 FOUNDING MEMBER</span>
              </div>
            )}
          </div>
        )}

        <div style={{marginBottom:24}}>
          {[['Email',user.email],['Membership',member?.membership_tier==='web_app'?'Web + App':'Web'],['Member Since',member?.membership_start_date?new Date(member.membership_start_date).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'}):'—'],['Status','● Active'],['Day',`${dayNum} of 365`]].map(([label,value])=>(
            <div key={label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 0',borderBottom:'1px solid rgba(255,255,255,.06)'}}>
              <span style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.45)'}}>{label}</span>
              <span style={{fontSize:13,fontFamily:'var(--font-ui)',color:label==='Status'?'var(--lime)':'var(--cream)'}}>{value}</span>
            </div>
          ))}
        </div>
        <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:12}}>YOUR REFERRAL IMPACT</p>
        {referrals.length===0?<p style={{fontSize:13,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',fontStyle:'italic',marginBottom:20}}>No referrals yet. Share your invite link from the 🌈 Widen the Circle tab.</p>:(
          <div style={{marginBottom:20}}>
            {referrals.map(r=>(
              <div key={r.id} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'10px 0',borderBottom:'1px solid rgba(255,255,255,.05)'}}>
                <span style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.6)'}}>{r.referred_email||'Member'}</span>
                <span style={{fontSize:12,fontFamily:'var(--font-ui)',color:{invited:'rgba(251,250,244,.35)',joined:'gold',month_1:'orange',month_2:'var(--lime)',rewarded:'var(--lime)'}[r.status]||'rgba(251,250,244,.4)'}}>{({invited:'Invited',joined:'Joined ✓',month_1:'Month 1 ✓',month_2:'Month 2 ✓',rewarded:'Rewarded 🎁'})[r.status]||r.status}</span>
              </div>
            ))}
          </div>
        )}
        <button onClick={()=>supabase.auth.signOut()} style={{width:'100%',padding:'12px',borderRadius:8,background:'rgba(255,255,255,.05)',border:'1px solid var(--border)',color:'rgba(251,250,244,.5)',fontSize:14,fontFamily:'var(--font-ui)',cursor:'pointer',marginTop:8}}>Sign Out</button>
      </>}

      </div>

      {/* ── MODERATOR PATH ── */}
      {tab!=='account'&&tab!=='preview'&&(
        <div style={{margin:'28px 16px 0',background:'rgba(255,20,147,.04)',border:'1px solid rgba(255,20,147,.15)',borderRadius:12,padding:20}}>
          <p style={{fontSize:13,fontWeight:700,color:'var(--pink)',fontFamily:'var(--font-ui)',marginBottom:10}}>✨ The Path to Moderator</p>
          <p style={{fontSize:13,color:'rgba(251,250,244,.55)',fontFamily:'var(--font-ui)',lineHeight:1.65,marginBottom:16}}>YRTCYK is moderated by members who have earned it — through consistent daily practice, genuine community contribution, and showing up for the WE of recovery.</p>
          {[
            {step:'1',text:'Complete The Daily Action consistently as a paying member'},
            {step:'2',text:'Share your Heroes, support your fellows, show up with honesty'},
            {step:'3',text:'Receive your invitation to become an Approved Moderator'},
          ].map(({step,text})=>(
            <div key={step} style={{display:'flex',alignItems:'flex-start',gap:12,marginBottom:10}}>
              <div style={{background:'var(--pink)',color:'#fff',borderRadius:'50%',width:22,height:22,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,flexShrink:0,marginTop:1}}>{step}</div>
              <p style={{fontSize:13,color:'rgba(251,250,244,.65)',fontFamily:'var(--font-ui)',margin:0,lineHeight:1.5}}>{text}</p>
            </div>
          ))}
        </div>
      )}

      {tab!=='account'&&tab!=='preview'&&(
        <div style={{padding:'24px 16px 0'}}>
          {msg&&<p style={{fontSize:13,fontFamily:'var(--font-ui)',textAlign:'center',marginBottom:12,color:msg.startsWith('Error')||msg.includes('required')?'var(--pink)':'var(--lime)'}}>{msg}</p>}
          <button className="btn-primary" style={{width:'100%',padding:14}} onClick={save} disabled={saving||!dirty}>{saving?'Saving…':'Save Changes'}</button>
        </div>
      )}
    </div>
  )
}
