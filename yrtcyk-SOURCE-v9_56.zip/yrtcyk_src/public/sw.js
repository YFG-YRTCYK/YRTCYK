/**
 * YRTCYK Service Worker — v9.44
 *
 * Phase 2 part 1 — Admin visibility & branding.
 *
 *  - Members directory query now fetches operators (was filtered out at SQL level).
 *    Added is_operator to SELECT. Filter logic excludes operators by default,
 *    reveals them ONLY when the new "👑 Admin" filter pill is active.
 *  - 5th filter pill added: All / Moderators / Trailblazers / Founding / Admin.
 *    Admin filter returns exactly one result (gvitrano@icloud.com per architecture).
 *  - YFG wand+wordmark image (existing /fairy_godfather.jpg already in bundle and
 *    APP_SHELL pre-cache, used in sticky header lockup) repurposed as the admin's
 *    avatar. Set as gvitrano@icloud.com avatar_url via SQL once deploy lands
 *    (post-deploy SQL update by chat-side Claude, not in this bundle).
 *
 * Phase 2 part 2 — Edit as Admin button — ships separately as v9.45.
 */

const CACHE_VERSION = 'yrtcyk-v9.44';
const APP_SHELL = [
  '/',
  '/index.html',
  '/manifest.webmanifest',
  '/yrtcyk_triangle.png',
  '/fairy_godfather.jpg',
  '/favicon.ico',
  '/favicon-16.png',
  '/favicon-32.png',
  '/favicon-48.png',
  '/apple-touch-icon.png',
  '/icon-192.png',
  '/icon-512.png',
  '/icon-maskable-512.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_VERSION).then((cache) => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  if (url.pathname.startsWith('/assets/')) {
    event.respondWith(cacheFirst(req));
    return;
  }
  event.respondWith(networkFirstWithCacheFallback(req));
});

async function cacheFirst(req) {
  const cached = await caches.match(req);
  if (cached) return cached;
  try {
    const res = await fetch(req);
    if (res && res.status === 200) {
      const cache = await caches.open(CACHE_VERSION);
      cache.put(req, res.clone());
    }
    return res;
  } catch (e) {
    return cached || Response.error();
  }
}

async function networkFirstWithCacheFallback(req) {
  try {
    const res = await fetch(req);
    if (res && res.status === 200) {
      const cache = await caches.open(CACHE_VERSION);
      cache.put(req, res.clone());
    }
    return res;
  } catch (e) {
    const cached = await caches.match(req);
    if (cached) return cached;
    if (req.mode === 'navigate') {
      return caches.match('/index.html');
    }
    return Response.error();
  }
}
