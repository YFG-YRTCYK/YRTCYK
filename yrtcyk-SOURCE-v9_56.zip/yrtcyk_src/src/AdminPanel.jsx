// ========================================================================
// AdminPanel.jsx — v9.7 (April 18, 2026)
//
// Full admin cockpit. Six tabs:
//   👥 Members       — activate/deactivate, Moderator toggle, Trailblazer toggle,
//                      set membership_end_reason (including deceased + date)
//   📝 Reflections   — post + comment review queue (embeds ModeratorPanel)
//   🕊️ Heroes        — mark a Hero as In Loving Memory
//   💬 Hero Comments — existing hero-comment approval queue
//   🛒 Marketplace   — review member-submitted item requests (v9.51 Item 8)
//   🗑️ Deletions     — GDPR/CCPA deletion queue (cancel pending on member's behalf)
//   📊 Analytics     — platform dashboard
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'
import ModeratorPanel from './ModeratorPanel'
import HeroMemorialAdmin from './HeroMemorialAdmin'
import DeletionQueueAdmin from './DeletionQueueAdmin'
import AdminAnalytics from './AdminAnalytics'

export default function AdminPanel({ user, onClose }) {
  const [tab, setTab] = useState('members')
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [pendingHeroComments, setPendingHeroComments] = useState([])
  // v9.51 Item 8 — Marketplace requests admin queue
  const [marketRequests, setMarketRequests] = useState([])
  const [marketAdminId, setMarketAdminId] = useState(null) // current admin's member id, for reviewed_by
  const [expandedMember, setExpandedMember] = useState(null)
  const [msg, setMsg] = useState('')

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    const [mRes, hcRes, mrRes, meRes] = await Promise.all([
      supabase.from('members').select('*').order('member_number', { ascending: true, nullsFirst: false }),
      supabase.from('hero_comments').select('*').eq('status', 'pending').order('created_at'),
      // v9.51 Item 8 — pending + recently-reviewed (last 50) marketplace item requests
      supabase.from('marketplace_item_requests')
        .select('id, member_id, title, purchase_url, reason, status, admin_note, reviewed_at, created_at')
        .order('created_at', { ascending: false })
        .limit(50),
      supabase.from('members').select('id').eq('email', user.email).single(),
    ])
    setMembers(mRes.data || [])
    setPendingHeroComments(hcRes.data || [])
    setMarketRequests(mrRes.data || [])
    setMarketAdminId(meRes?.data?.id || null)
    setLoading(false)
  }

  async function toggleModerator(id, current) {
    await supabase.from('members').update({ is_moderator: !current }).eq('id', id)
    loadAll()
  }
  async function toggleTrailblazer(id, current) {
    await supabase.from('members').update({ is_trailblazer: !current }).eq('id', id)
    loadAll()
  }
  async function toggleActive(id, current) {
    await supabase.from('members').update({ is_active: !current }).eq('id', id)
    loadAll()
  }

  async function setEndReason(id, reason, dateOfPassing = null) {
    const payload = { membership_end_reason: reason }
    if (reason === 'deceased' && dateOfPassing) payload.date_of_passing = dateOfPassing
    if (reason === null) payload.date_of_passing = null
    const { error } = await supabase.from('members').update(payload).eq('id', id)
    if (error) { setMsg('Error: ' + error.message); return }
    setMsg('Updated.'); setTimeout(() => setMsg(''), 2000)
    loadAll()
  }

  async function approveHeroComment(id) {
    await supabase.from('hero_comments').update({ status: 'approved' }).eq('id', id)
    setPendingHeroComments(prev => prev.filter(c => c.id !== id))
  }
  async function rejectHeroComment(id) {
    await supabase.from('hero_comments').update({ status: 'rejected' }).eq('id', id)
    setPendingHeroComments(prev => prev.filter(c => c.id !== id))
  }

  // v9.51 Item 8 — Marketplace request approval flow.
  // Approve: insert a new marketplace_items row using the request's data,
  // then mark the request as approved. Deny: just mark with optional note.
  async function approveItemRequest(req) {
    setMsg('')
    const purchaseUrl = (req.purchase_url || '').trim()
    if (!purchaseUrl || !/^https?:\/\//i.test(purchaseUrl)) {
      setMsg('Error: cannot approve — request has no valid purchase URL. Edit it via SQL or deny with a note asking the member for a URL.')
      return
    }
    // Insert into catalog at the next display_order slot
    const { data: maxRow } = await supabase
      .from('marketplace_items').select('display_order').order('display_order', { ascending: false }).limit(1).single()
    const nextOrder = (maxRow?.display_order || 0) + 1
    const { error: insErr } = await supabase.from('marketplace_items').insert({
      title: req.title,
      purchase_url: purchaseUrl,
      category: 'Books', // Admin can re-categorize via SQL if needed; default for v1
      display_order: nextOrder,
      status: 'active',
    })
    if (insErr) { setMsg('Error: ' + insErr.message); return }
    const { error: updErr } = await supabase.from('marketplace_item_requests').update({
      status: 'approved',
      reviewed_at: new Date().toISOString(),
      reviewed_by: marketAdminId,
    }).eq('id', req.id)
    if (updErr) { setMsg('Error: ' + updErr.message); return }
    setMsg(`Approved “${req.title}” and added to catalog.`); setTimeout(() => setMsg(''), 3500)
    loadAll()
  }
  async function denyItemRequest(req) {
    const note = window.prompt('Optional note to the member (why this isn\u2019t a fit, or what would help):', '') || ''
    const { error } = await supabase.from('marketplace_item_requests').update({
      status: 'denied',
      admin_note: note.trim() || null,
      reviewed_at: new Date().toISOString(),
      reviewed_by: marketAdminId,
    }).eq('id', req.id)
    if (error) { setMsg('Error: ' + error.message); return }
    setMsg(`Denied “${req.title}”.`); setTimeout(() => setMsg(''), 3000)
    loadAll()
  }

  return (
    <div style={{ padding:'20px 16px 40px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>⚙️ Admin</h2>
        <button onClick={onClose} style={{ color:'rgba(251,250,244,.5)', fontSize:13, fontFamily:'var(--font-ui)' }}>
          ← Back
        </button>
      </div>

      <div style={{ display:'flex', gap:6, marginBottom:20, overflowX:'auto', flexWrap:'nowrap', paddingBottom:4 }}>
        {(() => {
          const pendingMarket = marketRequests.filter(r => r.status === 'pending').length
          return [
            ['members', '👥 Members'],
            ['reflections', '📝 Reflections'],
            ['heroes', '🕊️ Heroes'],
            ['herocomments', `💬 Hero Comments${pendingHeroComments.length ? ` (${pendingHeroComments.length})` : ''}`],
            ['marketplace', `🛒 Marketplace${pendingMarket ? ` (${pendingMarket})` : ''}`],
            ['deletions', '🗑️ Deletions'],
            ['analytics', '📊 Analytics']
          ].map(([t, label]) => (
            <button key={t} onClick={() => setTab(t)}
              style={{
                padding:'8px 12px', borderRadius:8, fontSize:11, fontFamily:'var(--font-ui)', cursor:'pointer',
                background: tab === t ? 'var(--pink)' : 'rgba(255,255,255,.06)',
                color: tab === t ? '#fff' : 'rgba(251,250,244,.55)',
                border: `1px solid ${tab === t ? 'var(--pink)' : 'rgba(255,255,255,.1)'}`,
                whiteSpace:'nowrap', flexShrink:0
              }}>
              {label}
            </button>
          ))
        })()}
      </div>

      {msg && <p style={{
        fontSize:12, fontFamily:'var(--font-ui)', textAlign:'center', marginBottom:12,
        color: msg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)'
      }}>{msg}</p>}

      {/* ── MEMBERS TAB ── */}
      {tab === 'members' && (
        <>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1, marginBottom:16 }}>MEMBER MANAGEMENT · {members.length} TOTAL</p>
          {loading && <div className="spinner"/>}
          {members.map(m => {
            const isSelf = m.email === user.email
            const isExpanded = expandedMember === m.id
            return (
              <div key={m.id} className="card" style={{ marginBottom:10 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8, gap:8 }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:14, fontWeight:500 }}>
                      {m.display_name || m.email.split('@')[0]}
                      {m.member_number && (
                        <span style={{ fontSize:11, color:'rgba(251,250,244,.35)',
                          fontFamily:'var(--font-ui)', marginLeft:8 }}>#{m.member_number}</span>
                      )}
                    </p>
                    <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      overflow:'hidden', textOverflow:'ellipsis' }}>{m.email}</p>
                    <div style={{ marginTop:6 }}>
                      <MemberBadges member={m} size="sm"/>
                    </div>
                  </div>
                  <span style={{
                    fontSize:10, fontFamily:'var(--font-ui)', padding:'2px 8px', borderRadius:20,
                    background: m.is_active ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.07)',
                    color: m.is_active ? 'var(--lime)' : 'rgba(251,250,244,.4)',
                    border:'1px solid ' + (m.is_active ? 'rgba(25,229,94,.25)' : 'rgba(255,255,255,.1)'),
                    flexShrink:0
                  }}>
                    {m.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                  <button onClick={() => toggleActive(m.id, m.is_active)}
                    style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                      background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.12)',
                      color:'rgba(251,250,244,.6)' }}>
                    {m.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                  {!isSelf && (
                    <button onClick={() => toggleModerator(m.id, m.is_moderator)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background: m.is_moderator ? 'rgba(255,20,147,.12)' : 'rgba(255,255,255,.07)',
                        border:'1px solid ' + (m.is_moderator ? 'rgba(255,20,147,.25)' : 'rgba(255,255,255,.1)'),
                        color: m.is_moderator ? 'var(--pink)' : 'rgba(251,250,244,.5)' }}>
                      {m.is_moderator ? '✓ Mod' : '💜 Make Mod'}
                    </button>
                  )}
                  {!isSelf && (
                    <button onClick={() => toggleTrailblazer(m.id, m.is_trailblazer)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background: m.is_trailblazer ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.07)',
                        border:'1px solid ' + (m.is_trailblazer ? 'rgba(25,229,94,.25)' : 'rgba(255,255,255,.1)'),
                        color: m.is_trailblazer ? 'var(--lime)' : 'rgba(251,250,244,.5)' }}>
                      {m.is_trailblazer ? '✓ Trailblazer' : '✨ Trailblazer'}
                    </button>
                  )}
                  {!isSelf && (
                    <button onClick={() => setExpandedMember(isExpanded ? null : m.id)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background:'rgba(255,255,255,.05)', border:'1px solid rgba(255,255,255,.1)',
                        color:'rgba(251,250,244,.5)' }}>
                      {isExpanded ? '↑ Less' : 'End Reason…'}
                    </button>
                  )}
                </div>
                {isExpanded && !isSelf && (
                  <div style={{ marginTop:14, paddingTop:14, borderTop:'1px solid rgba(255,255,255,.05)' }}>
                    <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      letterSpacing:1.2, marginBottom:6 }}>MEMBERSHIP END REASON</p>
                    <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:10 }}>
                      {[
                        [null, 'None'],
                        ['cancelled', 'Cancelled'],
                        ['lapsed', 'Lapsed'],
                        ['deceased', '🕊️ Deceased']
                      ].map(([val, label]) => (
                        <button key={String(label)} onClick={() => setEndReason(m.id, val)}
                          style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                            background: m.membership_end_reason === val ? 'rgba(255,20,147,.15)' : 'rgba(255,255,255,.06)',
                            border:'1px solid ' + (m.membership_end_reason === val ? 'rgba(255,20,147,.3)' : 'rgba(255,255,255,.1)'),
                            color: m.membership_end_reason === val ? 'var(--pink)' : 'rgba(251,250,244,.55)' }}>
                          {label}
                        </button>
                      ))}
                    </div>
                    {m.membership_end_reason === 'deceased' && (
                      <div style={{ marginTop:4 }}>
                        <p style={{ fontSize:10, color:'rgba(200,180,220,.7)', fontFamily:'var(--font-ui)',
                          letterSpacing:1.2, marginBottom:6 }}>DATE OF PASSING</p>
                        <input type="date" value={m.date_of_passing || ''}
                          onChange={e => setEndReason(m.id, 'deceased', e.target.value)}/>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </>
      )}

      {/* ── REFLECTIONS QUEUE ── */}
      {tab === 'reflections' && <ModeratorPanel user={user} embedded={true}/>}

      {/* ── HERO MEMORIAL ── */}
      {tab === 'heroes' && <HeroMemorialAdmin/>}

      {/* ── HERO COMMENTS ── */}
      {tab === 'herocomments' && (
        <div>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1, marginBottom:16 }}>PENDING HERO COMMENTS</p>
          {pendingHeroComments.length === 0 && (
            <div className="card" style={{ textAlign:'center', padding:40 }}>
              <p style={{ fontSize:28, marginBottom:8 }}>✨</p>
              <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14 }}>All caught up.</p>
            </div>
          )}
          {pendingHeroComments.map(c => (
            <div key={c.id} className="card" style={{ marginBottom:12 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                {c.reaction && <span style={{ fontSize:20 }}>{c.reaction}</span>}
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:13, fontWeight:600, color:'var(--pink)' }}>{c.member_display_name}</p>
                  <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
                    On hero: <strong>{c.hero_name}</strong> · {new Date(c.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                  </p>
                </div>
              </div>
              {c.comment_text && (
                <p style={{ fontSize:13, color:'rgba(251,250,244,.8)', lineHeight:1.65, marginBottom:12,
                  padding:'10px 14px', background:'rgba(255,255,255,.04)', borderRadius:8,
                  borderLeft:'3px solid rgba(255,20,147,.3)' }}>
                  "{c.comment_text}"
                </p>
              )}
              <div style={{ display:'flex', gap:8 }}>
                <button onClick={() => approveHeroComment(c.id)}
                  style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(25,229,94,.15)',
                    border:'1px solid rgba(25,229,94,.3)', color:'var(--lime)', fontSize:12,
                    fontFamily:'var(--font-ui)', fontWeight:600 }}>
                  ✅ Approve
                </button>
                <button onClick={() => rejectHeroComment(c.id)}
                  style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(255,20,147,.1)',
                    border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontSize:12,
                    fontFamily:'var(--font-ui)' }}>
                  ❌ Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── MARKETPLACE REQUESTS ── v9.51 Item 8 ── */}
      {tab === 'marketplace' && (
        <div>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1, marginBottom:14 }}>
            MEMBER ITEM REQUESTS · {marketRequests.filter(r => r.status === 'pending').length} PENDING ·
            REVIEWED IN LAST 50: {marketRequests.filter(r => r.status !== 'pending').length}
          </p>
          {marketRequests.length === 0 && (
            <p style={{ fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)',
              fontStyle:'italic', textAlign:'center', padding:'30px 0' }}>
              No requests yet. When members submit something through the Marketplace, it'll show up here.
            </p>
          )}
          {marketRequests.map(r => {
            const status = r.status
            const palette = status === 'pending'
              ? { bg:'rgba(255,255,255,.04)', border:'rgba(255,20,147,.2)', label:'⏳ Pending', color:'rgba(251,250,244,.7)' }
              : status === 'approved'
              ? { bg:'rgba(25,229,94,.05)', border:'rgba(25,229,94,.2)', label:'✓ Approved', color:'var(--lime)' }
              : { bg:'rgba(255,255,255,.03)', border:'rgba(255,255,255,.08)', label:'Denied', color:'rgba(251,250,244,.45)' }
            const memberRow = members.find(mm => mm.id === r.member_id)
            const memberName = memberRow?.display_name || memberRow?.email || 'Unknown member'
            return (
              <div key={r.id} className="card" style={{
                marginBottom:12, background: palette.bg, border:`1px solid ${palette.border}`,
              }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', gap:10, marginBottom:6 }}>
                  <p style={{ fontSize:14, fontWeight:600, color:'var(--cream)', fontFamily:'var(--font-ui)' }}>
                    {r.title}
                  </p>
                  <span style={{ fontSize:10, fontFamily:'var(--font-ui)', color: palette.color, whiteSpace:'nowrap' }}>
                    {palette.label}
                  </span>
                </div>
                <p style={{ fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', marginBottom:6 }}>
                  Requested by <strong style={{color:'var(--pink)'}}>{memberName}</strong> · {new Date(r.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                </p>
                {r.purchase_url && (
                  <p style={{ fontSize:12, marginBottom:6, wordBreak:'break-all' }}>
                    <a href={r.purchase_url} target="_blank" rel="noopener noreferrer"
                      style={{ color:'var(--pink)', textDecoration:'none', fontFamily:'var(--font-ui)' }}>
                      ↗ {r.purchase_url}
                    </a>
                  </p>
                )}
                {r.reason && (
                  <p style={{ fontSize:13, color:'rgba(251,250,244,.75)', lineHeight:1.6, marginBottom:10,
                    padding:'10px 12px', background:'rgba(255,255,255,.04)', borderRadius:8,
                    borderLeft:'3px solid rgba(255,20,147,.3)' }}>
                    {r.reason}
                  </p>
                )}
                {r.admin_note && (
                  <p style={{ fontSize:12, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)',
                    fontStyle:'italic', lineHeight:1.5, marginBottom:10 }}>
                    Admin reply: {r.admin_note}
                  </p>
                )}
                {status === 'pending' && (
                  <div style={{ display:'flex', gap:8 }}>
                    <button onClick={() => approveItemRequest(r)}
                      style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(25,229,94,.15)',
                        border:'1px solid rgba(25,229,94,.3)', color:'var(--lime)', fontSize:12,
                        fontFamily:'var(--font-ui)', fontWeight:600, cursor:'pointer' }}>
                      ✅ Approve & add
                    </button>
                    <button onClick={() => denyItemRequest(r)}
                      style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(255,20,147,.1)',
                        border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontSize:12,
                        fontFamily:'var(--font-ui)', cursor:'pointer' }}>
                      Deny with note
                    </button>
                  </div>
                )}
              </div>
            )
          })}
          <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
            lineHeight:1.6, marginTop:16, fontStyle:'italic' }}>
            Approving an item adds it to the catalog with category "Books" and the next display_order slot.
            Re-categorize or hide via SQL if needed.
          </p>
        </div>
      )}

      {/* ── DELETIONS ── */}
      {tab === 'deletions' && <DeletionQueueAdmin user={user}/>}

      {/* ── ANALYTICS ── */}
      {tab === 'analytics' && <AdminAnalytics/>}
    </div>
  )
}
