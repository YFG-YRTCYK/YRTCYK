import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import './index.css'
import Dashboard from './Dashboard'
import HeroGallery from './HeroGallery'
import CommunityCalendar from './CommunityCalendar'
import InviteFriends from './InviteFriends'
import MemberDirectory from './MemberDirectory'
import CommunityBlog from './CommunityBlog'
import AdminPanel from './AdminPanel'
import ModeratorPanel from './ModeratorPanel'
import ProfilePage from './ProfilePage'
import WordOfMouth from './WordOfMouth'
import IdeaBox from './IdeaBox'
import Marketplace from './Marketplace'

const ADMIN_EMAILS = ['gvitrano@icloud.com']
const LAST_EMAIL_KEY = 'yfg_last_email'

export default function App() {
  const [session, setSession] = useState(null)
  const [loading, setLoading] = useState(true)
  const [view, setView] = useState('dashboard')
  const [overlay, setOverlay] = useState(null) // 'profile' | 'admin' | 'moderate'
  // v9.46 Item 1 — when an admin clicks "Edit as Admin" on a Member Detail page,
  // this holds the target member's UUID. ProfilePage reads it via the editAsMemberId
  // prop; if set, ProfilePage loads that row instead of the current user's row and
  // displays the persistent admin-edit banner. Reset on overlay close.
  const [editingMemberId, setEditingMemberId] = useState(null)
  // Pre-fill email from prior successful login if present in localStorage.
  const [email, setEmail] = useState(() => {
    try {
      return localStorage.getItem(LAST_EMAIL_KEY) || ''
    } catch (e) {
      return ''
    }
  })
  const [code, setCode] = useState('')
  const [codeSent, setCodeSent] = useState(false)
  const [authMsg, setAuthMsg] = useState('')
  const [sending, setSending] = useState(false)
  const [verifying, setVerifying] = useState(false)
  const [isMod, setIsMod] = useState(false)

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => { setSession(session); setLoading(false) })
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); setLoading(false) })
    return () => subscription.unsubscribe()
  }, [])

  // Persist email to localStorage on successful authentication.
  useEffect(() => {
    if (session?.user?.email) {
      try {
        localStorage.setItem(LAST_EMAIL_KEY, session.user.email)
      } catch (e) { /* private browsing — silent */ }
    }
  }, [session])

  useEffect(() => {
    if (session && !ADMIN_EMAILS.includes(session.user.email)) {
      supabase.from('members').select('is_moderator').eq('email', session.user.email).single()
        .then(({ data }) => { if (data?.is_moderator) setIsMod(true) })
    }
  }, [session])

  async function sendCode(e) {
    e.preventDefault(); setSending(true); setAuthMsg('')
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: 'https://action.yourfairygodfather.com' }
    })
    setSending(false)
    if (error) setAuthMsg('Error: ' + error.message)
    else {
      setCodeSent(true)
      setAuthMsg('Email sent. Type the 6-digit code below to sign in.')
    }
  }

  async function verifyCode(e) {
    e.preventDefault(); setVerifying(true); setAuthMsg('')
    const { error } = await supabase.auth.verifyOtp({ email, token: code.trim(), type: 'email' })
    setVerifying(false)
    if (error) setAuthMsg('Error: ' + (error.message || 'Invalid or expired code. Try again or request a new one.'))
  }

  function backToEmail() {
    setCodeSent(false); setCode(''); setAuthMsg('')
  }

  if (loading) return <div style={{display:'flex',alignItems:'center',justifyContent:'center',minHeight:'100vh'}}><div className="spinner"/></div>

  // ---- LOGIN VIEW ----
  // Padding accounts for the iPhone notch / Dynamic Island via env(safe-area-inset-top)
  // and the home indicator via env(safe-area-inset-bottom).
  if (!session) return (
    <div style={{
      minHeight:'100vh',
      display:'flex',
      flexDirection:'column',
      alignItems:'center',
      justifyContent:'center',
      padding:'calc(env(safe-area-inset-top) + 16px) 24px calc(env(safe-area-inset-bottom) + 16px)'
    }}>
      <div style={{textAlign:'center',marginBottom:40}}>
        <p style={{fontSize:13,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:3,marginBottom:12}}>YRTCYK</p>
        <h1 style={{fontSize:26,fontWeight:400,color:'var(--pink)'}}>Your Fairy Godfather</h1>
      </div>

      {!codeSent ? (
        <form onSubmit={sendCode} style={{width:'100%',maxWidth:340}}>
          <input
            value={email} onChange={e=>setEmail(e.target.value)}
            type="email" name="email" id="login-email"
            placeholder="your@email.com"
            autoComplete="email" autoCapitalize="off" autoCorrect="off" spellCheck="false" inputMode="email"
            style={{marginBottom:10}} required
          />
          <button type="submit" className="btn-primary" style={{width:'100%'}} disabled={sending}>
            {sending?'Sending…':'Send Sign-In Code'}
          </button>
        </form>
      ) : (
        <form onSubmit={verifyCode} style={{width:'100%',maxWidth:340}}>
          <input
            value={code} onChange={e=>setCode(e.target.value.replace(/\D/g,'').slice(0,6))}
            type="text" name="otp" id="login-otp"
            inputMode="numeric" pattern="[0-9]*"
            autoComplete="one-time-code" autoCapitalize="off" autoCorrect="off" spellCheck="false"
            autoFocus placeholder="000000"
            style={{marginBottom:10,letterSpacing:8,textAlign:'center',fontSize:22,fontFamily:'monospace'}}
            required maxLength={6}
          />
          <button type="submit" className="btn-primary" style={{width:'100%'}} disabled={verifying || code.length !== 6}>
            {verifying?'Verifying…':'Sign In'}
          </button>
          <button type="button" onClick={backToEmail}
            style={{width:'100%',marginTop:12,background:'transparent',border:'none',color:'rgba(251,250,244,.5)',fontSize:12,fontFamily:'var(--font-ui)',cursor:'pointer'}}>
            ← Use a different email
          </button>
        </form>
      )}

      {authMsg && <p style={{fontSize:13,fontFamily:'var(--font-ui)',textAlign:'center',marginTop:14,color:authMsg.startsWith('Error')?'var(--pink)':'var(--lime)',lineHeight:1.6,maxWidth:340}}>{authMsg}</p>}
    </div>
  )

  // ---- AUTHENTICATED ----
  const user = session.user
  const isAdmin = ADMIN_EMAILS.includes(user.email)
  const canModerate = isAdmin || isMod

  if (overlay === 'profile') return <ProfilePage user={user} isAdmin={isAdmin} editAsMemberId={editingMemberId} onClose={()=>{ setEditingMemberId(null); setOverlay(null) }}/>
  if (overlay === 'admin')   return <AdminPanel  user={user} onClose={()=>setOverlay(null)}/>
  if (overlay === 'moderate') return <ModeratorPanel user={user} onClose={()=>setOverlay(null)}/>

  const TABS = [
    { id:'dashboard',     label:'Home',            emoji:'🏠' },
    { id:'heroes',        label:'Heroes',          emoji:'🌟' },
    { id:'blog',          label:'Reflections',     emoji:'📝' },
    { id:'members',       label:'Members',         emoji:'👥' },
    { id:'calendar',      label:'Calendar',        emoji:'📅' },
    { id:'invite',        label:'Widen the Circle',emoji:'🌈' },
    { id:'wordofmouth',   label:'Word of Mouth',   emoji:'💋' },
    { id:'marketplace',   label:'YFG Marketplace', emoji:'🛒' },  // v9.51 Item 8
  ]

  // Shared button style for top-right utility buttons (admin / mod / profile / signout).
  const utilBtn = (color, bg, border) => ({
    display:'flex', flexDirection:'column', alignItems:'center', gap:1,
    padding:'4px 7px', borderRadius:7, fontSize:9,
    fontFamily:'var(--font-ui)',
    color, background: bg || 'transparent',
    border: border || '1px solid transparent',
    whiteSpace:'nowrap', cursor:'pointer'
  })

  return (
    <div style={{minHeight:'100vh',display:'flex',flexDirection:'column'}}>
      {/* TOP HEADER — slim. Logo + utility buttons. Honors notch via safe-area-inset-top. */}
      <div style={{
        background:'rgba(1,40,14,.97)',
        borderBottom:'1px solid var(--border)',
        paddingTop: 'calc(env(safe-area-inset-top) + 8px)',
        paddingBottom: '6px',
        paddingLeft: 'max(env(safe-area-inset-left), 12px)',
        paddingRight: 'max(env(safe-area-inset-right), 12px)',
        position:'sticky', top:0, zIndex:100
      }}>
        <div style={{maxWidth:700,margin:'0 auto',display:'flex',alignItems:'center',justifyContent:'space-between',gap:8}}>
          <div style={{flexShrink:0,background:'#ffffff',borderRadius:6,padding:'4px 6px',display:'flex',alignItems:'center'}}>
            <img src="/fairy_godfather.jpg" alt="Your Fairy Godfather" style={{height:32,width:'auto',display:'block'}}/>
          </div>
          <div style={{display:'flex',gap:4,alignItems:'center',flexShrink:0}}>
            {isAdmin && (
              <button onClick={()=>setOverlay('admin')} style={utilBtn('var(--lime)','rgba(25,229,94,.1)','1px solid rgba(25,229,94,.2)')}>
                <span style={{fontSize:14}}>⚙️</span><span>Admin</span>
              </button>
            )}
            {!isAdmin && isMod && (
              <button onClick={()=>setOverlay('moderate')} style={utilBtn('var(--pink)','rgba(255,20,147,.1)','1px solid rgba(255,20,147,.25)')}>
                <span style={{fontSize:14}}>🛡️</span><span>Mod</span>
              </button>
            )}
            {/* v9.51 nav reorg — Idea Box moved from bottom tab bar to top
                utility cluster so it sits next to Profile / Sign Out and the
                bottom tab bar can host YFG Marketplace without overflowing. */}
            <button onClick={()=>setView('ideabox')} style={utilBtn('rgba(251,250,244,.55)',null,'1px solid var(--border)')}>
              <span style={{fontSize:14}}>🪄</span><span>Idea Box</span>
            </button>
            <button onClick={()=>setOverlay('profile')} style={utilBtn('rgba(251,250,244,.55)',null,'1px solid var(--border)')}>
              <span style={{fontSize:14}}>👤</span><span>Profile</span>
            </button>
            <button onClick={()=>supabase.auth.signOut()} style={utilBtn('rgba(251,250,244,.4)')}>
              <span style={{fontSize:14}}>🚪</span><span>Sign Out</span>
            </button>
          </div>
        </div>
        <div style={{maxWidth:700,margin:'4px auto 0',textAlign:'center'}}>
          <span style={{fontSize:10,color:'rgba(251,250,244,.25)',fontFamily:'var(--font-ui)'}}>{user.email}</span>
        </div>
      </div>

      {/* CONTENT — flex-grows to fill available space between top header and bottom nav. */}
      <div style={{flex:1,maxWidth:700,margin:'0 auto',width:'100%',padding:'0 16px 24px'}}>
        {view==='dashboard' && <Dashboard user={user} isAdmin={isAdmin} setView={setView}/>}
        {view==='heroes'    && <HeroGallery user={user} isAdmin={isAdmin}/>}
        {view==='blog'      && <CommunityBlog user={user} isAdmin={canModerate}/>}
        {view==='members'   && <MemberDirectory user={user} isAdmin={isAdmin} onEditAsAdmin={(memberId)=>{ setEditingMemberId(memberId); setOverlay('profile') }}/>}
        {view==='calendar'  && <CommunityCalendar user={user}/>}
        {view==='invite'    && <InviteFriends user={user}/>}
        {view==='wordofmouth' && <WordOfMouth user={user} isAdmin={isAdmin}/>}
        {view==='marketplace' && <Marketplace user={user} isAdmin={isAdmin}/>}
        {view==='ideabox'    && <IdeaBox user={user}/>}
      </div>

      {/* BOTTOM TAB BAR — primary navigation. Honors home-indicator via safe-area-inset-bottom. */}
      <div style={{
        background:'rgba(1,40,14,.97)',
        borderTop:'1px solid var(--border)',
        paddingTop:'6px',
        paddingBottom: 'calc(env(safe-area-inset-bottom) + 6px)',
        paddingLeft: 'max(env(safe-area-inset-left), 8px)',
        paddingRight: 'max(env(safe-area-inset-right), 8px)',
        position:'sticky', bottom:0, zIndex:100,
        backdropFilter:'blur(8px)'
      }}>
        <nav style={{
          display:'flex',
          gap:2,
          overflowX:'auto',
          maxWidth:700,
          margin:'0 auto',
          scrollbarWidth:'none' // hide scrollbar on Firefox
        }}>
          {TABS.map(t => {
            const active = view === t.id
            return (
              <button
                key={t.id}
                onClick={()=>setView(t.id)}
                style={{
                  display:'flex', flexDirection:'column', alignItems:'center', gap:2,
                  padding:'6px 10px', borderRadius:8,
                  fontSize:10, fontFamily:'var(--font-ui)',
                  color: active ? 'var(--pink)' : 'rgba(251,250,244,.55)',
                  background: active ? 'rgba(255,20,147,.12)' : 'transparent',
                  border: active ? '1px solid rgba(255,20,147,.28)' : '1px solid transparent',
                  whiteSpace:'nowrap',
                  fontWeight: active ? 700 : 400,
                  cursor:'pointer',
                  flexShrink:0,
                  minWidth:60
                }}
              >
                <span style={{fontSize:20,lineHeight:1}}>{t.emoji}</span>
                <span>{t.label}</span>
              </button>
            )
          })}
        </nav>
      </div>
    </div>
  )
}
