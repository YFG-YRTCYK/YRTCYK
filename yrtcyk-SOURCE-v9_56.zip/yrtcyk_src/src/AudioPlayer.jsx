import { useReducer, useEffect, useRef, forwardRef, useImperativeHandle } from 'react'
import { supabase } from './supabaseClient'
import { createGateRecognizer, isSpeechRecognitionSupported } from './SpeechToText'

// ─── State machine — per YFG_Audio_Player_UIUX_Spec_v1_FINAL §11 ─────────────
//
// All 12 states are scaffolded. 8a wired the visuals. 8b wires the real
// <audio> element + audio-asset-url Edge Function call. 8c branches the
// AUDIO_ENDED transition for behaviorClass='B' to start the Class B chain
// (post-audio silence → invitation → input → ack → close → pulse → complete).
// 8e adds Media Session API + lock-screen artwork.

const STATE = {
  IDLE:                          'IDLE',
  LOADING_URL:                   'LOADING_URL',
  AUDIO_PLAYING:                 'AUDIO_PLAYING',
  AUDIO_PAUSED:                  'AUDIO_PAUSED',
  POST_AUDIO_SILENCE:            'POST_AUDIO_SILENCE',
  REFLECTION_INVITATION_PLAYING: 'REFLECTION_INVITATION_PLAYING',
  LISTENING_FOR_GATE_RESPONSE:   'LISTENING_FOR_GATE_RESPONSE',  // 8c v9.29 — voice gate
  REFLECTION_INPUT:              'REFLECTION_INPUT',
  SAVE_ACKNOWLEDGMENT_PLAYING:   'SAVE_ACKNOWLEDGMENT_PLAYING',
  CLOSE_PROMPT_PLAYING_SAVED:    'CLOSE_PROMPT_PLAYING_SAVED',
  CLOSE_PROMPT_PLAYING_SKIPPED:  'CLOSE_PROMPT_PLAYING_SKIPPED',
  CHECKBOX_PULSING:              'CHECKBOX_PULSING',
  COMPLETE:                      'COMPLETE',
  ERROR_STATE:                   'ERROR_STATE'
}

const initialState = {
  machine: STATE.IDLE,
  positionSec: 0,
  durationSec: 0,
  speed: 1,
  errorMessage: null,
  reflectionEntryReason: null,  // 8c v9.30 — 'voice_yes' triggers auto-mic on REFLECTION_INPUT entry
  skipClosePrompts: false       // 9.33 v2 — true in guided Play All; chain skips
                                //           CLOSE_PROMPT_PLAYING_* states (the audio "now go ahead
                                //           and check the box…" is wrong information when system
                                //           auto-completes the checkbox)
}

function reducer(state, action) {
  switch (action.type) {
    case 'PLAY_TAP':
      if (state.machine === STATE.IDLE)         return { ...state, machine: STATE.LOADING_URL }
      if (state.machine === STATE.AUDIO_PAUSED) return { ...state, machine: STATE.AUDIO_PLAYING }
      return state
    case 'URL_RECEIVED':
      // Initial section audio: LOADING_URL → AUDIO_PLAYING with full reset.
      // Mid-chain prompt loads (invitation, ack, close prompts) keep their
      // own *_PLAYING state; we only refresh duration/position for the scrub
      // bar so it tracks the new (much shorter) clip cleanly.
      if (state.machine === STATE.LOADING_URL) {
        return { ...state, machine: STATE.AUDIO_PLAYING, durationSec: action.durationSec || 0, positionSec: 0 }
      }
      if (state.machine === STATE.REFLECTION_INVITATION_PLAYING ||
          state.machine === STATE.SAVE_ACKNOWLEDGMENT_PLAYING ||
          state.machine === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
          state.machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED) {
        return { ...state, durationSec: action.durationSec || 0, positionSec: 0 }
      }
      return state
    case 'URL_FETCH_FAILED':
      return { ...state, machine: STATE.ERROR_STATE, errorMessage: action.message }
    case 'PAUSE_TAP':
      if (state.machine === STATE.AUDIO_PLAYING) return { ...state, machine: STATE.AUDIO_PAUSED }
      return state
    case 'AUDIO_ENDED':
      // 8c v9.28: section body ends → POST_AUDIO_SILENCE → invitation → REFLECTION_INPUT.
      // 8c v9.29: invitation now ends → LISTENING_FOR_GATE_RESPONSE (voice gate);
      // gate decides REFLECTION_INPUT (yes/timeout) or CLOSE_PROMPT_PLAYING_SKIPPED (no).
      // 9.33 v2: in guided Play All, skipClosePrompts short-circuits the
      // close-prompt audio (which says "now go ahead and check the box") because
      // the system is about to auto-complete the checkbox — playing the cue would
      // be wrong information.
      if (state.machine === STATE.AUDIO_PLAYING)                 return { ...state, machine: STATE.POST_AUDIO_SILENCE }
      if (state.machine === STATE.REFLECTION_INVITATION_PLAYING) return { ...state, machine: STATE.LISTENING_FOR_GATE_RESPONSE }
      if (state.machine === STATE.SAVE_ACKNOWLEDGMENT_PLAYING)   {
        return state.skipClosePrompts
          ? { ...state, machine: STATE.CHECKBOX_PULSING }
          : { ...state, machine: STATE.CLOSE_PROMPT_PLAYING_SAVED }
      }
      if (state.machine === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
          state.machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED)  return { ...state, machine: STATE.CHECKBOX_PULSING }
      return state
    case 'GATE_HEARD_YES':
      // Spoken "yes" — flagged so REFLECTION_INPUT can auto-start the mic.
      // Distinguished from GATE_TAPPED_YES (button tap) which doesn't auto-start.
      if (state.machine === STATE.LISTENING_FOR_GATE_RESPONSE) {
        return { ...state, machine: STATE.REFLECTION_INPUT, reflectionEntryReason: 'voice_yes' }
      }
      return state
    case 'GATE_TAPPED_YES':
    case 'GATE_TIMEOUT':
      // Tap-yes / timeout / error fallback all default to REFLECTION_INPUT
      // WITHOUT auto-starting the mic. Member taps mic when ready.
      if (state.machine === STATE.LISTENING_FOR_GATE_RESPONSE) {
        return { ...state, machine: STATE.REFLECTION_INPUT, reflectionEntryReason: 'tap_or_default' }
      }
      return state
    case 'GATE_HEARD_NO':
      // 9.33 v2: skip the close-prompt audio in guided Play All (see AUDIO_ENDED note).
      if (state.machine === STATE.LISTENING_FOR_GATE_RESPONSE) {
        return state.skipClosePrompts
          ? { ...state, machine: STATE.CHECKBOX_PULSING }
          : { ...state, machine: STATE.CLOSE_PROMPT_PLAYING_SKIPPED }
      }
      return state
    case 'POST_SILENCE_DONE':
      if (state.machine === STATE.POST_AUDIO_SILENCE) return { ...state, machine: STATE.REFLECTION_INVITATION_PLAYING }
      return state
    case 'SAVE_REFLECTION':
      // action.hasContent: boolean — reducer encodes spec §6 Class B skip-vs-saved branching
      // 9.33 v2: empty-content branch also skips close-prompt audio in guided Play All.
      if (state.machine === STATE.REFLECTION_INPUT) {
        if (action.hasContent) {
          return { ...state, machine: STATE.SAVE_ACKNOWLEDGMENT_PLAYING }
        }
        return state.skipClosePrompts
          ? { ...state, machine: STATE.CHECKBOX_PULSING }
          : { ...state, machine: STATE.CLOSE_PROMPT_PLAYING_SKIPPED }
      }
      return state
    case 'SET_SKIP_CLOSE_PROMPTS':
      // 9.33 v2 — set/clear the skip flag. PracticeView dispatches this via a
      // ref-handle on the active player when guided Play All starts on a Class B
      // section, so the entire chain runs without the (now-incorrect) "go ahead
      // and check the box" audio cues. Cleared automatically on CLOSE (initialState
      // reset).
      return { ...state, skipClosePrompts: !!action.skip }
    case 'CHECKBOX_PULSE_DONE':
      if (state.machine === STATE.CHECKBOX_PULSING) return { ...state, machine: STATE.COMPLETE }
      return state
    case 'SET_SPEED':
      return { ...state, speed: action.speed }
    case 'SEEK':
      return { ...state, positionSec: action.positionSec }
    case 'TICK':
      // Wired by 8b on <audio> timeupdate
      return { ...state, positionSec: action.positionSec }
    case 'CLOSE':
      // × button — return to IDLE without recording completion
      return { ...initialState }
    case 'COMPLETE_ACK':
      return { ...initialState }
    default:
      return state
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function formatTime(secs) {
  if (!Number.isFinite(secs) || secs < 0) return '0:00'
  const m = Math.floor(secs / 60)
  const s = Math.floor(secs % 60)
  return `${m}:${s.toString().padStart(2, '0')}`
}

function isExpanded(machine) {
  return machine !== STATE.IDLE && machine !== STATE.COMPLETE
}

function isPlaying(machine) {
  return machine === STATE.AUDIO_PLAYING ||
         machine === STATE.REFLECTION_INVITATION_PLAYING ||
         machine === STATE.SAVE_ACKNOWLEDGMENT_PLAYING ||
         machine === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
         machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED
}

function statusLineText(machine) {
  // Per spec §5.2 — minimal status line moments. Otherwise empty.
  if (machine === STATE.REFLECTION_INVITATION_PLAYING) return 'Listening to: reflection prompt'
  if (machine === STATE.LISTENING_FOR_GATE_RESPONSE)   return ''  // gate has its own dedicated UI block
  if (machine === STATE.REFLECTION_INPUT)              return ''  // input has its own prominent prompt in NotesBox
  if (machine === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
      machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED)  return 'Closing this section…'
  return ''
}

// ─── Sub-components ──────────────────────────────────────────────────────────

function PlayPauseIcon({ playing }) {
  if (playing) {
    // Pause: paired bars
    return (
      <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
        <rect x="3"   y="2" width="3.5" height="12" fill="#ffffff" rx="1" />
        <rect x="9.5" y="2" width="3.5" height="12" fill="#ffffff" rx="1" />
      </svg>
    )
  }
  // Play: right-pointing triangle
  return (
    <svg width="16" height="16" viewBox="0 0 16 16" fill="none" aria-hidden="true">
      <path d="M3 1.5 L13.5 8 L3 14.5 Z" fill="#ffffff" />
    </svg>
  )
}

function SunMoonIcon({ variant }) {
  // Hand-coded SVG per spec §5.4 — NOT emoji, to guarantee iOS WebKit consistency.
  if (variant === 'morning') {
    return (
      <svg width="22" height="22" viewBox="0 0 22 22" fill="none" aria-hidden="true">
        <circle cx="11" cy="11" r="4" fill="#FF1493" />
        {[0, 45, 90, 135, 180, 225, 270, 315].map(a => {
          const rad = a * Math.PI / 180
          return (
            <line
              key={a}
              x1={11 + 7   * Math.cos(rad)} y1={11 + 7   * Math.sin(rad)}
              x2={11 + 9.5 * Math.cos(rad)} y2={11 + 9.5 * Math.sin(rad)}
              stroke="#FF1493" strokeWidth="1.6" strokeLinecap="round"
            />
          )
        })}
      </svg>
    )
  }
  // evening — crescent moon
  return (
    <svg width="22" height="22" viewBox="0 0 22 22" fill="none" aria-hidden="true">
      <path d="M16 11a6 6 0 1 1-7-5.92A4.5 4.5 0 0 0 16 11z" fill="#FF1493" />
    </svg>
  )
}

function PlayButton({ machine, onClick }) {
  const playing = isPlaying(machine)
  const loading = machine === STATE.LOADING_URL
  return (
    <button
      onClick={onClick}
      aria-label={playing ? 'Pause' : 'Play'}
      style={{
        width: 44, height: 44, minWidth: 44, minHeight: 44,
        borderRadius: '50%',
        background: 'var(--pink)',
        border: '1px solid var(--cream)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        cursor: 'pointer',
        flexShrink: 0,
        padding: 0,
        opacity: loading ? 0.65 : 1,
        transition: 'opacity .2s ease'
      }}
    >
      {loading
        ? <span className="spinner" style={{ width: 18, height: 18, borderWidth: 2, margin: 0 }} />
        : <PlayPauseIcon playing={playing} />}
    </button>
  )
}

function ScrubBar({ positionSec, durationSec, onSeek }) {
  const pct = durationSec > 0 ? Math.min(100, (positionSec / durationSec) * 100) : 0
  function handleClick(e) {
    if (durationSec <= 0) return
    const rect = e.currentTarget.getBoundingClientRect()
    const ratio = Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width))
    onSeek(ratio * durationSec)
  }
  return (
    <div
      onClick={handleClick}
      style={{
        position: 'relative',
        height: 12,
        cursor: durationSec > 0 ? 'pointer' : 'default',
        marginBottom: 4
      }}
    >
      <div style={{
        position: 'absolute', top: 4, left: 0, right: 0, height: 4,
        background: 'var(--bg)',
        border: '1px solid var(--border)',
        borderRadius: 2
      }} />
      <div style={{
        position: 'absolute', top: 4, left: 0, height: 4,
        width: `${pct}%`,
        background: 'var(--pink)',
        borderRadius: 2,
        transition: 'width .1s linear'
      }} />
      <div style={{
        position: 'absolute', top: 0,
        left: `calc(${pct}% - 6px)`,
        width: 12, height: 12,
        background: 'var(--pink)',
        borderRadius: '50%',
        transition: 'left .1s linear',
        pointerEvents: 'none'
      }} />
    </div>
  )
}

function SpeedPills({ speed, onChange }) {
  const speeds = [0.75, 1, 1.25, 1.5]
  return (
    <div style={{ display: 'flex', gap: 8 }}>
      {speeds.map(s => {
        const active = Math.abs(speed - s) < 0.01
        return (
          <button
            key={s}
            onClick={() => onChange(s)}
            style={{
              width: 40, height: 24, padding: 0,
              borderRadius: 4,
              fontSize: 11,
              fontFamily: 'var(--font-ui)',
              fontWeight: 600,
              background: active ? 'var(--pink)' : 'transparent',
              color: active ? '#ffffff' : 'var(--cream)',
              border: `1px solid ${active ? 'var(--pink)' : 'var(--cream)'}`,
              cursor: 'pointer'
            }}
          >
            {s}×
          </button>
        )
      })}
    </div>
  )
}

function CloseButton({ onClick }) {
  return (
    <button
      onClick={onClick}
      aria-label="Close player"
      style={{
        width: 28, height: 28,
        borderRadius: '50%',
        background: 'transparent',
        color: 'rgba(251,250,244,.55)',
        fontSize: 18, lineHeight: 1,
        cursor: 'pointer',
        border: '1px solid var(--border)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        flexShrink: 0,
        padding: 0
      }}
    >
      ×
    </button>
  )
}

// ─── Main component ──────────────────────────────────────────────────────────
//
// One AudioPlayer instance per audio surface. Owns its own state machine.
// Behavior class controls which transitions auto-fire (wired in 8c, not 8a).
// In 8a, every "playable audio" simulates LOADING_URL → AUDIO_PLAYING with a
// 350 ms delay so the loading state is visually verifiable. No real audio.

const AudioPlayer = forwardRef(function AudioPlayer({
  contentType,                // 'header' | 'sources' | 'section_1'…'section_14' | 'bookend_morning' | 'bookend_evening' | 'hero_open' | 'hero_story'
  contentId,                  // string — day number, hero ID, etc.
  behaviorClass = 'A',        // 'A' | 'B' | 'C' | 'D' | 'E'
  emoji,                      // optional — section emoji (sits beside play button per Geo lock May 6 2026)
  title,                      // section title
  dayNumber,                  // for Media Session metadata (8e)
  bookendVariant,             // 'morning' | 'evening' (Class C only)
  bookendSubtitle,            // string (Class C only) — "Tap to begin today's practice", etc.
  onComplete,                 // (Class B) fires once when machine reaches COMPLETE
  onActiveChange,             // (Class E) fires (boolean) when expanded — for hero card pink border
  // 8c — Class B chain integration with sibling NotesBox + CheckRow.
  // SectionBlock owns those components' state and provides these callbacks
  // so the player can drive the textarea focus and checkbox pulse without
  // referencing those components' DOM directly.
  onWantsReflectionFocus,     // () => void — fires when REFLECTION_INPUT begins
  onWantsCheckboxPulse,       // () => void — fires when CHECKBOX_PULSING begins
  onWantsAutoMicStart,        // () => void — 8c v9.30 — fires when REFLECTION_INPUT
                              //               begins via SPOKEN "yes" only (not tap/timeout)
  // 9.33 — Play All mode props.
  playAllMode = 'idle',       // 'idle' | 'guided' | 'listen'
                              //   guided: intro → body → full Class B chain → onPlayAllAdvance
                              //   listen: intro → body → onPlayAllAdvance (no chain)
                              //   idle: existing solo behavior (default — no intro)
  playAllAutoStartKey = 0,    // number — when changes from 0 to non-zero (or between
                              //   non-zero values), this player auto-starts. Parent
                              //   bumps this for whichever section is current in seq.
  playIntroFirst = false,     // boolean — whether to play section_intro audio before
                              //   body. Sections 11/12 (evening_practice, step10) skip
                              //   because their titles are already in body audio.
  introContentId,             // string — content_id for the intro lookup
                              //   (e.g. '1' for section_1's intro)
  introContentType = 'section_intro',  // 9.37 — content_type for intro fetch.
                                       //   Default 'section_intro' for Class B Play All.
                                       //   Class E (hero) passes 'hero_open' to play the
                                       //   "🌈 In Loving Memory of [Name]" pre-roll.
  onPlayAllAdvance,           // () => void — fires when this section's segment is done
                              //   (intro+body+chain depending on mode). Parent advances cursor.
  onUserClose,                // () => void — fires only on user-tap × close
                              //   (NOT on auto-close from audio.ended). Parent uses this
                              //   to detect "exit Play All" gesture.
  onClassCEnded               // () => void — fires when a Class C bookend audio ends.
                              //   Parent uses this to scroll to first content section
                              //   (Section 1 morning, Section 11 evening) per spec §12.4.
}, ref) {
  const [state, dispatch] = useReducer(reducer, initialState)
  const expanded = isExpanded(state.machine)
  const status = statusLineText(state.machine)

  // Refs:
  // audioRef — the <audio> element, mounted below in JSX
  // playGenRef — generation counter that invalidates in-flight fetches when the
  //              user closes the player or the component unmounts mid-load
  // stateRef — current state snapshot for use inside event listeners (which
  //            close over their initial state otherwise — classic React closure
  //            trap when dispatching audio events)
  const audioRef = useRef(null)
  const playGenRef = useRef(0)
  const stateRef = useRef(state)
  useEffect(() => { stateRef.current = state }, [state])

  // 8c — behaviorClass captured in a ref so the audio.ended listener (mounted
  // once with [] deps) reads the current class without stale-closure surprises.
  const behaviorClassRef = useRef(behaviorClass)
  useEffect(() => { behaviorClassRef.current = behaviorClass }, [behaviorClass])

  // 8c — imperative handle exposing notifySaveTap for SectionBlock.
  // Called when the user taps SAVE on the NotesBox during REFLECTION_INPUT.
  // The reducer encodes the saved-vs-skipped branch from action.hasContent.
  useImperativeHandle(ref, () => ({
    notifySaveTap(reflectionContent) {
      if (stateRef.current.machine !== STATE.REFLECTION_INPUT) return
      const hasContent = !!(reflectionContent && reflectionContent.trim().length > 0)
      dispatch({ type: 'SAVE_REFLECTION', hasContent })
    }
  }), [])

  // Class E: notify parent on expansion change (used by HeroGallery for pink card border in step 9)
  useEffect(() => {
    if (onActiveChange) onActiveChange(expanded)
  }, [expanded, onActiveChange])

  // Class B: fire onComplete callback once the chain reaches COMPLETE
  useEffect(() => {
    if (state.machine === STATE.COMPLETE && onComplete) onComplete()
    // 9.33 — In Play All "guided" mode, COMPLETE also signals that this
    // section's full segment (intro → body → chain) is done. Fire the
    // advance callback so PracticeView can move to the next section.
    if (state.machine === STATE.COMPLETE && playAllMode === 'guided' && onPlayAllAdvance) {
      // Slightly longer pause than non-chain sections (500 ms vs 250 ms) so
      // the just-completed checkbox pulse has visual breathing room before
      // the next section's intro audio starts.
      const t = setTimeout(() => onPlayAllAdvance(), 500)
      return () => clearTimeout(t)
    }
  }, [state.machine, onComplete, playAllMode, onPlayAllAdvance])

  // 8c — Class B chain side effects driven by state.machine transitions.
  // Each "playing" state in the chain triggers a brand-prompt audio fetch+play.
  // Each timer state (POST_AUDIO_SILENCE, CHECKBOX_PULSING) sets a setTimeout
  // that dispatches the next action. Cleanup on unmount/state-change cancels
  // pending timers so a × close mid-chain doesn't ghost-fire later.
  useEffect(() => {
    if (state.machine === STATE.POST_AUDIO_SILENCE) {
      const t = setTimeout(() => dispatch({ type: 'POST_SILENCE_DONE' }), 500)
      return () => clearTimeout(t)
    }
    if (state.machine === STATE.REFLECTION_INVITATION_PLAYING) {
      playBrandPrompt('reflection_invitation')
      return
    }
    if (state.machine === STATE.LISTENING_FOR_GATE_RESPONSE) {
      // 8c v9.29 — voice gate per spec v1.2 §6 Class B.
      // Start the speech recognizer + a 12-sec wall-clock timeout. The
      // recognizer dispatches GATE_HEARD_YES or GATE_HEARD_NO when a
      // matching utterance is recognized. On timeout, fallback to
      // REFLECTION_INPUT (safer default for silent/contemplative members).
      // On error or unsupported browser, fall through immediately to
      // REFLECTION_INPUT — manual buttons stay visible regardless.
      let timer = null
      let recognizer = null
      if (isSpeechRecognitionSupported()) {
        recognizer = createGateRecognizer({
          onYes: () => dispatch({ type: 'GATE_HEARD_YES' }),
          onNo:  () => dispatch({ type: 'GATE_HEARD_NO' }),
          onError: (err) => {
            // 'not-allowed' = permission denied. Don't keep retrying.
            // Fall through to REFLECTION_INPUT so member can type or tap mic.
            console.warn('[AudioPlayer] gate recognizer error:', err && (err.error || err.message || err))
            dispatch({ type: 'GATE_TIMEOUT' })
          }
        })
        if (recognizer) recognizer.start()
      } else {
        // Browser doesn't support Web Speech API — fall through immediately.
        dispatch({ type: 'GATE_TIMEOUT' })
      }
      timer = setTimeout(() => dispatch({ type: 'GATE_TIMEOUT' }), 12000)
      return () => {
        if (timer) clearTimeout(timer)
        if (recognizer) recognizer.stop()
      }
    }
    if (state.machine === STATE.REFLECTION_INPUT) {
      // Hand-off to SectionBlock: focus the NOTES textarea so iOS
      // raises the soft keyboard. On iOS PWA, programmatic focus alone
      // does NOT raise the keyboard outside a direct user-gesture chain;
      // SectionBlock handles auto-scroll-into-view as a soft fallback.
      if (onWantsReflectionFocus) onWantsReflectionFocus()
      // 8c v9.30 — auto-start the reflection mic ONLY if the member arrived
      // here by speaking "yes" (per spec v1.3-FINAL §6 Class B). Tap-yes,
      // timeout, and error-fallback paths do NOT auto-start — those members
      // either preferred tap or were silent, so we don't surprise them with
      // an active mic. Defer ~300ms so the textarea/glow/scroll settle
      // before the mic flips into listening state — the sequence reads as
      // intentional rather than chaotic.
      if (state.reflectionEntryReason === 'voice_yes' && onWantsAutoMicStart) {
        const t = setTimeout(() => onWantsAutoMicStart(), 300)
        return () => clearTimeout(t)
      }
      return
    }
    if (state.machine === STATE.SAVE_ACKNOWLEDGMENT_PLAYING) {
      playBrandPrompt('save_acknowledgment')
      return
    }
    if (state.machine === STATE.CLOSE_PROMPT_PLAYING_SAVED) {
      playBrandPrompt('close_with_reflection')
      return
    }
    if (state.machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED) {
      playBrandPrompt('close_skipped_reflection')
      return
    }
    if (state.machine === STATE.CHECKBOX_PULSING) {
      // Hand-off to SectionBlock: trigger the 2-sec hot-pink pulse on the
      // CheckRow. Then advance to COMPLETE after the animation finishes.
      if (onWantsCheckboxPulse) onWantsCheckboxPulse()
      const t = setTimeout(() => dispatch({ type: 'CHECKBOX_PULSE_DONE' }), 2000)
      return () => clearTimeout(t)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.machine])

  // Audio element event listeners — wired once on mount.
  useEffect(() => {
    const audio = audioRef.current
    if (!audio) return

    function onLoadedMetadata() {
      // Re-apply playbackRate after src loads (some browsers reset it).
      audio.playbackRate = stateRef.current.speed
      // 9.40 — iOS Safari can't read MP3 duration from ElevenLabs streams
      // because they lack Xing/ID3 duration headers in the leading bytes;
      // audio.duration shows up as Infinity or near-zero on long files.
      // When that happens, fall back to the server-reported duration that
      // came back from audio-asset-url (computed from file size; accurate
      // to ~1%). Keep the native value when it's a sensible positive number.
      const audioDur = audio.duration
      const serverDur = serverReportedDurationRef.current
      const finalDur = (Number.isFinite(audioDur) && audioDur > 0.5)
        ? audioDur
        : (serverDur || 0)
      dispatch({ type: 'URL_RECEIVED', durationSec: finalDur })
    }
    function onTimeUpdate() {
      dispatch({ type: 'TICK', positionSec: audio.currentTime })
    }
    function onEnded() {
      // 9.33 — intro → body transition. While playing section_intro audio,
      // when it ends we don't advance the state machine — we just fetch
      // and start the body audio. The state machine sees one continuous
      // "playing" sequence (LOADING_URL → AUDIO_PLAYING) regardless of
      // whether intro played first.
      if (audioStageRef.current === 'intro') {
        audioStageRef.current = 'body'
        fetchAndPlayBody(playGenRef.current)
        return
      }

      // BODY audio ended — branch on behaviorClass + playAllMode.
      const m = stateRef.current.machine
      const cls = behaviorClassRef.current
      const mode = playAllModeRef.current

      // 9.33 — In Play All "listen" mode, Class B sections skip the chain
      // entirely. The body audio ending IS the section being done; advance
      // to the next section immediately.
      if (cls === 'B' && mode === 'listen') {
        dispatch({ type: 'CLOSE' })
        if (onPlayAllAdvanceRef.current) {
          // Brief pause for natural pacing between sections (~250 ms).
          setTimeout(() => onPlayAllAdvanceRef.current(), 250)
        }
        return
      }

      // 8c — Class B (guided/solo) and the four chain-prompt states all
      // dispatch AUDIO_ENDED to advance the post-audio chain.
      if (cls === 'B' || m === STATE.REFLECTION_INVITATION_PLAYING ||
          m === STATE.SAVE_ACKNOWLEDGMENT_PLAYING ||
          m === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
          m === STATE.CLOSE_PROMPT_PLAYING_SKIPPED) {
        dispatch({ type: 'AUDIO_ENDED' })
        return
      }

      // Class A/C/D/E: collapse to IDLE on audio end (8b behavior).
      dispatch({ type: 'CLOSE' })

      // 9.33 — Class C bookend → fire scroll callback so PracticeView can
      // smooth-scroll to first content section (§12.4).
      if (cls === 'C' && onClassCEndedRef.current) {
        onClassCEndedRef.current()
      }

      // 9.33 — In Play All mode, non-Class-B sections (header, sources,
      // bookend) advance the cursor when their audio ends.
      if (mode !== 'idle' && onPlayAllAdvanceRef.current) {
        setTimeout(() => onPlayAllAdvanceRef.current(), 250)
      }
    }
    function onError() {
      // Async error after src was set — typically expired URL or network drop.
      // Only surface if we're not in a state that's already handling load.
      if (stateRef.current.machine === STATE.LOADING_URL) return
      dispatch({ type: 'URL_FETCH_FAILED', message: 'Audio interrupted. Tap to retry.' })
    }

    audio.addEventListener('loadedmetadata', onLoadedMetadata)
    audio.addEventListener('timeupdate', onTimeUpdate)
    audio.addEventListener('ended', onEnded)
    audio.addEventListener('error', onError)

    return () => {
      audio.removeEventListener('loadedmetadata', onLoadedMetadata)
      audio.removeEventListener('timeupdate', onTimeUpdate)
      audio.removeEventListener('ended', onEnded)
      audio.removeEventListener('error', onError)
    }
  }, [])

  // Cleanup on unmount — pause audio and release the URL so iOS doesn't
  // background-buffer something the user navigated away from.
  useEffect(() => {
    return () => {
      ++playGenRef.current  // invalidate any in-flight fetch
      const audio = audioRef.current
      if (audio) {
        try { audio.pause() } catch {}
        audio.removeAttribute('src')
        audio.load()
      }
    }
  }, [])

  // ─── Audio control helpers ───────────────────────────────────────────────

  // 9.33 — `audioStageRef` tracks whether the currently-playing audio element
  // is on the section_intro phase or the body phase. The state machine itself
  // doesn't know about intros — they're a sub-segment that runs inside
  // LOADING_URL/AUDIO_PLAYING transparently. When intro audio.ended fires we
  // chain into body fetch; when body audio.ended fires we proceed with
  // existing class-based logic (chain or onPlayAllAdvance).
  const audioStageRef = useRef('body')

  // 9.40 — `serverReportedDurationRef` holds the duration_seconds value
  // returned from the audio-asset-url Edge Function for the most recently
  // fetched audio file. Used as a fallback when iOS Safari can't read the
  // duration from the MP3 stream (ElevenLabs MP3s lack proper Xing/ID3
  // duration headers, so on long files audio.duration reports Infinity or
  // a near-zero placeholder until the file plays through completely). The
  // server value is computed from file size at upload time and stored in
  // audio_assets.duration_seconds. See Handoff §3.39 for the underlying
  // MP3-header issue and Open Item §6(F) for the eventual re-encoding fix.
  const serverReportedDurationRef = useRef(0)

  // 9.33 — refs for in-listener access (closure-trap fix; identical pattern to
  // existing behaviorClassRef / stateRef from 8c).
  const playAllModeRef = useRef(playAllMode)
  useEffect(() => { playAllModeRef.current = playAllMode }, [playAllMode])
  const onPlayAllAdvanceRef = useRef(onPlayAllAdvance)
  useEffect(() => { onPlayAllAdvanceRef.current = onPlayAllAdvance }, [onPlayAllAdvance])
  const onClassCEndedRef = useRef(onClassCEnded)
  useEffect(() => { onClassCEndedRef.current = onClassCEnded }, [onClassCEnded])

  async function fetchSignedUrl(ctOverride, ciOverride) {
    // Optional overrides allow fetching section_intro URLs without disturbing
    // the player's primary contentType/contentId props.
    const ct = ctOverride || contentType
    const ci = ciOverride || contentId
    const { data, error } = await supabase.functions.invoke('audio-asset-url', {
      body: { content_type: ct, content_id: ci }
    })
    if (error) throw new Error(error.message || 'Audio service unavailable.')
    if (!data?.url) throw new Error('No URL returned from audio service.')
    // 9.40 — capture server-reported duration as fallback for iOS Safari.
    serverReportedDurationRef.current = Number(data.duration_seconds) || 0
    return data  // { url, expires_in, duration_seconds }
  }

  async function tryPlay() {
    // Returns true if play() resolved, false if it rejected (typical when src
    // is invalid/expired). iOS sometimes rejects without throwing, so wrap.
    try {
      await audioRef.current.play()
      return true
    } catch {
      return false
    }
  }

  async function playFromIdle() {
    const myGen = ++playGenRef.current
    dispatch({ type: 'PLAY_TAP' })  // → LOADING_URL

    // 9.33 — In Play All mode, sections 1-10/13/14 play their `section_intro`
    // audio (~2-second title cue like "Today's pattern.") BEFORE the body
    // audio. The player's <audio> element plays the intro first; on its
    // `ended` event the onEnded listener detects audioStageRef === 'intro'
    // and chains into fetchAndPlayBody. This keeps the state machine simple
    // (only the BODY's loadedmetadata triggers URL_RECEIVED).
    //
    // 9.37 — Class E (hero card) ALSO uses intro-first behavior, but in solo
    // mode rather than Play All. The intro is "🌈 In Loving Memory of [Name]"
    // (or living-hero variant) and the body is the obituary. Path A is
    // preserved for Class B (sections still skip intro in solo).
    if (playIntroFirst && (playAllMode !== 'idle' || behaviorClass === 'E')) {
      audioStageRef.current = 'intro'
      try {
        const introCi = introContentId != null ? String(introContentId) : contentId
        const introResp = await fetchSignedUrl(introContentType, introCi)
        if (myGen !== playGenRef.current) return
        const audio = audioRef.current
        audio.src = introResp.url
        audio.playbackRate = stateRef.current.speed
        audio.currentTime = 0
        const ok = await tryPlay()
        if (myGen !== playGenRef.current) {
          try { audio.pause() } catch {}
          audio.removeAttribute('src')
          return
        }
        if (!ok) {
          // Intro play() rejected — fall through to body.
          audioStageRef.current = 'body'
          await fetchAndPlayBody(myGen)
        }
        // Intro is playing. Body fetch happens in onEnded listener.
        return
      } catch (err) {
        // Intro fetch failed (missing row, network blip, etc.). Skip intro
        // and play body directly — graceful degradation, same approach as
        // brand_prompt fetch failures in 8c.
        if (myGen !== playGenRef.current) return
        console.warn('[AudioPlayer] section_intro fetch failed, skipping intro:', err)
        audioStageRef.current = 'body'
        await fetchAndPlayBody(myGen)
        return
      }
    }

    // Solo mode (or no intro for this section) — body straight away.
    audioStageRef.current = 'body'
    await fetchAndPlayBody(myGen)
  }

  // 9.33 — extracted from old playFromIdle. Loads body audio and plays it.
  // Called either directly (solo mode / no intro) or after intro audio ends
  // (the onEnded listener invokes this when audioStageRef === 'intro' →
  // 'body' transition).
  async function fetchAndPlayBody(myGen) {
    try {
      const { url } = await fetchSignedUrl()
      if (myGen !== playGenRef.current) return
      const audio = audioRef.current
      audio.src = url
      audio.playbackRate = stateRef.current.speed
      audio.currentTime = 0
      const ok = await tryPlay()
      if (myGen !== playGenRef.current) {
        try { audio.pause() } catch {}
        audio.removeAttribute('src')
        return
      }
      if (!ok) {
        dispatch({ type: 'URL_FETCH_FAILED', message: 'Audio temporarily unavailable. Please try again.' })
        return
      }
      // loadedmetadata listener will dispatch URL_RECEIVED with real duration.
    } catch (err) {
      if (myGen !== playGenRef.current) return
      dispatch({ type: 'URL_FETCH_FAILED', message: err.message || 'Audio temporarily unavailable. Please try again.' })
    }
  }

  async function resumeFromPause() {
    const audio = audioRef.current
    // First try resuming the existing src — usually works unless URL expired.
    const ok = await tryPlay()
    if (ok) {
      dispatch({ type: 'PLAY_TAP' })  // AUDIO_PAUSED → AUDIO_PLAYING
      return
    }
    // play() rejected — likely 403 expired URL per spec §8.2. Refetch once and retry.
    const myGen = ++playGenRef.current
    try {
      const { url } = await fetchSignedUrl()
      if (myGen !== playGenRef.current) return
      const savedPos = stateRef.current.positionSec
      audio.src = url
      audio.playbackRate = stateRef.current.speed
      audio.currentTime = savedPos
      const ok2 = await tryPlay()
      if (myGen !== playGenRef.current) return
      if (ok2) {
        dispatch({ type: 'PLAY_TAP' })
      } else {
        dispatch({ type: 'URL_FETCH_FAILED', message: 'Audio interrupted. Tap to retry.' })
      }
    } catch (err) {
      if (myGen !== playGenRef.current) return
      dispatch({ type: 'URL_FETCH_FAILED', message: err.message || 'Audio interrupted. Tap to retry.' })
    }
  }

  // 8c — fetch & play a brand_prompt audio file (reflection_invitation,
  // save_acknowledgment, close_with_reflection, close_skipped_reflection).
  // Re-uses the same audio-asset-url Edge Function and the same audioRef
  // element. Graceful failure: if the fetch/play fails for any reason
  // (network blip, missing row, etc.), dispatch AUDIO_ENDED to advance
  // the chain anyway — the contemplative flow shouldn't dead-end on a
  // backend hiccup.
  async function playBrandPrompt(promptId) {
    const myGen = ++playGenRef.current
    try {
      const { data, error } = await supabase.functions.invoke('audio-asset-url', {
        body: { content_type: 'brand_prompt', content_id: promptId }
      })
      if (myGen !== playGenRef.current) return
      if (error || !data?.url) {
        console.warn('[AudioPlayer] brand_prompt fetch failed:', promptId, error)
        dispatch({ type: 'AUDIO_ENDED' })  // skip ahead in chain
        return
      }
      const audio = audioRef.current
      audio.src = data.url
      audio.playbackRate = stateRef.current.speed
      audio.currentTime = 0
      const ok = await tryPlay()
      if (myGen !== playGenRef.current) {
        try { audio.pause() } catch {}
        audio.removeAttribute('src')
        return
      }
      if (!ok) {
        console.warn('[AudioPlayer] brand_prompt play() rejected:', promptId)
        dispatch({ type: 'AUDIO_ENDED' })
      }
      // loadedmetadata listener will dispatch URL_RECEIVED → updates duration
      // for scrub bar without changing machine state (per reducer 8c update).
    } catch (err) {
      if (myGen !== playGenRef.current) return
      console.warn('[AudioPlayer] brand_prompt threw:', promptId, err)
      dispatch({ type: 'AUDIO_ENDED' })
    }
  }

  // ─── Event handlers ──────────────────────────────────────────────────────

  function handlePlayClick() {
    // 8c — disable play/pause toggle during the Class B chain. The chain
    // advances automatically, and pausing chain audio mid-play would leave
    // the reducer's PAUSE_TAP / PLAY_TAP cases (which only handle AUDIO_PLAYING
    // / AUDIO_PAUSED) unable to resume. Future enhancement: dedicated chain
    // pause/resume states. For 8c, the play button is inert during chain.
    if (state.machine === STATE.POST_AUDIO_SILENCE ||
        state.machine === STATE.REFLECTION_INVITATION_PLAYING ||
        state.machine === STATE.LISTENING_FOR_GATE_RESPONSE ||
        state.machine === STATE.REFLECTION_INPUT ||
        state.machine === STATE.SAVE_ACKNOWLEDGMENT_PLAYING ||
        state.machine === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
        state.machine === STATE.CLOSE_PROMPT_PLAYING_SKIPPED ||
        state.machine === STATE.CHECKBOX_PULSING) {
      return
    }
    if (isPlaying(state.machine)) {
      try { audioRef.current?.pause() } catch {}
      dispatch({ type: 'PAUSE_TAP' })
      return
    }
    if (state.machine === STATE.AUDIO_PAUSED) {
      resumeFromPause()
      return
    }
    if (state.machine === STATE.IDLE) {
      playFromIdle()
      return
    }
    if (state.machine === STATE.ERROR_STATE) {
      // Retry from idle
      dispatch({ type: 'CLOSE' })
      // Tiny delay so the IDLE → LOADING_URL transition is visible
      setTimeout(() => playFromIdle(), 60)
      return
    }
  }

  function handleClose() {
    ++playGenRef.current  // invalidate in-flight load
    const audio = audioRef.current
    if (audio) {
      try { audio.pause() } catch {}
      audio.removeAttribute('src')
      audio.load()  // forces release of buffered data
    }
    audioStageRef.current = 'body'  // 9.33 — reset stage on close
    dispatch({ type: 'CLOSE' })
    // 9.33 — fire onUserClose AFTER dispatch so parent can read fresh state.
    // Only the user-tap × calls handleClose; auto-close from audio.ended
    // dispatches CLOSE directly without invoking this function.
    if (onUserClose) onUserClose()
  }

  // 9.33 — Play All auto-start. When parent assigns this player to be the
  // current section in the sequence, it bumps playAllAutoStartKey to a fresh
  // non-zero value. This effect detects the change and force-restarts playback
  // from a clean state. Bumping is required even when transitioning from
  // already-active to active-again (re-entry into Play All) — using a simple
  // boolean would miss the second activation.
  //
  // Counterpart: when the cursor moves off this player (key 0 OR a different
  // non-zero key BUT this player isn't currently in IDLE), collapse it to IDLE
  // so we don't end up with a screen full of expanded "completed" players.
  const lastAutoStartKeyRef = useRef(0)
  useEffect(() => {
    const prev = lastAutoStartKeyRef.current
    const next = playAllAutoStartKey
    lastAutoStartKeyRef.current = next

    if (next > 0 && next !== prev) {
      // This player is becoming the active Play All section — reset and play.
      ++playGenRef.current
      const audio = audioRef.current
      if (audio) {
        try { audio.pause() } catch {}
        audio.removeAttribute('src')
      }
      audioStageRef.current = 'body'
      dispatch({ type: 'CLOSE' })
      // 9.33 v2 — set the skip-close-prompts flag based on mode. Guided mode
      // auto-completes the checkbox, which makes the "go ahead and check the
      // box" audio cue wrong information. Listen mode never reaches the chain
      // anyway (Class B body onEnded short-circuits to onPlayAllAdvance).
      dispatch({ type: 'SET_SKIP_CLOSE_PROMPTS', skip: playAllMode === 'guided' })
      setTimeout(() => playFromIdle(), 60)
      return
    }

    // next is 0 (or unchanged 0). If we were previously active (prev > 0),
    // this player just got deselected — collapse to IDLE so the previous
    // section's expanded state doesn't linger on screen as cursor advances.
    if (next === 0 && prev > 0) {
      ++playGenRef.current
      const audio = audioRef.current
      if (audio) {
        try { audio.pause() } catch {}
        audio.removeAttribute('src')
      }
      audioStageRef.current = 'body'
      dispatch({ type: 'CLOSE' })
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playAllAutoStartKey])

  // ─── Media Session API (Phase 2 Step 8e) ─────────────────────────────────
  //
  // 9.37 — iOS lock-screen card + Bluetooth/AirPlay/CarPlay metadata. Without
  // this, members listening through Play All (~30 min guided practice) lose
  // audio when iOS dims the screen ~30 sec into the flow, and the lock screen
  // shows nothing useful even while audio is playing. With it: standard iOS
  // lock-screen card shows YFG triangle artwork, "Your Fairy Godfather" as
  // artist, current section title, and working ▶ / ▮▮ / ⏪ / ⏩ controls.
  //
  // Architecture note: Media Session is a global singleton (one navigator,
  // one session). With ~13 AudioPlayer instances on the page, each of them
  // could clobber the others' metadata. The single-player UX invariant —
  // at most one AudioPlayer is non-IDLE at any moment, enforced by the
  // Play All auto-collapse logic and by users not stacking solo plays —
  // means in practice only ONE player owns the session at a time. The
  // metadata effect skips IDLE/ERROR states, so only the active player
  // writes to navigator.mediaSession; the others stay quiet.

  // Latest-function refs so action handlers registered globally never
  // capture stale closures over `state` / `playFromIdle` / etc.
  const handlePlayClickRef = useRef(null)
  useEffect(() => { handlePlayClickRef.current = handlePlayClick })
  const handleCloseRef = useRef(null)
  useEffect(() => { handleCloseRef.current = handleClose })

  // Metadata + playbackState + action handlers. Runs on machine state changes,
  // title changes, or day changes (which happen across day-nav transitions).
  useEffect(() => {
    if (typeof navigator === 'undefined') return
    if (!('mediaSession' in navigator)) return  // graceful no-op on unsupported browsers

    const m = state.machine
    if (m === STATE.IDLE || m === STATE.ERROR_STATE) return  // not the active session owner

    // ── Metadata ────────────────────────────────────────────────────────
    // Title falls back to the contentType label if the parent didn't pass
    // a title prop. Album anchors the day so members glancing at their
    // lock screen see "YRTCYK · Day 24" rather than just an isolated section.
    try {
      if (typeof window !== 'undefined' && 'MediaMetadata' in window) {
        navigator.mediaSession.metadata = new window.MediaMetadata({
          title: title || contentType || 'YRTCYK',
          artist: 'Your Fairy Godfather',
          album: dayNumber ? `YRTCYK · Day ${dayNumber}` : 'YRTCYK',
          artwork: [
            { src: '/icon-192.png', sizes: '192x192', type: 'image/png' },
            { src: '/icon-512.png', sizes: '512x512', type: 'image/png' }
          ]
        })
      }
    } catch (e) {
      // iOS Safari has thrown on certain metadata fields historically; never
      // crash the player over a lock-screen niceity.
      console.warn('[AudioPlayer] mediaSession.metadata failed:', e)
    }

    // ── Playback state (drives the ▶ vs ▮▮ icon on the lock screen) ────
    try {
      if (isPlaying(m) ||
          m === STATE.REFLECTION_INVITATION_PLAYING ||
          m === STATE.SAVE_ACKNOWLEDGMENT_PLAYING ||
          m === STATE.CLOSE_PROMPT_PLAYING_SAVED ||
          m === STATE.CLOSE_PROMPT_PLAYING_SKIPPED) {
        navigator.mediaSession.playbackState = 'playing'
      } else if (m === STATE.AUDIO_PAUSED) {
        navigator.mediaSession.playbackState = 'paused'
      } else {
        // LOADING_URL, POST_AUDIO_SILENCE, LISTENING_FOR_GATE_RESPONSE,
        // REFLECTION_INPUT, CHECKBOX_PULSING, COMPLETE — engaged but no
        // audio bytes flowing. Show as paused so iOS keeps respecting the
        // session (vs 'none' which signals "audio is over").
        navigator.mediaSession.playbackState = 'paused'
      }
    } catch {}

    // ── Action handlers ─────────────────────────────────────────────────
    // setActionHandler is overwriting; safe to call repeatedly. Each handler
    // dereferences a ref so it always invokes the latest in-component closure.
    try {
      navigator.mediaSession.setActionHandler('play', () => {
        if (handlePlayClickRef.current) handlePlayClickRef.current()
      })
      navigator.mediaSession.setActionHandler('pause', () => {
        if (handlePlayClickRef.current) handlePlayClickRef.current()
      })
      navigator.mediaSession.setActionHandler('seekbackward', (details) => {
        const audio = audioRef.current
        if (!audio) return
        const skip = (details && details.seekOffset) || 15
        try { audio.currentTime = Math.max(0, audio.currentTime - skip) } catch {}
      })
      navigator.mediaSession.setActionHandler('seekforward', (details) => {
        const audio = audioRef.current
        if (!audio) return
        const skip = (details && details.seekOffset) || 15
        try { audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + skip) } catch {}
      })
      navigator.mediaSession.setActionHandler('stop', () => {
        if (handleCloseRef.current) handleCloseRef.current()
      })
    } catch {}
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.machine, title, dayNumber, contentType])

  // Position state — keeps the lock-screen scrub bar accurate. iOS interpolates
  // between updates based on playbackRate, so we don't need ultra-frequent
  // refresh; tying to state.positionSec (which updates ~4× per second from the
  // audio element's `timeupdate`) gives smooth tracking with negligible cost.
  useEffect(() => {
    if (typeof navigator === 'undefined') return
    if (!('mediaSession' in navigator)) return
    if (!('setPositionState' in navigator.mediaSession)) return
    const m = state.machine
    if (m !== STATE.AUDIO_PLAYING && m !== STATE.AUDIO_PAUSED) return
    try {
      const audio = audioRef.current
      if (audio && Number.isFinite(audio.duration) && audio.duration > 0) {
        navigator.mediaSession.setPositionState({
          duration: audio.duration,
          playbackRate: audio.playbackRate || 1,
          position: Math.min(audio.currentTime || 0, audio.duration)
        })
      }
    } catch {}
  }, [state.positionSec, state.machine])

  function handleSeek(positionSec) {
    const audio = audioRef.current
    if (audio && Number.isFinite(audio.duration) && audio.duration > 0) {
      audio.currentTime = Math.max(0, Math.min(audio.duration, positionSec))
    }
    dispatch({ type: 'SEEK', positionSec })
  }

  function handleSpeedChange(speed) {
    const audio = audioRef.current
    if (audio) {
      audio.playbackRate = speed
    }
    dispatch({ type: 'SET_SPEED', speed })
  }

  return (
    <div style={{ marginBottom: 0 }}>
      {/* Hidden HTMLAudioElement — controls are rendered by this component, not by the browser. */}
      <audio ref={audioRef} preload="metadata" />

      {/* Title row: [44×44 play button] [emoji or sun/moon] [title] [(duration when collapsed)] */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 10,
        marginBottom: 12,
        paddingBottom: 8,
        borderBottom: '1px solid rgba(255,255,255,.06)'
      }}>
        <PlayButton machine={state.machine} onClick={handlePlayClick} />

        {bookendVariant
          ? <SunMoonIcon variant={bookendVariant} />
          : (emoji && <span style={{ fontSize: 18, flexShrink: 0 }}>{emoji}</span>)}

        <div style={{ flex: 1, minWidth: 0 }}>
          <h2 style={{
            fontSize: 15,
            fontWeight: 600,
            fontFamily: 'var(--font-ui)',
            color: 'rgba(251,250,244,.85)',
            margin: 0,
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
          }}>
            {title}
          </h2>
          {bookendSubtitle && !expanded && (
            <p style={{
              fontSize: 13, fontStyle: 'italic',
              color: 'var(--cream)', opacity: .7,
              margin: '2px 0 0 0',
              fontFamily: 'var(--font-serif)'
            }}>
              {bookendSubtitle}
            </p>
          )}
          {/* v9.39 — Wand attribution as second-line subtitle.
              Always visible (collapsed + expanded), every audio surface.
              Replaces the v9.38 bottom-of-expanded placement per Geo's
              second-look design call. NEVER replace "Your Fairy Godfather"
              with the underlying voice ID — see brand-voice rule §3.40. */}
          <p className="player-wand-attribution" style={{
            fontSize: 11,
            fontStyle: 'italic',
            fontFamily: 'var(--font-ui)',
            color: 'rgba(251,250,244,.4)',
            margin: '2px 0 0 0',
            letterSpacing: '.01em',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap'
          }}>
            🪄 Narrated by Your Fairy Godfather
          </p>
        </div>

        {!expanded && state.durationSec > 0 && (
          <span style={{
            fontSize: 14, fontFamily: 'var(--font-serif)',
            color: 'var(--cream)', fontStyle: 'italic',
            flexShrink: 0,
            opacity: .85
          }}>
            ({formatTime(state.durationSec)})
          </span>
        )}
      </div>

      {/* Expanded controls — scrub, time, speeds, close, status */}
      {expanded && (
        <div style={{ marginBottom: 16, animation: 'fadeInPlayer .25s ease-out' }}>
          <ScrubBar
            positionSec={state.positionSec}
            durationSec={state.durationSec}
            onSeek={handleSeek}
          />
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            marginBottom: 10,
            fontSize: 12,
            fontFamily: 'var(--font-ui)',
            color: 'var(--cream)'
          }}>
            <span>{formatTime(state.positionSec)} / {formatTime(state.durationSec)}</span>
          </div>
          <div style={{
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            gap: 12
          }}>
            <SpeedPills speed={state.speed} onChange={handleSpeedChange} />
            <CloseButton onClick={handleClose} />
          </div>

          {status && (
            <p className="player-status-line" style={{
              fontSize: 12, fontStyle: 'italic',
              color: 'var(--cream)', opacity: .75,
              fontFamily: 'var(--font-ui)',
              margin: '10px 0 0 0'
            }}>
              {status}
            </p>
          )}

          {state.machine === STATE.LISTENING_FOR_GATE_RESPONSE && (
            <div className="voice-gate" style={{
              marginTop: 14,
              padding: '14px 12px',
              background: 'rgba(255,20,147,0.08)',
              border: '1px solid rgba(255,20,147,0.35)',
              borderRadius: 8,
              animation: 'fadeInPlayer .25s ease-out'
            }}>
              <div style={{
                display: 'flex', alignItems: 'center', gap: 10,
                marginBottom: 12
              }}>
                <span className="gate-listening-dot" style={{
                  width: 10, height: 10, borderRadius: '50%',
                  background: 'var(--pink)',
                  flexShrink: 0,
                  animation: 'gateListeningPulse 1.2s ease-in-out infinite'
                }} />
                <span style={{
                  fontSize: 13,
                  fontFamily: 'var(--font-ui)',
                  color: 'var(--cream)',
                  fontWeight: 500
                }}>
                  Listening — say <strong style={{ color: 'var(--pink)' }}>Yes</strong> or <strong style={{ color: 'var(--pink)' }}>No</strong>
                </span>
              </div>
              <p style={{
                fontSize: 11,
                fontFamily: 'var(--font-ui)',
                color: 'rgba(251,250,244,.55)',
                margin: '0 0 12px 0',
                fontStyle: 'italic'
              }}>
                Or tap below — either works.
              </p>
              <div style={{ display: 'flex', gap: 8 }}>
                <button
                  className="btn-primary"
                  style={{ flex: 1, fontSize: 13, padding: '10px 12px' }}
                  onClick={() => dispatch({ type: 'GATE_TAPPED_YES' })}
                >
                  Yes — record reflection
                </button>
                <button
                  style={{
                    flex: 1, fontSize: 13, padding: '10px 12px',
                    background: 'transparent',
                    color: 'var(--cream)',
                    border: '1px solid rgba(251,250,244,.3)',
                    borderRadius: 6,
                    cursor: 'pointer',
                    fontFamily: 'var(--font-ui)'
                  }}
                  onClick={() => dispatch({ type: 'GATE_HEARD_NO' })}
                >
                  Skip — check the box
                </button>
              </div>
            </div>
          )}

          {state.machine === STATE.ERROR_STATE && (
            <p style={{
              fontSize: 13, color: 'var(--pink)',
              fontFamily: 'var(--font-ui)', marginTop: 8
            }}>
              ⚠️ {state.errorMessage || 'Audio temporarily unavailable.'}
            </p>
          )}
        </div>
      )}
    </div>
  )
})

export default AudioPlayer
