// src/BlockedMembers.jsx — v9.56.
// "Blocked Members" list, rendered inside ProfilePage → My Account, own
// profile only. Lists everyone the current member has blocked, each with an
// Unblock control. Reads via the get_my_blocked_members() RPC so the blocked
// member's name/avatar resolve even though the members restrictive policy
// hides them from ordinary directory reads.
import { useState, useEffect } from 'react'
import { fetchMyBlockedMembers, unblockMember } from './blocks'

export default function BlockedMembers({ myMemberId }) {
  const [rows, setRows]     = useState([])
  const [loading, setLoading] = useState(true)
  const [busy, setBusy]     = useState(null)

  async function load() {
    setLoading(true)
    const data = await fetchMyBlockedMembers()
    setRows(data)
    setLoading(false)
  }
  useEffect(() => { load() }, [myMemberId])

  async function handleUnblock(targetId, name) {
    if (!window.confirm(
      `Unblock ${name}?\n\nThey will be able to see your profile again, and you'll see theirs across the community.`
    )) return
    setBusy(targetId)
    const { error } = await unblockMember(myMemberId, targetId)
    setBusy(null)
    if (error) { window.alert('Could not unblock right now. Please try again in a moment.'); return }
    setRows(rows.filter(r => r.member_id !== targetId))
  }

  return (
    <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
      <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:6}}>BLOCKED MEMBERS</p>
      <p style={{fontSize:12,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:14}}>
        Members you block can no longer see your profile, and you won't see theirs anywhere in the community. Blocking is silent — they are not notified.
      </p>

      {loading ? (
        <div className="spinner"/>
      ) : rows.length === 0 ? (
        <p style={{fontSize:13,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',fontStyle:'italic'}}>
          You haven't blocked anyone.
        </p>
      ) : (
        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          {rows.map(r => {
            const name    = r.display_name || (r.email || '').split('@')[0] || 'Member'
            const initial = (name[0] || '?').toUpperCase()
            return (
              <div key={r.block_id} style={{display:'flex',alignItems:'center',gap:12,padding:'10px 12px',borderRadius:8,background:'rgba(255,255,255,.03)',border:'1px solid rgba(255,255,255,.06)'}}>
                {r.avatar_url
                  ? <img src={r.avatar_url} alt="" style={{width:36,height:36,borderRadius:'50%',objectFit:'cover',flexShrink:0}}/>
                  : <div style={{width:36,height:36,borderRadius:'50%',background:'rgba(255,20,147,.15)',display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,fontSize:14,color:'var(--pink)',fontFamily:'var(--font-ui)'}}>{initial}</div>}
                <span style={{flex:1,minWidth:0,fontSize:14,color:'var(--cream)',fontFamily:'var(--font-ui)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{name}</span>
                <button
                  onClick={()=>handleUnblock(r.member_id, name)}
                  disabled={busy===r.member_id}
                  style={{padding:'6px 14px',borderRadius:8,background:'rgba(25,229,94,.12)',border:'1px solid rgba(25,229,94,.3)',color:'var(--lime)',fontSize:12,fontFamily:'var(--font-ui)',fontWeight:600,cursor:'pointer',whiteSpace:'nowrap',flexShrink:0,opacity:busy===r.member_id?0.6:1}}>
                  {busy===r.member_id ? '…' : 'Unblock'}
                </button>
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}
