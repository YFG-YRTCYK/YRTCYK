// ─── v9.46-followup Item 7 — Cheers inbox bell ─────────────────────────
// Renders next to the greeting on Dashboard. Shows a heart icon with a count
// badge when the current member has received cheers today. Tapping opens
// a dropdown listing each sender's display_name + their message.
//
// "Today" is anchored to America/Los_Angeles to match the existing daily
// cron + scoring conventions on the platform (see send-morning-emails v17,
// send-evening-emails v19, get_my_stats RPC).

import { useState, useEffect, useRef } from 'react'
import { supabase } from './supabaseClient'

/**
 * Compute the start-of-today timestamp in the platform's anchor timezone.
 * Returns an ISO string suitable for a Supabase .gte filter.
 */
function startOfTodayPT() {
  // Get current Y-M-D in America/Los_Angeles, then construct that date as
  // local-midnight in PT and convert back to UTC for the query.
  const now = new Date()
  const ymd = now.toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' }) // YYYY-MM-DD
  // Construct a Date that means "midnight on YMD in PT". PT offset varies
  // (PDT = UTC-7, PST = UTC-8), so we ask Intl what the offset currently is.
  // Simplest robust approach: parse the locale-string back through Date.
  // This produces 00:00:00 PT regardless of DST.
  const ptMidnight = new Date(`${ymd}T00:00:00${getPTOffsetString(now)}`)
  return ptMidnight.toISOString()
}

function getPTOffsetString(d) {
  // Returns "-07:00" during PDT, "-08:00" during PST.
  const tzShort = d.toLocaleString('en-US', { timeZone: 'America/Los_Angeles', timeZoneName: 'short' })
  return tzShort.includes('PDT') ? '-07:00' : '-08:00'
}

export default function CheersInbox({ member }) {
  const [cheers, setCheers]   = useState([])
  const [open, setOpen]       = useState(false)
  const [loading, setLoading] = useState(false)
  const dropdownRef = useRef(null)

  useEffect(() => {
    if (!member?.id) return
    load()
    // Soft refresh every 5 minutes — no realtime needed at this scale.
    const t = setInterval(load, 5 * 60 * 1000)
    return () => clearInterval(t)
  }, [member?.id])

  // Close on outside click
  useEffect(() => {
    if (!open) return
    function onDocClick(e) {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target)) setOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [open])

  async function load() {
    if (!member?.id) return
    setLoading(true)
    const since = startOfTodayPT()
    const { data, error } = await supabase
      .from('cheers')
      .select('id, message, milestone_type, created_at, sender:sender_id ( id, display_name, email )')
      .eq('recipient_id', member.id)
      .gte('created_at', since)
      .order('created_at', { ascending: false })
    if (error) {
      console.error('[CheersInbox] load error', error)
      setCheers([])
    } else {
      setCheers(data || [])
    }
    setLoading(false)
  }

  if (!member) return null
  const count = cheers.length
  if (count === 0 && !open) return null // hide entirely when nothing today

  return (
    <div ref={dropdownRef} style={{ position: 'relative', display: 'inline-block' }}>
      <button
        onClick={() => setOpen(o => !o)}
        title={count === 0 ? 'No cheers today' : `${count} cheer${count === 1 ? '' : 's'} today`}
        style={{
          background: 'rgba(255,20,147,.1)',
          border: '1px solid rgba(255,20,147,.3)',
          borderRadius: 20,
          padding: '6px 12px',
          display: 'inline-flex',
          alignItems: 'center',
          gap: 6,
          cursor: 'pointer',
          fontFamily: 'var(--font-ui)',
        }}
      >
        <span style={{ fontSize: 16, lineHeight: 1 }}>💗</span>
        <span style={{ fontSize: 12, color: 'var(--pink)', fontWeight: 700 }}>{count}</span>
      </button>

      {open && (
        <div
          style={{
            position: 'absolute',
            top: 'calc(100% + 8px)',
            right: 0,
            minWidth: 280,
            maxWidth: 360,
            maxHeight: 420,
            overflowY: 'auto',
            background: 'var(--bg)',
            border: '1px solid rgba(255,20,147,.3)',
            borderRadius: 12,
            padding: 14,
            boxShadow: '0 8px 24px rgba(0,0,0,.35)',
            zIndex: 50,
          }}
        >
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <p style={{ fontSize: 11, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: 1.2, textTransform: 'uppercase' }}>
              💗 Cheers Today
            </p>
            <button
              onClick={() => setOpen(false)}
              style={{ background: 'transparent', border: 'none', color: 'rgba(251,250,244,.5)', fontSize: 18, lineHeight: 1, cursor: 'pointer', padding: 0 }}
            >
              ×
            </button>
          </div>

          {loading && cheers.length === 0 ? (
            <p style={{ fontSize: 12, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', textAlign: 'center', padding: '16px 0' }}>Loading…</p>
          ) : cheers.length === 0 ? (
            <p style={{ fontSize: 12, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', fontStyle: 'italic', textAlign: 'center', padding: '16px 0' }}>
              No cheers today yet. 🌱
            </p>
          ) : (
            <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
              {cheers.map(c => {
                const senderName = c.sender?.display_name || (c.sender?.email ? c.sender.email.split('@')[0] : 'A member')
                return (
                  <div
                    key={c.id}
                    style={{
                      padding: '10px 12px',
                      borderRadius: 8,
                      background: 'rgba(255,20,147,.06)',
                      border: '1px solid rgba(255,20,147,.18)',
                    }}
                  >
                    <p style={{ fontSize: 13, color: 'var(--cream)', lineHeight: 1.5, marginBottom: 6, fontStyle: 'italic' }}>
                      "{c.message}"
                    </p>
                    <p style={{ fontSize: 11, color: 'rgba(251,250,244,.5)', fontFamily: 'var(--font-ui)' }}>
                      — {senderName}
                      <span style={{ color: 'rgba(251,250,244,.3)', marginLeft: 6 }}>
                        · {new Date(c.created_at).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' })}
                      </span>
                    </p>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      )}
    </div>
  )
}
