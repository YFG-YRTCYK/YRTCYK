import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import WomAttendance from './WomAttendance'
import SendCheersModal from './SendCheersModal'

// ─── YRTCYK Daily Meeting Config ──────────────────────────────────────────────
// ⚠️  UPDATE THESE with your real Zoom Meeting ID and Passcode
const MEETING_HOUR_PT   = 17   // 5 PM Pacific
const MEETING_MINUTE_PT = 30   // 5:30 PM
const ZOOM_MEETING_ID   = '867 6158 2536'
const ZOOM_PASSCODE     = '293820'
const ZOOM_LINK         = 'https://us02web.zoom.us/j/86761582536?pwd=c3RycXA5L05ZL1VkdENnL05tbEczdz09'

function DailyMeetingWidget() {
  const [now, setNow] = useState(new Date())
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000) // refresh every 30s
    return () => clearInterval(t)
  }, [])

  // Convert current time to PT offset (UTC-7 PDT / UTC-8 PST)
  // We use a simple heuristic: get PT time via toLocaleTimeString
  const ptStr = now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles', hour:'numeric', minute:'2-digit', hour12: true })
  const ptFull = now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles',
    hour:'numeric', minute:'2-digit', hour12: false })
  const [ptH, ptM] = ptFull.split(':').map(Number)
  const nowMins  = ptH * 60 + ptM
  const meetMins = MEETING_HOUR_PT * 60 + MEETING_MINUTE_PT
  const diffMins = meetMins - nowMins

  // Meeting time display  e.g. "5:30 PM PT"
  const meetTimeDisplay = new Date(2000, 0, 1, MEETING_HOUR_PT, MEETING_MINUTE_PT)
    .toLocaleTimeString('en-US', { hour:'numeric', minute:'2-digit', hour12:true }) + ' PT'

  // States: upcoming (>15min away), starting (0–15min), live (0 to +60min), ended
  const isStarting = diffMins > 0  && diffMins <= 15
  const isLive     = diffMins <= 0 && diffMins > -60
  const isEnded    = diffMins <= -60

  let statusColor  = 'rgba(255,20,147,.12)'
  let borderColor  = 'rgba(255,20,147,.25)'
  let dotColor     = 'rgba(255,20,147,.6)'
  let statusText   = ''
  let subText      = ''

  if (isLive) {
    statusColor = 'rgba(25,229,94,.12)'
    borderColor = 'rgba(25,229,94,.35)'
    dotColor    = '#19e55e'
    statusText  = '🟢 Meeting is LIVE right now'
    subText     = 'One click — you\'re in.'
  } else if (isStarting) {
    statusColor = 'rgba(255,165,0,.1)'
    borderColor = 'rgba(255,165,0,.3)'
    dotColor    = '#ffa500'
    statusText  = `Starting in ${diffMins} minute${diffMins !== 1 ? 's' : ''}`
    subText     = 'Get your coffee. You\'re almost there.'
  } else if (isEnded) {
    statusText = `Today's meeting has ended`
    subText    = `Next meeting tomorrow at ${meetTimeDisplay}`
  } else {
    const h = Math.floor(diffMins / 60)
    const m = diffMins % 60
    statusText = h > 0
      ? `Today at ${meetTimeDisplay} — ${h}h ${m > 0 ? m+'m' : ''} away`
      : `Today at ${meetTimeDisplay} — ${diffMins} minutes away`
    subText = 'YRTCYK Daily Meeting · Every day, same time, same room.'
  }

  return (
    <div style={{
      background: statusColor,
      border: `1px solid ${borderColor}`,
      borderRadius: 12,
      padding: '14px 16px',
      marginBottom: 20,
      position: 'relative',
      overflow: 'hidden'
    }}>
      {/* Subtle streak decoration */}
      <div style={{ position:'absolute', top:0, right:0, width:80, height:'100%',
        background: `linear-gradient(to left, ${dotColor}08, transparent)`, pointerEvents:'none' }}/>

      <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:8 }}>
        {/* Live dot */}
        <div style={{ position:'relative', flexShrink:0 }}>
          <div style={{ width:10, height:10, borderRadius:'50%', background: dotColor }}/>
          {(isLive || isStarting) && (
            <div style={{ position:'absolute', top:-3, left:-3, width:16, height:16, borderRadius:'50%',
              border: `2px solid ${dotColor}`, opacity:0.5,
              animation: 'ping 1.5s cubic-bezier(0,0,.2,1) infinite' }}/>
          )}
        </div>
        <div>
          <p style={{ fontSize:13, fontWeight:600, color: isLive ? 'var(--lime)' : isStarting ? '#ffa500' : 'var(--cream)', lineHeight:1.2, marginBottom:2 }}>
            {statusText}
          </p>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', lineHeight:1.4 }}>
            {subText}
          </p>
        </div>
      </div>

      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <a href={ZOOM_LINK} target="_blank" rel="noopener noreferrer"
          style={{
            display:'inline-block', padding:'9px 20px', borderRadius:8, textDecoration:'none',
            background: isLive ? 'var(--lime)' : isStarting ? '#ffa500' : 'var(--pink)',
            color: isLive ? '#01280e' : '#fff',
            fontSize:13, fontWeight:700, fontFamily:'var(--font-ui)',
            boxShadow: isLive ? '0 0 16px rgba(25,229,94,.3)' : 'none'
          }}>
          {isLive ? '🎙 Join Meeting Now' : isEnded ? '📅 Zoom Link' : '🎙 Join Meeting'}
        </a>
        <div style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', lineHeight:1.5 }}>
          Meeting ID: {ZOOM_MEETING_ID}<br/>
          Passcode: {ZOOM_PASSCODE}
        </div>
      </div>

      <style>{`
        @keyframes ping {
          0% { transform: scale(1); opacity: 0.6; }
          100% { transform: scale(2.2); opacity: 0; }
        }
      `}</style>
    </div>
  )
}



// ─── Event date range formatter (shared with Word of Mouth card rendering) ───
// Returns compact "June 3–11, 2026" for same-month, "June 30 – July 5, 2026" cross-month,
// "June 3, 2026" for single day, and full formatting for cross-year.
function formatDateRange(startStr, endStr) {
  if (!startStr) return ''
  const s = new Date(startStr + 'T00:00:00')
  const e = endStr ? new Date(endStr + 'T00:00:00') : null
  const sMonth = s.toLocaleDateString('en-US', { month: 'long' })
  const sDay = s.getDate(); const sYear = s.getFullYear()
  if (!e || s.getTime() === e.getTime()) return `${sMonth} ${sDay}, ${sYear}`
  if (s.getMonth() === e.getMonth() && s.getFullYear() === e.getFullYear()) return `${sMonth} ${sDay}–${e.getDate()}, ${sYear}`
  const eMonth = e.toLocaleDateString('en-US', { month: 'long' })
  return `${sMonth} ${sDay} – ${eMonth} ${e.getDate()}, ${e.getFullYear()}`
}



export default function CommunityCalendar({ user }) {
  const [events, setEvents] = useState([])
  const [weekOffset, setWeekOffset] = useState(0)
  const [loading, setLoading] = useState(true)
  // v9.46 Item 8 — current member row (id, display_name, avatar_url) for the I'm Going toggle.
  const [member, setMember] = useState(null)
  // v9.46-followup Item 7 — when set, the SendCheersModal renders for this event.
  // Shape: { recipientId, recipientName, milestoneType, milestoneLabel }
  const [cheersTarget, setCheersTarget] = useState(null)

  useEffect(()=>{ loadEvents() },[weekOffset])

  // v9.46 Item 8 — load member row once on mount; the toggle component needs this for inserts.
  useEffect(() => {
    if (!user?.email) return
    supabase
      .from('members')
      .select('id, display_name, avatar_url')
      .eq('email', user.email)
      .single()
      .then(({ data }) => { if (data) setMember(data) })
  }, [user?.email])

  async function loadEvents() {
    setLoading(true)
    const today = new Date(); today.setHours(0,0,0,0)
    const weekStart = new Date(today); weekStart.setDate(today.getDate() - today.getDay() + weekOffset*7)
    const weekEnd = new Date(weekStart); weekEnd.setDate(weekStart.getDate()+6)

    // v9.17: Exclude operator accounts — Admin's birthday/anniversary doesn't belong on the community calendar.
    const { data:members } = await supabase
      .from('members')
      .select('id,display_name,email,birth_date,show_age,program_1,program_1_date,show_years_1,program_2,program_2_date,show_years_2,program_3,program_3_date,show_years_3')
      .or('is_active.eq.true,is_active.is.null')
      .eq('is_operator', false)

    const evts = []
    if (members) {
      for (const m of members) {
        const name = m.display_name || m.email.split('@')[0]
        const year = weekStart.getFullYear()

        // Birthday — always show if birth_date exists, age only if show_age
        if (m.birth_date) {
          const bd = new Date(m.birth_date+'T00:00:00')
          for (const yr of [year, year+1]) {
            const bday = new Date(yr, bd.getMonth(), bd.getDate())
            if (bday >= weekStart && bday <= weekEnd) {
              let sub = '🎂 Happy Birthday!'
              if (m.show_age) {
                const age = yr - bd.getFullYear()
                sub = `🎂 Turning ${age}!`
              }
              // v9.46-followup Item 7: carry member_id + display_name so Send Cheers button can target the row.
              evts.push({ date:bday, type:'birthday', label:`${name}'s Birthday`, sub,
                          memberId: m.id, memberDisplayName: name,
                          milestoneLabel: m.show_age ? sub : 'Birthday' })
            }
          }
        }

        // All programs with name + date — show all three
        for (const n of [1,2,3]) {
          const prog = m[`program_${n}`]
          const sd   = m[`program_${n}_date`]
          const showYears = m[`show_years_${n}`] !== false // default true

          if (prog && sd) {
            const s = new Date(sd+'T00:00:00')
            for (const yr of [year, year+1]) {
              const anniv = new Date(yr, s.getMonth(), s.getDate())
              if (anniv >= weekStart && anniv <= weekEnd) {
                const years = yr - s.getFullYear()
                const sub = showYears
                  ? `${years} year${years!==1?'s':''} in ${prog}`
                  : `${prog} Anniversary`
                // v9.46-followup Item 7: carry member_id + display_name + a clean milestone label.
                evts.push({ date:anniv, type:'anniversary', label:`${name}'s ${prog} Anniversary 🏅`, sub,
                            memberId: m.id, memberDisplayName: name,
                            milestoneLabel: showYears ? `${years} year${years!==1?'s':''} in ${prog}` : `${prog} Anniversary` })
              }
            }
          }
        }
      }
    }

    // ── LGBT Recovery events (category='lgbt_recovery' with start_date set) ──
    // No year-shifting — events are for specific years as entered.
    // Overlap rule: event is visible if start_date <= weekEnd AND (end_date ?? start_date) >= weekStart.
    const { data: wom } = await supabase
      .from('word_of_mouth')
      .select('id,event_name,business_name,city,address,website_url,start_date,end_date,member_display_name')
      .eq('category', 'lgbt_recovery')
      .not('start_date', 'is', null)

    if (wom) {
      for (const w of wom) {
        const s = new Date(w.start_date + 'T00:00:00')
        const e = w.end_date ? new Date(w.end_date + 'T00:00:00') : s
        // Overlap with current visible week
        if (s <= weekEnd && e >= weekStart) {
          evts.push({
            id: w.id, // v9.46 Item 8 — needed by WomAttendance toggle
            date: s, // primary sort key — event's start day
            spanStart: s,
            spanEnd: e,
            type: 'lgbt_event',
            label: w.event_name || w.business_name, // v9.12: event_name is primary when set
            venue: (w.event_name && w.business_name) ? w.business_name : null, // secondary line when both exist
            sub: formatDateRange(w.start_date, w.end_date),
            city: w.city,
            address: w.address,
            websiteUrl: w.website_url,
          })
        }
      }
    }

    // ── v9.50: Memorial dates ─────────────────────────────────────────────
    // Two sources:
    //   (1) Active member registry — date_of_passing on members where
    //       membership_end_reason='deceased'. Per the schema comment,
    //       deceased is the only end_reason that surfaces publicly. Annual
    //       remembrance (year-shifted into the visible week).
    //   (2) Hero showcases — date_of_death on hero_showcases where
    //       life_status='in_memoriam' AND status='approved'. Annual
    //       remembrance, year-shifted.
    // Both render as type='memorial' on the calendar with a cream pip and
    // "In loving memory" treatment.
    const { data: deceasedMembers } = await supabase
      .from('members')
      .select('id, display_name, email, date_of_passing, memorial_tribute')
      .eq('membership_end_reason', 'deceased')
      .not('date_of_passing', 'is', null)

    if (deceasedMembers) {
      for (const m of deceasedMembers) {
        const name = m.display_name || (m.email ? m.email.split('@')[0] : 'Member')
        const dop = new Date(m.date_of_passing + 'T00:00:00')
        const year = weekStart.getFullYear()
        for (const yr of [year, year+1]) {
          const anniv = new Date(yr, dop.getMonth(), dop.getDate())
          if (anniv >= weekStart && anniv <= weekEnd) {
            const yearsGone = yr - dop.getFullYear()
            const sub = yearsGone === 0
              ? 'In loving memory'
              : `${yearsGone} year${yearsGone!==1?'s':''} since they passed`
            evts.push({
              date: anniv,
              type: 'memorial',
              label: `Remembering ${name}`,
              sub,
              memberId: m.id,
              memberDisplayName: name,
              memorialTribute: m.memorial_tribute || null,
              memorialKind: 'member',
            })
          }
        }
      }
    }

    const { data: heroMemorials } = await supabase
      .from('hero_showcases')
      .select('id, hero_name, hero_type, date_of_death, memorial_note, member_display_name')
      .eq('life_status', 'in_memoriam')
      .eq('status', 'approved')
      .not('date_of_death', 'is', null)

    if (heroMemorials) {
      for (const h of heroMemorials) {
        const dod = new Date(h.date_of_death + 'T00:00:00')
        const year = weekStart.getFullYear()
        for (const yr of [year, year+1]) {
          const anniv = new Date(yr, dod.getMonth(), dod.getDate())
          if (anniv >= weekStart && anniv <= weekEnd) {
            const yearsGone = yr - dod.getFullYear()
            const sub = yearsGone === 0
              ? 'In loving memory'
              : `${yearsGone} year${yearsGone!==1?'s':''} since they passed`
            evts.push({
              date: anniv,
              type: 'memorial',
              label: `Remembering ${h.hero_name}`,
              sub,
              heroId: h.id,
              memorialTribute: h.memorial_note || null,
              memorialKind: 'hero',
              honoredBy: h.member_display_name || null,
            })
          }
        }
      }
    }

    evts.sort((a,b)=>a.date-b.date)
    setEvents(evts)
    setLoading(false)
  }

  const today = new Date(); today.setHours(0,0,0,0)
  const weekStart = new Date(today); weekStart.setDate(today.getDate() - today.getDay() + weekOffset*7)
  const days = Array.from({length:7},(_,i)=>{ const d=new Date(weekStart); d.setDate(weekStart.getDate()+i); return d })

  // Build month suffix: "May 2026" if week stays in one month, "April / May 2026" if it spans
  const weekEnd = new Date(weekStart.getTime() + 6*86400000)
  const startMonth = weekStart.toLocaleDateString('en-US',{month:'long'})
  const endMonth   = weekEnd.toLocaleDateString('en-US',{month:'long'})
  const yearLabel  = weekEnd.getFullYear()
  const monthLabel = startMonth === endMonth
    ? `${startMonth} ${yearLabel}`
    : `${startMonth} / ${endMonth} ${yearLabel}`

  const baseLabel = weekOffset===0 ? 'This Week'
    : weekOffset===1 ? 'Next Week'
    : weekOffset===-1 ? 'Last Week'
    : null

  const weekLabel = baseLabel
    ? `${baseLabel} · ${monthLabel}`
    : weekStart.toLocaleDateString('en-US',{month:'short',day:'numeric'}) + ' – ' + weekEnd.toLocaleDateString('en-US',{month:'short',day:'numeric'})

  return (
    <div style={{paddingTop:20}}>

      {/* ── Daily YRTCYK Meeting Banner ── */}
      <DailyMeetingWidget />

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:400}}>Calendar 📅</h2>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <button onClick={()=>setWeekOffset(p=>p-1)} style={{padding:'6px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)',fontFamily:'system-ui',fontSize:13}}>‹</button>
          <span style={{fontSize:12,fontFamily:'system-ui',color:'rgba(251,250,244,.5)',minWidth:160,textAlign:'center'}}>{weekLabel}</span>
          <button onClick={()=>setWeekOffset(p=>p+1)} style={{padding:'6px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)',fontFamily:'system-ui',fontSize:13}}>›</button>
        </div>
      </div>

      {/* Week strip */}
      <div style={{display:'grid',gridTemplateColumns:'repeat(7,1fr)',gap:4,marginBottom:12}}>
        {days.map(d=>{
          const isToday = d.getTime()===today.getTime()
          // Lime dot: member milestone (birthday or anniversary) on this exact day
          const hasMilestone = events.some(e => (e.type === 'birthday' || e.type === 'anniversary') && e.date.getTime() === d.getTime())
          // Pink dot: LGBT event active on this day (d falls inside [spanStart, spanEnd])
          const hasEvent = events.some(e => e.type === 'lgbt_event' && d >= e.spanStart && d <= e.spanEnd)
          // v9.50 — Cream dot: memorial day for a passed member or in-memoriam Hero
          const hasMemorial = events.some(e => e.type === 'memorial' && e.date.getTime() === d.getTime())
          return (
            <div key={d.getTime()} style={{textAlign:'center',padding:'8px 4px',borderRadius:8,background:isToday?'rgba(255,20,147,.15)':'transparent',border:isToday?'1px solid rgba(255,20,147,.3)':'1px solid transparent'}}>
              <p style={{fontSize:9,fontFamily:'system-ui',color:'rgba(251,250,244,.35)',letterSpacing:.5,marginBottom:4}}>{['SUN','MON','TUE','WED','THU','FRI','SAT'][d.getDay()]}</p>
              <p style={{fontSize:15,fontFamily:'system-ui',fontWeight:isToday?700:400,color:isToday?'var(--pink)':'var(--cream)'}}>{d.getDate()}</p>
              {(hasMilestone || hasEvent || hasMemorial) && (
                <div style={{display:'flex',justifyContent:'center',gap:3,marginTop:4}}>
                  {hasMilestone && <div style={{width:6,height:6,borderRadius:'50%',background:'var(--lime)'}}/>}
                  {hasEvent && <div style={{width:6,height:6,borderRadius:'50%',background:'var(--pink)'}}/>}
                  {hasMemorial && <div style={{width:6,height:6,borderRadius:'50%',background:'rgba(251,250,244,.55)'}}/>}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {/* Legend */}
      <div style={{display:'flex',justifyContent:'center',gap:16,marginBottom:24,flexWrap:'wrap'}}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:6,height:6,borderRadius:'50%',background:'var(--lime)'}}/>
          <span style={{fontSize:10,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',letterSpacing:.5}}>Member milestones</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:6,height:6,borderRadius:'50%',background:'var(--pink)'}}/>
          <span style={{fontSize:10,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',letterSpacing:.5}}>🏳️‍🌈 Community events</span>
        </div>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <div style={{width:6,height:6,borderRadius:'50%',background:'rgba(251,250,244,.55)'}}/>
          <span style={{fontSize:10,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',letterSpacing:.5}}>In loving memory</span>
        </div>
      </div>

      {loading&&<div className="spinner"/>}

      {!loading&&events.length===0&&(
        <div className="card" style={{textAlign:'center',padding:32}}>
          <p style={{color:'rgba(251,250,244,.3)',fontFamily:'system-ui',fontSize:14}}>Nothing on the calendar this week. 🌱</p>
          <p style={{color:'rgba(251,250,244,.25)',fontFamily:'system-ui',fontSize:12,marginTop:8}}>Members add birthdays &amp; sobriety dates in their Profile. Community events come from Word of Mouth submissions in the 🏳️‍🌈 LGBT Recovery category.</p>
        </div>
      )}

      {/* v9.51 — 2-column responsive grid. Auto-fill keeps mobile at 2
          columns and widens on tablet/desktop. Long event cards (LGBT
          events with addresses, memorials with tributes) flow naturally
          since each grid cell sizes to its content.
          v9.51.2 — bumped minmax from 200px → 300px. At 200px, iPad
          landscape (~1162-1334px container) yielded 5-6 narrow columns;
          birthday/anniversary cards (emoji 42 + Send Cheers btn 134 = 176
          fixed) had ~24px left for the name+date text, which wrapped
          character-by-character into vertical soup. 300px gives iPad
          landscape 4 columns at ~290-326px, leaving ~110-150px for text. */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(300px, 1fr))', gap:10}}>
        {events.map((e,i)=>{
          // Rich card layout for LGBT Recovery events
          if (e.type === 'lgbt_event') {
            const mapsUrl = e.address
              ? `https://www.google.com/maps/search/${encodeURIComponent(e.address)}`
              : `https://www.google.com/maps/search/${encodeURIComponent(e.label + ' ' + (e.city || ''))}`
            const hasWebsite = e.websiteUrl && e.websiteUrl.startsWith('http')
            return (
              <div key={i} className="card" style={{borderLeft:'3px solid var(--pink)', paddingLeft:14}}>
                <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
                  <span style={{fontSize:16}}>🏳️‍🌈</span>
                  <span style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:.8,textTransform:'uppercase'}}>
                    LGBT Recovery Event
                  </span>
                </div>
                <h3 style={{fontSize:16,fontWeight:600,marginBottom: e.venue ? 2 : 6}}>{e.label}</h3>
                {e.venue && (
                  <p style={{fontSize:12,color:'rgba(251,250,244,.55)',fontStyle:'italic',marginBottom:6}}>
                    at {e.venue}
                  </p>
                )}
                <p style={{fontSize:13,color:'var(--pink)',fontFamily:'var(--font-ui)',fontWeight:600,marginBottom:4}}>
                  📅 {e.sub}
                </p>
                {(e.address || e.city) && (
                  <p style={{fontSize:12,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.5,marginBottom:hasWebsite?10:0}}>
                    📍 {e.address || e.city}
                  </p>
                )}
                {hasWebsite && (
                  <div style={{display:'flex',gap:6,marginTop:10}}>
                    <a href={e.websiteUrl} target="_blank" rel="noopener noreferrer"
                      style={{padding:'6px 12px',borderRadius:8,background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.25)',color:'var(--pink)',fontSize:11,fontFamily:'var(--font-ui)',textDecoration:'none'}}>
                      🌐 Visit site
                    </a>
                    <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                      style={{padding:'6px 12px',borderRadius:8,background:'rgba(25,229,94,.1)',border:'1px solid rgba(25,229,94,.2)',color:'var(--lime)',fontSize:11,fontFamily:'var(--font-ui)',textDecoration:'none'}}>
                      📍 Maps
                    </a>
                  </div>
                )}
                {/* v9.46 Item 8 — I'm Going toggle + attendee pile */}
                <WomAttendance womId={e.id} member={member} />
              </div>
            )
          }
          // v9.50 — Memorial card. Hover-low palette (cream-on-shadow)
          // distinguishes from active-member milestones. No Send Cheers
          // button — cheers are for living milestones only.
          if (e.type === 'memorial') {
            const tribute = e.memorialTribute && e.memorialTribute.trim().length > 0 ? e.memorialTribute : null
            return (
              <div key={i} className="card" style={{borderLeft:'3px solid rgba(251,250,244,.45)', paddingLeft:14, background:'rgba(255,255,255,.02)'}}>
                <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
                  <span style={{fontSize:14}}>🕯️</span>
                  <span style={{fontSize:10,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',letterSpacing:.8,textTransform:'uppercase'}}>
                    {e.memorialKind === 'hero' ? 'Hero — In memoriam' : 'Member — In memoriam'}
                  </span>
                </div>
                <h3 style={{fontSize:15,fontWeight:600,marginBottom:2,color:'var(--cream)'}}>{e.label}</h3>
                <p style={{fontSize:12,color:'rgba(251,250,244,.45)',fontFamily:'system-ui',marginBottom: tribute ? 8 : 0}}>
                  {e.sub} · {e.date.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}
                </p>
                {tribute && (
                  <p style={{fontSize:13,color:'rgba(251,250,244,.6)',fontStyle:'italic',lineHeight:1.6,margin:0}}>
                    "{tribute}"
                  </p>
                )}
                {e.honoredBy && (
                  <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:6,marginBottom:0}}>
                    Honored by {e.honoredBy}
                  </p>
                )}
              </div>
            )
          }

          // Existing card layout for birthdays and anniversaries
          // v9.46-followup Item 7: hide Send Cheers when the event is the current member's own milestone (no self-cheers).
          // v9.51.2: flexWrap added so on narrow widths (or future minmax
          // tightening) Send Cheers wraps to its own row instead of
          // squeezing the name/date text into vertical character soup.
          // Text block keeps minWidth:0 so flex shrinking still works.
          const canCheer = !!member && e.memberId && e.memberId !== member.id
          const milestoneType = e.type === 'birthday' ? 'birthday' : 'sobriety_anniversary'
          return (
            <div key={i} className="card" style={{display:'flex',gap:14,alignItems:'center',flexWrap:'wrap'}}>
              <div style={{fontSize:28,flexShrink:0}}>{e.type==='birthday'?'🎂':'🏅'}</div>
              <div style={{flex:'1 1 140px', minWidth:0}}>
                <p style={{fontSize:15,marginBottom:2}}>{e.label}</p>
                <p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'system-ui'}}>{e.sub} · {e.date.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'numeric'})}</p>
              </div>
              {canCheer && (
                <button
                  onClick={() => setCheersTarget({
                    recipientId:    e.memberId,
                    recipientName:  e.memberDisplayName,
                    milestoneType,
                    milestoneLabel: e.milestoneLabel,
                  })}
                  title={`Send cheers to ${e.memberDisplayName}`}
                  style={{
                    flexShrink: 0,
                    padding: '7px 12px',
                    borderRadius: 20,
                    background: 'rgba(255,20,147,.1)',
                    border: '1px solid rgba(255,20,147,.35)',
                    color: 'var(--pink)',
                    fontSize: 11,
                    fontFamily: 'var(--font-ui)',
                    fontWeight: 700,
                    cursor: 'pointer',
                    whiteSpace: 'nowrap',
                  }}
                >
                  🌟 Send Cheers
                </button>
              )}
            </div>
          )
        })}
      </div>

      {/* v9.46-followup Item 7 — Send Cheers modal (fixed overlay) */}
      {cheersTarget && member && (
        <SendCheersModal
          recipient={{ id: cheersTarget.recipientId, display_name: cheersTarget.recipientName }}
          sender={member}
          milestoneType={cheersTarget.milestoneType}
          milestoneLabel={cheersTarget.milestoneLabel}
          onClose={() => setCheersTarget(null)}
        />
      )}
    </div>
  )
}
