import { useState, useEffect, useRef, useMemo, createContext, useContext } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'
import AudioPlayer from './AudioPlayer'
import CheersInbox from './CheersInbox'
import MeetingCard from './MeetingCard'
import { createReflectionRecognizer, isSpeechRecognitionSupported } from './SpeechToText'

// 8c — Class B audio chain integration. SectionBlock provides this context for
// sections whose audio behaviorClass is 'B' so the player (rendered by
// SectionBlock) can coordinate with the sibling NotesBox (textarea focus on
// REFLECTION_INPUT, save-tap notification, mic-button visibility, glow border,
// auto-scroll-into-view) and CheckRow (2-sec pulse on CHECKBOX_PULSING).
// Non-Class-B sections never read this context.
//
//   textareaRef        — bound to the NotesBox <textarea>; player calls .focus()
//   pulseKey           — number; increments to remount CheckRow's <label> and
//                        replay the @keyframes pulseCheckbox 2s animation
//   notifySaveTap      — NotesBox calls this with current textarea content when
//                        user taps Save during REFLECTION_INPUT; player decides
//                        saved-vs-skipped branch from content presence
//   isReflectionInput  — boolean; NotesBox uses this to apply the pink glow
//                        border + render the mic button + the prominent prompt
const SectionAudioContext = createContext(null)

export default function Dashboard({ user, isAdmin, setView }) {
  const [member, setMember]         = useState(null)
  const [dayContent, setDayContent] = useState(null)
  const [dayNum, setDayNum]         = useState(1)         // 9.32 — viewing day (defaults to today)
  const [todayNum, setTodayNum]     = useState(1)         // 9.32 — actual today (anchor; never changes within session)
  const [actions, setActions]       = useState({})
  const [kpi, setKpi]               = useState({ total_members:0, active_today:0, community_completion_pct:0, total_days_completed:0 })
  const [myStats, setMyStats]       = useState({ today_pct:0, monthly_pct:0, overall_pct:0, days_active:0 })
  const [myResponses, setMyResponses]   = useState(0)
  const [commResponses, setCommResponses] = useState(0)
  const [practice, setPractice]     = useState(null)
  const [saving, setSaving]         = useState({})
  const [navLoading, setNavLoading] = useState(false)     // 9.32 — brief loading indicator while day data fetches
  const [latestReflections, setLatestReflections] = useState([]) // v9.55 — home-screen preview: 2 most-recent approved reflections

  useEffect(() => { init() }, [])

  async function init() {
    const { data: m } = await supabase.from('members').select('*').eq('email', user.email).single()
    if (!m) return
    setMember(m)
    const start = new Date(m.membership_start_date + 'T00:00:00')
    const today = new Date(); start.setHours(0,0,0,0); today.setHours(0,0,0,0)
    const tn = Math.max(1, Math.min(365, Math.floor((today - start) / 86400000) + 1))
    setTodayNum(tn)
    setDayNum(tn)

    // KPI / stats / response counts only fetch once at init — they're not day-scoped.
    // v9.55 — added blog_posts query (limit 2 latest approved) for the home preview.
    const [kpiRes, statsRes, myRespRes, commRespRes, refRes] = await Promise.all([
      supabase.rpc('get_community_kpi'),
      supabase.rpc('get_my_stats'),
      supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('member_id', m.id).eq('item_type', 'text').not('text_value', 'is', null),
      supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('item_type', 'text').not('text_value', 'is', null),
      supabase.from('blog_posts').select('id, title, body, author_id, created_at')
        .eq('status', 'approved').order('created_at', { ascending: false }).limit(2),
    ])

    if (kpiRes.data) setKpi(kpiRes.data)
    if (statsRes.data) setMyStats(statsRes.data)
    if (myRespRes.count !== null) setMyResponses(myRespRes.count)
    if (commRespRes.count !== null) setCommResponses(commRespRes.count)

    // v9.55 — Resolve author display_names for the reflection preview cards.
    // Done as a follow-up query (not embedded in the Promise.all) so we don't
    // pay the latency unless reflections actually exist.
    if (refRes.data && refRes.data.length > 0) {
      const authorIds = [...new Set(refRes.data.map(p => p.author_id).filter(Boolean))]
      const { data: authors } = await supabase.from('members').select('id, display_name').in('id', authorIds)
      const authorMap = {}
      authors?.forEach(a => { authorMap[a.id] = a })
      setLatestReflections(refRes.data.map(r => ({ ...r, author: authorMap[r.author_id] })))
    }

    // Day-scoped data (content + actions) loads via loadDayData so the same
    // path is re-used by prev/next/today navigation handlers.
    await loadDayData(m, tn)
  }

  // 9.32 — fetches day_content and daily_actions for a given day number.
  // Used by init() and by the prev/next/today navigation handlers.
  async function loadDayData(memberObj, dn) {
    setNavLoading(true)
    const [dcRes, daRes] = await Promise.all([
      supabase.from('day_content').select('*').eq('day_number', dn).single(),
      supabase.from('daily_actions').select('*').eq('member_id', memberObj.id).eq('day_number', dn),
    ])
    if (dcRes.data) setDayContent(dcRes.data)
    else setDayContent(null)
    if (daRes.data) {
      const a = {}
      daRes.data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    } else {
      setActions({})
    }
    setNavLoading(false)
  }

  // 9.32 — Day navigation handlers. Forward is capped at todayNum
  // (recovery-aligned: a day at a time, look at your feet — no previewing
  // future days). Backward is capped at Day 1.
  function goPrevDay() {
    if (!member || dayNum <= 1 || navLoading) return
    const next = dayNum - 1
    setDayNum(next)
    loadDayData(member, next)
  }
  function goNextDay() {
    if (!member || dayNum >= todayNum || navLoading) return
    const next = dayNum + 1
    setDayNum(next)
    loadDayData(member, next)
  }
  function goToday() {
    if (!member || dayNum === todayNum || navLoading) return
    setDayNum(todayNum)
    loadDayData(member, todayNum)
  }

  async function save(section, itemKey, itemType, value) {
    if (!member) return
    const k = `${section}::${itemKey}`
    setSaving(p => ({ ...p, [k]: true }))
    const isCompleted = itemType === 'checkbox' ? value : !!value?.trim()
    const row = {
      member_id: member.id, day_number: dayNum,
      section, item_key: itemKey, item_type: itemType,
      is_checked: itemType === 'checkbox' ? value : false,
      text_value: itemType === 'text' ? value : null,
      is_completed: isCompleted,
      completed_at: isCompleted ? new Date().toISOString() : null,
      updated_at: new Date().toISOString()
    }
    await supabase.from('daily_actions').upsert(row, { onConflict: 'member_id,day_number,section,item_key' })
    setActions(p => ({ ...p, [k]: row }))
    setSaving(p => ({ ...p, [k]: false }))
    // Refresh response count if text was saved
    if (itemType === 'text') {
      const { count } = await supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('member_id', member.id).eq('item_type', 'text').not('text_value', 'is', null)
      if (count !== null) setMyResponses(count)
    }
  }

  async function reloadActions() {
    if (!member) return
    const { data } = await supabase.from('daily_actions').select('*').eq('member_id', member.id).eq('day_number', dayNum)
    if (data) {
      const a = {}
      data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    }
  }

  const isChecked = (s, k) => !!actions[`${s}::${k}`]?.is_checked
  const textVal   = (s, k) => actions[`${s}::${k}`]?.text_value || ''
  const isSaving  = (s, k) => !!saving[`${s}::${k}`]

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const name = member?.display_name || user.email.split('@')[0]
  const dateStr = new Date().toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric', year:'numeric' })

  if (practice) return (
    <PracticeView period={practice} dayNum={dayNum} dayContent={dayContent}
      memberId={member?.id}
      isChecked={isChecked} textVal={textVal} isSaving={isSaving} save={save}
      actions={actions} onBack={() => setPractice(null)}
      onSwitchPeriod={(p) => setPractice(p)}
      reloadActions={reloadActions} />
  )

  return (
    <div style={{ paddingTop: 20 }}>

      {/* Day 1 Welcome — shows for first 24 hours only — 9.32: only when actually on Day 1 (not when navigating back). */}
      {dayNum === 1 && todayNum === 1 && (
        <div style={{ background: 'linear-gradient(135deg, #01280e, #01380e)', border: '1px solid #19e55e', borderRadius: 12, padding: 24, marginBottom: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🪄</div>
          <h2 style={{ color: 'var(--pink)', fontSize: 20, fontWeight: 700, marginBottom: 8, fontFamily: 'var(--font-ui)' }}>Welcome. This is your Day 1 here.</h2>
          <p style={{ color: 'var(--cream)', fontSize: 15, lineHeight: 1.6, marginBottom: 12, fontFamily: 'var(--font-ui)' }}>That took courage. You showed up. Now let's do the work.</p>
          <p style={{ color: 'var(--lime)', fontSize: 14, fontFamily: 'var(--font-ui)' }}>Start with your Morning Practice below ↓</p>
        </div>
      )}

      <div style={{ marginBottom: 24 }}>
        {/* Greeting + cheers inbox row */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12, marginBottom: 4 }}>
          <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)' }}>{greeting}, {name}</p>
          {/* v9.46-followup Item 7 — heart bell renders only when cheers received today */}
          <CheersInbox member={member} />
        </div>
        {member && (
          <div style={{ marginBottom: 8 }}>
            <MemberBadges member={member} size="md"/>
          </div>
        )}
        {/* v9.49 / Phase 4 Item 11B — pulsating meeting card. Renders only
            when a member's home group meeting is starting within 90 minutes
            or started within the last 60 minutes (in their timezone). Pure
            client-side computation against member_home_groups. Silently
            absent when nothing's happening today.

            v9.49.1: When member has at least one home group set up but none
            match today's day-of-week, renders a softer empty-state card
            offering the Daily YRTCYK Group + Calendar tab. Brand-new members
            (zero home groups) still see nothing — Profile setup is their
            real next step, not a Dashboard nudge. */}
        {member && (
          <MeetingCard
            memberId={member.id}
            memberTz={member.timezone}
            onOpenCalendar={setView ? () => setView('calendar') : null}
          />
        )}
        {/* 9.32 — Day navigation row. Backward to Day 1, forward capped at today
            (recovery-aligned: a day at a time, look at your feet). */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginTop: 8 }}>
          <button
            onClick={goPrevDay}
            disabled={dayNum <= 1 || navLoading}
            aria-label="Previous day"
            style={{
              background: 'transparent',
              border: '1px solid ' + (dayNum <= 1 ? 'rgba(251,250,244,.1)' : 'rgba(255,20,147,.4)'),
              color: dayNum <= 1 ? 'rgba(251,250,244,.2)' : 'var(--pink)',
              width: 44, height: 44, minWidth: 44,
              borderRadius: 22,
              fontSize: 20,
              fontWeight: 600,
              cursor: dayNum <= 1 ? 'default' : 'pointer',
              fontFamily: 'var(--font-ui)',
              padding: 0,
              flexShrink: 0,
              opacity: navLoading ? 0.5 : 1,
              transition: 'opacity .2s ease'
            }}>
            ←
          </button>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 42, fontWeight: 700, color: 'var(--pink)', fontFamily: 'var(--font-ui)', lineHeight: 1 }}>
              Day {dayNum}
            </div>
            <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginTop: 4 }}>
              {dayNum === todayNum ? (
                <>Today · {dateStr}</>
              ) : (
                <>
                  {(todayNum - dayNum) === 1 ? 'Yesterday' : `${todayNum - dayNum} days ago`}
                  {' · '}
                  <button onClick={goToday} disabled={navLoading} style={{
                    background: 'none',
                    border: 'none',
                    color: 'var(--lime)',
                    cursor: 'pointer',
                    padding: 0,
                    fontFamily: 'var(--font-ui)',
                    fontSize: 13,
                    textDecoration: 'underline',
                    textUnderlineOffset: 2
                  }}>
                    ← Back to Today
                  </button>
                </>
              )}
            </p>
          </div>
          <button
            onClick={goNextDay}
            disabled={dayNum >= todayNum || navLoading}
            aria-label="Next day"
            style={{
              background: 'transparent',
              border: '1px solid ' + (dayNum >= todayNum ? 'rgba(251,250,244,.1)' : 'rgba(255,20,147,.4)'),
              color: dayNum >= todayNum ? 'rgba(251,250,244,.2)' : 'var(--pink)',
              width: 44, height: 44, minWidth: 44,
              borderRadius: 22,
              fontSize: 20,
              fontWeight: 600,
              cursor: dayNum >= todayNum ? 'default' : 'pointer',
              fontFamily: 'var(--font-ui)',
              padding: 0,
              flexShrink: 0,
              opacity: navLoading ? 0.5 : 1,
              transition: 'opacity .2s ease'
            }}>
            →
          </button>
        </div>
      </div>

      {dayContent && (
        <div className="card" style={{ marginBottom: 20, background: 'rgba(255,20,147,.04)', border: '1px solid rgba(255,20,147,.1)' }}>
          <p className="section-label" style={{ marginBottom: 8 }}>
            Day {dayNum}{dayNum === todayNum ? ' — Today' : ''}
          </p>
          <h3 style={{ fontSize: 18, fontWeight: 400, marginBottom: 6 }}>{dayContent.title}</h3>
          {dayContent.spiritual_principle && <p style={{ fontSize: 12, color: 'var(--pink)', fontFamily: 'var(--font-ui)', letterSpacing: .5 }}>{dayContent.spiritual_principle}</p>}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
        <button onClick={() => setPractice('morning')} style={{ background: 'rgba(255,20,147,.08)', border: '1px solid rgba(255,20,147,.2)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌅</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--pink)', fontSize: 14, marginBottom: 2 }}>Morning Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Upon awakening</div>
        </button>
        <button onClick={() => setPractice('evening')} style={{ background: 'rgba(25,229,94,.06)', border: '1px solid rgba(25,229,94,.15)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌙</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--lime)', fontSize: 14, marginBottom: 2 }}>Evening Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Before sleep</div>
        </button>
      </div>

      <p className="section-label">My Progress</p>
      <div className="kpi-grid" style={{ marginBottom: 28 }}>
        {[
          { val:`${Math.round(myStats.today_pct||0)}%`,   label:'Today' },
          { val:`${Math.round(myStats.monthly_pct||0)}%`,   label:'This Month' },
          { val:`${Math.round(myStats.overall_pct||0)}%`, label:'Overall' },
          { val:`${myStats.days_active||0}/365`,           label:'Days Active' },
          { val: myResponses,                              label:'Responses Saved', green: true },
        ].map(s => <div key={s.label} className="kpi-cell"><div className={`kpi-value${s.green?' green':''}`}>{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>

      <p className="section-label">Our Community</p>
      <div className="kpi-grid" style={{ marginBottom: 8 }}>
        {[
          { val:kpi.total_members||0,                               label:'Members' },
          { val:`${Math.round(kpi.community_completion_pct||0)}%`,  label:'Avg Completion' },
          { val:kpi.active_today||0,                                label:'Active Today' },
          { val:kpi.total_days_completed||0,                        label:'Days Completed' },
          { val: commResponses,                                     label:'Responses Saved', green: true },
        ].map(s => <div key={s.label} className="kpi-cell"><div className={`kpi-value green`}>{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>
      <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.3)', fontStyle:'italic', marginBottom:28 }}>The company you keep is showing up. 🌈</p>

      {/* v9.55 — Latest Reflections preview on landing page.
          Two most-recent approved blog_posts in a forced 2-column grid
          (per Geo's "TWO side by side" spec — narrows tighten on iPhone
          but never break to 1-col, since the side-by-side relationship
          IS the design intent). Each card is tappable → opens Reflections.
          Title with 2-line clamp; body preview with 3-line clamp. */}
      {latestReflections.length > 0 && (
        <div style={{ marginBottom:28 }}>
          <p className="section-label">📓 Latest Reflections</p>
          <div style={{
            display:'grid',
            gridTemplateColumns:'repeat(2, 1fr)',
            gap:10,
          }}>
            {latestReflections.map(r => {
              const preview = (r.body || '').replace(/\s+/g, ' ').trim().slice(0, 180)
              const authorName = r.author?.display_name || 'Member'
              const dateStr = new Date(r.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric' })
              return (
                <button
                  key={r.id}
                  onClick={() => setView && setView('blog')}
                  style={{
                    textAlign:'left',
                    cursor:'pointer',
                    background:'rgba(255,20,147,.05)',
                    border:'1px solid rgba(255,20,147,.18)',
                    borderRadius:12,
                    padding:'14px 14px',
                    display:'flex',
                    flexDirection:'column',
                    gap:8,
                    fontFamily:'inherit',
                    color:'inherit',
                    minHeight:140,
                    transition:'background .15s, border-color .15s',
                  }}>
                  <p style={{
                    fontSize:13,
                    fontWeight:700,
                    color:'var(--pink)',
                    fontFamily:'Georgia, serif',
                    lineHeight:1.3,
                    overflow:'hidden',
                    textOverflow:'ellipsis',
                    display:'-webkit-box',
                    WebkitLineClamp:2,
                    WebkitBoxOrient:'vertical',
                  }}>{r.title}</p>
                  <p style={{
                    fontSize:11,
                    color:'rgba(251,250,244,.65)',
                    lineHeight:1.5,
                    flex:1,
                    overflow:'hidden',
                    textOverflow:'ellipsis',
                    display:'-webkit-box',
                    WebkitLineClamp:3,
                    WebkitBoxOrient:'vertical',
                    fontFamily:'var(--font-ui)',
                  }}>{preview}…</p>
                  <div style={{
                    display:'flex',
                    justifyContent:'space-between',
                    alignItems:'baseline',
                    fontSize:10,
                    color:'rgba(251,250,244,.4)',
                    fontFamily:'var(--font-ui)',
                    gap:6,
                  }}>
                    <span style={{ overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', minWidth:0 }}>— {authorName} · {dateStr}</span>
                    <span style={{ color:'var(--pink)', flexShrink:0 }}>Read →</span>
                  </div>
                </button>
              )
            })}
          </div>
          <div style={{ textAlign:'right', marginTop:8 }}>
            <button
              onClick={() => setView && setView('blog')}
              style={{
                background:'none',
                border:'none',
                color:'var(--lime)',
                cursor:'pointer',
                fontSize:11,
                fontFamily:'var(--font-ui)',
                padding:0,
                letterSpacing:.5,
              }}>
              See all reflections →
            </button>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div style={{ borderTop:'1px solid rgba(255,255,255,.06)', paddingTop:20, marginBottom:8 }}>
        <p style={{ fontSize:11, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)', lineHeight:1.7, textAlign:'center' }}>
          YRTCYK — You aRe The Company You Keep — has always been associated exclusively with Your Fairy Godfather and GPV Consulting, LLC. In the spirit of AA&apos;s Tradition Six, we are not affiliated with, endorsed by, or representative of Alcoholics Anonymous or any AA group. The 12 Steps and 12 Traditions belong to AA World Services, Inc. We practice them with gratitude and respect their integrity.
        </p>
      </div>

      {/* v9.20: Brand lockup centered below disclaimer */}
      <div style={{ textAlign:'center', paddingTop:32, paddingBottom:20 }}>
        <img src="/yrtcyk_triangle.png" alt="YRTCYK — Unity, Service, Recovery, Pride"
          style={{ width:180, height:'auto', display:'inline-block', marginBottom:16 }}/>
        <div style={{ fontSize:20, fontWeight:700, color:'var(--pink)', fontFamily:'Georgia, serif', letterSpacing:1, marginBottom:4 }}>
          Your Fairy Godfather
        </div>
        <div style={{ fontSize:12, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1.5 }}>
          <span style={{ color:'var(--pink)', fontWeight:700 }}>Y</span>ou <span style={{ color:'var(--pink)', fontWeight:700 }}>aR</span>e <span style={{ color:'var(--pink)', fontWeight:700 }}>T</span>he <span style={{ color:'var(--pink)', fontWeight:700 }}>C</span>ompany <span style={{ color:'var(--pink)', fontWeight:700 }}>Y</span>ou <span style={{ color:'var(--pink)', fontWeight:700 }}>K</span>eep
        </div>
      </div>
    </div>
  )
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function SectionBlock({
  emoji,
  title,
  children,
  // Audio props (optional). When audioContentType is set, the block renders
  // an AudioPlayer in place of the static title row.
  audioContentType,
  audioContentId,
  audioBehaviorClass,
  audioBookendVariant,
  audioBookendSubtitle,
  audioDayNumber,
  onAudioComplete,
  // 9.33 — Play All forwarding props. SectionBlock just passes these through
  // to the inner AudioPlayer; PracticeView owns the orchestration logic.
  playAllMode = 'idle',
  playAllAutoStartKey = 0,
  playIntroFirst = false,
  introContentId,
  onPlayAllAdvance,
  onUserClose,
  scrollRef                  // 9.33 — ref callback so PracticeView can scrollIntoView
                             //   this section when it becomes the active Play All cursor
}) {
  // 8c — Class B sections lift state (textarea ref, pulse key, player ref,
  // reflection-input flag, auto-mic key) and provide SectionAudioContext
  // for sibling NotesBox + CheckRow. Hooks declared unconditionally to keep
  // React's hook order stable; they no-op for non-Class-B sections.
  const [pulseKey, setPulseKey] = useState(0)
  const [autoMicKey, setAutoMicKey] = useState(0)  // 8c v9.30 — increments to trigger one-shot auto-mic in NotesBox
  const [isReflectionInput, setIsReflectionInput] = useState(false)
  const textareaRef = useRef(null)
  const audioPlayerRef = useRef(null)
  const isClassBAudio = audioContentType && audioBehaviorClass === 'B'

  const audioCtxValue = useMemo(() => ({
    textareaRef,
    pulseKey,
    autoMicKey,
    isReflectionInput,
    notifySaveTap: (content) => {
      // Lower the input flag right when user taps Save — chain is leaving
      // REFLECTION_INPUT and we don't want a stale glow during Brian's
      // acknowledgment / close-prompt audio.
      setIsReflectionInput(false)
      if (audioPlayerRef.current && audioPlayerRef.current.notifySaveTap) {
        audioPlayerRef.current.notifySaveTap(content)
      }
    }
  }), [pulseKey, autoMicKey, isReflectionInput])

  if (isClassBAudio) {
    return (
      <SectionAudioContext.Provider value={audioCtxValue}>
        <div ref={scrollRef} style={{ marginBottom: 20 }}>
          <AudioPlayer
            ref={audioPlayerRef}
            contentType={audioContentType}
            contentId={audioContentId}
            behaviorClass="B"
            emoji={emoji}
            title={title}
            dayNumber={audioDayNumber}
            bookendVariant={audioBookendVariant}
            bookendSubtitle={audioBookendSubtitle}
            onComplete={() => {
              setIsReflectionInput(false)
              if (onAudioComplete) onAudioComplete()
            }}
            onWantsReflectionFocus={() => {
              setIsReflectionInput(true)
              // Auto-scroll the NOTES textarea into view. iOS Safari respects
              // smooth scroll-into-view from non-gesture contexts even though
              // it refuses to raise the keyboard. The .focus() call below
              // sets the cursor; the visible textarea + glow + mic button +
              // pink prompt give the member every cue they need.
              if (textareaRef.current) {
                textareaRef.current.focus()
                // Defer the scroll one tick so any layout shifts (glow border
                // adding to height, etc.) settle before we measure.
                setTimeout(() => {
                  if (textareaRef.current && textareaRef.current.scrollIntoView) {
                    textareaRef.current.scrollIntoView({
                      behavior: 'smooth',
                      block: 'center'
                    })
                  }
                }, 50)
              }
            }}
            onWantsCheckboxPulse={() => {
              setIsReflectionInput(false)  // safety net
              setPulseKey(k => k + 1)
            }}
            onWantsAutoMicStart={() => setAutoMicKey(k => k + 1)}
            playAllMode={playAllMode}
            playAllAutoStartKey={playAllAutoStartKey}
            playIntroFirst={playIntroFirst}
            introContentId={introContentId}
            onPlayAllAdvance={onPlayAllAdvance}
            onUserClose={onUserClose}
          />
          {children}
        </div>
      </SectionAudioContext.Provider>
    )
  }

  if (audioContentType) {
    // Class A / C / D / E — audio without the chain. No context needed.
    return (
      <div ref={scrollRef} style={{ marginBottom: 20 }}>
        <AudioPlayer
          contentType={audioContentType}
          contentId={audioContentId}
          behaviorClass={audioBehaviorClass || 'A'}
          emoji={emoji}
          title={title}
          dayNumber={audioDayNumber}
          bookendVariant={audioBookendVariant}
          bookendSubtitle={audioBookendSubtitle}
          onComplete={onAudioComplete}
          playAllMode={playAllMode}
          playAllAutoStartKey={playAllAutoStartKey}
          playIntroFirst={playIntroFirst}
          introContentId={introContentId}
          onPlayAllAdvance={onPlayAllAdvance}
          onUserClose={onUserClose}
        />
        {children}
      </div>
    )
  }
  return (
    <div ref={scrollRef} style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,.06)' }}>
        <span style={{ fontSize: 18 }}>{emoji}</span>
        <h2 style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.85)' }}>{title}</h2>
      </div>
      {children}
    </div>
  )
}

function RichText({ text }) {
  if (!text) return null
  const cleaned = text
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*\*/g, '')
    .replace(/\\\s*\n/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/\\/g, '')
    .trim()
  const lines = cleaned.split('\n')
  return (
    <div style={{ fontSize: 14, lineHeight: 1.85, color: 'rgba(251,250,244,.78)' }}>
      {lines.map((line, i) => {
        const t = line.trim()
        if (!t) return <div key={i} style={{ height: 6 }}/>
        if (t.startsWith('•') || t.startsWith('- ') || t.startsWith('* ')) {
          return <div key={i} style={{ paddingLeft: 16, marginBottom: 4 }}>{t.replace(/^[-•*]\s+/, '')}</div>
        }
        return <p key={i} style={{ marginBottom: 6 }}>{t}</p>
      })}
    </div>
  )
}

// Single Notes text box — used for sections 4, 5, 6, 11, 12, 13, 14
// 8c v9.28: when rendered inside a Class B SectionBlock, the textarea ref binds
// to SectionAudioContext so the player can focus() it on REFLECTION_INPUT,
// and Save taps dispatch into the player chain via notifySaveTap.
// 8c v9.29: adds the 🎤 microphone button per spec v1.2 §6 Class B (Web Speech
// API transcription); pink glow + prominent pink prompt header during
// REFLECTION_INPUT; permission/error fallback degrades to type-only mode.
function NotesBox({ section, itemKey, value, onSave, saving }) {
  const [local, setLocal] = useState(value)
  useEffect(() => setLocal(value), [value])
  const audioCtx = useContext(SectionAudioContext)

  // 8c v9.29 — mic state. Only relevant when audioCtx is present (Class B).
  const [micState, setMicState] = useState('idle')  // 'idle' | 'listening' | 'denied' | 'unsupported'
  const [interimText, setInterimText] = useState('')
  const recognizerRef = useRef(null)
  const localRef = useRef(local)
  useEffect(() => { localRef.current = local }, [local])

  // 8c v9.31 — silence detection refs.
  // SILENCE_TIMEOUT_MS = 2500 — after first speech, 2.5 sec of no new
  // transcripts auto-stops the mic and advances the chain (same path as
  // a manual tap-to-stop or a Save tap with content).
  const SILENCE_TIMEOUT_MS = 2500
  const silenceTimerRef = useRef(null)
  const lastResultAtRef = useRef(0)
  // handleSaveRef holds a stable reference to the latest handleSave closure
  // so the silence timer (long-lived setInterval) can call it without
  // stale-closure surprises around `local` / `audioCtx` / `onSave`.
  const handleSaveRef = useRef(null)

  function clearSilenceTimer() {
    if (silenceTimerRef.current) {
      clearInterval(silenceTimerRef.current)
      silenceTimerRef.current = null
    }
  }

  // Stop the recognizer if the section advances out of REFLECTION_INPUT
  // (Save tap, × close, etc.). Without this, an open mic would keep
  // listening and burn battery / capture audio after the chain moves on.
  useEffect(() => {
    if (audioCtx && !audioCtx.isReflectionInput && recognizerRef.current) {
      try { recognizerRef.current.stop() } catch {}
      recognizerRef.current = null
      clearSilenceTimer()
      setMicState('idle')
      setInterimText('')
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [audioCtx?.isReflectionInput])

  // 8c v9.30 — auto-start the mic when the player signals "spoken yes" via
  // SectionBlock's incremented autoMicKey. We watch the key value (not just
  // its truthiness) so subsequent increments would re-trigger if the chain
  // ever loops within the same section instance. Idempotent guards: only
  // start if mic is currently idle and the recognizer can be created. If
  // iOS rejects (e.g., gesture requirement, permission revoked), the
  // recognizer's onError handler falls us back to 'idle' or 'denied' and
  // the manual button continues to work.
  const autoMicKey = audioCtx?.autoMicKey ?? 0
  useEffect(() => {
    if (autoMicKey === 0) return  // initial mount — never auto-start
    if (!audioCtx || !audioCtx.isReflectionInput) return  // not in reflection state
    if (micState !== 'idle') return  // already listening / denied / unsupported
    handleMicTap()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoMicKey])

  function handleSave() {
    clearSilenceTimer()
    // Stop the mic if it's active — Save commits the typed/spoken content.
    if (recognizerRef.current) {
      try { recognizerRef.current.stop() } catch {}
      recognizerRef.current = null
      setMicState('idle')
      setInterimText('')
    }
    const content = localRef.current
    onSave(section, itemKey, 'text', content)
    if (audioCtx && audioCtx.notifySaveTap) audioCtx.notifySaveTap(content)
  }
  // Keep handleSaveRef pointed at the latest closure so the silence timer
  // (a long-lived setInterval) can fire it without stale-closure issues.
  handleSaveRef.current = handleSave

  function handleMicTap() {
    if (micState === 'listening') {
      // 8c v9.31 — tap-to-stop now advances the chain (same as Save tap).
      // Member's mental model: "Listening — tap to stop" means "I'm done."
      // Calling handleSave stops the recognizer, clears the silence timer,
      // commits content, and notifies the player to advance.
      handleSave()
      return
    }
    if (!isSpeechRecognitionSupported()) {
      setMicState('unsupported')
      return
    }
    const recognizer = createReflectionRecognizer({
      onInterim: (text) => {
        // 8c v9.31 — track timestamp for silence detection. Start the
        // silence timer the first time results arrive so the auto-stop
        // window doesn't begin while the member is still gathering thoughts.
        lastResultAtRef.current = Date.now()
        if (!silenceTimerRef.current) {
          silenceTimerRef.current = setInterval(() => {
            if (Date.now() - lastResultAtRef.current > SILENCE_TIMEOUT_MS) {
              if (handleSaveRef.current) handleSaveRef.current()
            }
          }, 500)
        }
        setInterimText(text)
      },
      onFinal: (text) => {
        lastResultAtRef.current = Date.now()
        // Append finalized chunk to the textarea content. localRef avoids
        // racing with React state — recognizer fires onFinal repeatedly
        // and we always want to append to the latest value.
        const current = localRef.current || ''
        const sep = current.length > 0 && !current.endsWith(' ') ? ' ' : ''
        const next = (current + sep + text.trim()).trim()
        setLocal(next)
        localRef.current = next
        setInterimText('')
      },
      onError: (err) => {
        const errCode = err && (err.error || err.message || '')
        console.warn('[NotesBox] reflection recognizer error:', errCode)
        clearSilenceTimer()
        if (String(errCode).includes('not-allowed') || String(errCode).includes('permission')) {
          setMicState('denied')
        } else {
          setMicState('idle')
        }
        recognizerRef.current = null
        setInterimText('')
      },
      onEnd: () => {
        // Recognizer ended (timeout, manual stop, or natural pause).
        // If still in 'listening' state UI-wise, drop back to idle so the
        // button reads "Tap to Speak" again.
        clearSilenceTimer()
        setMicState(prev => prev === 'listening' ? 'idle' : prev)
      }
    })
    if (!recognizer) {
      setMicState('unsupported')
      return
    }
    recognizerRef.current = recognizer
    lastResultAtRef.current = Date.now()  // reset baseline
    setMicState('listening')
    recognizer.start()
  }

  const inReflectionInput = !!(audioCtx && audioCtx.isReflectionInput)
  const showMic = !!audioCtx  // mic button only renders inside Class B context

  const textareaStyle = {
    resize: 'vertical',
    marginBottom: 8,
    transition: 'box-shadow .25s ease, border-color .25s ease'
  }
  if (inReflectionInput) {
    textareaStyle.boxShadow = '0 0 0 2px var(--pink), 0 0 18px rgba(255,20,147,0.45)'
    textareaStyle.borderColor = 'var(--pink)'
  }

  return (
    <div style={{ marginTop: 12 }}>
      {inReflectionInput && (
        <p className="reflection-prompt" style={{
          fontSize: 14, fontWeight: 600,
          color: 'var(--pink)',
          fontFamily: 'var(--font-ui)',
          margin: '0 0 8px 0'
        }}>
          ✨ Your turn — speak your reflection or type below, then tap Save
        </p>
      )}
      <p style={{
        fontSize: 11,
        color: inReflectionInput ? 'var(--pink)' : 'rgba(251,250,244,.35)',
        fontFamily: 'var(--font-ui)',
        letterSpacing: 1,
        marginBottom: 6
      }}>REFLECTION</p>
      <textarea
        ref={audioCtx ? audioCtx.textareaRef : null}
        rows={3} value={local + (interimText ? ' ' + interimText : '')}
        onChange={e => {
          // When mic is active, ignore typed input changes that would erase
          // interim text. When mic is idle, normal editing behavior.
          if (micState === 'listening') {
            // Only honor edits that don't shrink past the current local + interim
            const newVal = e.target.value
            // Strip any trailing interim suffix the user might be trying to keep
            const interimSuffix = interimText ? ' ' + interimText : ''
            if (newVal.endsWith(interimSuffix)) {
              setLocal(newVal.slice(0, newVal.length - interimSuffix.length))
            } else {
              // User edited the body — accept directly, drop the interim
              setLocal(newVal)
              setInterimText('')
            }
          } else {
            setLocal(e.target.value)
          }
        }}
        style={textareaStyle}
        placeholder="Write your response here…"/>
      {showMic && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 10 }}>
          <button
            type="button"
            onClick={handleMicTap}
            disabled={micState === 'unsupported' || micState === 'denied'}
            style={{
              fontSize: 13,
              padding: '10px 14px',
              background: micState === 'listening' ? 'var(--pink)' : 'transparent',
              color: micState === 'listening' ? '#fff' : 'var(--pink)',
              border: '1px solid var(--pink)',
              borderRadius: 6,
              cursor: (micState === 'unsupported' || micState === 'denied') ? 'default' : 'pointer',
              fontFamily: 'var(--font-ui)',
              fontWeight: 500,
              opacity: (micState === 'unsupported' || micState === 'denied') ? 0.5 : 1,
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8
            }}>
            {micState === 'listening' && (
              <span className="gate-listening-dot" style={{
                width: 8, height: 8, borderRadius: '50%',
                background: '#fff',
                animation: 'gateListeningPulse 1.2s ease-in-out infinite'
              }} />
            )}
            {micState === 'listening'
              ? 'Listening… tap to stop'
              : micState === 'denied'
                ? '🎤 Microphone access denied — type instead'
                : micState === 'unsupported'
                  ? '🎤 Voice input not available — type instead'
                  : '🎤 Tap to Speak Your Reflection'}
          </button>
          {micState === 'denied' && (
            <p style={{ fontSize: 11, color: 'rgba(251,250,244,.5)', fontFamily: 'var(--font-ui)', margin: 0 }}>
              To re-enable: iOS Settings → Safari → Microphone → Allow.
            </p>
          )}
        </div>
      )}
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="btn-primary" style={{
          fontSize: 13,
          padding: '8px 16px',
          fontWeight: inReflectionInput ? 600 : 500
        }}
          onClick={handleSave} disabled={saving}>
          {saving ? 'Saving…' : value ? 'Update' : 'Save'}
        </button>
        {value && <span style={{ fontSize: 11, color: 'var(--lime)', fontFamily: 'var(--font-ui)' }}>✓ Saved</span>}
      </div>
    </div>
  )
}

function CheckRow({ label, section, itemKey, checked, onSave, saving }) {
  // 8c — when inside a Class B SectionBlock, pulseKey increments each time
  // the player enters CHECKBOX_PULSING. Using it as a React `key` on the
  // <label> forces a remount so the @keyframes pulseCheckbox animation
  // restarts cleanly on every chain completion. Outside Class B, pulseKey
  // stays 0 and no animation runs.
  const audioCtx = useContext(SectionAudioContext)
  const pulseKey = audioCtx ? audioCtx.pulseKey : 0
  const pulseStyle = pulseKey > 0
    ? { animation: 'pulseCheckbox 2s ease-in-out 1' }
    : undefined
  return (
    <div className="card" style={{ marginBottom: 10, marginTop: 10 }}>
      <label key={`pulse-${pulseKey}`} className="check-row" style={pulseStyle}>
        <input type="checkbox" checked={checked}
          onChange={e => onSave(section, itemKey, 'checkbox', e.target.checked)}
          style={{ width: 18, height: 18, accentColor: 'var(--pink)', flexShrink: 0 }} />
        <span className={`check-label${checked ? ' done' : ''}`}>{label}</span>
        {saving && <span style={{ fontSize: 11, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginLeft: 'auto' }}>…</span>}
      </label>
    </div>
  )
}

// ─── Practice View ────────────────────────────────────────────────────────────

// 9.33 — Maps each Class B section's audio content_type to its checkbox row.
// Used by Play All "guided" mode to auto-complete the checkbox after the
// chain finishes. Sections without a checkbox (header, sources, bookend) are
// absent from this map.
const SECTION_CHECK_MAP = {
  'section_1':  ['pattern',          'completed'],
  'section_2':  ['opposite_action',  'completed'],
  'section_3':  ['prayer',           'completed'],
  'section_4':  ['act_of_service',   'completed'],
  'section_5':  ['bonus_challenge',  'completed'],
  'section_6':  ['morning_practice', 'completed'],
  'section_7':  ['grounding',        'breathing'],
  'section_8':  ['grounding',        'grounding'],
  'section_9':  ['affirmation',      'spoken'],
  'section_10': ['meditation',       'completed'],
  'section_11': ['evening_practice', 'completed'],
  'section_12': ['step10',           'completed'],
  'section_13': ['visualization',    'completed'],
  'section_14': ['gratitude',        'completed'],
}

// 9.33 — sections that have a section_intro audio rendered (Path A locked
// v1.1-FINAL). Sections 11 (evening_practice) and 12 (step10) are absent
// because their titles are already spoken in the body audio.
const SECTIONS_WITH_INTRO = new Set([
  'section_1', 'section_2', 'section_3', 'section_4', 'section_5',
  'section_6', 'section_7', 'section_8', 'section_9', 'section_10',
  'section_13', 'section_14'
])

function PracticeView({ period, dayNum, dayContent: dc, memberId, isChecked, textVal, isSaving, save, actions, onBack, onSwitchPeriod, reloadActions }) {
  const isMorning = period === 'morning'

  useEffect(() => { reloadActions() }, [])

  // Scoring — checkboxes only
  const dailyKeys  = [['pattern','completed'],['opposite_action','completed'],['prayer','completed'],['act_of_service','completed'],['bonus_challenge','completed']]
  const morningKeys = [['morning_practice','completed'],['grounding','breathing'],['grounding','grounding'],['affirmation','spoken'],['meditation','completed']]
  const eveningKeys = [['evening_practice','completed'],['step10','completed'],['visualization','completed'],['gratitude','completed']]

  const checkKeys = isMorning ? [...dailyKeys, ...morningKeys] : eveningKeys
  const totalItems = checkKeys.length
  const doneItems  = checkKeys.filter(([s,k]) => isChecked(s,k)).length
  const pct = totalItems > 0 ? Math.round(doneItems / totalItems * 100) : 0

  // Engagement: count saved text responses for today
  const commentsToday = Object.values(actions).filter(a => a.item_type === 'text' && a.text_value?.trim()).length

  // 9.33 — Play All state and orchestration. Two modes:
  //   'guided' (🪄 Practice with Your Fairy Godfather) — full Class B chain
  //     per section + auto-complete checkbox + auto-advance. Immersive.
  //   'listen' (▶ Play All Audio) — body-only listen-through. Plays
  //     section_intro + body for each section, no chain, no completions.
  //
  // activeSequence is the ordered list of audio surfaces to play. Cursor
  // advances when the active player fires onPlayAllAdvance. Each surface's
  // computed playAllAutoStartKey bumps when it becomes active, triggering
  // the player to auto-start.
  const [playAllMode, setPlayAllMode] = useState('idle')        // 'idle' | 'guided' | 'listen'
  const [playAllCursor, setPlayAllCursor] = useState(0)
  const scrollRefs = useRef({})  // map of content_type → DOM node, for smooth-scroll on cursor change

  const activeSequence = useMemo(() => {
    if (!dc) return []
    const bookendKey = isMorning ? 'bookend_morning' : 'bookend_evening'
    const seq = [bookendKey, 'header']
    // Sources only appears if at least one source field is populated
    if (dc.source_big_book || dc.source_twelve_twelve || dc.source_drop_rock || dc.source_ripple_effect) {
      seq.push('sources')
    }
    // Daily sections (1-5) — only those with content rendered
    if (dc.pattern_detail)    seq.push('section_1')
    if (dc.opposite_action)   seq.push('section_2')
    // v9.51.2 — fix: column is `step7_prayer`, not `prayer`. JSX render gate
    // (line ~1198) uses dc.step7_prayer, so the playlist must match or the
    // user sees section_3 on screen but it never auto-plays in Play All —
    // cursor silently skips it, jumping section_2 → section_4.
    if (dc.step7_prayer)      seq.push('section_3')
    if (dc.act_of_service)    seq.push('section_4')
    if (dc.bonus_challenge)   seq.push('section_5')
    // Period-specific sections
    // v9.51.3 — section_6 and section_11 gates now match JSX content. The
    // `morning_practice` and `evening_practice` columns are empty for ALL
    // 365 days (audited via Supabase). The JSX SectionBlocks render
    // unconditionally and pull from morning_questions+morning_intention
    // (s6) and evening_questions (s11). The audio assets exist and
    // narrate exactly that on-screen content. v9.51.2 fixed s3 and s12
    // but left s6/s11 silently dropped from every day's playlist.
    if (isMorning) {
      if ((Array.isArray(dc.morning_questions) && dc.morning_questions.length > 0) || dc.morning_intention) {
        seq.push('section_6')
      }
      if (dc.breathing)        seq.push('section_7')
      if (dc.grounding)        seq.push('section_8')
      if (dc.affirmation)      seq.push('section_9')
      if (dc.meditation)       seq.push('section_10')
    } else {
      if (Array.isArray(dc.evening_questions) && dc.evening_questions.length > 0) {
        seq.push('section_11')
      }
      // v9.51.2 — fix: column is `step10_items` (jsonb array), not `step10`.
      // Inner JSX (line ~1335) gates on (dc.step10_items||[]).length > 0,
      // so the playlist must match. Without this, evening Play All silently
      // skips section_12 even when items are present.
      if (Array.isArray(dc.step10_items) && dc.step10_items.length > 0) seq.push('section_12')
      if (dc.visualization)    seq.push('section_13')
      if (dc.gratitude)        seq.push('section_14')
    }
    return seq
  }, [dc, isMorning])

  // Helper for inner JSX: returns autoStartKey for a given content_type
  // (0 unless this surface is the current cursor in an active Play All).
  // Multiplying by 1000 + playAllMode bit ensures the value is unique per
  // (mode, cursor) so re-entering with a different mode triggers re-start.
  function autoStartKeyFor(ct) {
    if (playAllMode === 'idle') return 0
    if (activeSequence[playAllCursor] !== ct) return 0
    const modeBit = playAllMode === 'guided' ? 1 : 2
    return (playAllCursor + 1) * 10 + modeBit
  }

  // 9.33 — auto-scroll the active section into view whenever the cursor
  // advances during Play All. Smooth scroll, centered. Solo-mode scrolling
  // (e.g., bookend onClassCEnded) is handled separately, in the bookend's
  // dedicated callback below.
  useEffect(() => {
    if (playAllMode === 'idle') return
    const currentKey = activeSequence[playAllCursor]
    if (!currentKey) return
    const node = scrollRefs.current[currentKey]
    if (node && node.scrollIntoView) {
      // 80 ms delay so the auto-start dispatch lands first; the scroll then
      // happens just as the LOADING_URL → AUDIO_PLAYING transition begins.
      setTimeout(() => {
        try {
          node.scrollIntoView({ behavior: 'smooth', block: 'center' })
        } catch {
          /* older browsers may not support ScrollIntoViewOptions object */
        }
      }, 80)
    }
  }, [playAllCursor, playAllMode, activeSequence])

  // 9.33 — fired by the active player when its segment is done. Auto-completes
  // the checkbox in BOTH guided AND listen modes (the "they engaged with the
  // content — give them credit" Geo-locked behavior — listening through is
  // engagement and earns the same scoring as guided practice). Then advances
  // cursor or exits if at end.
  function handlePlayAllAdvance() {
    const currentKey = activeSequence[playAllCursor]
    if (playAllMode !== 'idle' && currentKey && SECTION_CHECK_MAP[currentKey]) {
      const [section, itemKey] = SECTION_CHECK_MAP[currentKey]
      if (!isChecked(section, itemKey)) {
        save(section, itemKey, 'checkbox', true)
      }
    }
    const nextCursor = playAllCursor + 1
    if (nextCursor >= activeSequence.length) {
      // Sequence done — exit Play All mode. Scroll back to top so the member
      // sees the completion state of their full practice.
      setPlayAllMode('idle')
      setPlayAllCursor(0)
      try {
        window.scrollTo({ top: 0, behavior: 'smooth' })
      } catch { /* IE/Safari fallback ignored */ }
    } else {
      setPlayAllCursor(nextCursor)
    }
  }

  // 9.33 — fired by AudioPlayer's user-tap × close (NOT audio-ended close).
  // Treat as "exit Play All" gesture. The member said: I'm done with this
  // sequence, return me to manual control.
  function handleUserClose() {
    if (playAllMode !== 'idle') {
      setPlayAllMode('idle')
      setPlayAllCursor(0)
    }
  }

  // 9.33 — Bookend (Class C) audio ended in solo (non-Play-All) mode.
  // Smooth-scrolls to first content section per spec §12.4: morning →
  // Section 1, evening → Section 11. In Play All mode, this is suppressed
  // because the auto-scroll cursor effect handles section transitions.
  function handleBookendEnded() {
    if (playAllMode !== 'idle') return  // suppressed in Play All
    const targetKey = isMorning ? 'section_1' : 'section_11'
    const node = scrollRefs.current[targetKey]
    if (node && node.scrollIntoView) {
      setTimeout(() => {
        try { node.scrollIntoView({ behavior: 'smooth', block: 'start' }) } catch { /* */ }
      }, 200)  // brief beat after audio ends so the moment lands
    }
  }

  function setScrollRef(key) {
    return (el) => { if (el) scrollRefs.current[key] = el; else delete scrollRefs.current[key] }
  }

  // Helper to compute introContentId from a content_type like 'section_3'
  function introIdFor(ct) {
    return ct.startsWith('section_') ? ct.replace('section_', '') : null
  }

  return (
    <div style={{ paddingTop: 20, paddingBottom: 48 }}>
      <button onClick={onBack} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:20 }}>← Back</button>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>{isMorning ? '🌅 Morning Practice' : '🌙 Evening Practice'}</h2>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:22, fontWeight:700, fontFamily:'var(--font-ui)', color:pct===100?'var(--lime)':'var(--pink)' }}>{pct}%</div>
          <div style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>{doneItems}/{totalItems}</div>
        </div>
      </div>

      {/* Morning or Evening bookend — Class C player. v9.33: scrollRef +
          onClassCEnded for solo-mode auto-scroll to first content section,
          plus full Play All forwarding props. */}
      {dc && (
        <div ref={setScrollRef(isMorning ? 'bookend_morning' : 'bookend_evening')} style={{ marginBottom: 16 }}>
          <AudioPlayer
            contentType={isMorning ? 'bookend_morning' : 'bookend_evening'}
            contentId={String(dayNum)}
            behaviorClass="C"
            title={`Day ${dayNum} — ${isMorning ? 'Morning' : 'Evening'} Bookend`}
            bookendVariant={isMorning ? 'morning' : 'evening'}
            bookendSubtitle={isMorning ? 'Tap to begin today\u2019s practice' : 'Tap to begin evening practice'}
            dayNumber={dayNum}
            playAllMode={playAllMode}
            playAllAutoStartKey={autoStartKeyFor(isMorning ? 'bookend_morning' : 'bookend_evening')}
            onPlayAllAdvance={handlePlayAllAdvance}
            onUserClose={handleUserClose}
            onClassCEnded={handleBookendEnded}
          />
        </div>
      )}

      {/* 9.33 — Two Play All buttons replace the stub. Pink-filled primary is
          the immersive guided practice (chain + auto-completions), outlined
          secondary is the body-only listen-through. When Play All is active,
          a pink-bordered "Stop" button replaces both for clean exit. */}
      {dc && playAllMode === 'idle' && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10, marginBottom: 14 }}>
          <button
            onClick={() => { setPlayAllCursor(0); setPlayAllMode('guided') }}
            style={{
              width: '100%',
              background: 'var(--pink)',
              color: 'var(--cream)',
              border: 'none',
              borderRadius: 8,
              padding: '12px 16px',
              fontFamily: 'var(--font-ui)',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 2
            }}>
            <span style={{ fontSize: 16, fontWeight: 700 }}>🪄 Practice with Your Fairy Godfather</span>
            <span style={{ fontSize: 12, fontWeight: 400, opacity: 0.9, fontStyle: 'italic' }}>Guided · Spoken Reflections · The Real Work</span>
          </button>
          <button
            onClick={() => { setPlayAllCursor(0); setPlayAllMode('listen') }}
            style={{
              width: '100%',
              background: 'transparent',
              color: 'var(--pink)',
              border: '1px solid rgba(255,20,147,.5)',
              borderRadius: 8,
              padding: '10px 16px',
              fontFamily: 'var(--font-ui)',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: 2
            }}>
            <span style={{ fontSize: 15, fontWeight: 600 }}>▶ Play All Audio</span>
            <span style={{ fontSize: 12, fontWeight: 400, opacity: 0.75, fontStyle: 'italic' }}>Listen Now · Action Later</span>
          </button>
        </div>
      )}

      {/* 9.35 — At-your-own-pace explainer. Sits below the two Play All buttons
          (only when Play All is idle, so it doesn't compete with the Stop button)
          and clarifies that solo single-section play is the third valid mode —
          the scorecard still tracks the work because YFG still prompts members
          to save reflections and check Complete. */}
      {dc && playAllMode === 'idle' && (
        <div style={{
          marginBottom: 20,
          padding: '12px 14px',
          borderLeft: '2px solid rgba(255,20,147,.35)',
          background: 'rgba(255,20,147,.03)',
          borderRadius: '0 6px 6px 0',
          fontFamily: 'var(--font-ui)',
          fontSize: 12.5,
          lineHeight: 1.55,
          color: 'rgba(251,250,244,.7)'
        }}>
          <span style={{ color: 'var(--pink)', fontWeight: 600, fontStyle: 'italic' }}>Or move at your own pace.</span>{' '}
          Tap any individual section&rsquo;s play button — Your Fairy Godfather still reads it to you, still invites a spoken reflection,
          and gently prompts you to save and check Complete when you&rsquo;re done. The scorecard reflects the work you&rsquo;re actually doing.
        </div>
      )}
      {dc && playAllMode !== 'idle' && (
        <div style={{ marginBottom: 20 }}>
          <button
            onClick={() => { setPlayAllMode('idle'); setPlayAllCursor(0) }}
            style={{
              width: '100%',
              background: 'rgba(255,20,147,.1)',
              color: 'var(--pink)',
              border: '1px solid var(--pink)',
              borderRadius: 8,
              padding: '12px 16px',
              fontFamily: 'var(--font-ui)',
              fontWeight: 600,
              fontSize: 14,
              cursor: 'pointer',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              gap: 8
            }}>
            <span style={{ fontSize: 16 }}>⏹</span>
            <span>Stop {playAllMode === 'guided' ? 'Guided Practice' : 'Listen-Through'} ({playAllCursor + 1} / {activeSequence.length})</span>
          </button>
        </div>
      )}

      {/* Day header — `header` content_type AudioPlayer above the card. v9.33: Play All wired. */}
      {dc && (
        <div ref={setScrollRef('header')} style={{ marginBottom: 24 }}>
          <AudioPlayer
            contentType="header"
            contentId={String(dayNum)}
            behaviorClass="A"
            emoji="📖"
            title={`Day ${dayNum} — ${dc.title}`}
            dayNumber={dayNum}
            playAllMode={playAllMode}
            playAllAutoStartKey={autoStartKeyFor('header')}
            onPlayAllAdvance={handlePlayAllAdvance}
            onUserClose={handleUserClose}
          />
          <div className="card" style={{ background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.1)' }}>
            <p className="section-label">Day {dayNum}</p>
            <h3 style={{ fontSize:18, fontWeight:400, marginBottom:6 }}>{dc.title}</h3>
            {dc.spiritual_principle && <p style={{ fontSize:12, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom: dc.pattern ? 8 : 0 }}>{dc.spiritual_principle}</p>}
            {dc.pattern && <p style={{ fontSize:13, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>Pattern: {dc.pattern}</p>}
          </div>
        </div>
      )}

      {/* ── MORNING VIEW ── */}
      {isMorning && dc && <>

        {/* Sources — read only */}
        {(dc.source_big_book || dc.source_twelve_twelve || dc.source_drop_rock || dc.source_ripple_effect) && (
          <SectionBlock emoji="📚" title="Today's Sources"
            audioContentType="sources" audioContentId={String(dayNum)} audioBehaviorClass="A" audioDayNumber={dayNum} scrollRef={setScrollRef('sources')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('sources')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            {dc.source_big_book      && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📖 BIG BOOK</p><RichText text={dc.source_big_book}/></div>}
            {dc.source_twelve_twelve && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📗 TWELVE STEPS & TRADITIONS</p><RichText text={dc.source_twelve_twelve}/></div>}
            {dc.source_drop_rock     && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📘 DROP THE ROCK</p><RichText text={dc.source_drop_rock}/></div>}
            {dc.source_ripple_effect && <div><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📙 RIPPLE EFFECT</p><RichText text={dc.source_ripple_effect}/></div>}
          </SectionBlock>
        )}

        {/* 1. Pattern — read + checkbox */}
        {dc.pattern_detail && (
          <SectionBlock emoji="💙" title="Today's Pattern"
            audioContentType="section_1" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_1')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_1')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_1')} introContentId={introIdFor('section_1')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.pattern_detail}/>
            <NotesBox section="pattern" itemKey="notes"
              value={textVal('pattern','notes')} onSave={save} saving={isSaving('pattern','notes')}/>
            <CheckRow label="Completed — Today's Pattern (1)" section="pattern" itemKey="completed"
              checked={isChecked('pattern','completed')} onSave={save} saving={isSaving('pattern','completed')}/>
          </SectionBlock>
        )}

        {/* 2. Opposite Action — read + checkbox */}
        {dc.opposite_action && (
          <SectionBlock emoji="🟩" title="Opposite Action"
            audioContentType="section_2" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_2')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_2')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_2')} introContentId={introIdFor('section_2')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.opposite_action}/>
            <NotesBox section="opposite_action" itemKey="notes"
              value={textVal('opposite_action','notes')} onSave={save} saving={isSaving('opposite_action','notes')}/>
            <CheckRow label="Completed — Opposite Action (2)" section="opposite_action" itemKey="completed"
              checked={isChecked('opposite_action','completed')} onSave={save} saving={isSaving('opposite_action','completed')}/>
          </SectionBlock>
        )}

        {/* 3. Prayer of the Day — read + checkbox */}
        {dc.step7_prayer && (
          <SectionBlock emoji="💛" title="Prayer of the Day"
            audioContentType="section_3" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_3')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_3')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_3')} introContentId={introIdFor('section_3')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <div style={{ background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.1)', borderRadius:8, padding:16, marginBottom:4 }}>
              <RichText text={dc.step7_prayer}/>
            </div>
            <NotesBox section="prayer" itemKey="notes"
              value={textVal('prayer','notes')} onSave={save} saving={isSaving('prayer','notes')}/>
            <CheckRow label="Said my prayer today (3)" section="prayer" itemKey="completed"
              checked={isChecked('prayer','completed')} onSave={save} saving={isSaving('prayer','completed')}/>
          </SectionBlock>
        )}

        {/* 4. Act of Service — read + notes box + checkbox */}
        {dc.act_of_service && (
          <SectionBlock emoji="🌟" title="Act of Service"
            audioContentType="section_4" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_4')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_4')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_4')} introContentId={introIdFor('section_4')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.act_of_service}/>
            <NotesBox section="act_of_service" itemKey="notes"
              value={textVal('act_of_service','notes')} onSave={save} saving={isSaving('act_of_service','notes')}/>
            <CheckRow label="Completed act of service (4)" section="act_of_service" itemKey="completed"
              checked={isChecked('act_of_service','completed')} onSave={save} saving={isSaving('act_of_service','completed')}/>
          </SectionBlock>
        )}

        {/* 5. Bonus Challenge — read + notes box + checkbox */}
        {dc.bonus_challenge && (
          <SectionBlock emoji="🎯" title="Bonus Challenge"
            audioContentType="section_5" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_5')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_5')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_5')} introContentId={introIdFor('section_5')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.bonus_challenge}/>
            <NotesBox section="bonus_challenge" itemKey="notes"
              value={textVal('bonus_challenge','notes')} onSave={save} saving={isSaving('bonus_challenge','notes')}/>
            <CheckRow label="Completed bonus challenge (5)" section="bonus_challenge" itemKey="completed"
              checked={isChecked('bonus_challenge','completed')} onSave={save} saving={isSaving('bonus_challenge','completed')}/>
          </SectionBlock>
        )}

        {/* 6. Morning Practice — questions displayed as text + notes box + checkbox */}
        <SectionBlock emoji="🌅" title="Morning Practice"
          audioContentType="section_6" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_6')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_6')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_6')} introContentId={introIdFor('section_6')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
          {(dc.morning_questions||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.morning_questions||[]).map((q, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {q.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          {dc.morning_intention && (
            <div className="card" style={{ marginBottom:8, background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.06)' }}>
              <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom:6 }}>INTENTION</p>
              <p style={{ fontSize:14, fontStyle:'italic', color:'rgba(251,250,244,.7)', lineHeight:1.7 }}>"{dc.morning_intention}"</p>
            </div>
          )}
          <NotesBox section="morning_practice" itemKey="notes"
            value={textVal('morning_practice','notes')} onSave={save} saving={isSaving('morning_practice','notes')}/>
          <CheckRow label="Morning practice completed (6)" section="morning_practice" itemKey="completed"
            checked={isChecked('morning_practice','completed')} onSave={save} saving={isSaving('morning_practice','completed')}/>
        </SectionBlock>

        {/* 7. Breathing — read + checkbox */}
        {dc.breathing && (
          <SectionBlock emoji="🌬" title="Breathing Practice"
            audioContentType="section_7" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_7')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_7')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_7')} introContentId={introIdFor('section_7')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.breathing}/>
            <NotesBox section="grounding" itemKey="breathing_notes"
              value={textVal('grounding','breathing_notes')} onSave={save} saving={isSaving('grounding','breathing_notes')}/>
            <CheckRow label="Completed breathing exercise (7)" section="grounding" itemKey="breathing"
              checked={isChecked('grounding','breathing')} onSave={save} saving={isSaving('grounding','breathing')}/>
          </SectionBlock>
        )}

        {/* 8. Grounding — read + checkbox */}
        {dc.grounding && (
          <SectionBlock emoji="🌳" title="Grounding Statement"
            audioContentType="section_8" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_8')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_8')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_8')} introContentId={introIdFor('section_8')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.grounding}/>
            <NotesBox section="grounding" itemKey="grounding_notes"
              value={textVal('grounding','grounding_notes')} onSave={save} saving={isSaving('grounding','grounding_notes')}/>
            <CheckRow label="Completed grounding exercise (8)" section="grounding" itemKey="grounding"
              checked={isChecked('grounding','grounding')} onSave={save} saving={isSaving('grounding','grounding')}/>
          </SectionBlock>
        )}

        {/* 9. Affirmation — read + checkbox */}
        {dc.affirmation && (
          <SectionBlock emoji="🌈" title="Affirmation of the Day"
            audioContentType="section_9" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_9')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_9')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_9')} introContentId={introIdFor('section_9')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <div style={{ textAlign:'center', padding:'12px 16px', background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.12)', borderRadius:8, marginBottom:4 }}>
              <p style={{ fontSize:17, fontStyle:'italic', color:'var(--pink)', lineHeight:1.65 }}>"{dc.affirmation}"</p>
            </div>
            <NotesBox section="affirmation" itemKey="notes"
              value={textVal('affirmation','notes')} onSave={save} saving={isSaving('affirmation','notes')}/>
            <CheckRow label="Spoke this affirmation aloud (9)" section="affirmation" itemKey="spoken"
              checked={isChecked('affirmation','spoken')} onSave={save} saving={isSaving('affirmation','spoken')}/>
          </SectionBlock>
        )}

        {/* 10. Meditation — read + checkbox */}
        {dc.meditation && (
          <SectionBlock emoji="🙏" title="Short Meditation"
            audioContentType="section_10" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_10')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_10')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_10')} introContentId={introIdFor('section_10')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.meditation}/>
            <NotesBox section="meditation" itemKey="notes"
              value={textVal('meditation','notes')} onSave={save} saving={isSaving('meditation','notes')}/>
            <CheckRow label="Completed meditation (10)" section="meditation" itemKey="completed"
              checked={isChecked('meditation','completed')} onSave={save} saving={isSaving('meditation','completed')}/>
          </SectionBlock>
        )}

      </>}

      {/* ── EVENING VIEW ── */}
      {!isMorning && dc && <>

        {/* 11. Evening Practice — questions as text + notes box + checkbox */}
        <SectionBlock emoji="✏️" title="Evening Practice"
          audioContentType="section_11" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_11')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_11')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_11')} introContentId={introIdFor('section_11')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
          {(dc.evening_questions||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.evening_questions||[]).map((q, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {q.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          <NotesBox section="evening_practice" itemKey="notes"
            value={textVal('evening_practice','notes')} onSave={save} saving={isSaving('evening_practice','notes')}/>
          <CheckRow label="Evening practice completed (11)" section="evening_practice" itemKey="completed"
            checked={isChecked('evening_practice','completed')} onSave={save} saving={isSaving('evening_practice','completed')}/>
        </SectionBlock>

        {/* 12. Step 10 Mini-Inventory — items as text + notes box + ONE checkbox */}
        <SectionBlock emoji="📘" title="Step 10 Mini-Inventory"
          audioContentType="section_12" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_12')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_12')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_12')} introContentId={introIdFor('section_12')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
          {(dc.step10_items||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.step10_items||[]).map((item, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {item.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          <NotesBox section="step10" itemKey="notes"
            value={textVal('step10','notes')} onSave={save} saving={isSaving('step10','notes')}/>
          <CheckRow label="Step 10 inventory complete (12)" section="step10" itemKey="completed"
            checked={isChecked('step10','completed')} onSave={save} saving={isSaving('step10','completed')}/>
        </SectionBlock>

        {/* 13. Visualization — read + checkbox */}
        {dc.visualization && (
          <SectionBlock emoji="✨" title="Visualization"
            audioContentType="section_13" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_13')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_13')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_13')} introContentId={introIdFor('section_13')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.visualization}/>
            <NotesBox section="visualization" itemKey="notes"
              value={textVal('visualization','notes')} onSave={save} saving={isSaving('visualization','notes')}/>
            <CheckRow label="Completed visualization (13)" section="visualization" itemKey="completed"
              checked={isChecked('visualization','completed')} onSave={save} saving={isSaving('visualization','completed')}/>
          </SectionBlock>
        )}

        {/* 14. Gratitude — read + checkbox only */}
        {dc.gratitude && (
          <SectionBlock emoji="🧡" title="Gratitude for Today"
            audioContentType="section_14" audioContentId={String(dayNum)} audioBehaviorClass="B" audioDayNumber={dayNum} scrollRef={setScrollRef('section_14')} playAllMode={playAllMode} playAllAutoStartKey={autoStartKeyFor('section_14')} playIntroFirst={SECTIONS_WITH_INTRO.has('section_14')} introContentId={introIdFor('section_14')} onPlayAllAdvance={handlePlayAllAdvance} onUserClose={handleUserClose}>
            <RichText text={dc.gratitude}/>
            <NotesBox section="gratitude" itemKey="notes"
              value={textVal('gratitude','notes')} onSave={save} saving={isSaving('gratitude','notes')}/>
            <CheckRow label="Gratitude completed (14)" section="gratitude" itemKey="completed"
              checked={isChecked('gratitude','completed')} onSave={save} saving={isSaving('gratitude','completed')}/>
          </SectionBlock>
        )}


      </>}

      {/* Attestation Score Panel */}
      <AttestationPanel dc={dc} isChecked={isChecked} textVal={textVal}
        isMorning={isMorning} onBack={onBack} onSwitchPeriod={onSwitchPeriod}
        commentsToday={commentsToday}/>
    </div>
  )
}

// ─── Attestation Score Panel ──────────────────────────────────────────────────

function AttestationPanel({ dc, isChecked, textVal, isMorning, onBack, onSwitchPeriod, commentsToday }) {
  // Daily score: sections 1-5 checkboxes
  const dailyDone  = [
    isChecked('pattern','completed'),
    isChecked('opposite_action','completed'),
    isChecked('prayer','completed'),
    isChecked('act_of_service','completed'),
    isChecked('bonus_challenge','completed'),
  ].filter(Boolean).length
  const dailyTotal = 5

  // Morning score: sections 6-10 checkboxes
  const morningDone  = [
    isChecked('morning_practice','completed'),
    isChecked('grounding','breathing'),
    isChecked('grounding','grounding'),
    isChecked('affirmation','spoken'),
    isChecked('meditation','completed'),
  ].filter(Boolean).length
  const morningTotal = 5

  // Evening score: sections 11-14 checkboxes
  const eveningDone  = [
    isChecked('evening_practice','completed'),
    isChecked('step10','completed'),
    isChecked('visualization','completed'),
    isChecked('gratitude','completed'),
  ].filter(Boolean).length
  const eveningTotal = 4

  const totalAll = dailyTotal + morningTotal + eveningTotal
  const doneAll  = dailyDone + morningDone + eveningDone
  const pct      = Math.round(doneAll / totalAll * 100)
  const complete = pct === 100

  return (
    <div style={{ marginTop:24, marginBottom:16 }}>
      <div style={{
        background: complete ? 'rgba(25,229,94,.08)' : 'rgba(255,20,147,.04)',
        border: `1px solid ${complete ? 'rgba(25,229,94,.2)' : 'rgba(255,20,147,.15)'}`,
        borderRadius:12, padding:20
      }}>
        <p style={{ fontSize:11, color:complete?'var(--lime)':'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:1.5, textAlign:'center', marginBottom:16 }}>
          ✓ DAILY ATTESTATION — Contract with My HP & I
        </p>

        {/* 4 score boxes: Daily, Morning, Evening, Comments */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:8, marginBottom:16 }}>
          {[
            { label:'Daily',    done:dailyDone,   total:dailyTotal,   sub:'checks 1–5'   },
            { label:'Morning',  done:morningDone, total:morningTotal, sub:'checks 6–10'  },
            { label:'Evening',  done:isMorning?null:eveningDone, total:isMorning?null:eveningTotal, sub:'checks 11–14' },
            { label:'Responses', done:commentsToday, total:null, sub:'saved today', isComments:true },
          ].map(({ label, done, total, sub, isComments }) => (
            <div key={label} style={{ textAlign:'center', padding:'10px 6px', background:'rgba(0,0,0,.2)', borderRadius:8 }}>
              <p style={{ fontSize:16, fontWeight:700, fontFamily:'var(--font-ui)',
                color: isComments ? 'var(--lime)' : (done!==null&&done===total)?'var(--lime)':'var(--pink)',
                marginBottom:2 }}>
                {done !== null ? (total !== null ? `${done}/${total}` : done) : '—'}
              </p>
              <p style={{ fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)' }}>{label}</p>
              <p style={{ fontSize:9, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)' }}>{sub}</p>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        <div style={{ height:6, borderRadius:3, background:'rgba(255,255,255,.1)', marginBottom:12, overflow:'hidden' }}>
          <div style={{ height:'100%', width:`${pct}%`, borderRadius:3, background:complete?'var(--lime)':'var(--pink)', transition:'width .4s ease' }}/>
        </div>

        <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:4 }}>
          Today's Total Completion
        </p>
        <p style={{ textAlign:'center', fontSize:26, fontWeight:700, fontFamily:'var(--font-ui)', color:complete?'var(--lime)':'var(--pink)', marginBottom:4 }}>
          {pct}%
        </p>

        {isMorning && !complete && (
          <p style={{ textAlign:'center', fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>
            Evening practice updates when you complete it tonight
          </p>
        )}
        {complete && (
          <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.6)', fontFamily:'var(--font-ui)', fontStyle:'italic', marginTop:8, lineHeight:1.6 }}>
            "We are not a glum lot. We absolutely insist on enjoying life." 🌈
          </p>
        )}
      </div>

      {/* Nav buttons */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginTop:16 }}>
        <button onClick={onBack}
          style={{ padding:'14px', borderRadius:10, background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.15)', color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
          Dashboard
        </button>
        {isMorning ? (
          <button onClick={() => onSwitchPeriod('evening')}
            style={{ padding:'14px', borderRadius:10, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)', color:'var(--lime)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
            Evening →
          </button>
        ) : (
          <button onClick={() => onSwitchPeriod('morning')}
            style={{ padding:'14px', borderRadius:10, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
            ← Morning
          </button>
        )}
      </div>
    </div>
  )
}
