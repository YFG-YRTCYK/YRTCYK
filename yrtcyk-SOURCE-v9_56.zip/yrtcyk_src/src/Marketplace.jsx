// ========================================================================
// Marketplace.jsx — v9.51 Item 8
//
// YFG Marketplace — curated catalog of recovery-related items members can
// buy. Direct publisher links only (no affiliate codes). Members can also
// submit a request for an item to be added; admin reviews in AdminPanel
// → Marketplace tab.
//
// Surface: 2-column responsive grid of cards, matching the v9.51 Heroes/
// Calendar/MemberDirectory pattern (repeat(auto-fill, minmax(160px, 1fr))).
//
// Catalog ships with 5 launch items seeded in the v951_item8_marketplace
// migration (Big Book, 12 & 12, Drop the Rock, Ripple Effect, Grapevine).
// Categories visible at launch: 'Books', 'Subscriptions'.
//
// Architecture:
//   marketplace_items          → public-readable when status='active'
//   marketplace_item_requests  → members read own; admin reads all; INSERT
//                                with member_id-scoped policy
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

// Category → emoji header. Keep in sync with seed values in the migration.
// Falls back to 🛒 for any future category we haven't mapped.
const CATEGORY_EMOJI = {
  'Books':         '📚',
  'Subscriptions': '📰',
  'Apps':          '📱',
}

function emojiForItem(item) {
  // Title-specific overrides for the launch catalog so the cards have a
  // distinct visual signature without hosting cover images.
  const t = (item.title || '').toLowerCase()
  if (t.startsWith('alcoholics anonymous'))      return '📕'
  if (t.startsWith('twelve steps'))              return '📘'
  if (t.startsWith('drop the rock'))             return '🪨'
  if (t.includes('grapevine'))                   return '📰'
  return CATEGORY_EMOJI[item.category] || '🛒'
}

export default function Marketplace({ user, isAdmin }) {
  const [items, setItems]     = useState([])
  const [loading, setLoading] = useState(true)
  // Request form state
  const [showForm, setShowForm]   = useState(false)
  const [reqTitle, setReqTitle]   = useState('')
  const [reqUrl, setReqUrl]       = useState('')
  const [reqReason, setReqReason] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [msg, setMsg] = useState('')
  // Member's own request history
  const [myRequests, setMyRequests] = useState([])
  const [me, setMe] = useState(null)

  useEffect(() => { load() }, [])

  async function load() {
    setLoading(true)
    const { data: itemRows } = await supabase
      .from('marketplace_items')
      .select('id, title, subtitle, description, image_url, purchase_url, category, display_order, status')
      .eq('status', 'active')
      .order('display_order')
    setItems(itemRows || [])

    // Resolve current member id so we can fetch their own requests + scope
    // the INSERT correctly.
    const { data: meRow } = await supabase
      .from('members').select('id').eq('email', user.email).single()
    setMe(meRow || null)

    if (meRow?.id) {
      const { data: reqRows } = await supabase
        .from('marketplace_item_requests')
        .select('id, title, purchase_url, reason, status, admin_note, created_at, reviewed_at')
        .eq('member_id', meRow.id)
        .order('created_at', { ascending: false })
      setMyRequests(reqRows || [])
    }

    setLoading(false)
  }

  async function submitRequest() {
    if (!me?.id) { setMsg('Error: could not identify your account.'); return }
    if (!reqTitle.trim()) { setMsg('Title is required.'); return }
    setSubmitting(true)
    setMsg('')
    const payload = {
      member_id: me.id,
      title: reqTitle.trim(),
      purchase_url: reqUrl.trim() || null,
      reason: reqReason.trim() || null,
    }
    const { error } = await supabase.from('marketplace_item_requests').insert(payload)
    setSubmitting(false)
    if (error) {
      setMsg(`Error: ${error.message}`)
      return
    }
    setReqTitle(''); setReqUrl(''); setReqReason('')
    setShowForm(false)
    setMsg('Thanks — your request was sent. You\u2019ll see it appear below.')
    setTimeout(() => setMsg(''), 4500)
    // Refresh request history
    const { data: reqRows } = await supabase
      .from('marketplace_item_requests')
      .select('id, title, purchase_url, reason, status, admin_note, created_at, reviewed_at')
      .eq('member_id', me.id)
      .order('created_at', { ascending: false })
    setMyRequests(reqRows || [])
  }

  if (loading) {
    return <div style={{paddingTop:40, display:'flex', justifyContent:'center'}}><div className="spinner"/></div>
  }

  return (
    <div style={{paddingTop:14}}>
      {/* Header */}
      <div style={{marginBottom:18}}>
        <h2 style={{fontSize:22, fontWeight:400, fontFamily:'var(--font-serif)', color:'var(--cream)', marginBottom:6}}>
          🛒 YFG Marketplace
        </h2>
        <p style={{fontSize:13, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', lineHeight:1.6}}>
          Curated recovery essentials. Direct links to publishers — no affiliate codes, no markup.
          Don't see what you need? Request it below.
        </p>
      </div>

      {msg && (
        <p style={{
          fontSize:12, fontFamily:'var(--font-ui)', textAlign:'center', marginBottom:14,
          padding:'8px 12px', borderRadius:8,
          color: msg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)',
          background: msg.startsWith('Error') ? 'rgba(255,20,147,.08)' : 'rgba(25,229,94,.08)',
          border: `1px solid ${msg.startsWith('Error') ? 'rgba(255,20,147,.2)' : 'rgba(25,229,94,.2)'}`,
        }}>{msg}</p>
      )}

      {/* Catalog grid — 2-col on mobile, more on wider screens */}
      <div style={{
        display:'grid',
        gridTemplateColumns:'repeat(auto-fill, minmax(160px, 1fr))',
        gap:10,
        marginBottom:24,
      }}>
        {items.map(item => (
          <div key={item.id} style={{
            background:'rgba(255,255,255,.04)',
            border:'1px solid rgba(255,20,147,.2)',
            borderRadius:12,
            overflow:'hidden',
            display:'flex',
            flexDirection:'column',
          }}>
            {/* Emoji header — square 1:1 */}
            <div style={{
              aspectRatio:'1 / 1',
              background:'linear-gradient(135deg, rgba(255,20,147,.08), rgba(25,229,94,.04))',
              display:'flex',
              alignItems:'center',
              justifyContent:'center',
              fontSize:60,
              borderBottom:'1px solid rgba(255,20,147,.15)',
            }}>
              {item.image_url
                ? <img src={item.image_url} alt={item.title} style={{width:'100%', height:'100%', objectFit:'cover'}}/>
                : <span aria-hidden="true">{emojiForItem(item)}</span>}
            </div>
            {/* Body */}
            <div style={{padding:'10px 12px 12px', flex:1, display:'flex', flexDirection:'column', gap:6}}>
              <p style={{fontSize:13, fontWeight:700, color:'var(--pink)', fontFamily:'var(--font-ui)', lineHeight:1.3}}>
                {item.title}
              </p>
              {item.subtitle && (
                <p style={{fontSize:11, color:'rgba(251,250,244,.6)', fontFamily:'var(--font-ui)', lineHeight:1.4, fontStyle:'italic'}}>
                  {item.subtitle}
                </p>
              )}
              {item.description && (
                <p style={{
                  fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.5,
                  display:'-webkit-box', WebkitLineClamp:3, WebkitBoxOrient:'vertical', overflow:'hidden',
                }}>
                  {item.description}
                </p>
              )}
              {item.category && (
                <span style={{
                  alignSelf:'flex-start',
                  fontSize:10, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.55)',
                  padding:'2px 8px', borderRadius:999,
                  background:'rgba(255,255,255,.05)', border:'1px solid rgba(255,255,255,.1)',
                }}>{item.category}</span>
              )}
              <a
                href={item.purchase_url}
                target="_blank"
                rel="noopener noreferrer"
                style={{
                  marginTop:'auto',
                  display:'block',
                  textAlign:'center',
                  padding:'8px 10px',
                  borderRadius:8,
                  background:'var(--pink)',
                  color:'#fff',
                  fontSize:12,
                  fontWeight:600,
                  fontFamily:'var(--font-ui)',
                  textDecoration:'none',
                }}
              >
                Buy now →
              </a>
            </div>
          </div>
        ))}
      </div>

      {/* Request form */}
      <div style={{
        background:'rgba(25,229,94,.04)',
        border:'1px solid rgba(25,229,94,.2)',
        borderRadius:12,
        padding:'14px 14px 12px',
        marginBottom:18,
      }}>
        {!showForm && (
          <button onClick={() => setShowForm(true)} style={{
            width:'100%',
            padding:'10px 12px',
            borderRadius:8,
            background:'rgba(25,229,94,.1)',
            border:'1px dashed rgba(25,229,94,.4)',
            color:'var(--lime)',
            fontSize:13,
            fontFamily:'var(--font-ui)',
            fontWeight:600,
            cursor:'pointer',
          }}>
            ✨ Don't see what you're looking for? Request an item →
          </button>
        )}
        {showForm && (
          <div style={{display:'flex', flexDirection:'column', gap:10}}>
            <p style={{fontSize:12, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.6)', lineHeight:1.6}}>
              Tell us what should be on this list. Geo will review your suggestion and
              either add it, ask follow-up questions, or send a brief note explaining
              why it's not a fit.
            </p>
            <input
              type="text"
              placeholder="Title — e.g. Living Sober (AA pamphlet)"
              value={reqTitle}
              onChange={e => setReqTitle(e.target.value)}
              maxLength={120}
              style={{fontSize:13, fontFamily:'var(--font-ui)', padding:'8px 10px', borderRadius:8, background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.12)', color:'var(--cream)'}}
            />
            <input
              type="url"
              placeholder="Purchase URL (optional) — https://…"
              value={reqUrl}
              onChange={e => setReqUrl(e.target.value)}
              style={{fontSize:13, fontFamily:'var(--font-ui)', padding:'8px 10px', borderRadius:8, background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.12)', color:'var(--cream)'}}
            />
            <textarea
              placeholder="Why this should be on the list (optional)"
              value={reqReason}
              onChange={e => setReqReason(e.target.value)}
              rows={3}
              maxLength={500}
              style={{fontSize:13, fontFamily:'var(--font-ui)', padding:'8px 10px', borderRadius:8, background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.12)', color:'var(--cream)', resize:'vertical'}}
            />
            <div style={{display:'flex', gap:8}}>
              <button onClick={submitRequest} disabled={submitting || !reqTitle.trim()} style={{
                flex:1,
                padding:'9px 12px',
                borderRadius:8,
                background:'var(--pink)',
                color:'#fff',
                border:'none',
                fontSize:13,
                fontWeight:600,
                fontFamily:'var(--font-ui)',
                cursor: (submitting || !reqTitle.trim()) ? 'not-allowed' : 'pointer',
                opacity: (submitting || !reqTitle.trim()) ? .5 : 1,
              }}>
                {submitting ? 'Sending…' : 'Send request'}
              </button>
              <button onClick={() => { setShowForm(false); setMsg('') }} style={{
                padding:'9px 14px',
                borderRadius:8,
                background:'rgba(255,255,255,.06)',
                color:'rgba(251,250,244,.6)',
                border:'1px solid rgba(255,255,255,.1)',
                fontSize:13,
                fontFamily:'var(--font-ui)',
                cursor:'pointer',
              }}>Cancel</button>
            </div>
          </div>
        )}
      </div>

      {/* Member's own request history */}
      {myRequests.length > 0 && (
        <div>
          <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>
            YOUR REQUESTS
          </p>
          <div style={{display:'flex', flexDirection:'column', gap:8}}>
            {myRequests.map(r => {
              const palette = r.status === 'approved'
                ? { color:'var(--lime)', bg:'rgba(25,229,94,.06)', border:'rgba(25,229,94,.2)', label:'✓ Approved' }
                : r.status === 'denied'
                ? { color:'rgba(251,250,244,.55)', bg:'rgba(255,255,255,.04)', border:'rgba(255,255,255,.1)', label:'Not added' }
                : { color:'rgba(251,250,244,.7)', bg:'rgba(255,255,255,.04)', border:'rgba(255,255,255,.1)', label:'⏳ Pending' }
              return (
                <div key={r.id} style={{
                  padding:'10px 12px', borderRadius:8,
                  background: palette.bg, border:`1px solid ${palette.border}`,
                }}>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'baseline', gap:10, marginBottom:4}}>
                    <p style={{fontSize:13, fontWeight:600, color:'var(--cream)', fontFamily:'var(--font-ui)'}}>{r.title}</p>
                    <span style={{fontSize:10, fontFamily:'var(--font-ui)', color: palette.color, whiteSpace:'nowrap'}}>{palette.label}</span>
                  </div>
                  {r.reason && (
                    <p style={{fontSize:12, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.5, marginBottom:4}}>
                      {r.reason}
                    </p>
                  )}
                  {r.admin_note && (
                    <p style={{fontSize:11, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', lineHeight:1.5, fontStyle:'italic', marginTop:4, paddingTop:4, borderTop:'1px dashed rgba(255,255,255,.07)'}}>
                      Reply: {r.admin_note}
                    </p>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}
    </div>
  )
}
