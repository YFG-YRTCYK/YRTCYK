// MeetingCard.jsx — v9.49 / Phase 4 Item 11B (v9.50: Hybrid format removed)
//                   v9.51.4: Visibility window expanded to all-day-on-day.
//
// Pulsating Dashboard card surfacing a member's home group meeting whenever
// today's day-of-week matches the meeting's scheduled day. Pure client-side
// computation against member_home_groups + members.timezone.
// No Edge Function, no cron, no email volume.
//
// Composition:
//   - Renders zero, one, or many cards (one per qualifying home group row)
//   - Stack ordered by time-to-start ascending — soonest first
//   - Card pulse intensifies as start time approaches; calm otherwise
//   - Action button:
//       Online (Zoom)        → primary "Join meeting →" opens Zoom URL
//       In-Person            → primary "Get directions →" opens Google Maps
//   - Auto-ticks every 60 seconds so the countdown stays current
//
// Visibility window:
//   - v9.51.4: Card appears all day on the meeting's day-of-week. Geo's
//     stated spec — "if there is a Home Group meeting on Thursday, show it
//     today on Thursday at the top." Earlier (-60, +90) min window from
//     v9.49 silently triggered the empty-state ("No home group on the
//     books today") for any check outside that 2.5-hour band on a day
//     when the member DID have a meeting. That was a spec mismatch.
//   - At midnight the day-of-week rolls over and the card naturally
//     disappears. computeMinutesUntil() returns null on non-matching
//     days, which the filter respects.
//
// Usage:
//   <MeetingCard memberId={member.id} memberTz={member.timezone} />

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

const PROGRAM_LABEL = {
  'AA':              'Alcoholics Anonymous',
  'ACoA':            'Adult Children of Alcoholics',
  'Al-Anon':         'Al-Anon Family Groups',
  'CMA':             'Crystal Meth Anonymous',
  'CoDA':            'Co-Dependents Anonymous',
  'GA':              'Gamblers Anonymous',
  'NA':              'Narcotics Anonymous',
  'OA':              'Overeaters Anonymous',
  'SLAA':            'Sex and Love Addicts Anonymous',
  'Stopped Smoking': 'Stopped Smoking',
}

// Compute "minutes until this meeting starts" in the member's timezone.
// Returns null when today's day-of-week doesn't match the meeting's day.
// Positive = future. Negative = already started.
function computeMinutesUntil(meetingDay, meetingTime, memberTz) {
  if (!meetingDay || !meetingTime) return null
  try {
    const tz = memberTz || 'America/Los_Angeles'
    const fmt = new Intl.DateTimeFormat('en-US', {
      timeZone: tz, weekday: 'long', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    })
    const parts = fmt.formatToParts(new Date())
    const todayDay = parts.find(p => p.type === 'weekday')?.value
    if (todayDay !== meetingDay) return null
    const h = parseInt(parts.find(p => p.type === 'hour')?.value ?? '0', 10)
    const m = parseInt(parts.find(p => p.type === 'minute')?.value ?? '0', 10)
    const [mh, mm] = String(meetingTime).split(':').map(n => parseInt(n, 10))
    if (Number.isNaN(mh) || Number.isNaN(mm)) return null
    return (mh * 60 + mm) - (h * 60 + m)
  } catch (e) {
    console.warn('[MeetingCard] tz compute failed:', e.message)
    return null
  }
}

function formatTimeLabel(minutesUntil) {
  const m = minutesUntil
  // v9.51.4: friendlier copy for distant past on the same day. After the
  // -60 min mark we stop counting "Started X min ago" (which would read
  // awkwardly as "Started 480 min ago" if a member checks at 11 PM after
  // a 5:30 PM meeting) and just acknowledge the meeting happened earlier.
  if (m <= -60)  return 'Met earlier today'
  if (m <= -1)   return `Started ${-m} min ago`
  if (m === 0)   return 'Happening now'
  if (m === 1)   return 'Starts in 1 min'
  if (m < 60)    return `Starts in ${m} min`
  if (m < 120)   return `Starts in 1 hr ${m - 60} min`
  return `Starts in ${Math.round(m / 60)} hours`
}

function formatClockTime(meetingTime) {
  if (!meetingTime) return ''
  const [h, m] = String(meetingTime).split(':').map(n => parseInt(n, 10))
  const ampm = h >= 12 ? 'PM' : 'AM'
  const h12 = h % 12 === 0 ? 12 : h % 12
  return `${h12}:${String(m).padStart(2, '0')} ${ampm}`
}

function buildMapsUrl(address) {
  if (!address) return null
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`
}

function SingleCard({ row }) {
  const m = row.minutesUntil
  const isImminent = m >= 0 && m <= 30  // intense pulse: starting in next 30 min
  const isHappening = m > -60 && m <= 0 // happening now: lime accent
  const animation = isImminent || isHappening
    ? 'yfgMeetingPulse 1.6s ease-in-out infinite'
    : 'yfgMeetingPulse 3s ease-in-out infinite'

  const accent = isHappening ? 'rgba(25,229,94,.45)' : 'rgba(255,20,147,.45)'
  const accentBg = isHappening ? 'rgba(25,229,94,.08)' : 'rgba(255,20,147,.08)'

  const programLabel = PROGRAM_LABEL[row.program] || row.program
  const isOnline = row.format === 'Online (Zoom)'
  const isInPerson = row.format === 'In-Person'
  const zoomUrl = isOnline ? row.location_or_zoom : null
  const mapsUrl = isInPerson ? buildMapsUrl(row.address || row.location_or_zoom) : null

  return (
    <div style={{
      background: accentBg,
      border: `1.5px solid ${accent}`,
      borderRadius: 12,
      padding: '16px 18px',
      marginBottom: 12,
      animation,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', flexWrap: 'wrap', gap: 8, marginBottom: 8 }}>
        <p style={{ fontSize: 11, color: 'rgba(251,250,244,.55)', fontFamily: 'var(--font-ui)', letterSpacing: 1.2, margin: 0, textTransform: 'uppercase' }}>
          🏠 {programLabel} home group
        </p>
        <p style={{
          fontSize: 12, fontWeight: 700, fontFamily: 'var(--font-ui)',
          color: isHappening ? 'var(--lime)' : 'var(--pink)',
          margin: 0, letterSpacing: .3,
        }}>
          {formatTimeLabel(m)}
        </p>
      </div>
      <p style={{ fontSize: 17, fontWeight: 600, color: 'var(--cream)', fontFamily: 'Georgia, serif', margin: '0 0 4px 0', lineHeight: 1.25 }}>
        {row.home_group_name || 'Your meeting'}
      </p>
      <p style={{ fontSize: 12, color: 'rgba(251,250,244,.5)', fontFamily: 'var(--font-ui)', margin: '0 0 12px 0' }}>
        {formatClockTime(row.meeting_time)} · {row.format || 'Meeting'}
        {row.address && isInPerson ? ` · ${row.address}` : ''}
      </p>
      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
        {zoomUrl && (
          <a href={zoomUrl} target="_blank" rel="noreferrer"
            style={{
              display: 'inline-block',
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 600,
              fontFamily: 'var(--font-ui)',
              textDecoration: 'none',
              background: 'var(--pink)',
              color: '#fff',
              border: '1px solid var(--pink)',
            }}>
            🪄 Join meeting →
          </a>
        )}
        {mapsUrl && (
          <a href={mapsUrl} target="_blank" rel="noreferrer"
            style={{
              display: 'inline-block',
              padding: '8px 16px',
              borderRadius: 8,
              fontSize: 13,
              fontWeight: 600,
              fontFamily: 'var(--font-ui)',
              textDecoration: 'none',
              background: 'transparent',
              color: zoomUrl ? 'var(--cream)' : '#fff',
              border: zoomUrl ? '1px solid rgba(251,250,244,.3)' : '1px solid var(--pink)',
              ...(zoomUrl ? {} : { background: 'var(--pink)' }),
            }}>
            📍 Get directions →
          </a>
        )}
      </div>
    </div>
  )
}

// v9.49.1 — Empty state. Renders ONLY when the member has at least one
// home group configured but none match today's day-of-week. Brand-new
// members (zero home groups) see nothing — they need Profile setup, not
// a Dashboard nudge.
//
// Voice: warm, recovery-knowing, never scolding. The Daily YRTCYK Group
// runs every day on the same Zoom (different host, different format) —
// the card surfaces it as an always-available option. The "Open the
// Calendar" button is the action; it switches the App-level tab when a
// callback is provided.
function EmptyStateCard({ onOpenCalendar }) {
  return (
    <div style={{
      background: 'rgba(255,20,147,.04)',
      border: '1px dashed rgba(255,20,147,.32)',
      borderRadius: 12,
      padding: '18px 20px',
      marginBottom: 12,
    }}>
      <p style={{
        fontSize: 11,
        color: 'rgba(251,250,244,.5)',
        fontFamily: 'var(--font-ui)',
        letterSpacing: 1.4,
        margin: '0 0 10px 0',
        textTransform: 'uppercase',
      }}>
        🪄 No home group on the books today
      </p>
      <p style={{
        fontSize: 15,
        color: 'var(--cream)',
        fontFamily: 'Georgia, serif',
        lineHeight: 1.6,
        margin: '0 0 14px 0',
      }}>
        But the rooms never close, darling. The{' '}
        <span style={{ color: 'var(--pink)', fontWeight: 600 }}>Daily YRTCYK Group</span>{' '}
        runs <strong style={{ color: 'var(--cream)' }}>EVERY DAY</strong> · same Zoom ·
        same time · different format & hosts. Your seat is always saved.
        Or peek at the{' '}
        <span style={{ color: 'var(--pink)', fontWeight: 600 }}>Calendar</span>{' '}
        and see who else is showing up for themselves today.
      </p>
      {onOpenCalendar && (
        <button
          onClick={onOpenCalendar}
          style={{
            display: 'inline-block',
            padding: '8px 16px',
            borderRadius: 8,
            fontSize: 13,
            fontWeight: 600,
            fontFamily: 'var(--font-ui)',
            background: 'transparent',
            color: 'var(--pink)',
            border: '1px solid var(--pink)',
            cursor: 'pointer',
          }}>
          📅 Open the Calendar →
        </button>
      )}
    </div>
  )
}

export default function MeetingCard({ memberId, memberTz, onOpenCalendar }) {
  const [rows, setRows] = useState([])
  const [, setTick] = useState(0)

  // Fetch this member's home groups once on mount.
  useEffect(() => {
    if (!memberId) return
    let cancelled = false
    supabase
      .from('member_home_groups')
      .select('id, program, home_group_name, day, meeting_time, format, location_or_zoom, address')
      .eq('member_id', memberId)
      .then(({ data, error }) => {
        if (cancelled) return
        if (error) { console.warn('[MeetingCard] load failed:', error.message); return }
        setRows(data || [])
      })
    return () => { cancelled = true }
  }, [memberId])

  // Auto-tick every 60 seconds so the countdown labels update without reload.
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 60000)
    return () => clearInterval(id)
  }, [])

  // Annotate each row with minutesUntil and filter to today's day-of-week.
  // v9.51.4: minutesUntil !== null is the day-of-week gate (returns null
  // when today doesn't match meeting.day). No additional time-window
  // restriction — show all day on its scheduled day.
  const visible = rows
    .map(r => ({ ...r, minutesUntil: computeMinutesUntil(r.day, r.meeting_time, memberTz) }))
    .filter(r => r.minutesUntil !== null)
    .sort((a, b) => a.minutesUntil - b.minutesUntil)

  // No home groups configured at all → render nothing. Brand-new members
  // need Profile setup, not a nudge.
  if (rows.length === 0) return null

  // Has home groups, has a qualifying meeting today → render meeting card(s).
  if (visible.length > 0) {
    return (
      <div style={{ marginBottom: 20 }}>
        <style>{`
          @keyframes yfgMeetingPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(255,20,147,0); }
            50%      { box-shadow: 0 0 0 6px rgba(255,20,147,.12); }
          }
        `}</style>
        {visible.map(r => <SingleCard key={r.id} row={r}/>)}
      </div>
    )
  }

  // Has home groups, none today → empty-state nudge.
  return (
    <div style={{ marginBottom: 20 }}>
      <EmptyStateCard onOpenCalendar={onOpenCalendar}/>
    </div>
  )
}
