// v9.51 — Member Directory rebuild.
//
// Two material changes from v9.50:
//   1. The flat row list becomes a 2–4 column responsive grid of square
//      photo tiles. Tiles use the avatar as a full-bleed background
//      with a gradient overlay carrying display name + badges + program
//      count. This collapses the original Item 14 stages 1–4 ask into a
//      single ship.
//   2. The per-member detail view renders via the shared <ProfileSnapshot/>
//      component, which is the same JSX used by ProfilePage Preview tab.
//      That guarantees what a member sees in their own Preview equals
//      exactly what someone else sees when tapping their tile.
//
// Member-row fetch on the directory list pulls only the columns needed
// for tile rendering. When a tile is clicked, the detail view fetches
// the supporting data lazily: member_home_groups, member_sponsor_links,
// member_sponsee_links, hero_showcases for that member, word_of_mouth
// places, and a small membersById map of all community members for chip
// resolution + consent gating. Avoids O(N) joins at directory render
// time.

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'
import ProfileSnapshot from './ProfileSnapshot'
import { getMyMemberId, blockMember } from './blocks'

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
// v9.51 — Picklist must mirror ProfilePage canonical PROGRAMS list.
// SMART Recovery / Refuge Recovery / Other are NOT in the platform
// fellowship roster (per v9.48.x picklist hardening).
const PROGRAMS = ['AA','ACoA','Al-Anon','CMA','CoDA','GA','NA','OA','SLAA','Stopped Smoking']

function initials(m) {
  const n = m.display_name || m.email || ''
  return n.split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase().slice(0,2) || '?'
}

export default function MemberDirectory({ user, isAdmin, onEditAsAdmin }) {
  const [members, setMembers]     = useState([])
  const [search, setSearch]       = useState('')
  const [selected, setSelected]   = useState(null)
  const [loading, setLoading]     = useState(true)
  const [showFilters, setShowFilters] = useState(false)
  const [showLegend, setShowLegend]   = useState(false)
  // v9.56 — current member's id, for the Block control + writes.
  const [myId, setMyId] = useState(null)

  // Detail-view supporting data — fetched on click.
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailHomeGroups, setDetailHomeGroups]   = useState({1:null,2:null,3:null})
  const [detailSponsorLinks, setDetailSponsorLinks] = useState({1:null,2:null,3:null})
  const [detailSponseeLinks, setDetailSponseeLinks] = useState({1:[],2:[],3:[]})
  const [detailGoalLinks, setDetailGoalLinks]   = useState({}) // v9.51 Item 7
  const [detailHeroes, setDetailHeroes]   = useState([])
  const [detailWomPlaces, setDetailWomPlaces] = useState([])
  const [detailContributions, setDetailContributions] = useState(null)
  const [detailMembersById, setDetailMembersById]   = useState(new Map())

  // Filters
  const [filterType, setFilterType]     = useState('all')
  const [filterProgram, setFilterProgram] = useState('')
  const [filterCity, setFilterCity]     = useState('')
  const [filterTimezone, setFilterTimezone] = useState('')
  const [filterBdayMonth, setFilterBdayMonth] = useState('')
  const [filterAnnivMonth, setFilterAnnivMonth] = useState('')

  useEffect(() => { load(); getMyMemberId(user.email).then(setMyId) }, [])

  async function load() {
    // v9.51 — Tile-rendering needs avatar + display fields + badges +
    // program list + filterable date columns + show-flags. Detail-view
    // expansion fetches the rest lazily.
    const { data } = await supabase
      .from('members')
      .select(`
        id,email,display_name,first_name,last_name,
        avatar_url,
        is_active,is_moderator,is_trailblazer,is_operator,
        member_number,membership_start_date,membership_end_reason,
        program_1,program_1_date,program_2,program_2_date,program_3,program_3_date,
        city,timezone,birth_date,
        show_full_name,show_age,show_phone,phone,show_email,
        show_pronouns,show_location,show_birthday,
        pronouns
      `)
      .eq('is_active', true)
      .order('display_name')
    setMembers(data || [])
    setLoading(false)
  }

  // ── Detail loader: fetch full member row + supporting data on click ──
  async function loadDetail(memberRow) {
    setDetailLoading(true)
    setSelected(memberRow) // tile-level data first so the header renders immediately
    try {
      const [
        { data: full },
        { data: hgRows },
        { data: spRows },
        { data: seRows },
        { data: glRows },
        { data: heroRows },
        { data: womRows },
        { data: blogRows },
        { data: blogCommentsRows },
        { data: refRows },
        { data: communityMembers },
      ] = await Promise.all([
        supabase.from('members').select('*').eq('id', memberRow.id).single(),
        supabase.from('member_home_groups').select('id,slot,program,home_group_name,day,meeting_time,format,location_or_zoom,address,notes,place_id,place_lat,place_lng').eq('member_id', memberRow.id),
        supabase.from('member_sponsor_links').select('id,slot,sponsor_member_id').eq('member_id', memberRow.id),
        supabase.from('member_sponsee_links').select('id,slot,sponsee_member_id').eq('member_id', memberRow.id),
        // v9.51 Item 7 — Goal URL recommendations for this member
        supabase.from('member_goal_links').select('id,topic,slot,url,label').eq('member_id', memberRow.id),
        supabase.from('hero_showcases').select('id,hero_name,hero_type,tagline,photos,thumbnail_index,status').eq('member_id', memberRow.id).eq('status', 'approved'),
        supabase.from('word_of_mouth').select('id,business_name,category,city,website_url,place_id').eq('member_id', memberRow.id).order('created_at', { ascending: false }),
        supabase.from('blog_posts').select('id').eq('author_id', memberRow.id),
        supabase.from('blog_comments').select('id').eq('author_id', memberRow.id),
        supabase.from('referrals').select('id,status').eq('referrer_id', memberRow.id),
        supabase.from('members').select('id,display_name,email,first_name,last_name,avatar_url,allow_sponsor_tags,allow_sponsee_tags').eq('is_operator', false),
      ])

      if (full) setSelected(full)

      const hgMap = { 1:null, 2:null, 3:null }
      ;(hgRows || []).forEach(r => { hgMap[r.slot] = r })
      setDetailHomeGroups(hgMap)

      const spMap = { 1:null, 2:null, 3:null }
      ;(spRows || []).forEach(r => { spMap[r.slot] = r })
      setDetailSponsorLinks(spMap)

      const seMap = { 1:[], 2:[], 3:[] }
      ;(seRows || []).forEach(r => { (seMap[r.slot] = seMap[r.slot] || []).push(r) })
      setDetailSponseeLinks(seMap)

      // v9.51 Item 7 — Group goal-link rows by topic + slot for ProfileSnapshot
      const glMap = {}
      ;(glRows || []).forEach(r => {
        if (!glMap[r.topic]) glMap[r.topic] = { 1: null, 2: null }
        glMap[r.topic][r.slot] = { id: r.id, url: r.url, label: r.label }
      })
      setDetailGoalLinks(glMap)

      setDetailHeroes(heroRows || [])
      setDetailWomPlaces(womRows || [])

      const heroes = heroRows || []
      setDetailContributions({
        referred:      (refRows || []).length,
        joined:        (refRows || []).filter(r => r.status !== 'invited').length,
        heroes_person: heroes.filter(h => h.hero_type === 'person').length,
        heroes_place:  heroes.filter(h => h.hero_type === 'place').length,
        heroes_thing:  heroes.filter(h => h.hero_type === 'thing').length,
        blog_posts:    (blogRows || []).length,
        blog_comments: (blogCommentsRows || []).length,
      })

      setDetailMembersById(new Map((communityMembers || []).map(m => [m.id, m])))
    } catch (e) {
      console.error('[MemberDirectory] loadDetail failed:', e)
    }
    setDetailLoading(false)
  }

  // ── Filters / lists ──
  const cities    = [...new Set(members.filter(m => m.city && m.show_location).map(m => m.city))].sort()
  const timezones = [...new Set(members.filter(m => m.timezone).map(m => m.timezone))].sort()
  const activeFilters = [filterProgram, filterCity, filterTimezone, filterBdayMonth, filterAnnivMonth].filter(Boolean).length

  const filtered = members.filter(m => {
    const q = (search || '').toLowerCase()
    if (q && !(m.display_name || m.email || '').toLowerCase().includes(q)) return false
    if (filterType === 'admin') {
      if (!m.is_operator) return false
    } else {
      if (m.is_operator) return false
    }
    if (filterType === 'moderators' && !m.is_moderator && !(isAdmin && m.email === user.email)) return false
    if (filterType === 'trailblazers' && !m.is_trailblazer) return false
    if (filterType === 'founding' && !(typeof m.member_number === 'number' && m.member_number >= 1 && m.member_number <= 100)) return false
    if (filterProgram && ![m.program_1, m.program_2, m.program_3].includes(filterProgram)) return false
    if (filterCity && m.city !== filterCity) return false
    if (filterTimezone && m.timezone !== filterTimezone) return false
    if (filterBdayMonth) {
      if (!m.birth_date || !m.show_birthday) return false
      const mo = new Date(m.birth_date + 'T00:00:00').getMonth()
      if (String(mo) !== filterBdayMonth) return false
    }
    if (filterAnnivMonth) {
      const dates = [m.program_1_date, m.program_2_date, m.program_3_date].filter(Boolean)
      if (!dates.length) return false
      const matches = dates.some(d => String(new Date(d + 'T00:00:00').getMonth()) === filterAnnivMonth)
      if (!matches) return false
    }
    return true
  })

  function clearFilters() {
    setFilterType('all'); setFilterProgram(''); setFilterCity('')
    setFilterTimezone(''); setFilterBdayMonth(''); setFilterAnnivMonth('')
  }

  const isMe = m => m.email === user.email

  // v9.56 — Block a member. Mutual + silent. The members restrictive policy
  // (can_see) makes the blocked member vanish from this directory in both
  // directions on the next load(), so after a successful block we return to
  // the grid and refetch — the list comes back already filtered.
  async function handleBlock(target) {
    const name = target.display_name || (target.email || '').split('@')[0] || 'this member'
    if (!window.confirm(
      `Block ${name}?\n\nThey will no longer see your profile, and you won't see them anywhere in the community. Blocking is silent — they are not notified. You can unblock anytime from Profile → My Account.`
    )) return
    const { error } = await blockMember(myId, target.id)
    if (error) { window.alert('Could not block right now. Please try again in a moment.'); return }
    setSelected(null)
    load()
  }
  function tzLabel(tz) {
    const map = {
      'America/Los_Angeles':'Pacific','America/Denver':'Mountain','America/Chicago':'Central',
      'America/New_York':'Eastern','America/Anchorage':'Alaska','Pacific/Honolulu':'Hawaii',
      'Europe/London':'London','Europe/Paris':'Central Europe','Asia/Tokyo':'Tokyo',
      'Australia/Sydney':'Sydney','UTC':'UTC'
    }
    return map[tz] || tz
  }

  // ── DETAIL VIEW ── v9.51: ProfileSnapshot rendering
  if (selected) {
    return (
      <div style={{paddingTop:20, paddingBottom:40}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20, gap:12, flexWrap:'wrap'}}>
          <button onClick={() => { setSelected(null) }}
            style={{color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)'}}>
            ← Back to Members
          </button>
          {/* v9.46 Item 1 — Edit as Admin button. Visible only for is_operator
              users editing somebody other than themselves. The two-account model
              relies on this never appearing on yourfairygodfather@me.com. */}
          {isAdmin && !isMe(selected) && onEditAsAdmin && (
            <button
              onClick={() => onEditAsAdmin(selected.id)}
              title={`Open ${selected.display_name || (selected.email || '').split('@')[0]}'s profile in admin-edit mode`}
              style={{
                padding:'8px 14px', borderRadius:8,
                background:'rgba(255,20,147,.12)', border:'1px solid rgba(255,20,147,.35)',
                color:'var(--pink)', fontSize:12, fontFamily:'var(--font-ui)',
                fontWeight:600, cursor:'pointer', whiteSpace:'nowrap',
              }}>
              ✏️ Edit as Admin
            </button>
          )}

          {/* v9.56 — Block control. Shown to ordinary members viewing another
              non-admin member. Admins moderate (they get Edit-as-Admin
              instead), the operator account can't be blocked, and you can't
              block yourself. */}
          {!isAdmin && myId && !isMe(selected) && !selected.is_operator && (
            <button
              onClick={() => handleBlock(selected)}
              title={`Block ${selected.display_name || (selected.email || '').split('@')[0]}`}
              style={{
                padding:'8px 14px', borderRadius:8,
                background:'rgba(255,255,255,.05)', border:'1px solid rgba(255,255,255,.18)',
                color:'rgba(251,250,244,.6)', fontSize:12, fontFamily:'var(--font-ui)',
                fontWeight:600, cursor:'pointer', whiteSpace:'nowrap',
              }}>
              🚫 Block
            </button>
          )}
        </div>

        {detailLoading && (
          <div style={{display:'flex', justifyContent:'center', padding:'20px 0'}}>
            <div className="spinner"/>
          </div>
        )}

        <ProfileSnapshot
          member={selected}
          homeGroups={detailHomeGroups}
          sponsorLinks={detailSponsorLinks}
          sponseeLinks={detailSponseeLinks}
          goalLinks={detailGoalLinks}
          membersById={detailMembersById}
          approvedHeroes={detailHeroes}
          womPlaces={detailWomPlaces}
          contributions={detailContributions}
          viewMode="community"
          onTaggedMemberClick={(memberId) => {
            // Navigate to that member by tile-data lookup. If they're not
            // in the loaded list (rare — operator filter, etc.), fall back
            // to fetching by id.
            const target = members.find(m => m.id === memberId)
            if (target) loadDetail(target)
          }}
        />

        {/* Special closing line for Admin profile per v9.50 tradition */}
        {selected.email === 'gvitrano@icloud.com' && (
          <div className="card" style={{background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.1)', marginTop:12}}>
            <p style={{fontSize:13, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', lineHeight:1.75, fontStyle:'italic'}}>
              "When someone shows you who they are, believe them the first time." — Maya Angelou. Your Fairy Godfather shows up every day without fail. 🪄
            </p>
          </div>
        )}
      </div>
    )
  }

  // ── DIRECTORY GRID VIEW ──
  return (
    <div style={{paddingTop:20, paddingBottom:40}}>
      <h2 style={{fontSize:20, fontWeight:400, marginBottom:16}}>Members 👥</h2>

      {/* Search + filter row */}
      <div style={{display:'flex', gap:8, marginBottom:12}}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search members…" style={{flex:1}}/>
        <button onClick={()=>setShowFilters(f=>!f)}
          style={{padding:'10px 14px', borderRadius:8, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer', whiteSpace:'nowrap',
            background: showFilters || activeFilters > 0 ? 'rgba(255,20,147,.15)' : 'rgba(255,255,255,.07)',
            border: `1px solid ${showFilters || activeFilters > 0 ? 'rgba(255,20,147,.3)' : 'rgba(255,255,255,.1)'}`,
            color: showFilters || activeFilters > 0 ? 'var(--pink)' : 'rgba(251,250,244,.55)'}}>
          Filters{activeFilters > 0 ? ` (${activeFilters})` : ''} {showFilters ? '▲' : '▾'}
        </button>
        <button onClick={()=>setShowLegend(l=>!l)} title="Show badge legend"
          style={{padding:'10px 12px', borderRadius:8, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer', whiteSpace:'nowrap',
            background: showLegend ? 'rgba(255,20,147,.15)' : 'rgba(255,255,255,.07)',
            border: `1px solid ${showLegend ? 'rgba(255,20,147,.3)' : 'rgba(255,255,255,.1)'}`,
            color: showLegend ? 'var(--pink)' : 'rgba(251,250,244,.55)'}}>
          Badges ℹ️
        </button>
      </div>

      {/* Badge Legend */}
      {showLegend && (
        <div className="card" style={{marginBottom:16, background:'rgba(255,255,255,.03)', padding:16}}>
          <p style={{fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:12}}>BADGE LEGEND</p>
          <div style={{display:'flex', flexDirection:'column', gap:14}}>
            <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
              <div style={{flexShrink:0, minWidth:110}}><MemberBadges member={{ email:'gvitrano@icloud.com' }} size="md"/></div>
              <p style={{fontSize:12, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)', lineHeight:1.5, flex:1}}>
                The System Administrator. The only free account on the platform. Approves Hero submissions, awards Trailblazer badges, manages the member community. Reserved for the Founder.
              </p>
            </div>
            <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
              <div style={{flexShrink:0, minWidth:110}}><MemberBadges member={{ email:'x@x.com', is_trailblazer:true }} size="md"/></div>
              <p style={{fontSize:12, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)', lineHeight:1.5, flex:1}}>
                One of the Original. Hand-awarded by Admin to members whose contributions have shaped the community in lasting ways. A rare and personal recognition — earned, not requested.
              </p>
            </div>
            <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
              <div style={{flexShrink:0, minWidth:110}}><MemberBadges member={{ email:'x@x.com', member_number:50 }} size="md"/></div>
              <p style={{fontSize:12, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)', lineHeight:1.5, flex:1}}>
                One of the first 100 paying members of YRTCYK. Automatically and permanently awarded to members #1 through #100 based on join order. A piece of platform history — worn for life.
              </p>
            </div>
            <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
              <div style={{flexShrink:0, minWidth:110}}><MemberBadges member={{ email:'x@x.com', is_moderator:true }} size="md"/></div>
              <p style={{fontSize:12, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)', lineHeight:1.5, flex:1}}>
                Elected community moderator. Granted by Admin to paying members who have earned the community's trust through consistent participation. Helps enforce House Rules on Reflections and flag issues. Moderators pay the standard $5.99/month — the badge carries no discount.
              </p>
            </div>
            <div style={{display:'flex', alignItems:'flex-start', gap:12}}>
              <div style={{flexShrink:0, minWidth:110}}><MemberBadges member={{ email:'x@x.com', membership_end_reason:'deceased' }} size="md"/></div>
              <p style={{fontSize:12, color:'rgba(251,250,244,.65)', fontFamily:'var(--font-ui)', lineHeight:1.5, flex:1}}>
                A member we have lost. Applied by Admin with family consent. Their Heroes, Reflections, and presence in the community are preserved in accordance with House Rule #6 — <em>the door doesn't close behind you</em>.
              </p>
            </div>
          </div>
          <p style={{fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', lineHeight:1.5, marginTop:14, paddingTop:14, borderTop:'1px solid rgba(255,255,255,.06)'}}>
            Profiles can display up to three badges. Members can earn more than one — a Founding Member can also be a Moderator, and a Moderator who has passed will be remembered with both their 💜 and 🕊️ badges.
          </p>
        </div>
      )}

      {/* Quick type filters */}
      <div style={{display:'flex', gap:8, marginBottom: showFilters ? 0 : 16, flexWrap:'wrap'}}>
        {[['all','All Members'],['moderators','🪄 Moderators'],['trailblazers','✨ Trailblazers'],['founding','🌈 Founding'],['admin','👑 Admin']].map(([val,label]) => (
          <button key={val} onClick={()=>setFilterType(val)}
            style={{padding:'6px 14px', borderRadius:20, fontFamily:'var(--font-ui)', fontSize:12, cursor:'pointer',
              background: filterType === val ? 'var(--pink)' : 'rgba(255,255,255,.07)',
              color:      filterType === val ? '#fff'        : 'rgba(251,250,244,.55)',
              border: `1px solid ${filterType === val ? 'var(--pink)' : 'rgba(255,255,255,.1)'}`}}>
            {label}
          </button>
        ))}
      </div>

      {/* Expanded filter panel */}
      {showFilters && (
        <div className="card" style={{marginTop:12, marginBottom:16, background:'rgba(255,255,255,.03)'}}>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10}}>
            <div>
              <p style={{fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:5}}>PROGRAM</p>
              <select value={filterProgram} onChange={e=>setFilterProgram(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {PROGRAMS.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
            <div>
              <p style={{fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:5}}>CITY</p>
              <select value={filterCity} onChange={e=>setFilterCity(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {cities.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <p style={{fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:5}}>TIMEZONE</p>
              <select value={filterTimezone} onChange={e=>setFilterTimezone(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {timezones.map(t => <option key={t} value={t}>{tzLabel(t)}</option>)}
              </select>
            </div>
            <div>
              <p style={{fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:5}}>BIRTHDAY MONTH</p>
              <select value={filterBdayMonth} onChange={e=>setFilterBdayMonth(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {MONTHS.map((m, i) => <option key={i} value={String(i)}>{m}</option>)}
              </select>
            </div>
            <div>
              <p style={{fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:5}}>SOBRIETY ANNIVERSARY MONTH</p>
              <select value={filterAnnivMonth} onChange={e=>setFilterAnnivMonth(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {MONTHS.map((m, i) => <option key={i} value={String(i)}>{m}</option>)}
              </select>
            </div>
          </div>
          {activeFilters > 0 && (
            <button onClick={clearFilters}
              style={{fontSize:12, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.45)', background:'none', border:'none', cursor:'pointer', padding:0, marginTop:4}}>
              ✕ Clear all filters
            </button>
          )}
        </div>
      )}

      {loading && <div className="spinner"/>}

      {!loading && (
        <p style={{fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', marginBottom:14}}>
          {filtered.length} member{filtered.length !== 1 ? 's' : ''}
          {activeFilters > 0 || search ? ' matching' : ' total'}
        </p>
      )}

      {!loading && filtered.length === 0 && (
        <p style={{color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14, textAlign:'center', paddingTop:30}}>No members found.</p>
      )}

      {/* ── Tile grid ── responsive: 2 cols on mobile, auto-fills wider */}
      <div style={{
        display:'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(140px, 1fr))',
        gap: 10,
      }}>
        {filtered.map(m => <MemberTile key={m.id} m={m} onClick={() => loadDetail(m)} isMe={isMe(m)}/>)}
      </div>
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────
// MemberTile — v9.51.1: mirrors the Heroes gallery card pattern.
// Square photo header (full-bleed, no overlay text), body panel below
// with name + badges + program pill. Photo never gets covered.
// ────────────────────────────────────────────────────────────────────

function MemberTile({ m, onClick, isMe }) {
  const programs = [m.program_1, m.program_2, m.program_3].filter(Boolean)
  const programsLabel = programs.length > 0
    ? (programs.length === 1 ? programs[0] : `${programs[0]} +${programs.length - 1}`)
    : null
  const name = m.display_name || (m.email || '').split('@')[0] || 'Member'
  const hasAvatar = !!m.avatar_url

  return (
    <div
      onClick={onClick}
      className="card"
      style={{
        cursor:'pointer',
        overflow:'hidden',
        padding:0,
        display:'flex',
        flexDirection:'column',
        transition:'transform .15s, border-color .15s, box-shadow .15s',
      }}
      onMouseEnter={e => {
        e.currentTarget.style.transform = 'translateY(-2px)'
        e.currentTarget.style.borderColor = 'rgba(255,20,147,.5)'
        e.currentTarget.style.boxShadow = '0 6px 20px rgba(255,20,147,.18)'
      }}
      onMouseLeave={e => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.borderColor = ''
        e.currentTarget.style.boxShadow = 'none'
      }}
    >
      {/* Photo region — square, full-bleed. Nothing overlaid except the
          "YOU" pip for the current member. */}
      <div style={{
        position:'relative',
        width:'100%',
        aspectRatio:'1 / 1',
        overflow:'hidden',
        background: hasAvatar
          ? '#01280e'
          : 'linear-gradient(135deg, rgba(255,20,147,.18), rgba(25,229,94,.10))',
      }}>
        {hasAvatar ? (
          <img src={m.avatar_url} alt="" style={{ width:'100%', height:'100%', objectFit:'cover' }}/>
        ) : (
          <div style={{ width:'100%', height:'100%', display:'flex', alignItems:'center', justifyContent:'center' }}>
            <span style={{ fontSize:34, fontWeight:700, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:1 }}>
              {initials(m)}
            </span>
          </div>
        )}
        {isMe && (
          <span style={{
            position:'absolute', top:8, right:8,
            padding:'2px 8px', borderRadius:20,
            background:'rgba(25,229,94,.85)', color:'#01280e',
            fontSize:9, fontFamily:'var(--font-ui)', fontWeight:700,
            letterSpacing:.5,
          }}>YOU</span>
        )}
      </div>

      {/* Body region — name + badges + program. Same padding rhythm as
          the Heroes card body (10px / 12px) for visual continuity. */}
      <div style={{
        padding:'10px 12px',
        flex:1,
        display:'flex',
        flexDirection:'column',
        gap:6,
        textAlign:'left',
      }}>
        <h3 style={{
          fontSize:14,
          fontWeight:600,
          lineHeight:1.3,
          fontFamily:'var(--font-serif)',
          color:'var(--cream)',
          overflow:'hidden',
          textOverflow:'ellipsis',
          whiteSpace:'nowrap',
          maxWidth:'100%',
        }}>{name}</h3>
        <div style={{ display:'flex', alignItems:'center', gap:6, flexWrap:'wrap' }}>
          <MemberBadges member={m} size="sm"/>
          {programsLabel && (
            <span style={{
              fontSize:10, color:'rgba(251,250,244,.65)',
              fontFamily:'var(--font-ui)',
              padding:'1px 7px', borderRadius:20,
              background:'rgba(25,229,94,.12)', border:'1px solid rgba(25,229,94,.22)',
            }}>{programsLabel}</span>
          )}
        </div>
      </div>
    </div>
  )
}
