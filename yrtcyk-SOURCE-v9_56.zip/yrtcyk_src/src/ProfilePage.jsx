import { useState, useEffect, useRef } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'
import ProfileSnapshot from './ProfileSnapshot'
import BlockedMembers from './BlockedMembers'

const DEFAULT_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88" viewBox="0 0 88 88"><circle cx="44" cy="44" r="44" fill="#01280e"/><circle cx="44" cy="44" r="42" fill="none" stroke="#FF1493" stroke-width="2"/><text x="44" y="52" text-anchor="middle" font-family="Georgia,serif" font-size="28" font-weight="700" fill="#FF1493">YFG</text></svg>')}`

const TIMEZONES = [
  ['America/Los_Angeles','Pacific Time (LA, SF, Seattle)'],
  ['America/Denver','Mountain Time (Denver, Phoenix)'],
  ['America/Chicago','Central Time (Chicago, Dallas)'],
  ['America/New_York','Eastern Time (NYC, Miami, Boston)'],
  ['America/Anchorage','Alaska Time'],
  ['Pacific/Honolulu','Hawaii Time'],
  ['Europe/London','London / Dublin'],
  ['Europe/Paris','Central Europe — Paris, Berlin, Rome'],
  ['Europe/Athens','Eastern Europe — Athens, Helsinki'],
  ['Asia/Dubai','Gulf Time — Dubai, Abu Dhabi'],
  ['Asia/Kolkata','India Standard Time'],
  ['Asia/Tokyo','Japan / Korea'],
  ['Australia/Sydney','Eastern Australia'],
  ['Pacific/Auckland','New Zealand'],
  ['UTC','UTC'],
]
const PRONOUNS     = ['He/Him','She/Her','They/Them','He/They','She/They','Ze/Zir','Any/All','Prefer not to say']
const ORIENTATIONS = ['Gay','Lesbian','Bisexual','Pansexual','Queer','Straight/Heterosexual','Asexual','Prefer not to say']
const GENDERS      = ['Man','Woman','Non-binary','Genderqueer','Genderfluid','Transgender Man','Transgender Woman','Two-Spirit','Prefer not to say']
const ETHNICITIES  = ['Asian/Pacific Islander','Black/African American','Hispanic/Latino','Indigenous/Native American','Middle Eastern/North African','Multiracial','White/Caucasian','Prefer not to say']
const LANGUAGES    = ['English','Spanish','French','Portuguese','German','Italian','Mandarin','Cantonese','Japanese','Korean','Arabic','Hindi','Russian','Other']
const PET_TYPES    = ['Dog','Cat','Bird','Fish','Rabbit','Hamster/Guinea Pig','Reptile','Horse','Other']
// v9.48.1 — Recovery program picklist.
//
// Each entry has:
//   value: short code stored in members.program_1/2/3 (preserves existing data)
//   label: full official name shown in the dropdown
//
// Removed in v9.47.3: SMART Recovery, Refuge Recovery (no active members
// using either at time of removal — safe).
// Added in v9.47.3: CoDA (in v9.47.2), ACoA.
// v9.48.1: Removed "Other" — the canonical 9-program list is sufficient and
//   "Other" gave the impression of an incomplete catalog. Added "Stopped
//   Smoking" — sobriety milestone with a counter but no meeting structure
//   (no home group, no directory URL, no fellowship to attend).
// v9.48.2: Added CMA (Crystal Meth Anonymous). Added per-fellowship verb
//   used in the SobrietyCounter header — different programs use different
//   words for the time-since milestone (sober / clean / abstinent /
//   in active recovery / smoke-free).
//
// Display elsewhere (Calendar, Member Directory) renders the value, so the
// short code remains how the program appears in conversation
// ("Maya's AA Anniversary 🏅"). The dropdown is the only place we expand to
// the official name so newcomers know what each abbreviation means.
//
// MEETING_DIRECTORY_URLS — canonical per-program meeting-finder URLs
// confirmed by Geo May 7, 2026. "Stopped Smoking" intentionally omitted
// (no organized fellowship); the directory link silently does not render
// for any program absent from this map.
//
// PROGRAMS_WITHOUT_HOME_GROUPS — programs that should NOT render the
// per-slot Home Group card. "Stopped Smoking" is a personal milestone
// without meetings; the slot only collects the sobriety/effective date and
// the polished counter.
const PROGRAMS = [
  { value: 'AA',              label: 'Alcoholics Anonymous (AA)' },
  { value: 'ACoA',            label: 'Adult Children of Alcoholics (ACoA)' },
  { value: 'Al-Anon',         label: 'Al-Anon Family Groups' },
  { value: 'CMA',             label: 'Crystal Meth Anonymous (CMA)' },
  { value: 'CoDA',            label: 'Co-Dependents Anonymous (CoDA)' },
  { value: 'GA',              label: 'Gamblers Anonymous (GA)' },
  { value: 'NA',              label: 'Narcotics Anonymous (NA)' },
  { value: 'OA',              label: 'Overeaters Anonymous (OA)' },
  { value: 'SLAA',            label: 'Sex and Love Addicts Anonymous (SLAA)' },
  { value: 'Stopped Smoking', label: 'Stopped Smoking' },
]

export const MEETING_DIRECTORY_URLS = {
  'AA':       'https://www.aa.org/find-aa',
  'ACoA':     'https://adultchildren.org/',
  'Al-Anon':  'https://al-anon.org/',
  'CMA':      'https://www.crystalmeth.org/',
  'CoDA':     'https://coda.org/',
  'GA':       'https://gamblersanonymous.org/find-a-meeting/',
  'NA':       'https://na.org/meetingsearch/',
  'OA':       'https://oa.org/',
  'SLAA':     'https://slaafws.org/meetings/',
}

// Programs that don't have organized meetings — render the sobriety counter
// only, suppress the Home Group card. Add new milestone-only programs here.
const PROGRAMS_WITHOUT_HOME_GROUPS = ['Stopped Smoking']

// v9.50 — Per-program emoji icons for Recovery tab card headers. The icon and
// program name BOTH link to MEETING_DIRECTORY_URLS[program]. Stopped Smoking
// has no directory URL → icon and name render as plain text (no link).
const PROGRAM_ICONS = {
  'AA':              '🍃',
  'ACoA':            '🌳',
  'Al-Anon':         '🤝',
  'CMA':             '❄️',
  'CoDA':            '🔗',
  'GA':              '🎲',
  'NA':              '💊',
  'OA':              '🍽️',
  'SLAA':            '💗',
  'Stopped Smoking': '🚭',
}

// v9.50 — Sponsorship status options. Stored on members.sponsor_status_<slot>.
// Mirrors the schema CHECK constraint exactly.
const SPONSOR_STATUSES = [
  { value: 'has',     label: 'Has one' },
  { value: 'looking', label: 'Looking' },
  { value: 'none',    label: 'None' },
]

// v9.50 — Sponsee count buckets. Stored on members.sponsee_count_<slot>.
// Mirrors the schema CHECK constraint exactly.
const SPONSEE_COUNTS = [
  { value: 'none',   label: 'None' },
  { value: '1',      label: '1' },
  { value: '2',      label: '2' },
  { value: '3',      label: '3' },
  { value: '4_plus', label: '4+' },
]

// v9.50 — Reused from WordOfMouth. Same Cloud project, billing already enabled.
const GOOGLE_MAPS_KEY = 'AIzaSyAh1IwlpWmi9DiKd2-HJRW_1rrhY3z1dzw'

// v9.48.2 — Per-fellowship time-since-milestone verb.
// Different programs use different words: AA/SLAA say "sober",
// NA/CMA say "clean", OA/GA say "abstinent", relational programs
// (Al-Anon/ACoA/CoDA) say "in active recovery", and Stopped Smoking
// says "smoke-free". Defaults to "in active recovery" for any unknown
// program (defensive — picklist is closed, so this should never fire).
const SOBRIETY_VERB = {
  'AA':              'sober',
  'ACoA':            'in active recovery',
  'Al-Anon':         'in active recovery',
  'CMA':             'clean',
  'CoDA':            'in active recovery',
  'GA':              'abstinent',
  'NA':              'clean',
  'OA':              'abstinent',
  'SLAA':            'sober',
  'Stopped Smoking': 'smoke-free',
}

const WELLNESS_AREAS = [
  { key:'physical',     label:'Physical Health',          icon:'💪', topics:['Walking / Hiking','Running / Jogging','Weight Training','Yoga','Pilates','Swimming','Cycling','Team Sports','Dance','Martial Arts','Sleep Hygiene','Nutrition & Eating Well','Sober Fitness','Weight Management','Chronic Pain Management'] },
  { key:'emotional',    label:'Emotional Wellbeing',      icon:'💙', topics:['Therapy / Counseling','Journaling','Emotional Regulation','Grief & Loss','Trauma Recovery','Anger Management','Self-Compassion','Boundaries','Anxiety Management','Depression Support','Mindfulness','Meditation','Breathwork','Inner Child Work','Somatic Work'] },
  { key:'spiritual',    label:'Spiritual Growth',         icon:'✨', topics:['Step Work','Prayer','Meditation','Nature Connection','Religious Practice','Buddhism / Mindfulness','Gratitude Practice','Service Work','Spiritual Literature','Retreats','12-Step Community','SMART Recovery','Faith Community','Purpose & Meaning','Forgiveness Work'] },
  { key:'social',       label:'Relationships & Community',icon:'🌈', topics:['Rebuilding Family Relationships','Friendships in Recovery','Dating in Sobriety','LGBTQ+ Community','Sponsorship','Finding a Home Group','Social Anxiety','Healthy Boundaries','Communication Skills','Conflict Resolution','Parenting in Recovery','Rebuilding Trust','Overcoming Loneliness','Making Amends','Community Involvement'] },
  { key:'financial',    label:'Financial & Occupational', icon:'🌱', topics:['Debt Recovery','Budgeting Basics','Saving & Investing','Career Development','Job Search','Work-Life Balance','Entrepreneurship','Education & Retraining','Gambling Recovery','Financial Amends','Credit Rebuilding','Housing Stability','Benefits Navigation','Retirement Planning','Workplace Relationships'] },
  { key:'intellectual', label:'Intellectual & Creative',  icon:'🎨', topics:['Reading','Writing','Music','Visual Arts','Photography','Cooking','Gardening','Learning New Skills','Online Courses','Podcasts & Audiobooks','Theater / Performance','Film & Cinema','Crafts & Hobbies','Language Learning','Technology'] },
  { key:'fun',          label:'Fun, Play & Adventure',    icon:'🎭', topics:['Travel','Camping & Outdoors','Live Music & Concerts','Comedy Shows','Gaming','Cooking Adventures','Day Trips','Trying New Restaurants','Sober Nightlife','Volunteering','Pets & Animals','Sports & Games','Theme Parks','Collecting','Sober Travel'] },
  { key:'environmental',label:'Home & Environment',       icon:'🏡', topics:['Decluttering & Organization','Creating a Safe Space','Home Improvement','Sustainability','Urban Gardening','Minimalism','Interior Design','Digital Detox','Nature Immersion','Animal Welfare','Sacred Space Creation','Neighborhood Community','Moving to a Sober Environment','Climate Consciousness','Intentional Living'] },
]

function parseList(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  try { const p = JSON.parse(val); if (Array.isArray(p)) return p } catch {}
  return val.split(',').map(s => s.trim()).filter(Boolean)
}
function parsePets(val) {
  if (!val) return []
  try {
    const p = JSON.parse(val)
    if (Array.isArray(p)) {
      if (p.length === 0) return []
      if (typeof p[0] === 'object' && p[0].type) return p
      return p.map(v => ({ type: v, name: '' }))
    }
  } catch {}
  if (typeof val === 'string' && val.trim()) return [{ type:'Dog', name: val }]
  return []
}
function formatPhone(val) {
  const d = (val||'').replace(/\D/g,'').slice(0,10)
  if (d.length <= 3) return d
  if (d.length <= 6) return `(${d.slice(0,3)}) ${d.slice(3)}`
  return `(${d.slice(0,3)}) ${d.slice(3,6)}-${d.slice(6)}`
}
// v9.48 — sobriety stats. Returns decimal years/months and integer
// days/hours/minutes. The richer object powers the polished counter card
// in the Recovery tab; legacy `days`, `years`, and `label` are preserved
// so MemberDirectory and Preview tab consumers don't break.
function sobrietyStats(dateStr) {
  if (!dateStr) return null
  const start = new Date(dateStr + 'T00:00:00')
  const now = new Date()
  const diffMs = now - start
  if (diffMs < 0) return null
  const minutes = Math.floor(diffMs / 60000)
  const hours   = Math.floor(diffMs / 3600000)
  const days    = Math.floor(diffMs / 86400000)
  const yearsExact  = diffMs / (365.25 * 86400000)
  const monthsExact = yearsExact * 12
  let label = ''
  if (days < 30) label = `${days} day${days !== 1 ? 's' : ''}`
  else if (days < 365) label = `${Math.floor(days/30)} month${Math.floor(days/30)!==1?'s':''}`
  else {
    const y = Math.floor(yearsExact)
    const rem = days - Math.floor(y * 365.25)
    const m = Math.floor(rem / 30)
    label = `${y} yr${y!==1?'s':''}${m>0?` ${m} mo`:''}`
  }
  return {
    days, hours, minutes,
    years:        parseFloat(yearsExact.toFixed(1)),     // legacy field, kept for MemberDirectory etc.
    yearsExact,                                          // full precision for the counter
    monthsExact,                                         // full precision for the counter
    label,
  }
}
async function lookupZip(zip) {
  try {
    const res = await fetch(`https://api.zippopotam.us/us/${zip}`)
    if (!res.ok) return null
    const data = await res.json()
    const place = data.places?.[0]
    if (!place) return null
    return `${place['place name']}, ${place['state abbreviation']}`
  } catch { return null }
}


// ── Field helpers — defined OUTSIDE component to prevent focus loss on re-render ──
function Lbl({ t, sub, req }) {
  return <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:6,marginTop:16}}>{t}{req&&<span style={{color:'var(--pink)',marginLeft:4}}>*</span>}{sub&&<span style={{color:'rgba(251,250,244,.2)',marginLeft:6}}>{sub}</span>}</p>
}
function Inp({ fieldKey, P, set, ...props }) {
  return <input value={P[fieldKey]||''} onChange={e=>set(fieldKey,e.target.value)} {...props}/>
}
function Sel({ fieldKey, P, set, opts, ph }) {
  return <select value={P[fieldKey]||''} onChange={e=>set(fieldKey,e.target.value)}><option value="">{ph||'Select…'}</option>{opts.map(o=>Array.isArray(o)?<option key={o[0]} value={o[0]}>{o[1]}</option>:<option key={o} value={o}>{o}</option>)}</select>
}
function Chips({ fieldKey, P, set, opts }) {
  return <div style={{display:'flex',flexWrap:'wrap',gap:8,marginTop:8}}>{opts.map(o=>{const sel=(P[fieldKey]||[]).includes(o);return<button key={o} onClick={()=>set(fieldKey,(P[fieldKey]||[]).includes(o)?(P[fieldKey]||[]).filter(v=>v!==o):[...(P[fieldKey]||[]),o])} style={{padding:'6px 14px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:sel?'rgba(255,20,147,.18)':'rgba(255,255,255,.06)',border:`1px solid ${sel?'rgba(255,20,147,.35)':'rgba(255,255,255,.1)'}`,color:sel?'var(--pink)':'rgba(251,250,244,.6)',cursor:'pointer'}}>{o}</button>})}</div>
}
function Chk({ fieldKey, P, set, label }) {
  return <label style={{display:'flex',gap:10,alignItems:'center',cursor:'pointer',marginTop:12}}><input type="checkbox" checked={!!P[fieldKey]} onChange={e=>set(fieldKey,e.target.checked)} style={{width:18,height:18,accentColor:'var(--pink)',flexShrink:0}}/><span style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.65)'}}>{label}</span></label>
}

// v9.51 — Compact single-select. Shows the chosen value as a pink pill plus
// a "✏️ Change" affordance; tap reveals the full option list as wrapping
// pills inline. Selecting auto-collapses. Empty state offers a "Tap to
// choose" prompt that opens the picker. Keeps the Identity tab tight on
// PWA viewports without hiding the option library.
function PickOne({ fieldKey, P, set, opts, placeholder = 'Tap to choose' }) {
  const [open, setOpen] = useState(false)
  const value = P[fieldKey] || ''
  const norm = (o) => Array.isArray(o) ? { v: o[0], l: o[1] } : { v: o, l: o }
  const valueLabel = value ? (opts.map(norm).find(o => o.v === value)?.l || value) : null
  return (
    <div style={{ marginBottom: 4 }}>
      {!open && value && (
        <div style={{ display:'flex', alignItems:'center', gap:8, flexWrap:'wrap', marginTop:4 }}>
          <span style={{
            display:'inline-flex', alignItems:'center', gap:6,
            padding:'6px 12px', borderRadius:20,
            background:'rgba(255,20,147,.16)', border:'1px solid rgba(255,20,147,.4)',
            color:'var(--cream)', fontSize:13, fontFamily:'var(--font-ui)',
          }}>{valueLabel}</span>
          <button onClick={() => setOpen(true)}
            style={{
              padding:'5px 11px', borderRadius:20,
              background:'transparent', border:'1px dashed rgba(255,255,255,.2)',
              color:'rgba(251,250,244,.5)', fontSize:11, fontFamily:'var(--font-ui)',
              cursor:'pointer',
            }}>
            ✏️ Change
          </button>
        </div>
      )}
      {!open && !value && (
        <button onClick={() => setOpen(true)}
          style={{
            marginTop:4, padding:'7px 14px', borderRadius:20,
            background:'rgba(255,255,255,.04)', border:'1px dashed rgba(255,255,255,.18)',
            color:'rgba(251,250,244,.45)', fontSize:12, fontFamily:'var(--font-ui)',
            cursor:'pointer',
          }}>
          {placeholder}
        </button>
      )}
      {open && (
        <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:6 }}>
          {opts.map((o) => {
            const { v, l } = norm(o)
            const sel = v === value
            return (
              <button key={v}
                onClick={() => { set(fieldKey, sel ? '' : v); setOpen(false) }}
                style={{
                  padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)',
                  background: sel ? 'rgba(255,20,147,.2)' : 'rgba(255,255,255,.06)',
                  border: `1px solid ${sel ? 'rgba(255,20,147,.4)' : 'rgba(255,255,255,.1)'}`,
                  color: sel ? 'var(--pink)' : 'rgba(251,250,244,.7)',
                  cursor:'pointer',
                }}>
                {l}
              </button>
            )
          })}
          <button onClick={() => setOpen(false)}
            style={{
              padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)',
              background:'transparent', border:'1px solid rgba(255,255,255,.12)',
              color:'rgba(251,250,244,.4)', cursor:'pointer',
            }}>
            Done
          </button>
        </div>
      )}
    </div>
  )
}

// v9.51 — Compact multi-select. Default view shows ONLY selected items as
// chips with × to remove plus a "+ Add" affordance; tap "+ Add" to reveal
// full option list as toggleable pills. Empty state shows the "+ Add"
// button alone. Keeps the Identity tab tight on PWA viewports.
function PickMany({ fieldKey, P, set, opts, addLabel = '+ Add' }) {
  const [open, setOpen] = useState(false)
  const list = P[fieldKey] || []
  function toggle(v) {
    const next = list.includes(v) ? list.filter(x => x !== v) : [...list, v]
    set(fieldKey, next)
  }
  return (
    <div style={{ marginBottom: 4 }}>
      <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:4 }}>
        {list.map(v => (
          <span key={v} style={{
            display:'inline-flex', alignItems:'center', gap:6,
            padding:'4px 6px 4px 12px', borderRadius:20,
            background:'rgba(255,20,147,.16)', border:'1px solid rgba(255,20,147,.4)',
            color:'var(--cream)', fontSize:12, fontFamily:'var(--font-ui)',
          }}>
            {v}
            <button onClick={() => toggle(v)} title={`Remove ${v}`}
              style={{
                background:'none', border:'none', color:'rgba(251,250,244,.6)',
                cursor:'pointer', fontSize:14, lineHeight:1, padding:'0 4px',
              }}>×</button>
          </span>
        ))}
        {!open && (
          <button onClick={() => setOpen(true)}
            style={{
              padding:'4px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)',
              background:'transparent', border:'1px dashed rgba(255,255,255,.2)',
              color:'rgba(251,250,244,.5)', cursor:'pointer',
            }}>
            {addLabel}
          </button>
        )}
      </div>
      {open && (
        <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:8 }}>
          {opts.map(o => {
            const sel = list.includes(o)
            return (
              <button key={o} onClick={() => toggle(o)}
                style={{
                  padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)',
                  background: sel ? 'rgba(255,20,147,.2)' : 'rgba(255,255,255,.06)',
                  border: `1px solid ${sel ? 'rgba(255,20,147,.4)' : 'rgba(255,255,255,.1)'}`,
                  color: sel ? 'var(--pink)' : 'rgba(251,250,244,.7)',
                  cursor:'pointer',
                }}>
                {o}
              </button>
            )
          })}
          <button onClick={() => setOpen(false)}
            style={{
              padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)',
              background:'transparent', border:'1px solid rgba(255,255,255,.12)',
              color:'rgba(251,250,244,.4)', cursor:'pointer',
            }}>
            Done
          </button>
        </div>
      )}
    </div>
  )
}

// v9.51 — Per-pet card with photo upload. Photo lands in the same
// avatars storage bucket with a pets/{member_id}/{ts}.jpg path prefix
// so existing RLS policies apply unchanged. Renders inline alongside
// type/name/age inputs. Tapping the photo square (or the camera badge)
// opens the file picker; uploaded URL is written to pet.photo_url.
function PetRow({ pet, index, memberId, onChange, onRemove, onPhoto }) {
  const [uploading, setUploading] = useState(false)
  async function uploadPhoto(file) {
    if (!file || !memberId) return
    setUploading(true)
    try {
      const ext = (file.name.split('.').pop() || 'jpg').toLowerCase()
      const path = `pets/${memberId}/${index}-${Date.now()}.${ext}`
      const { error } = await supabase.storage.from('avatars').upload(path, file, {
        cacheControl: '3600', upsert: true, contentType: file.type || 'image/jpeg',
      })
      if (error) throw error
      const { data } = supabase.storage.from('avatars').getPublicUrl(path)
      if (data?.publicUrl) onPhoto(data.publicUrl)
    } catch (e) { console.error('[PetRow] upload failed:', e) }
    setUploading(false)
  }
  return (
    <div style={{
      display:'flex', gap:10, alignItems:'center', flexWrap:'wrap',
      padding:10, borderRadius:10,
      background:'rgba(255,255,255,.03)', border:'1px solid var(--border)',
    }}>
      {/* Photo square */}
      <label style={{
        position:'relative', width:52, height:52, borderRadius:10, overflow:'hidden',
        background: pet.photo_url ? 'transparent' : 'rgba(255,20,147,.08)',
        border:`1px solid ${pet.photo_url ? 'rgba(255,20,147,.35)' : 'rgba(255,20,147,.2)'}`,
        cursor:'pointer', flexShrink:0, display:'flex', alignItems:'center', justifyContent:'center',
      }}>
        {uploading
          ? <div className="spinner" style={{width:18, height:18, borderWidth:2}}/>
          : pet.photo_url
            ? <img src={pet.photo_url} alt="" style={{width:'100%', height:'100%', objectFit:'cover'}}/>
            : <span style={{fontSize:22}}>{
                pet.type === 'Dog' ? '🐶' :
                pet.type === 'Cat' ? '🐱' :
                pet.type === 'Bird' ? '🐦' :
                pet.type === 'Fish' ? '🐠' :
                pet.type === 'Rabbit' ? '🐰' :
                pet.type === 'Horse' ? '🐴' :
                pet.type === 'Reptile' ? '🦎' :
                '🐾'
              }</span>}
        <span style={{
          position:'absolute', bottom:1, right:1,
          width:18, height:18, borderRadius:'50%',
          background:'var(--pink)', color:'#fff',
          display:'flex', alignItems:'center', justifyContent:'center',
          fontSize:10,
          boxShadow:'0 0 0 2px var(--bg)',
        }}>📷</span>
        <input type="file" accept="image/jpeg,image/png,image/webp,image/gif" style={{display:'none'}}
          onChange={e => { const f = e.target.files?.[0]; if (f) uploadPhoto(f); e.target.value = '' }}/>
      </label>

      {/* Type select */}
      <select value={pet.type} onChange={e => onChange('type', e.target.value)}
        style={{flex:'0 0 130px', minWidth:0}}>
        {PET_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
      </select>
      {/* Name input */}
      <input value={pet.name || ''} onChange={e => onChange('name', e.target.value)}
        placeholder="Pet's name" style={{flex:1, minWidth:100}}/>
      {/* Age select */}
      <select value={pet.age || ''} onChange={e => onChange('age', e.target.value)}
        style={{flex:'0 0 80px'}} title="Age (optional)">
        <option value="">Age…</option>
        {Array.from({length:30}, (_, n) => n+1).map(n => <option key={n} value={n}>{n} yo</option>)}
      </select>
      <button onClick={onRemove}
        style={{background:'none', border:'none', color:'rgba(251,250,244,.35)', cursor:'pointer', fontSize:20, padding:'0 4px'}}>
        ×
      </button>
    </div>
  )
}

// v9.48 — Polished sobriety counter card. 3-2 compact grid (Years / Months /
// Days on top row, Hours / Minutes on bottom row). Live tick every second so
// Minutes increments visibly. Years and Months render with two decimals;
// Days, Hours, Minutes are integers with thousands separators.
const DAYS_OF_WEEK = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
const FORMATS      = ['In-Person','Online (Zoom)']  // v9.50: Hybrid removed

function SobrietyCounter({ dateStr, program }) {
  const [tick, setTick] = useState(0)
  useEffect(() => {
    const id = setInterval(() => setTick(t => t + 1), 1000)
    return () => clearInterval(id)
  }, [])
  const s = sobrietyStats(dateStr)
  if (!s) return null
  const fmt2  = (n) => n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
  const fmtInt = (n) => n.toLocaleString('en-US')
  // v9.48.2 — Per-fellowship verb: "sober" / "clean" / "abstinent" /
  // "in active recovery" / "smoke-free", with a defensive fallback.
  const verb = SOBRIETY_VERB[program] || 'in active recovery'
  const Stat = ({ value, label }) => (
    <div style={{flex:1, textAlign:'center', padding:'4px 0'}}>
      <p style={{fontSize:18, fontWeight:600, color:'var(--lime)', fontFamily:'Georgia, serif', margin:0, lineHeight:1.1, fontVariantNumeric:'tabular-nums'}}>{value}</p>
      <p style={{fontSize:10, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1, margin:'4px 0 0', textTransform:'uppercase'}}>{label}</p>
    </div>
  )
  return (
    <div style={{marginTop:10, padding:'14px 12px', borderRadius:10, background:'rgba(25,229,94,.08)', border:'1px solid rgba(25,229,94,.18)'}}>
      <p style={{fontSize:11, color:'rgba(251,250,244,.55)', fontFamily:'Georgia, serif', fontStyle:'italic', textAlign:'center', margin:'0 0 10px', letterSpacing:.3}}>
        🌱 You've been {verb} for
      </p>
      <div style={{display:'flex', gap:6, marginBottom:6}}>
        <Stat value={fmt2(s.yearsExact)}  label="Years"/>
        <Stat value={fmt2(s.monthsExact)} label="Months"/>
        <Stat value={fmtInt(s.days)}      label="Days"/>
      </div>
      <div style={{display:'flex', gap:6, paddingTop:8, borderTop:'1px solid rgba(25,229,94,.12)'}}>
        <Stat value={fmtInt(s.hours)}   label="Hours"/>
        <Stat value={fmtInt(s.minutes)} label="Minutes"/>
      </div>
    </div>
  )
}

// v9.48 — Per-slot Home Group card. Uses the canonical MEETING_DIRECTORY_URLS
// for the Find-a-Meeting link inside each card. Address field appears only when
// format is In-Person or Hybrid. Custom Other programs hide the directory link.
// v9.50 — Per-slot Home Group card. Rebuilt for compact UI:
//   - Day / Time / Format collapsed into a 3-up grid (was 3 stacked rows)
//   - Format-conditional sub-form: Online → smart Zoom paste with auto-parsed
//     meeting ID/passcode display; In-Person → Google Places autocomplete
//     stamping place_id, place_lat, place_lng on the row
//   - Hybrid removed (DB CHECK already excludes it)
//   - "Find a meeting" link moves into the section header alongside Clear
function HomeGroupCard({ slot, program, value, onChange, onClear }) {
  const directoryUrl = MEETING_DIRECTORY_URLS[program]
  const hg  = value || {}
  const upd = (key, v) => onChange(slot, { ...hg, [key]: v })

  const isOnline   = hg.format === 'Online (Zoom)'
  const isInPerson = hg.format === 'In-Person'

  // Smart Zoom URL parser. Matches both us02web.zoom.us/j/{id} and zoom.us/j/{id},
  // optional ?pwd= query parameter. Returns null when the URL doesn't match,
  // which the UI uses to surface a "couldn't parse" warning.
  function parseZoom(url) {
    if (!url) return null
    const m = String(url).match(/zoom\.us\/[a-z]\/(\d+)(?:[^a-zA-Z]+pwd=([^&\s]+))?/i)
    if (!m) return null
    const raw = m[1]
    // Format meeting ID like Zoom does: 867 6158 2536 (groups of 3-4-4 or 3-3-3-...)
    const formatted = raw.length === 11
      ? `${raw.slice(0,3)} ${raw.slice(3,7)} ${raw.slice(7)}`
      : raw.length === 10
        ? `${raw.slice(0,3)} ${raw.slice(3,6)} ${raw.slice(6)}`
        : raw
    return { meetingId: formatted, hasPasscode: !!m[2] }
  }
  const zoom = isOnline ? parseZoom(hg.location_or_zoom) : null

  // Google Places autocomplete on the In-Person address field. Pulls in the
  // existing gmap-script if WordOfMouth already loaded it; otherwise injects
  // its own. Cleans up listeners when the slot leaves In-Person mode.
  const addressRef = useRef(null)
  const acRef      = useRef(null)
  useEffect(() => {
    if (!isInPerson) {
      if (acRef.current && window.google?.maps?.event) {
        window.google.maps.event.clearInstanceListeners(acRef.current)
      }
      acRef.current = null
      return
    }

    function attach() {
      if (!addressRef.current || acRef.current) return
      const ac = new window.google.maps.places.Autocomplete(addressRef.current, {
        types:  ['establishment','geocode'],
        fields: ['name','formatted_address','geometry','place_id']
      })
      ac.addListener('place_changed', () => {
        const place = ac.getPlace()
        if (!place.formatted_address) return
        const addr = place.name && !place.formatted_address.startsWith(place.name)
          ? `${place.name}, ${place.formatted_address}`
          : place.formatted_address
        const lat = place.geometry?.location?.lat?.()
        const lng = place.geometry?.location?.lng?.()
        if (addressRef.current) addressRef.current.value = addr
        onChange(slot, {
          ...hg,
          address:   addr,
          place_id:  place.place_id || null,
          place_lat: typeof lat === 'number' ? lat : null,
          place_lng: typeof lng === 'number' ? lng : null,
        })
      })
      acRef.current = ac
    }

    if (window.google?.maps?.places) { setTimeout(attach, 50); return }
    if (document.getElementById('gmap-script')) {
      const poll = setInterval(() => {
        if (window.google?.maps?.places) { clearInterval(poll); attach() }
      }, 100)
      return () => clearInterval(poll)
    }
    const s = document.createElement('script')
    s.id = 'gmap-script'
    s.src = 'https://maps.googleapis.com/maps/api/js?key=' + GOOGLE_MAPS_KEY + '&libraries=places'
    s.async = true
    s.onload = () => setTimeout(attach, 50)
    document.head.appendChild(s)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isInPerson, slot])

  return (
    <div style={{marginTop:14, padding:'14px 12px', borderRadius:10, background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.18)'}}>
      <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:8, marginBottom:10, flexWrap:'wrap'}}>
        <p style={{fontSize:13, fontWeight:600, fontFamily:'var(--font-ui)', color:'var(--cream)', margin:0}}>
          🏠 Home group
        </p>
        <div style={{display:'flex', gap:14, alignItems:'center'}}>
          {directoryUrl && (
            <a href={directoryUrl} target="_blank" rel="noreferrer"
              style={{fontSize:11, color:'var(--pink)', fontFamily:'var(--font-ui)', textDecoration:'none'}}>
              🔍 Find a {program} meeting →
            </a>
          )}
          {hg.home_group_name && (
            <button onClick={() => onClear(slot)} title="Clear this home group"
              style={{background:'none', border:'none', color:'rgba(251,250,244,.35)', cursor:'pointer', fontSize:11, fontFamily:'var(--font-ui)'}}>
              clear
            </button>
          )}
        </div>
      </div>

      <input value={hg.home_group_name||''} onChange={e=>upd('home_group_name', e.target.value)} placeholder="Meeting name (e.g. Sunday Serenity Group)" style={{marginBottom:8}}/>

      {/* v9.50 — Day / Time / Format collapsed into a single row. */}
      <div style={{display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:8, marginBottom:8}}>
        <select value={hg.day||''} onChange={e=>upd('day', e.target.value || null)}>
          <option value="">Day…</option>
          {DAYS_OF_WEEK.map(d => <option key={d} value={d}>{d}</option>)}
        </select>
        <input type="time" value={hg.meeting_time||''} onChange={e=>upd('meeting_time', e.target.value || null)}/>
        <select value={hg.format||''} onChange={e=>{
          const f = e.target.value || null
          const next = { ...hg, format: f }
          // Switching out of In-Person clears the address+place fields so we
          // don't keep stale geo data on a now-online meeting.
          if (f !== 'In-Person') {
            next.address = null; next.place_id = null
            next.place_lat = null; next.place_lng = null
          }
          // Switching out of Online (Zoom) doesn't auto-clear location_or_zoom
          // since In-Person reuses that field for venue name. We rely on the
          // user explicitly editing it.
          onChange(slot, next)
        }}>
          <option value="">Format…</option>
          {FORMATS.map(f => <option key={f} value={f}>{f}</option>)}
        </select>
      </div>

      {/* v9.50 — Online: smart Zoom paste with parsed display */}
      {isOnline && (
        <div style={{background:'rgba(0,0,0,.2)', border:'1px solid rgba(255,20,147,.15)', borderRadius:8, padding:'10px', marginBottom:8}}>
          <p style={{fontSize:10, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6, marginTop:0}}>PASTE YOUR ZOOM INVITE LINK</p>
          <input value={hg.location_or_zoom||''} onChange={e=>upd('location_or_zoom', e.target.value)} placeholder="https://us02web.zoom.us/j/… (use Copy Invite Link from Zoom)"/>
          {zoom ? (
            <div style={{display:'flex', gap:14, marginTop:8, fontSize:11, fontFamily:'var(--font-ui)', flexWrap:'wrap', alignItems:'center'}}>
              <span style={{color:'var(--lime)'}}>✓ Parsed</span>
              <span style={{color:'rgba(251,250,244,.7)'}}>Meeting ID: {zoom.meetingId}</span>
              {zoom.hasPasscode && <span style={{color:'rgba(251,250,244,.7)'}}>Passcode embedded</span>}
              <a href={hg.location_or_zoom} target="_blank" rel="noreferrer" style={{marginLeft:'auto', color:'var(--pink)', textDecoration:'none'}}>▶ Test one-click join</a>
            </div>
          ) : hg.location_or_zoom ? (
            <p style={{fontSize:11, color:'rgba(255,159,0,.85)', fontFamily:'var(--font-ui)', marginTop:8, marginBottom:0}}>⚠ Couldn't parse a meeting ID. Use the full Copy-Invite link from Zoom for one-click join to work for the community.</p>
          ) : null}
        </div>
      )}

      {/* v9.50 — In-Person: Google Places autocomplete with map link */}
      {isInPerson && (
        <div style={{background:'rgba(0,0,0,.2)', border:'1px solid rgba(255,20,147,.15)', borderRadius:8, padding:'10px', marginBottom:8}}>
          <p style={{fontSize:10, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:6, marginTop:0}}>📍 ADDRESS (Google search)</p>
          <input ref={addressRef} defaultValue={hg.address||''} onBlur={e=>{
            // Only stamp manual edits to address; place picker fires onChange via the listener
            if (e.target.value !== hg.address) {
              onChange(slot, { ...hg, address: e.target.value, place_id: null, place_lat: null, place_lng: null })
            }
          }} placeholder="Start typing the venue name or address…"/>
          {hg.address && (
            <div style={{display:'flex', gap:14, marginTop:8, fontSize:11, fontFamily:'var(--font-ui)', alignItems:'center', flexWrap:'wrap'}}>
              <span style={{color: hg.place_id ? 'var(--lime)' : 'rgba(251,250,244,.4)'}}>
                {hg.place_id ? '✓ Pinned' : '— Manual entry'}
              </span>
              <a
                href={hg.place_id
                  ? `https://www.google.com/maps/place/?q=place_id:${hg.place_id}`
                  : `https://www.google.com/maps/search/${encodeURIComponent(hg.address)}`}
                target="_blank" rel="noreferrer"
                style={{marginLeft:'auto', color:'var(--pink)', textDecoration:'none'}}>
                🗺 View on map
              </a>
            </div>
          )}
        </div>
      )}

      <Lbl t="NOTES" sub="(optional)"/>
      <textarea rows={2} value={hg.notes||''} onChange={e=>upd('notes', e.target.value)} placeholder="Why you chose this group, special instructions, etc." style={{resize:'vertical'}}/>
    </div>
  )
}

// v9.50 — Inline expandable picker for tagging another community member as
// the current member's sponsor or sponsee. The host (SponsorshipRow) controls
// visibility and passes already-tagged ids in `excludeIds` so we don't show
// the same person twice. `roleConsentField` is 'allow_sponsor_tags' or
// 'allow_sponsee_tags' — we filter out members who have that flag set FALSE.
function MemberTagPicker({ allMembers, excludeIds, roleConsentField, currentMemberId, onPick, onClose }) {
  const [q, setQ] = useState('')
  const matches = allMembers
    .filter(m => m.id !== currentMemberId)
    .filter(m => !excludeIds.includes(m.id))
    .filter(m => m[roleConsentField] !== false)
    .filter(m => {
      if (!q.trim()) return true
      const needle = q.toLowerCase()
      return (m.display_name || '').toLowerCase().includes(needle)
          || (m.first_name   || '').toLowerCase().includes(needle)
          || (m.last_name    || '').toLowerCase().includes(needle)
    })
    .slice(0, 8)
  return (
    <div style={{marginTop:8, padding:'10px 12px', borderRadius:8, background:'rgba(0,0,0,.25)', border:'1px solid rgba(255,20,147,.25)'}}>
      <div style={{display:'flex', gap:8, marginBottom:8, alignItems:'center'}}>
        <input autoFocus value={q} onChange={e=>setQ(e.target.value)} placeholder="Search community members…" style={{flex:1}}/>
        <button onClick={onClose} style={{background:'none', border:'none', color:'rgba(251,250,244,.4)', cursor:'pointer', fontSize:18, lineHeight:1, padding:'0 4px'}}>×</button>
      </div>
      {matches.length === 0 ? (
        <p style={{fontSize:11, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', margin:0, padding:'4px 0'}}>
          {q.trim() ? 'No matches.' : 'Start typing to search.'}
        </p>
      ) : (
        <div style={{display:'flex', flexDirection:'column', gap:4}}>
          {matches.map(m => (
            <button key={m.id} onClick={() => onPick(m)}
              style={{display:'flex', alignItems:'center', gap:10, padding:'6px 8px', borderRadius:6, background:'transparent', border:'1px solid transparent', cursor:'pointer', textAlign:'left'}}
              onMouseEnter={e=>{ e.currentTarget.style.background='rgba(255,20,147,.08)'; e.currentTarget.style.borderColor='rgba(255,20,147,.25)' }}
              onMouseLeave={e=>{ e.currentTarget.style.background='transparent'; e.currentTarget.style.borderColor='transparent' }}>
              {m.avatar_url
                ? <img src={m.avatar_url} alt="" style={{width:24, height:24, borderRadius:'50%', objectFit:'cover', flexShrink:0}}/>
                : <div style={{width:24, height:24, borderRadius:'50%', background:'rgba(255,20,147,.15)', display:'flex', alignItems:'center', justifyContent:'center', flexShrink:0, fontSize:10, color:'var(--pink)', fontFamily:'var(--font-ui)'}}>{(m.display_name || m.email || '?')[0]?.toUpperCase()}</div>}
              <span style={{fontSize:13, color:'var(--cream)', fontFamily:'var(--font-ui)'}}>{m.display_name || m.email}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

// v9.50 — Sponsor + sponsee row for a single program slot. Renders two pill
// segmented controls (Sponsor status / Sponsee count) plus tagged-member chips
// for in-community sponsors/sponsees. State lives on the parent: this is a
// presentational component that calls onChange with { sponsor_status,
// sponsee_count, sponsorMemberId, sponseeMemberIds[] } for the slot.
function SponsorshipRow({
  slot,
  sponsorStatus,
  sponseeCount,
  sponsorLink,        // single object {id, sponsor_member_id} or null
  sponseeLinks,       // array of objects [{id, sponsee_member_id}, …]
  allMembers,
  currentMemberId,
  onSponsorStatus,    // (newStatus) => void
  onSponseeCount,     // (newCount) => void
  onSponsorPick,      // (memberObj) => void  — sets sponsor link
  onSponsorClear,     // () => void           — clears sponsor link
  onSponseeAdd,       // (memberObj) => void  — adds a sponsee link
  onSponseeRemove,    // (memberObj) => void  — removes a sponsee link
}) {
  const [pickerOpen, setPickerOpen] = useState(null) // 'sponsor' | 'sponsee' | null

  function memberById(id) {
    return allMembers.find(m => m.id === id)
  }

  // Sponsor link → resolve to display data
  const sponsorMember = sponsorLink ? memberById(sponsorLink.sponsor_member_id) : null
  // Sponsee links → resolve
  const sponseeMembers = (sponseeLinks || []).map(l => ({ link: l, m: memberById(l.sponsee_member_id) })).filter(x => x.m)
  const sponseeIds = sponseeMembers.map(x => x.m.id)

  return (
    <div style={{marginTop:14, padding:'12px 14px', borderRadius:10, background:'rgba(255,255,255,.025)', border:'1px solid rgba(255,255,255,.08)'}}>
      <p style={{fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1, margin:'0 0 8px 0'}}>SPONSORSHIP</p>

      {/* Sponsor row */}
      <div style={{display:'flex', flexWrap:'wrap', gap:6, alignItems:'center', marginBottom:8}}>
        <span style={{fontSize:12, color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', minWidth:72}}>Sponsor</span>
        {SPONSOR_STATUSES.map(s => (
          <button key={s.value}
            onClick={() => onSponsorStatus(s.value)}
            style={{
              fontSize:12, fontFamily:'var(--font-ui)', padding:'4px 12px', borderRadius:999, cursor:'pointer',
              background: sponsorStatus===s.value ? 'var(--pink)' : 'rgba(255,20,147,.06)',
              border:    `1px solid ${sponsorStatus===s.value ? 'var(--pink)' : 'rgba(255,20,147,.25)'}`,
              color:     sponsorStatus===s.value ? 'var(--cream)' : 'rgba(251,250,244,.85)',
            }}>
            {s.label}
          </button>
        ))}
        {sponsorStatus === 'has' && sponsorMember && (
          <span style={{display:'inline-flex', alignItems:'center', gap:6, marginLeft:4, padding:'2px 10px 2px 2px', borderRadius:999, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)', fontSize:12, fontFamily:'var(--font-ui)', color:'var(--cream)'}}>
            {sponsorMember.avatar_url
              ? <img src={sponsorMember.avatar_url} alt="" style={{width:22, height:22, borderRadius:'50%', objectFit:'cover'}}/>
              : <span style={{width:22, height:22, borderRadius:'50%', background:'rgba(255,20,147,.2)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:9, color:'var(--pink)'}}>{(sponsorMember.display_name || '?')[0]?.toUpperCase()}</span>}
            {sponsorMember.display_name || sponsorMember.email}
            <button onClick={onSponsorClear} title="Remove tag"
              style={{background:'none', border:'none', color:'rgba(251,250,244,.5)', cursor:'pointer', fontSize:12, lineHeight:1, padding:'0 2px'}}>×</button>
          </span>
        )}
        {sponsorStatus === 'has' && !sponsorMember && pickerOpen !== 'sponsor' && (
          <button onClick={() => setPickerOpen('sponsor')}
            style={{fontSize:11, color:'var(--pink)', background:'none', border:'1px dashed rgba(255,20,147,.4)', borderRadius:999, padding:'3px 10px', cursor:'pointer', fontFamily:'var(--font-ui)', marginLeft:4}}>
            + Tag a community member
          </button>
        )}
      </div>
      {pickerOpen === 'sponsor' && (
        <MemberTagPicker
          allMembers={allMembers}
          excludeIds={[]}
          roleConsentField="allow_sponsor_tags"
          currentMemberId={currentMemberId}
          onClose={() => setPickerOpen(null)}
          onPick={(m) => { onSponsorPick(m); setPickerOpen(null) }}
        />
      )}

      {/* Sponsee row */}
      <div style={{display:'flex', flexWrap:'wrap', gap:6, alignItems:'center', marginTop:8}}>
        <span style={{fontSize:12, color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', minWidth:72}}>Sponsees</span>
        {SPONSEE_COUNTS.map(s => (
          <button key={s.value}
            onClick={() => onSponseeCount(s.value)}
            style={{
              fontSize:12, fontFamily:'var(--font-ui)', padding:'4px 12px', borderRadius:999, cursor:'pointer',
              background: sponseeCount===s.value ? 'var(--pink)' : 'rgba(255,20,147,.06)',
              border:    `1px solid ${sponseeCount===s.value ? 'var(--pink)' : 'rgba(255,20,147,.25)'}`,
              color:     sponseeCount===s.value ? 'var(--cream)' : 'rgba(251,250,244,.85)',
            }}>
            {s.label}
          </button>
        ))}
      </div>
      {sponseeMembers.length > 0 && (
        <div style={{display:'flex', flexWrap:'wrap', gap:6, alignItems:'center', marginTop:8, marginLeft:80}}>
          {sponseeMembers.map(({ link, m }) => (
            <span key={link.id || m.id} style={{display:'inline-flex', alignItems:'center', gap:6, padding:'2px 10px 2px 2px', borderRadius:999, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)', fontSize:12, fontFamily:'var(--font-ui)', color:'var(--cream)'}}>
              {m.avatar_url
                ? <img src={m.avatar_url} alt="" style={{width:22, height:22, borderRadius:'50%', objectFit:'cover'}}/>
                : <span style={{width:22, height:22, borderRadius:'50%', background:'rgba(255,20,147,.2)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:9, color:'var(--pink)'}}>{(m.display_name || '?')[0]?.toUpperCase()}</span>}
              {m.display_name || m.email}
              <button onClick={() => onSponseeRemove(m)} title="Remove tag"
                style={{background:'none', border:'none', color:'rgba(251,250,244,.5)', cursor:'pointer', fontSize:12, lineHeight:1, padding:'0 2px'}}>×</button>
            </span>
          ))}
        </div>
      )}
      {sponseeCount !== 'none' && pickerOpen !== 'sponsee' && (
        <div style={{marginLeft:80, marginTop:8}}>
          <button onClick={() => setPickerOpen('sponsee')}
            style={{fontSize:11, color:'var(--pink)', background:'none', border:'1px dashed rgba(255,20,147,.4)', borderRadius:999, padding:'3px 10px', cursor:'pointer', fontFamily:'var(--font-ui)'}}>
            + Tag a community member
          </button>
        </div>
      )}
      {pickerOpen === 'sponsee' && (
        <MemberTagPicker
          allMembers={allMembers}
          excludeIds={sponseeIds}
          roleConsentField="allow_sponsee_tags"
          currentMemberId={currentMemberId}
          onClose={() => setPickerOpen(null)}
          onPick={(m) => { onSponseeAdd(m); setPickerOpen(null) }}
        />
      )}

      <p style={{fontSize:10, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', margin:'10px 0 0 0', lineHeight:1.5}}>
        Tagged members link to their profile. Members can opt out of being tagged in Account → Privacy.
      </p>
    </div>
  )
}

function WellnessArea({ area, selectedTopics, onToggle, goalLinks, onSetGoalLink }) {
  const [open, setOpen] = useState(false)
  // Topics from this area that are currently selected; also drives the
  // "Recommended Resources" URL-editor strip below the chip wrap.
  const selected = selectedTopics.filter(t => area.topics.includes(t))
  return (
    <div style={{ border:`1px solid ${selected.length>0?'rgba(255,20,147,.3)':'var(--border)'}`, borderRadius:8, marginBottom:10, overflow:'hidden', background:selected.length>0?'rgba(255,20,147,.04)':'rgba(255,255,255,.03)' }}>
      <button onClick={() => setOpen(o=>!o)} style={{ width:'100%', background:'none', border:'none', padding:'14px 16px', display:'flex', alignItems:'center', gap:12, cursor:'pointer', textAlign:'left' }}>
        <span style={{ fontSize:22, flexShrink:0 }}>{area.icon}</span>
        <div style={{ flex:1 }}>
          <div style={{ fontSize:14, fontWeight:600, color:'var(--cream)', fontFamily:'var(--font-ui)' }}>{area.label}</div>
          <div style={{ fontSize:12, color:'rgba(251,250,244,.45)', marginTop:2 }}>{selected.length>0?`${selected.length} topic${selected.length!==1?'s':''} selected`:'Tap to expand'}</div>
        </div>
        <span style={{ fontSize:16, color:'rgba(251,250,244,.3)', transform:open?'rotate(180deg)':'none', transition:'transform .2s' }}>▾</span>
      </button>
      {open && (
        <div style={{ padding:'0 16px 16px' }}>
          <div style={{ display:'flex', flexWrap:'wrap', gap:8 }}>
            {area.topics.map(t => {
              const sel = selectedTopics.includes(t)
              return <button key={t} onClick={()=>onToggle(t)} style={{ padding:'6px 12px', borderRadius:20, fontSize:12, fontFamily:'var(--font-ui)', background:sel?'rgba(255,20,147,.2)':'rgba(255,255,255,.06)', border:`1px solid ${sel?'rgba(255,20,147,.4)':'rgba(255,255,255,.1)'}`, color:sel?'var(--pink)':'rgba(251,250,244,.6)', cursor:'pointer' }}>{t}</button>
            })}
          </div>
          {/* v9.51 Item 7 — Per-selected-topic URL editor.
              Each selected topic in this area gets a small expandable card
              with two URL slot rows (URL + optional label). Members typically
              attach a website, app, or book recommendation tied to the goal.
              URLs render on the public profile only when populated. */}
          {selected.length > 0 && onSetGoalLink && (
            <div style={{marginTop:14, paddingTop:14, borderTop:'1px solid rgba(255,20,147,.15)'}}>
              <p style={{fontSize:10, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8}}>🔗 RECOMMENDED RESOURCES</p>
              <p style={{fontSize:11, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', lineHeight:1.5, marginBottom:10}}>Add up to 2 links per topic — a website, app, or book that supports your work in this area. They show on your public profile when filled in.</p>
              <div style={{display:'flex', flexDirection:'column', gap:10}}>
                {selected.map(topic => (
                  <TopicLinksEditor key={topic} topic={topic} links={goalLinks?.[topic]} onSetGoalLink={onSetGoalLink}/>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

// v9.51 Item 7 — Inline URL editor for a single selected topic.
// Renders 2 slot rows. Each row: URL input + optional Label input + clear button.
// Collapsed by default; tap "Add link" or the topic name to expand.
function TopicLinksEditor({ topic, links, onSetGoalLink }) {
  const slot1 = links?.[1]
  const slot2 = links?.[2]
  const populatedCount = (slot1?.url ? 1 : 0) + (slot2?.url ? 1 : 0)
  const [open, setOpen] = useState(populatedCount > 0)
  return (
    <div style={{background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,20,147,.18)', borderRadius:8, overflow:'hidden'}}>
      <button onClick={() => setOpen(o=>!o)} style={{width:'100%', background:'none', border:'none', padding:'8px 12px', display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, cursor:'pointer', textAlign:'left'}}>
        <span style={{fontSize:12, fontFamily:'var(--font-ui)', color:'var(--pink)', fontWeight:600}}>{topic}</span>
        <span style={{fontSize:11, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.5)'}}>
          {populatedCount > 0 ? `${populatedCount} link${populatedCount!==1?'s':''}` : 'Add a link'} <span style={{fontSize:14, color:'rgba(251,250,244,.3)', transform:open?'rotate(180deg)':'none', display:'inline-block', transition:'transform .2s'}}>▾</span>
        </span>
      </button>
      {open && (
        <div style={{padding:'4px 12px 12px', display:'flex', flexDirection:'column', gap:8}}>
          {[1, 2].map(slot => {
            const link = slot === 1 ? slot1 : slot2
            return (
              <div key={slot} style={{display:'flex', flexDirection:'column', gap:4}}>
                <div style={{display:'flex', alignItems:'center', gap:6}}>
                  <input
                    type="url"
                    placeholder={`URL ${slot} — https://…`}
                    value={link?.url || ''}
                    onChange={e => onSetGoalLink(topic, slot, { url: e.target.value, label: link?.label || '' })}
                    style={{flex:1, fontSize:12, fontFamily:'var(--font-ui)', padding:'6px 8px', borderRadius:6, background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.12)', color:'var(--cream)', minWidth:0}}
                  />
                  {link?.url && (
                    <button onClick={() => onSetGoalLink(topic, slot, { url: '', label: '' })} title="Remove this link"
                      style={{background:'none', border:'1px solid rgba(255,255,255,.15)', borderRadius:6, color:'rgba(251,250,244,.5)', fontSize:14, padding:'4px 8px', cursor:'pointer', flexShrink:0}}>
                      ×
                    </button>
                  )}
                </div>
                <input
                  type="text"
                  placeholder="Friendly name (optional) — e.g. The Phoenix app"
                  value={link?.label || ''}
                  onChange={e => onSetGoalLink(topic, slot, { url: link?.url || '', label: e.target.value })}
                  maxLength={80}
                  style={{fontSize:11, fontFamily:'var(--font-ui)', padding:'4px 8px', borderRadius:6, background:'rgba(255,255,255,.02)', border:'1px solid rgba(255,255,255,.07)', color:'rgba(251,250,244,.7)'}}
                />
              </div>
            )
          })}
        </div>
      )}
    </div>
  )
}

export default function ProfilePage({ user, isAdmin, editAsMemberId, onClose }) {
  // v9.46 Item 1 — when editAsMemberId is set, this Profile is in admin-edit mode:
  // load the target member's row instead of the current user's, show the persistent
  // pink banner, and hide controls that act on the admin's own auth account
  // (Sign Out, GDPR Download/Delete).
  const isAdminEdit = !!editAsMemberId
  const [tab, setTab]       = useState('account')
  const [member, setMember] = useState(null)
  const [P, setP]           = useState({})
  const [pets, setPets]     = useState([])
  // v9.48 Item 11A — Per-slot home groups, keyed by slot number (1, 2, 3).
  // Each value is an object matching the member_home_groups row shape, or
  // null if no row exists for that slot. Save handler upserts on dirty slots.
  const [homeGroups, setHomeGroups] = useState({ 1: null, 2: null, 3: null })
  // v9.50 — Per-slot sponsor link, keyed by slot. Schema enforces UNIQUE
  // (member_id, slot) so each slot has 0 or 1 entry. Loaded from
  // member_sponsor_links and reconciled on save.
  const [sponsorLinks, setSponsorLinks] = useState({ 1: null, 2: null, 3: null })
  // v9.50 — Per-slot sponsee links, keyed by slot. Multiple allowed per slot
  // (UNIQUE on (member_id, slot, sponsee_member_id)). Loaded from
  // member_sponsee_links and reconciled on save.
  const [sponseeLinks, setSponseeLinks] = useState({ 1: [], 2: [], 3: [] })
  // v9.51 Item 7 — Up to 2 URL recommendations per selected wellness sub-topic.
  // Shape: { [topic]: { 1: {id, url, label} | null, 2: {...} | null } }.
  // Topics with no links are simply absent. Loaded from member_goal_links
  // and reconciled on save.
  const [goalLinks, setGoalLinks] = useState({})
  // v9.50 — All community members for the tag picker. Loaded once on mount.
  // Excludes operator accounts so admin doesn't show up as a sponsor option.
  const [allMembers, setAllMembers] = useState([])
  const [referrals, setReferrals]       = useState([])
  const [contributions, setContributions] = useState(null)
  const [womPlaces, setWomPlaces]           = useState([])
  const [approvedHeroes, setApprovedHeroes]   = useState([])
  const [avatarUrl, setAvatarUrl]       = useState(DEFAULT_AVATAR)
  const [avatarUploading, setAvatarUploading] = useState(false)
  const [dragOver, setDragOver]         = useState(false)
  const [zipLooking, setZipLooking]     = useState(false)
  const [loading, setLoading]           = useState(true)
  const [saving, setSaving]             = useState(false)
  const [msg, setMsg]                   = useState('')
  const [dirty, setDirty]               = useState(false)
  const [tzDetectMsg, setTzDetectMsg]   = useState('')

  useEffect(() => { load() }, [])

  async function load() {
    // v9.46 Item 1 — admin-edit mode loads the target member's row by id (RLS allows
    // is_operator to read all members). Otherwise loads the current user's own row.
    const baseQuery = supabase.from('members').select('*')
    const { data } = isAdminEdit
      ? await baseQuery.eq('id', editAsMemberId).single()
      : await baseQuery.eq('email', user.email).single()
    if (data) {
      setMember(data)
      setP({ ...data, spoken_languages: parseList(data.spoken_languages), written_languages: parseList(data.written_languages), wellness_topics: parseList(data.wellness_topics) })
      setPets(parsePets(data.pets))
      setAvatarUrl(data.avatar_url || DEFAULT_AVATAR)

      const { data: refs } = await supabase.from('referrals').select('*').eq('referrer_id', data.id).order('created_at', { ascending:false })
      setReferrals(refs || [])

      // v9.48 Item 11A — Load this member's per-slot home group rows.
      const { data: hgRows } = await supabase
        .from('member_home_groups')
        .select('id, slot, program, home_group_name, day, meeting_time, format, location_or_zoom, address, notes, place_id, place_lat, place_lng')
        .eq('member_id', data.id)
      const hgMap = { 1: null, 2: null, 3: null }
      ;(hgRows || []).forEach(r => { hgMap[r.slot] = r })
      setHomeGroups(hgMap)

      // v9.50 — Load sponsor + sponsee links for this member.
      const [{ data: spRows }, { data: seRows }, { data: memberRows }, { data: glRows }] = await Promise.all([
        supabase.from('member_sponsor_links').select('id, slot, sponsor_member_id').eq('member_id', data.id),
        supabase.from('member_sponsee_links').select('id, slot, sponsee_member_id').eq('member_id', data.id),
        supabase.from('members').select('id, display_name, email, first_name, last_name, avatar_url, allow_sponsor_tags, allow_sponsee_tags').eq('is_operator', false),
        // v9.51 Item 7 — Goal URL recommendations
        supabase.from('member_goal_links').select('id, topic, slot, url, label').eq('member_id', data.id),
      ])
      const spMap = { 1: null, 2: null, 3: null }
      ;(spRows || []).forEach(r => { spMap[r.slot] = r })
      setSponsorLinks(spMap)
      const seMap = { 1: [], 2: [], 3: [] }
      ;(seRows || []).forEach(r => { (seMap[r.slot] = seMap[r.slot] || []).push(r) })
      setSponseeLinks(seMap)
      setAllMembers(memberRows || [])
      // v9.51 Item 7 — Group goal-link rows by topic + slot.
      const glMap = {}
      ;(glRows || []).forEach(r => {
        if (!glMap[r.topic]) glMap[r.topic] = { 1: null, 2: null }
        glMap[r.topic][r.slot] = { id: r.id, url: r.url, label: r.label }
      })
      setGoalLinks(glMap)

      const [heroRes, blogRes, commentRes] = await Promise.all([
        supabase.from('hero_showcases').select('id,hero_name,hero_type,tagline,photos,thumbnail_index,status').eq('member_id', data.id),
        supabase.from('blog_posts').select('id').eq('author_id', data.id),
        supabase.from('blog_comments').select('id').eq('author_id', data.id),
      ])
      // Approved heroes for profile display
      setApprovedHeroes((heroRes.data||[]).filter(h=>h.status==='approved'))
      const { data: womData } = await supabase.from('word_of_mouth').select('id,business_name,category,city,website_url,place_id').eq('member_id', data.id).order('created_at', { ascending: false })
      setWomPlaces(womData || [])
      const heroes = heroRes.data || []
      setContributions({
        referred:      (refs||[]).length,
        joined:        (refs||[]).filter(r=>r.status!=='invited').length,
        heroes_person: heroes.filter(h=>h.hero_type==='person').length,
        heroes_place:  heroes.filter(h=>h.hero_type==='place').length,
        heroes_thing:  heroes.filter(h=>h.hero_type==='thing').length,
        blog_posts:    (blogRes.data||[]).length,
        blog_comments: (commentRes.data||[]).length,
      })
    }
    setLoading(false)
  }

  function set(key, val) { setP(p=>({...p,[key]:val})); setDirty(true) }

  // v9.48 Item 11A — Program slot change with home-group data confirm.
  // If the slot has existing home-group data and the new program differs from
  // the stored one, prompt before allowing the swap. Confirm clears the home
  // group for that slot. Cancel reverts the program selection.
  function setProgramSlot(slot, newValue) {
    const existing = homeGroups[slot]
    const oldProgram = P[`program_${slot}`]
    if (existing && existing.home_group_name && newValue !== oldProgram) {
      const ok = window.confirm(
        `Changing your Program ${slot} from ${oldProgram} to ${newValue} will clear your "${existing.home_group_name}" home group details for this slot. Continue?`
      )
      if (!ok) return
      // Clear the home group for this slot (will sync to DB on next save).
      setHomeGroups(hg => ({ ...hg, [slot]: { ...existing, _delete: true } }))
    }
    set(`program_${slot}`, newValue)
  }

  function setHomeGroup(slot, next) {
    setHomeGroups(hg => ({ ...hg, [slot]: { ...next, slot, _dirty: true } }))
    setDirty(true)
  }
  function clearHomeGroup(slot) {
    if (!window.confirm('Clear all home group details for this program?')) return
    setHomeGroups(hg => ({ ...hg, [slot]: hg[slot] ? { ...hg[slot], _delete: true } : null }))
    setDirty(true)
  }

  function toggleList(key, val) { const cur=P[key]||[]; set(key, cur.includes(val)?cur.filter(v=>v!==val):[...cur,val]) }
  function setPet(i,f,v){const p=[...pets];p[i]={...p[i],[f]:v};setPets(p);setDirty(true)}
  function removePet(i){setPets(pets.filter((_,j)=>j!==i));setDirty(true)}
  function addPet(){setPets([...pets,{type:'Dog',name:'',age:''}]);setDirty(true)}

  async function handleZipChange(zip) {
    set('zip_code', zip)
    if (zip.length >= 5 && /^\d{5}/.test(zip)) {
      setZipLooking(true)
      const city = await lookupZip(zip.slice(0,5))
      if (city) set('city', city)
      setZipLooking(false)
    }
  }

  async function save() {
    if (!member) return
    if (!P.display_name?.trim()) { setMsg('Display name is required.'); return }
    if (!P.first_name?.trim())   { setMsg('First name is required.'); return }
    if (!P.last_name?.trim())    { setMsg('Last name is required.'); return }
    if (!P.zip_code?.trim())     { setMsg('Zip code is required.'); return }
    if (!P.timezone)             { setMsg('Timezone is required.'); return }
    setSaving(true)
    const payload = {
      ...P,
      spoken_languages:  (P.spoken_languages||[]).join(', '),
      written_languages: (P.written_languages||[]).join(', '),
      wellness_topics:   JSON.stringify(P.wellness_topics||[]),
      pets:              JSON.stringify(pets),
      updated_at:        new Date().toISOString(),
    }
    ;['birth_date','program_1_date','program_2_date','program_3_date'].forEach(k=>{
      if (!payload[k]||String(payload[k]).trim()==='') payload[k]=null
    })
    const { error } = await supabase.from('members').update(payload).eq('id', member.id)
    if (error) { setSaving(false); setMsg('Error: '+error.message); return }

    // v9.48 Item 11A — Sync per-slot home group rows. For each slot:
    //   _delete: if row had an id, DELETE; otherwise no-op.
    //   _dirty (no _delete): upsert with the snapshotted program from members.program_<slot>.
    //   neither: leave alone.
    // Slots whose program is empty get the row deleted (orphan cleanup).
    const hgErrors = []
    for (const slot of [1, 2, 3]) {
      const hg = homeGroups[slot]
      const programForSlot = (P[`program_${slot}`] || '').trim()
      const isNoHomeGroupProgram = PROGRAMS_WITHOUT_HOME_GROUPS.includes(programForSlot)
      // Orphan cleanup: program is empty OR is a no-home-group program
      // (e.g. Stopped Smoking), but a row exists → delete.
      if ((!programForSlot || isNoHomeGroupProgram) && hg && hg.id) {
        const { error: delErr } = await supabase.from('member_home_groups').delete().eq('id', hg.id)
        if (delErr) hgErrors.push(`Slot ${slot} delete: ${delErr.message}`)
        continue
      }
      if (!hg) continue
      if (hg._delete) {
        if (hg.id) {
          const { error: delErr } = await supabase.from('member_home_groups').delete().eq('id', hg.id)
          if (delErr) hgErrors.push(`Slot ${slot} delete: ${delErr.message}`)
        }
        continue
      }
      if (hg._dirty && programForSlot && !isNoHomeGroupProgram) {
        const row = {
          member_id: member.id,
          slot,
          program: programForSlot,
          home_group_name:  hg.home_group_name || null,
          day:              hg.day || null,
          meeting_time:     hg.meeting_time || null,
          format:           hg.format || null,
          location_or_zoom: hg.location_or_zoom || null,
          address:          hg.address || null,
          notes:            hg.notes || null,
          // v9.50 — Google Places fields populated when format='In-Person'
          place_id:         hg.place_id || null,
          place_lat:        hg.place_lat ?? null,
          place_lng:        hg.place_lng ?? null,
        }
        const { error: upErr } = await supabase
          .from('member_home_groups')
          .upsert(row, { onConflict: 'member_id,slot' })
        if (upErr) hgErrors.push(`Slot ${slot} save: ${upErr.message}`)
      }
    }

    // Refresh local home-group state from DB so _dirty/_delete flags clear and
    // freshly-inserted rows pick up their server-assigned id.
    const { data: hgRows2 } = await supabase
      .from('member_home_groups')
      .select('id, slot, program, home_group_name, day, meeting_time, format, location_or_zoom, address, notes, place_id, place_lat, place_lng')
      .eq('member_id', member.id)
    const hgMap2 = { 1: null, 2: null, 3: null }
    ;(hgRows2 || []).forEach(r => { hgMap2[r.slot] = r })
    setHomeGroups(hgMap2)

    // v9.50 — Reconcile sponsor_links and sponsee_links against the local state.
    // We diff against the original spRows / seRows snapshots: anything in local
    // state with no id is an INSERT; anything in DB but missing locally is a
    // DELETE. The status/count fields on members are saved by the regular
    // members-table update above (they're plain columns in P).
    const linkErrors = []
    // Sponsor links — at most one per slot, so the diff is simpler.
    const { data: spExisting } = await supabase
      .from('member_sponsor_links').select('id, slot, sponsor_member_id').eq('member_id', member.id)
    for (const slot of [1, 2, 3]) {
      const local = sponsorLinks[slot]
      const remote = (spExisting || []).find(r => r.slot === slot)
      const status = P[`sponsor_status_${slot}`]
      // If status is not 'has', we should have no link.
      if (status !== 'has') {
        if (remote) {
          const { error: e } = await supabase.from('member_sponsor_links').delete().eq('id', remote.id)
          if (e) linkErrors.push(`Slot ${slot} sponsor delete: ${e.message}`)
        }
        continue
      }
      // status === 'has'. Reconcile.
      if (!local) {
        if (remote) {
          const { error: e } = await supabase.from('member_sponsor_links').delete().eq('id', remote.id)
          if (e) linkErrors.push(`Slot ${slot} sponsor delete: ${e.message}`)
        }
        continue
      }
      if (!remote) {
        const { error: e } = await supabase.from('member_sponsor_links').insert({
          member_id: member.id, slot, sponsor_member_id: local.sponsor_member_id
        })
        if (e) linkErrors.push(`Slot ${slot} sponsor add: ${e.message}`)
      } else if (remote.sponsor_member_id !== local.sponsor_member_id) {
        const { error: e } = await supabase.from('member_sponsor_links')
          .update({ sponsor_member_id: local.sponsor_member_id })
          .eq('id', remote.id)
        if (e) linkErrors.push(`Slot ${slot} sponsor update: ${e.message}`)
      }
    }
    // Sponsee links — multi-row per slot, diff by sponsee_member_id.
    const { data: seExisting } = await supabase
      .from('member_sponsee_links').select('id, slot, sponsee_member_id').eq('member_id', member.id)
    for (const slot of [1, 2, 3]) {
      const localList  = sponseeLinks[slot] || []
      const remoteList = (seExisting || []).filter(r => r.slot === slot)
      const localIds  = new Set(localList.map(l => l.sponsee_member_id))
      const remoteIds = new Set(remoteList.map(r => r.sponsee_member_id))
      // Inserts: in local, not in remote
      for (const l of localList) {
        if (!remoteIds.has(l.sponsee_member_id)) {
          const { error: e } = await supabase.from('member_sponsee_links').insert({
            member_id: member.id, slot, sponsee_member_id: l.sponsee_member_id
          })
          if (e) linkErrors.push(`Slot ${slot} sponsee add: ${e.message}`)
        }
      }
      // Deletes: in remote, not in local
      for (const r of remoteList) {
        if (!localIds.has(r.sponsee_member_id)) {
          const { error: e } = await supabase.from('member_sponsee_links').delete().eq('id', r.id)
          if (e) linkErrors.push(`Slot ${slot} sponsee delete: ${e.message}`)
        }
      }
    }
    // Refresh sponsor/sponsee links from DB so id values land back in local state
    const [{ data: spRows2 }, { data: seRows2 }] = await Promise.all([
      supabase.from('member_sponsor_links').select('id, slot, sponsor_member_id').eq('member_id', member.id),
      supabase.from('member_sponsee_links').select('id, slot, sponsee_member_id').eq('member_id', member.id),
    ])
    const spMap2 = { 1: null, 2: null, 3: null }
    ;(spRows2 || []).forEach(r => { spMap2[r.slot] = r })
    setSponsorLinks(spMap2)
    const seMap2 = { 1: [], 2: [], 3: [] }
    ;(seRows2 || []).forEach(r => { (seMap2[r.slot] = seMap2[r.slot] || []).push(r) })
    setSponseeLinks(seMap2)

    // v9.51 Item 7 — Reconcile member_goal_links per (topic, slot).
    // Local state holds the desired set; DB holds the existing set.
    // For each (topic, slot) pair: INSERT if local has url and remote doesn't;
    // UPDATE if both exist and url/label differ; DELETE if remote has it and
    // local does not (either topic was deselected or slot was cleared). We
    // also DELETE all rows for any topic that's no longer in P.wellness_topics.
    const glErrors = []
    const selectedTopicSet = new Set(P.wellness_topics || [])
    const { data: glExisting } = await supabase
      .from('member_goal_links').select('id, topic, slot, url, label').eq('member_id', member.id)
    const glRemoteMap = {}
    ;(glExisting || []).forEach(r => {
      if (!glRemoteMap[r.topic]) glRemoteMap[r.topic] = { 1: null, 2: null }
      glRemoteMap[r.topic][r.slot] = { id: r.id, url: r.url, label: r.label }
    })
    // Union of all topics in either local or remote so we don't miss orphans
    const allGoalTopics = new Set([...Object.keys(goalLinks || {}), ...Object.keys(glRemoteMap)])
    for (const topic of allGoalTopics) {
      const isStillSelected = selectedTopicSet.has(topic)
      for (const slot of [1, 2]) {
        const local  = isStillSelected ? (goalLinks[topic]?.[slot] || null) : null
        const remote = glRemoteMap[topic]?.[slot] || null
        const localHasUrl = local && local.url && local.url.trim() !== ''
        // CASE 1: remote exists, local empty → delete
        if (remote && !localHasUrl) {
          const { error: e } = await supabase.from('member_goal_links').delete().eq('id', remote.id)
          if (e) glErrors.push(`${topic} slot ${slot} delete: ${e.message}`)
          continue
        }
        // CASE 2: remote missing, local has url → insert
        if (!remote && localHasUrl) {
          const { error: e } = await supabase.from('member_goal_links').insert({
            member_id: member.id, topic, slot,
            url: local.url.trim(),
            label: (local.label || '').trim() || null,
          })
          if (e) glErrors.push(`${topic} slot ${slot} add: ${e.message}`)
          continue
        }
        // CASE 3: both exist → update if changed
        if (remote && localHasUrl) {
          const localLabel = (local.label || '').trim() || null
          const remoteLabel = remote.label || null
          if (remote.url !== local.url.trim() || remoteLabel !== localLabel) {
            const { error: e } = await supabase.from('member_goal_links')
              .update({ url: local.url.trim(), label: localLabel, updated_at: new Date().toISOString() })
              .eq('id', remote.id)
            if (e) glErrors.push(`${topic} slot ${slot} update: ${e.message}`)
          }
        }
      }
    }
    // Refresh goalLinks from DB so freshly-inserted ids land back in state.
    const { data: glRows2 } = await supabase
      .from('member_goal_links').select('id, topic, slot, url, label').eq('member_id', member.id)
    const glMap2 = {}
    ;(glRows2 || []).forEach(r => {
      if (!glMap2[r.topic]) glMap2[r.topic] = { 1: null, 2: null }
      glMap2[r.topic][r.slot] = { id: r.id, url: r.url, label: r.label }
    })
    setGoalLinks(glMap2)

    const allErrors = [...hgErrors, ...linkErrors, ...glErrors]
    setSaving(false)
    if (allErrors.length) {
      setMsg('Saved with warnings: ' + allErrors.join('; '))
    } else {
      setMsg('Saved ✓'); setDirty(false); setTimeout(()=>setMsg(''), 2500)
    }
  }

  async function uploadAvatar(file) {
    if (!member||!file) return
    if (!['image/jpeg','image/png','image/gif','image/webp'].includes(file.type)) return
    setAvatarUploading(true)
    try {
      const ext = file.name.split('.').pop()
      const path = `${member.id}/avatar.${ext}`
      const { error } = await supabase.storage.from('avatars').upload(path, file, { upsert:true })
      if (error) throw error
      const { data:{ publicUrl } } = supabase.storage.from('avatars').getPublicUrl(path)
      await supabase.from('members').update({ avatar_url: publicUrl }).eq('id', member.id)
      setAvatarUrl(publicUrl)
    } catch(e){ console.error(e) }
    setAvatarUploading(false)
  }

  if (loading) return <div style={{paddingTop:40}}><div className="spinner"/></div>

  // v9.54 — Basics tab merged into My Account. The merged tab now hosts
  // Profile / Where & When / Contact / Audio (formerly Basics) + Membership
  // / Notifications & Privacy / Referral Impact / Account Actions / Path to
  // Moderator (formerly Account). Tab count drops 6 → 5; My Account leads
  // because it's the entry point for new members completing their profile.
  const TABS   = ['account','identity','recovery','goals','preview']
  const LABELS = { account:'My Account', identity:'Identity', recovery:'Recovery', goals:'Goals', preview:'Preview' }

  const dayNum = Math.max(1,Math.floor((new Date()-new Date((member?.membership_start_date||new Date().toISOString().split('T')[0])+'T00:00:00'))/86400000)+1)
  const programs = [1,2,3].filter(n=>P[`program_${n}`]).map(n=>({ name:P[`program_${n}`], date:P[`program_${n}_date`], stats:sobrietyStats(P[`program_${n}_date`]) }))

  return (
    <div style={{paddingTop:20,paddingBottom:48}}>
      {/* v9.46 Item 1 — admin-edit banner. Pink left-border treatment, non-dismissable. */}
      {isAdminEdit && member && (
        <div style={{
          margin:'0 16px 16px',
          padding:'12px 14px',
          borderRadius:8,
          background:'rgba(255,20,147,.08)',
          borderLeft:'4px solid var(--pink)',
          border:'1px solid rgba(255,20,147,.25)',
          display:'flex',
          alignItems:'center',
          gap:10,
          flexWrap:'wrap',
        }}>
          <span style={{fontSize:18}}>✏️</span>
          <span style={{fontSize:13,fontFamily:'var(--font-ui)',fontWeight:700,color:'var(--pink)',letterSpacing:.5,textTransform:'uppercase'}}>
            Editing {member.display_name || member.email?.split('@')[0] || 'Member'} as Admin
          </span>
          <span style={{fontSize:11,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.55)',marginLeft:'auto'}}>
            {member.email}
          </span>
        </div>
      )}

      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20,padding:'0 16px'}}>
        <h2 style={{fontSize:20,fontWeight:400}}>{isAdminEdit ? "Member's Profile" : 'My Profile'}</h2>
        <button onClick={onClose} style={{color:'rgba(251,250,244,.45)',fontSize:13,fontFamily:'var(--font-ui)'}}>← Back</button>
      </div>

      {member && (
        <div style={{padding:'0 16px',marginBottom:16}}>
          <MemberBadges member={member} size="md" layout="inline"/>
        </div>
      )}

      <div className="tab-bar" style={{marginBottom:20,padding:'0 16px'}}>
        {TABS.map(t=><button key={t} onClick={()=>setTab(t)} className={`tab-btn${tab===t?' active':''}`}>{LABELS[t]}</button>)}
      </div>

      <div style={{padding:'0 16px'}}>

      {/* ── BASICS block deleted in v9.54 — merged into MY ACCOUNT below ── */}


      {/* ── IDENTITY ── */}
      {tab==='identity' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:16}}>
          All fields are optional. Whatever you fill in will appear on your member profile. Leave blank anything you prefer to keep private.
        </p>
        {/* v9.51 — Compact pickers: each field collapses to its current
            value as a chip, with one tap to expand the full option library
            inline. Keeps the Identity tab tight on PWA viewports without
            hiding any choices from the user.
            v9.53 — Demographics + languages now arranged in auto-fit grids
            so the tab compacts side-by-side at any width with room. On
            iPhone narrow: 2 cols for demographics, 1 col for the rest.
            On iPad portrait+: 4 cols demographics, 2 cols languages. */}
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(160px, 1fr))', gap:'0 14px', marginBottom:6}}>
          <div><Lbl t="PRONOUNS"/><PickOne fieldKey="pronouns" P={P} set={set} opts={PRONOUNS} placeholder="Tap to choose pronouns"/></div>
          <div><Lbl t="SEXUAL ORIENTATION"/><PickOne fieldKey="sexual_orientation" P={P} set={set} opts={ORIENTATIONS}/></div>
          <div><Lbl t="GENDER IDENTITY"/><PickOne fieldKey="gender_identity" P={P} set={set} opts={GENDERS}/></div>
          <div><Lbl t="RACE / ETHNICITY"/><PickOne fieldKey="ethnicity" P={P} set={set} opts={ETHNICITIES}/></div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(160px, 1fr))', gap:'0 14px', marginBottom:6}}>
          <div><Lbl t="SPOKEN LANGUAGES"/><PickMany fieldKey="spoken_languages" P={P} set={set} opts={LANGUAGES} addLabel="+ Add a language"/></div>
          <div><Lbl t="WRITTEN LANGUAGES"/><PickMany fieldKey="written_languages" P={P} set={set} opts={LANGUAGES} addLabel="+ Add a language"/></div>
        </div>
        <Lbl t="PETS" sub="(optional)"/>
        {/* v9.51 — Per-pet card: photo (40×40 square) + type/name/age in a
            compact row. Photo upload reuses the avatars storage bucket
            with a pets/ path prefix so existing RLS applies. */}
        <div style={{display:'flex', flexDirection:'column', gap:10, marginTop:8}}>
          {pets.map((pet,i)=>(
            <PetRow key={i} pet={pet} index={i} memberId={member?.id}
              onChange={(field, val) => setPet(i, field, val)}
              onRemove={() => removePet(i)}
              onPhoto={(url) => setPet(i, 'photo_url', url)}/>
          ))}
        </div>
        <button onClick={addPet} style={{marginTop:10,padding:'8px 14px',borderRadius:8,background:'rgba(255,255,255,.06)',border:'1px solid var(--border)',color:'rgba(251,250,244,.6)',fontSize:13,fontFamily:'var(--font-ui)',cursor:'pointer'}}>+ Add a Pet</button>
      </>}

      {/* ── RECOVERY ── */}
      {tab==='recovery' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:16}}>
          Up to 3 programs. Each one is its own card — fill what fits, leave the rest. Everything below appears on your member profile.
        </p>
        {[1,2,3].map(n=>{
          const programVal = P[`program_${n}`] || ''
          const showHomeGroup = programVal && !PROGRAMS_WITHOUT_HOME_GROUPS.includes(programVal)
          // v9.50 — Stopped Smoking is the milestone-only program. We render
          // ONLY the date + counter — no home group, no sponsorship row, no
          // per-program recovery bio. The card edge does the visual framing.
          const isMilestoneOnly = PROGRAMS_WITHOUT_HOME_GROUPS.includes(programVal)
          const directoryUrl  = MEETING_DIRECTORY_URLS[programVal]
          const programLabel  = (PROGRAMS.find(p => p.value === programVal) || {}).label || programVal
          const programIcon   = PROGRAM_ICONS[programVal]
          // Effective-date label adapts to fellowship verb (sober / clean / etc).
          const verb = SOBRIETY_VERB[programVal]
          const dateLbl = verb === 'smoke-free' ? 'SMOKE-FREE SINCE'
                        : verb === 'clean'      ? 'CLEAN DATE'
                        : verb === 'abstinent'  ? 'ABSTINENT SINCE'
                        : 'SOBRIETY / EFFECTIVE DATE'
          return (
          <div key={n} style={{
            marginBottom:14,
            padding:16,
            borderRadius:12,
            background: programVal ? 'rgba(255,20,147,.04)' : 'rgba(255,255,255,.03)',
            border: programVal ? '2px solid rgba(255,20,147,.45)' : '1px solid var(--border)',
          }}>
            {/* v9.50 — Card header. When a program is selected we show the
                linked icon + name; the program-change dropdown moves below.
                When empty we show a clean prompt.
                v9.51 — Pink emphasis: thicker border + bold pink program name
                so each program reads as a clear visual grouping. */}
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', gap:10, flexWrap:'wrap', marginBottom:8}}>
              {programVal ? (
                <div style={{display:'flex', alignItems:'center', gap:10}}>
                  {directoryUrl ? (
                    <a href={directoryUrl} target="_blank" rel="noreferrer" title={`Visit ${programLabel}`}
                      style={{display:'inline-flex', alignItems:'center', justifyContent:'center', width:34, height:34, borderRadius:8, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)', textDecoration:'none', fontSize:18}}>
                      {programIcon || '🪄'}
                    </a>
                  ) : (
                    <span style={{display:'inline-flex', alignItems:'center', justifyContent:'center', width:34, height:34, borderRadius:8, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)', fontSize:18}}>
                      {programIcon || '🪄'}
                    </span>
                  )}
                  <div>
                    {directoryUrl ? (
                      <a href={directoryUrl} target="_blank" rel="noreferrer"
                        style={{fontSize:16, fontWeight:700, color:'var(--pink)', fontFamily:'var(--font-ui)', textDecoration:'none', letterSpacing:.3}}>
                        {programLabel}
                      </a>
                    ) : (
                      <span style={{fontSize:16, fontWeight:700, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:.3}}>{programLabel}</span>
                    )}
                    <div style={{fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginTop:1}}>Slot {n}{n>1?' · optional':''}</div>
                  </div>
                </div>
              ) : (
                <p style={{fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, margin:0}}>
                  PROGRAM {n}{n>1 && <span style={{color:'rgba(251,250,244,.2)'}}> (optional)</span>}
                </p>
              )}
              {programVal && P[`program_${n}_date`] && (
                <button onClick={()=>set(`show_years_${n}`,P[`show_years_${n}`]===false?true:false)}
                  title="Toggle whether this anniversary appears on the Community Calendar"
                  style={{fontSize:11,fontFamily:'var(--font-ui)',padding:'4px 12px',borderRadius:20,cursor:'pointer',
                    background:P[`show_years_${n}`]!==false?'rgba(25,229,94,.12)':'rgba(255,255,255,.06)',
                    border:`1px solid ${P[`show_years_${n}`]!==false?'rgba(25,229,94,.3)':'rgba(255,255,255,.12)'}`,
                    color:P[`show_years_${n}`]!==false?'var(--lime)':'rgba(251,250,244,.35)'}}>
                  {P[`show_years_${n}`]!==false?'📅 Showing on calendar':'Hidden from calendar'}
                </button>
              )}
            </div>

            {/* Program / date — compact 2-up grid */}
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom: programVal ? 12 : 0}}>
              <div>
                <p style={{fontSize:10,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:4,marginTop:0}}>PROGRAM</p>
                <select value={programVal} onChange={e => setProgramSlot(n, e.target.value)}>
                  <option value="">Select program…</option>
                  {PROGRAMS.map(p=><option key={p.value} value={p.value}>{p.label}</option>)}
                </select>
              </div>
              {programVal && (
                <div>
                  <p style={{fontSize:10,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:4,marginTop:0}}>{dateLbl}</p>
                  <input type="date" value={P[`program_${n}_date`]||''} onChange={e=>set(`program_${n}_date`,e.target.value||null)}/>
                </div>
              )}
            </div>

            {programVal && <>
              {/* Counter — same component, verb auto-adapts */}
              <SobrietyCounter dateStr={P[`program_${n}_date`]} program={programVal}/>

              {/* v9.50 — Sponsorship row (hidden for milestone-only programs) */}
              {!isMilestoneOnly && (
                <SponsorshipRow
                  slot={n}
                  sponsorStatus={P[`sponsor_status_${n}`] || 'none'}
                  sponseeCount ={P[`sponsee_count_${n}`]   || 'none'}
                  sponsorLink  ={sponsorLinks[n]}
                  sponseeLinks ={sponseeLinks[n] || []}
                  allMembers   ={allMembers}
                  currentMemberId={member?.id}
                  onSponsorStatus={(v) => {
                    set(`sponsor_status_${n}`, v)
                    // If switching away from 'has', clear the local link too
                    if (v !== 'has') setSponsorLinks(prev => ({ ...prev, [n]: null }))
                  }}
                  onSponseeCount={(v) => {
                    set(`sponsee_count_${n}`, v)
                    // If switching to 'none', clear all local sponsee tags for this slot
                    if (v === 'none') setSponseeLinks(prev => ({ ...prev, [n]: [] }))
                  }}
                  onSponsorPick={(m) => {
                    setSponsorLinks(prev => ({ ...prev, [n]: { sponsor_member_id: m.id } }))
                    setDirty(true)
                  }}
                  onSponsorClear={() => {
                    setSponsorLinks(prev => ({ ...prev, [n]: null }))
                    setDirty(true)
                  }}
                  onSponseeAdd={(m) => {
                    setSponseeLinks(prev => ({
                      ...prev,
                      [n]: [...(prev[n] || []), { sponsee_member_id: m.id }]
                    }))
                    setDirty(true)
                  }}
                  onSponseeRemove={(m) => {
                    setSponseeLinks(prev => ({
                      ...prev,
                      [n]: (prev[n] || []).filter(l => l.sponsee_member_id !== m.id)
                    }))
                    setDirty(true)
                  }}
                />
              )}

              {/* v9.48.1 Item 11A — Per-slot Home Group card. Hidden for milestone-only
                  programs like Stopped Smoking (no fellowship → no meeting structure). */}
              {showHomeGroup && (
                <HomeGroupCard
                  slot={n}
                  program={programVal}
                  value={homeGroups[n] && !homeGroups[n]._delete ? homeGroups[n] : null}
                  onChange={setHomeGroup}
                  onClear={clearHomeGroup}
                />
              )}

              {/* v9.50 — Per-program Recovery Story (hidden for milestone-only) */}
              {!isMilestoneOnly && (
                <div style={{marginTop:14}}>
                  <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:6}}>
                    <p style={{fontSize:10, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', letterSpacing:1, margin:0}}>RECOVERY STORY (THIS PROGRAM)</p>
                    <span style={{fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)'}}>{(P[`recovery_bio_${n}`]||'').length}/500</span>
                  </div>
                  <textarea rows={3} value={P[`recovery_bio_${n}`]||''}
                    onChange={e => {
                      const v = e.target.value.slice(0, 500)
                      set(`recovery_bio_${n}`, v)
                    }}
                    placeholder={`A short paragraph about your ${programLabel} journey…`}
                    style={{resize:'vertical'}}/>
                </div>
              )}
            </>}
          </div>
        )})}
      </>}

      {/* ── GOALS ── */}
      {tab==='goals' && <>
        <p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.7,marginBottom:4}}>Select the areas of your life you want to focus on in recovery.</p>
        <p style={{fontSize:12,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:20}}>Your selected topics will appear on your member profile. Add up to 2 URL recommendations per topic — a website, app, or book that supports your work in that area.</p>
        {WELLNESS_AREAS.map(area=><WellnessArea
          key={area.key}
          area={area}
          selectedTopics={P.wellness_topics||[]}
          onToggle={t=>toggleList('wellness_topics',t)}
          goalLinks={goalLinks}
          onSetGoalLink={(topic, slot, fields) => {
            // Update local goalLinks state. Persisted on save() via reconcile.
            setGoalLinks(prev => {
              const next = { ...prev }
              const cur = next[topic] ? { ...next[topic] } : { 1: null, 2: null }
              const url = (fields.url || '').trim()
              const label = (fields.label || '').trim()
              if (!url && !label) {
                cur[slot] = null
              } else {
                cur[slot] = { ...(cur[slot] || {}), url, label }
              }
              if (!cur[1] && !cur[2]) {
                delete next[topic]
              } else {
                next[topic] = cur
              }
              return next
            })
            setDirty(true)
          }}
        />)}
      </>}

      {/* ── PREVIEW ── v9.51 rebuilt: render via shared ProfileSnapshot component
          so this view is byte-identical to what shows in the Member Directory
          when someone else taps this profile. Legacy ABOUT (singular bio)
          and HOME GROUP (singular row) sections are gone — both lived as
          stale reads of the v9.50 per-slot canonical schema. */}
      {tab==='preview' && (()=>{
        // Build a Map of community members by id, used by ProfileSnapshot
        // to resolve sponsor/sponsee chips and apply consent gating.
        const membersById = new Map((allMembers || []).map(m => [m.id, m]))
        // Synthesize a "member" prop carrying P (the live edit-state) merged
        // onto the persisted member row, so unsaved changes preview correctly.
        const liveMember = { ...(member || {}), ...P }
        return (
          <ProfileSnapshot
            member={liveMember}
            homeGroups={homeGroups}
            sponsorLinks={sponsorLinks}
            sponseeLinks={sponseeLinks}
            goalLinks={goalLinks}
            membersById={membersById}
            approvedHeroes={approvedHeroes}
            womPlaces={womPlaces}
            contributions={contributions}
            viewMode="preview"
            avatarUrlOverride={avatarUrl}
          />
        )
      })()}


      {/* ── MY ACCOUNT (v9.54 merged tab) ──
          Combines former Basics + Account into one entry-point tab.
          Sections, top to bottom:
            1. PROFILE — avatar, names
            2. WHERE & WHEN — zip, timezone (v9.53 paired grid)
            3. CONTACT — phone, DOB, email (v9.53 paired grid)
            4. AUDIO — voice picker (Brian — as Your Fairy Godfather format)
            5. MEMBERSHIP — number card + status table (Email row removed
               since it's now in CONTACT above — single source of truth)
            6. NOTIFICATIONS & PRIVACY — cheers digest + sponsor/sponsee tags
            7. YOUR REFERRAL IMPACT — compacted: 3 stat tiles + chip row
            8. ACCOUNT ACTIONS — Sign Out + GDPR (admin-edit hides whole block)
          The Path to Moderator callout sits outside this div, conditional
          on tab==='account' (formerly basics-only). */}
      {tab==='account' && <>

        {/* ─── 1. PROFILE ─── */}
        <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14,marginTop:0}}>PROFILE</p>

        {/* Avatar */}
        <div style={{textAlign:'center',marginBottom:20}}>
          <label style={{position:'relative',display:'inline-block',cursor:'pointer'}}
            onDragOver={e=>{e.preventDefault();e.stopPropagation();setDragOver(true)}}
            onDragEnter={e=>{e.preventDefault();e.stopPropagation();setDragOver(true)}}
            onDragLeave={e=>{e.preventDefault();e.stopPropagation();setDragOver(false)}}
            onDrop={e=>{e.preventDefault();e.stopPropagation();setDragOver(false);const f=e.dataTransfer.files[0];if(f)uploadAvatar(f)}}>
            <div style={{width:88,height:88,borderRadius:'50%',overflow:'hidden',border:`3px solid ${dragOver?'var(--lime)':'var(--pink)'}`,background:'rgba(255,20,147,.1)',transition:'border-color .2s',transform:dragOver?'scale(1.08)':'scale(1)'}}>
              {avatarUploading?<div className="spinner" style={{margin:'auto',marginTop:28,width:24,height:24,borderWidth:2}}/>:<img src={avatarUrl} alt="" style={{width:88,height:88,objectFit:'cover'}}/>}
            </div>
            <div style={{position:'absolute',bottom:2,right:2,background:'var(--pink)',borderRadius:'50%',width:24,height:24,display:'flex',alignItems:'center',justifyContent:'center',fontSize:12,boxShadow:'0 0 0 2px var(--bg)',pointerEvents:'none'}}>📷</div>
            <input type="file" accept="image/jpeg,image/png,image/gif,image/webp" style={{display:'none'}} onChange={e=>{const f=e.target.files?.[0];if(f)uploadAvatar(f);e.target.value=''}}/>
          </label>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:8}}>{dragOver?'✅ Drop now!':avatarUploading?'Uploading…':'Tap to upload your photo'}</p>
        </div>

        <Lbl t="DISPLAY NAME" req={true} sub="(shown to all members)"/>
        <Inp fieldKey="display_name" P={P} set={set} placeholder="Your community name"/>

        <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginTop:4}}>
          <div><Lbl t="FIRST NAME" req={true}/><Inp fieldKey="first_name" P={P} set={set} placeholder="First"/></div>
          <div><Lbl t="LAST NAME" req={true}/><Inp fieldKey="last_name" P={P} set={set} placeholder="Last"/></div>
        </div>
        <Chk fieldKey="show_full_name" P={P} set={set} label="Show my full name on my member profile"/>

        {/* ─── 2. WHERE & WHEN ─── */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>WHERE &amp; WHEN</p>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:'0 18px'}}>
            <div>
              <Lbl t="ZIP CODE" req={true}/>
              <div style={{display:'flex',gap:10,alignItems:'center'}}>
                <input value={P.zip_code||''} onChange={e=>handleZipChange(e.target.value)} placeholder="90210" maxLength={10} style={{flex:'0 0 120px'}}/>
                {zipLooking&&<span style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>Looking up…</span>}
                {P.city&&!zipLooking&&<span style={{fontSize:13,color:'var(--lime)',fontFamily:'var(--font-ui)'}}>📍 {P.city}</span>}
              </div>
              <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginTop:4}}>City auto-fills. Only your city is shown to members — never your zip.</p>
            </div>
            <div>
              <Lbl t="TIMEZONE" req={true} sub="(determines when your morning + evening practice emails arrive)"/>
              <div style={{display:'flex',gap:8,alignItems:'center'}}>
                <div style={{flex:1}}>
                  <Sel fieldKey="timezone" P={P} set={set} opts={TIMEZONES} ph="Select timezone…"/>
                </div>
                <button
                  type="button"
                  onClick={()=>{
                    try {
                      const detected = Intl.DateTimeFormat().resolvedOptions().timeZone
                      if (!detected) {
                        setTzDetectMsg('⚠️ Could not detect — please pick from the list')
                      } else {
                        const inList = TIMEZONES.some(t => t[0] === detected)
                        const friendly = detected.split('/').pop().replace(/_/g,' ')
                        if (!inList) {
                          setTzDetectMsg(`Detected ${detected} — not in our list yet. Pick the closest match below.`)
                        } else if (P.timezone === detected) {
                          setTzDetectMsg(`✓ Already set to ${friendly}`)
                        } else {
                          set('timezone', detected)
                          setTzDetectMsg(`✓ Set to ${friendly}`)
                        }
                      }
                    } catch {
                      setTzDetectMsg('⚠️ Could not detect — please pick from the list')
                    }
                    setTimeout(() => setTzDetectMsg(''), 4000)
                  }}
                  title="Use the timezone your device reports"
                  style={{padding:'8px 12px',borderRadius:8,background:'rgba(25,229,94,.08)',border:'1px solid rgba(25,229,94,.25)',color:'var(--lime)',fontSize:12,fontFamily:'var(--font-ui)',cursor:'pointer',whiteSpace:'nowrap'}}>
                  🌐 Find Me
                </button>
              </div>
              {tzDetectMsg && (
                <p style={{
                  fontSize:12,
                  color: tzDetectMsg.startsWith('⚠️') ? 'var(--pink)' : 'var(--lime)',
                  fontFamily:'var(--font-ui)',
                  marginTop:6,
                  transition:'opacity .2s'
                }}>{tzDetectMsg}</p>
              )}
            </div>
          </div>
        </div>

        {/* ─── 3. CONTACT ─── */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>CONTACT</p>
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(200px, 1fr))', gap:'0 18px'}}>
            <div>
              <Lbl t="PHONE" sub="(for reminders)"/>
              <input value={P.phone||''} onChange={e=>set('phone',formatPhone(e.target.value))} placeholder="(555) 555-5555" type="tel"/>
              <Chk fieldKey="show_phone" P={P} set={set} label="Show my phone number on my member profile"/>
            </div>
            <div>
              <Lbl t="DATE OF BIRTH"/>
              <input type="date" value={P.birth_date||''} onChange={e=>set('birth_date',e.target.value||null)}/>
              <Chk fieldKey="show_age" P={P} set={set} label="Show my age on my member profile"/>
            </div>
          </div>
          <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginTop:6,lineHeight:1.6}}>
            Your birthday (month &amp; day) always appears on the community calendar. Only your age is optional.
          </p>

          <Lbl t="EMAIL" sub="(your login email — cannot be changed)"/>
          <p style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',padding:'10px 12px',borderRadius:8,background:'rgba(255,255,255,.04)',border:'1px solid rgba(255,255,255,.07)',marginBottom:4}}>{isAdminEdit ? (member?.email || '—') : user.email}</p>
          <Chk fieldKey="show_email" P={P} set={set} label="Show my email address on my member profile"/>
        </div>

        {/* ─── 4. AUDIO ─── */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:8}}>AUDIO</p>
          <p style={{fontSize:13,color:'rgba(251,250,244,.55)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:14}}>
            The voice you hear during your daily practice.
          </p>
          {/* v9.54 — Voice picker. The "[Name] — as Your Fairy Godfather"
              format is the canonical member-facing convention because YFG
              will offer multiple voices over time (Cindy as YFG, George as
              YFG, etc.). The voice product name identifies which voice is
              delivering the persona. value="brian" is the internal field
              identifier and is not displayed. */}
          <label style={{display:'flex',alignItems:'center',gap:12,padding:'12px 14px',background:'rgba(255,20,147,.06)',border:'1px solid rgba(255,20,147,.18)',borderRadius:8,cursor:'pointer'}}>
            <input
              type="radio"
              name="preferred_voice"
              value="brian"
              checked={true}
              readOnly
              style={{accentColor:'var(--pink)',width:16,height:16,flexShrink:0}}
            />
            <div style={{flex:1}}>
              <div style={{fontSize:14,fontFamily:'var(--font-ui)',fontWeight:600,color:'var(--cream)'}}>
                Brian — as Your Fairy Godfather
              </div>
              <div style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',marginTop:2}}>
                Warm, clear, mid-pace
              </div>
            </div>
            <span style={{fontSize:10,fontFamily:'var(--font-ui)',fontWeight:700,color:'var(--pink)',background:'rgba(255,20,147,.15)',padding:'3px 8px',borderRadius:10,letterSpacing:.5}}>
              DEFAULT
            </span>
          </label>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:10,lineHeight:1.6,fontStyle:'italic'}}>
            More voices will appear here as our community grows. 🪄
          </p>
        </div>

        {/* ─── 5. MEMBERSHIP ─── */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>MEMBERSHIP</p>

          {/* Member Number Card */}
          {member?.member_number && (
            <div style={{background:'linear-gradient(135deg,rgba(255,20,147,.08),rgba(25,229,94,.05))',border:'1px solid rgba(255,20,147,.25)',borderRadius:14,padding:'24px 20px',marginBottom:20,textAlign:'center'}}>
              <p style={{fontSize:11,letterSpacing:3,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',textTransform:'uppercase',marginBottom:10}}>Your Place in the Story</p>
              <p style={{fontSize:52,fontWeight:700,color:'var(--pink)',fontFamily:'var(--font-ui)',lineHeight:1,marginBottom:6}}>#{member.member_number}</p>
              <p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom: member.member_number <= 100 ? 12 : 0}}>
                You are Member #{member.member_number} of YRTCYK.
              </p>
              {member.member_number <= 100 && (
                <div style={{display:'inline-block',background:'rgba(25,229,94,.12)',border:'1px solid rgba(25,229,94,.3)',borderRadius:20,padding:'4px 14px',marginTop:4}}>
                  <span style={{fontSize:11,color:'var(--lime)',fontFamily:'var(--font-ui)',fontWeight:700,letterSpacing:1}}>🌈 FOUNDING MEMBER</span>
                </div>
              )}
            </div>
          )}

          {/* Status table — Email row removed in v9.54; it's in CONTACT above. */}
          <div>
            {[['Membership',member?.membership_tier==='web_app'?'Web + App':'Web'],['Member Since',member?.membership_start_date?new Date(member.membership_start_date).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'}):'—'],['Status','● Active'],['Day',`${dayNum} of 365`]].map(([label,value])=>(
              <div key={label} style={{display:'flex',justifyContent:'space-between',alignItems:'center',padding:'12px 0',borderBottom:'1px solid rgba(255,255,255,.06)'}}>
                <span style={{fontSize:13,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.45)'}}>{label}</span>
                <span style={{fontSize:13,fontFamily:'var(--font-ui)',color:label==='Status'?'var(--lime)':'var(--cream)'}}>{value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* ─── 6. NOTIFICATIONS & PRIVACY ─── */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>NOTIFICATIONS &amp; PRIVACY</p>

          {/* Cheers digest (v9.47.1 Item 7.1) */}
          <div style={{marginBottom:14,padding:'14px 16px',borderRadius:8,background:'rgba(255,255,255,.03)',border:'1px solid rgba(255,255,255,.06)'}}>
            <label style={{display:'flex',alignItems:'flex-start',gap:12,cursor:'pointer'}}>
              <input
                type="checkbox"
                checked={!!P.cheers_digest_email}
                onChange={e => set('cheers_digest_email', e.target.checked)}
                style={{width:18,height:18,accentColor:'var(--pink)',marginTop:2,flexShrink:0}}
              />
              <div style={{minWidth:0}}>
                <p style={{fontSize:14,fontFamily:'var(--font-ui)',color:'var(--cream)',marginBottom:4}}>
                  💗 Daily cheers digest
                </p>
                <p style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',lineHeight:1.5}}>
                  Receive an email each evening summarizing the cheers other members sent you that day. Off by default.
                </p>
              </div>
            </label>
          </div>

          {/* Sponsor / sponsee tagging consent (v9.50). Default ON. */}
          <div style={{padding:'14px 16px',borderRadius:8,background:'rgba(255,255,255,.03)',border:'1px solid rgba(255,255,255,.06)'}}>
            <label style={{display:'flex',alignItems:'flex-start',gap:12,cursor:'pointer',marginBottom:14}}>
              <input
                type="checkbox"
                checked={P.allow_sponsor_tags !== false}
                onChange={e => set('allow_sponsor_tags', e.target.checked)}
                style={{width:18,height:18,accentColor:'var(--pink)',marginTop:2,flexShrink:0}}
              />
              <div style={{minWidth:0}}>
                <p style={{fontSize:14,fontFamily:'var(--font-ui)',color:'var(--cream)',marginBottom:4}}>
                  Allow other members to tag me as their sponsor
                </p>
                <p style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',lineHeight:1.5}}>
                  When members fill out their Recovery tab and identify their sponsor, they can tag you (with a thumbnail link to your profile) if you're in the community. Turn this off to opt out — your name won't appear as anyone's sponsor on the community-facing profile.
                </p>
              </div>
            </label>
            <label style={{display:'flex',alignItems:'flex-start',gap:12,cursor:'pointer'}}>
              <input
                type="checkbox"
                checked={P.allow_sponsee_tags !== false}
                onChange={e => set('allow_sponsee_tags', e.target.checked)}
                style={{width:18,height:18,accentColor:'var(--pink)',marginTop:2,flexShrink:0}}
              />
              <div style={{minWidth:0}}>
                <p style={{fontSize:14,fontFamily:'var(--font-ui)',color:'var(--cream)',marginBottom:4}}>
                  Allow other members to tag me as their sponsee
                </p>
                <p style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.5)',lineHeight:1.5}}>
                  Same as above, but for sponsees. Off here means your name won't appear in anyone's "Sponsees" list on the community-facing profile.
                </p>
              </div>
            </label>
          </div>
        </div>

        {/* ─── 7. YOUR REFERRAL IMPACT ──
            v9.54 compaction: replaces the per-row vertical list with a
            summary header (3 stat tiles using the v9.52 Community
            Contributions auto-fill pattern) plus a chip row showing each
            referral with a status icon. ~50% vertical reduction vs the
            prior layout. Empty state preserves the existing nudge to
            🌈 Widen the Circle. */}
        <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>YOUR REFERRAL IMPACT</p>
          {referrals.length === 0 ? (
            <p style={{fontSize:13,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',fontStyle:'italic'}}>
              No referrals yet. Share your invite link from the 🌈 Widen the Circle tab.
            </p>
          ) : (() => {
            const joined   = referrals.filter(r => ['joined','month_1','month_2','rewarded'].includes(r.status)).length
            const rewarded = referrals.filter(r => ['month_2','rewarded'].includes(r.status)).length
            const refIcon  = { invited:'✉', joined:'✓', month_1:'⏳', month_2:'🎁', rewarded:'🎁' }
            const refColor = { invited:'rgba(251,250,244,.35)', joined:'gold', month_1:'orange', month_2:'var(--lime)', rewarded:'var(--lime)' }
            return (
              <>
                {/* Stat tiles — auto-fill grid matching v9.52 pattern */}
                <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(90px, 1fr))', gap:8, marginBottom:14}}>
                  {[
                    ['INVITED',  referrals.length, 'rgba(251,250,244,.85)'],
                    ['JOINED',   joined,           'gold'],
                    ['REWARDED', rewarded,         'var(--lime)'],
                  ].map(([label, val, color]) => (
                    <div key={label} style={{
                      padding:'10px 8px',
                      borderRadius:10,
                      background:'rgba(255,20,147,.04)',
                      border:'1px solid rgba(255,20,147,.15)',
                      textAlign:'center',
                    }}>
                      <p style={{fontSize:22, fontWeight:700, color, fontFamily:'Georgia, serif', lineHeight:1, marginBottom:4, fontVariantNumeric:'tabular-nums'}}>{val}</p>
                      <p style={{fontSize:9, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:1.2}}>{label}</p>
                    </div>
                  ))}
                </div>
                {/* Chip row — one chip per referral with status icon */}
                <div style={{display:'flex', flexWrap:'wrap', gap:6}}>
                  {referrals.map(r => {
                    const local = r.referred_email ? r.referred_email.split('@')[0] : 'Member'
                    const icon  = refIcon[r.status] || '✉'
                    const color = refColor[r.status] || 'rgba(251,250,244,.4)'
                    return (
                      <span key={r.id} style={{
                        padding:'4px 10px', borderRadius:20,
                        fontSize:11, fontFamily:'var(--font-ui)',
                        background:'rgba(255,255,255,.04)',
                        border:'1px solid rgba(255,255,255,.08)',
                        color:'rgba(251,250,244,.7)',
                        display:'inline-flex', alignItems:'center', gap:5,
                      }}>
                        {local}
                        <span style={{color, fontSize:11}}>{icon}</span>
                      </span>
                    )
                  })}
                </div>
                <p style={{fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginTop:10, lineHeight:1.6, fontStyle:'italic'}}>
                  Want to invite more? Head to the 🌈 Widen the Circle tab.
                </p>
              </>
            )
          })()}
        </div>

        {/* ─── 7.5 BLOCKED MEMBERS ─── own profile only (v9.56) */}
        {!isAdminEdit && <BlockedMembers myMemberId={member?.id} />}

        {/* ─── 8. ACCOUNT ACTIONS ───
            Sign Out + GDPR are scoped to the auth user — admin-edit hides
            the entire block since admins can't sign out as the member they're
            editing or trigger that member's GDPR controls. */}
        {!isAdminEdit && (
          <div style={{marginTop:32,paddingTop:24,borderTop:'1px solid rgba(255,255,255,.08)'}}>
            <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:14}}>ACCOUNT ACTIONS</p>
            <button onClick={()=>supabase.auth.signOut()} style={{width:'100%',padding:'12px',borderRadius:8,background:'rgba(255,255,255,.05)',border:'1px solid var(--border)',color:'rgba(251,250,244,.5)',fontSize:14,fontFamily:'var(--font-ui)',cursor:'pointer'}}>Sign Out</button>

            <div style={{marginTop:24}}>
              <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:8}}>YOUR DATA</p>
              <p style={{fontSize:12,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:14}}>
                Under GDPR and CCPA, you have the right to access and delete your personal data at any time.
              </p>
              <GdprControls user={user} member={member}/>
            </div>
          </div>
        )}
      </>}


      </div>

      {/* ── MODERATOR PATH — My Account tab only (v9.54: was Basics-only) ── */}
      {tab==='account'&&(
        <div style={{margin:'28px 16px 0',background:'rgba(255,20,147,.04)',border:'1px solid rgba(255,20,147,.15)',borderRadius:12,padding:20}}>
          <p style={{fontSize:13,fontWeight:700,color:'var(--pink)',fontFamily:'var(--font-ui)',marginBottom:10}}>✨ The Path to Moderator</p>
          <p style={{fontSize:13,color:'rgba(251,250,244,.55)',fontFamily:'var(--font-ui)',lineHeight:1.65,marginBottom:16}}>YRTCYK is moderated by members who have earned it — through consistent daily practice, genuine community contribution, and showing up for the WE of recovery.</p>
          {[
            {step:'1',text:'Complete The Daily Action consistently as a paying member'},
            {step:'2',text:'Share your Heroes, support your fellows, show up with honesty'},
            {step:'3',text:'Receive your invitation to become an Approved Moderator'},
          ].map(({step,text})=>(
            <div key={step} style={{display:'flex',alignItems:'flex-start',gap:12,marginBottom:10}}>
              <div style={{background:'var(--pink)',color:'#fff',borderRadius:'50%',width:22,height:22,display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,flexShrink:0,marginTop:1}}>{step}</div>
              <p style={{fontSize:13,color:'rgba(251,250,244,.65)',fontFamily:'var(--font-ui)',margin:0,lineHeight:1.5}}>{text}</p>
            </div>
          ))}
        </div>
      )}

      {/* v9.54 — Save shows on every tab except Preview. Was previously
          hidden on Account when !dirty, but Account is now the primary
          editor surface (post-Basics-merge) so always-visible Save with
          disabled state is the right pattern for an editable form. */}
      {tab!=='preview'&&(
        <div style={{padding:'24px 16px 0'}}>
          {msg&&<p style={{fontSize:13,fontFamily:'var(--font-ui)',textAlign:'center',marginBottom:12,color:msg.startsWith('Error')||msg.includes('required')?'var(--pink)':'var(--lime)'}}>{msg}</p>}
          <button className="btn-primary" style={{width:'100%',padding:14}} onClick={save} disabled={saving||!dirty}>{saving?'Saving…':'Save Changes'}</button>
        </div>
      )}
    </div>
  )
}

// ============================================================
// GdprControls — Download my data / Delete my account
// ============================================================
function GdprControls({ user, member }) {
  const [busy, setBusy] = useState('')
  const [gdprMsg, setGdprMsg] = useState('')
  const [pendingDeletion, setPendingDeletion] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [confirmText, setConfirmText] = useState('')

  useEffect(() => {
    if (member?.id) {
      supabase.from('deletion_requests')
        .select('*').eq('member_id', member.id).eq('status', 'pending')
        .maybeSingle()
        .then(({ data }) => setPendingDeletion(data))
    }
  }, [member?.id])

  async function downloadData() {
    setBusy('download'); setGdprMsg('')
    const { data, error } = await supabase.rpc('export_member_data', { p_email: user.email })
    setBusy('')
    if (error) { setGdprMsg('Error: ' + error.message); return }
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `yrtcyk-my-data-${new Date().toISOString().split('T')[0]}.json`
    a.click()
    URL.revokeObjectURL(url)
    setGdprMsg('Downloaded ✓')
    setTimeout(() => setGdprMsg(''), 3000)
  }

  async function requestDeletion() {
    if (confirmText !== 'DELETE') { setGdprMsg('Type DELETE exactly to confirm.'); return }
    setBusy('delete'); setGdprMsg('')
    const { data, error } = await supabase.rpc('request_account_deletion', { p_email: user.email })
    setBusy('')
    if (error) { setGdprMsg('Error: ' + error.message); return }
    setPendingDeletion({ ...data, email: user.email, member_id: member.id })
    setConfirmDelete(false); setConfirmText('')
    setGdprMsg('Deletion scheduled. You have 7 days to reconsider.')
  }

  async function cancelDeletion() {
    if (!pendingDeletion?.cancellation_token) return
    setBusy('cancel'); setGdprMsg('')
    const { error } = await supabase.rpc('cancel_account_deletion', {
      p_email: user.email,
      p_token: pendingDeletion.cancellation_token
    })
    setBusy('')
    if (error) { setGdprMsg('Error: ' + error.message); return }
    setPendingDeletion(null)
    setGdprMsg('Deletion cancelled. Welcome back.')
    setTimeout(() => setGdprMsg(''), 3000)
  }

  const graceDaysLeft = pendingDeletion?.scheduled_for
    ? Math.max(0, Math.ceil((new Date(pendingDeletion.scheduled_for).getTime() - Date.now()) / 86400000))
    : 0

  return (
    <>
      {pendingDeletion && (
        <div style={{
          background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)',
          borderRadius:10, padding:14, marginBottom:14
        }}>
          <p style={{fontSize:13,fontWeight:600,color:'var(--pink)',fontFamily:'var(--font-ui)',marginBottom:6}}>
            ⏳ Deletion scheduled
          </p>
          <p style={{fontSize:12,color:'rgba(251,250,244,.65)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:10}}>
            Your account and all associated data will be permanently deleted in <strong>{graceDaysLeft} day{graceDaysLeft !== 1 ? 's' : ''}</strong>.
            This is irreversible once executed.
          </p>
          <button onClick={cancelDeletion} disabled={busy === 'cancel'}
            style={{
              width:'100%',padding:10,borderRadius:8,
              background:'rgba(25,229,94,.12)',border:'1px solid rgba(25,229,94,.3)',
              color:'var(--lime)',fontSize:13,fontFamily:'var(--font-ui)',fontWeight:600
            }}>
            {busy === 'cancel' ? 'Cancelling…' : '✓ Cancel deletion — keep my account'}
          </button>
        </div>
      )}

      <button onClick={downloadData} disabled={busy === 'download'}
        style={{
          width:'100%',padding:12,borderRadius:8,
          background:'rgba(255,255,255,.06)',border:'1px solid var(--border)',
          color:'rgba(251,250,244,.75)',fontSize:13,fontFamily:'var(--font-ui)',marginBottom:10
        }}>
        {busy === 'download' ? 'Preparing…' : '📥 Download my data (JSON)'}
      </button>

      {!pendingDeletion && !confirmDelete && (
        <button onClick={() => { setConfirmDelete(true); setGdprMsg('') }}
          style={{
            width:'100%',padding:12,borderRadius:8,
            background:'rgba(255,20,147,.06)',border:'1px solid rgba(255,20,147,.2)',
            color:'rgba(255,20,147,.7)',fontSize:13,fontFamily:'var(--font-ui)'
          }}>
          🗑️ Delete my account
        </button>
      )}

      {!pendingDeletion && confirmDelete && (
        <div style={{
          background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.2)',
          borderRadius:10, padding:14
        }}>
          <p style={{fontSize:12,color:'rgba(251,250,244,.65)',fontFamily:'var(--font-ui)',lineHeight:1.6,marginBottom:12}}>
            This will permanently delete your profile, daily practice, Heroes, Reflections, comments,
            and all related data after a <strong>7-day grace period</strong>. You can cancel anytime before execution.
          </p>
          <p style={{fontSize:11,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom:6}}>
            Type <strong style={{color:'var(--pink)'}}>DELETE</strong> to confirm:
          </p>
          <input type="text" value={confirmText}
            onChange={e => setConfirmText(e.target.value)}
            placeholder="DELETE" style={{marginBottom:10}}/>
          <div style={{display:'flex',gap:8}}>
            <button onClick={requestDeletion} disabled={busy === 'delete' || confirmText !== 'DELETE'}
              style={{
                flex:1,padding:10,borderRadius:8,
                background: confirmText === 'DELETE' ? 'var(--pink)' : 'rgba(255,20,147,.2)',
                color:'#fff',fontSize:13,fontFamily:'var(--font-ui)',fontWeight:600,
                opacity: busy === 'delete' || confirmText !== 'DELETE' ? 0.6 : 1
              }}>
              {busy === 'delete' ? 'Requesting…' : 'Schedule deletion'}
            </button>
            <button onClick={() => { setConfirmDelete(false); setConfirmText('') }}
              style={{
                padding:'10px 16px',borderRadius:8,
                background:'rgba(255,255,255,.06)',border:'1px solid var(--border)',
                color:'rgba(251,250,244,.6)',fontSize:13,fontFamily:'var(--font-ui)'
              }}>
              Cancel
            </button>
          </div>
        </div>
      )}

      {gdprMsg && (
        <p style={{
          fontSize:12,fontFamily:'var(--font-ui)',marginTop:10,textAlign:'center',
          color: gdprMsg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)'
        }}>{gdprMsg}</p>
      )}
    </>
  )
}
