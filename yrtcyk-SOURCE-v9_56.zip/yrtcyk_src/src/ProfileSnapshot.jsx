// v9.51 — Shared community-profile rendering component.
//
// Single source of truth for "what the community sees." Consumed by:
//   1. ProfilePage Preview tab — viewMode='preview' (member previewing
//      their own public face)
//   2. MemberDirectory click-through — viewMode='community' (member
//      viewing someone else's profile)
//
// Per-program cards (icon, name, sobriety pill, sponsorship row, home
// group line, recovery story) collapse the legacy split where Programs,
// the singular ABOUT bio, and the singular HOME GROUP card lived as
// disconnected sections. Sponsor/sponsee chip rendering filters at the
// component edge by allow_sponsor_tags / allow_sponsee_tags consent.
//
// Stopped Smoking renders a minimal card (date + counter only — no
// sponsorship row, no home group, no recovery story) per v9.50 spec.
//
// The legacy singular columns (recovery_bio, homegroup_*, cal_sobriety_*)
// are deliberately unread here. They survive in the DB until v9.52
// cleanup; this component is the canonical reader of the per-slot world.

import { useState } from 'react'
import MemberBadges from './MemberBadges'

// ────────────────────────────────────────────────────────────────────
// Constants — duplicated from ProfilePage so this component is
// self-contained and importable without circular dependencies. Keep
// in sync with ProfilePage when programs/icons/verbs change.
// ────────────────────────────────────────────────────────────────────

const MEETING_DIRECTORY_URLS = {
  'AA':       'https://www.aa.org/find-aa',
  'ACoA':     'https://adultchildren.org/',
  'Al-Anon':  'https://al-anon.org/',
  'CMA':      'https://www.crystalmeth.org/',
  'CoDA':     'https://coda.org/',
  'GA':       'https://gamblersanonymous.org/find-a-meeting/',
  'NA':       'https://na.org/meetingsearch/',
  'OA':       'https://oa.org/',
  'SLAA':     'https://slaafws.org/meetings/',
}

const PROGRAM_ICONS = {
  'AA':              '🍃',
  'ACoA':            '🌳',
  'Al-Anon':         '🤝',
  'CMA':             '❄️',
  'CoDA':            '🔗',
  'GA':              '🎲',
  'NA':              '💊',
  'OA':              '🍽️',
  'SLAA':            '💗',
  'Stopped Smoking': '🚭',
}

const SOBRIETY_VERB = {
  'AA':              'sober',
  'ACoA':            'in active recovery',
  'Al-Anon':         'in active recovery',
  'CMA':             'clean',
  'CoDA':            'in active recovery',
  'GA':              'abstinent',
  'NA':              'clean',
  'OA':              'abstinent',
  'SLAA':            'sober',
  'Stopped Smoking': 'smoke-free',
}

const PROGRAMS_WITHOUT_HOME_GROUPS = ['Stopped Smoking']

const SPONSOR_STATUS_LABELS = {
  has:     'Has a sponsor',
  looking: 'Looking for a sponsor',
  none:    null, // 'none' is the default — rendered as nothing
}

const SPONSEE_COUNT_LABELS = {
  none:   null,
  '1':    '1 sponsee',
  '2':    '2 sponsees',
  '3':    '3 sponsees',
  '4_plus': '4+ sponsees',
}

// ────────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────────

function sobrietyStats(dateStr) {
  if (!dateStr) return null
  const start = new Date(dateStr + 'T00:00:00')
  const diffMs = new Date() - start
  if (diffMs < 0) return null
  const days = Math.floor(diffMs / 86400000)
  const yearsExact = diffMs / (365.25 * 86400000)
  let label = ''
  if (days < 30) label = `${days} day${days !== 1 ? 's' : ''}`
  else if (days < 365) label = `${Math.floor(days/30)} month${Math.floor(days/30)!==1?'s':''}`
  else {
    const y = Math.floor(yearsExact)
    const rem = days - Math.floor(y * 365.25)
    const m = Math.floor(rem / 30)
    label = `${y} yr${y!==1?'s':''}${m>0?` ${m} mo`:''}`
  }
  return { days, label }
}

function parseListLocal(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  try { const p = JSON.parse(val); if (Array.isArray(p)) return p } catch {}
  return val.split(',').map(s => s.trim()).filter(Boolean)
}

function parsePetsLocal(val) {
  if (!val) return []
  try {
    const p = JSON.parse(val)
    if (Array.isArray(p)) {
      if (p.length === 0) return []
      if (typeof p[0] === 'object' && p[0].type) return p
      return p.map(v => ({ type: v, name: '' }))
    }
  } catch {}
  return []
}

function fmtTime(t) {
  if (!t) return null
  // accepts "HH:MM:SS" or "HH:MM"
  return new Date('1970-01-01T' + t).toLocaleTimeString('en-US', { hour:'numeric', minute:'2-digit' })
}

// ────────────────────────────────────────────────────────────────────
// Sub-components
// ────────────────────────────────────────────────────────────────────

// A small inline chip rendering a tagged member (sponsor or sponsee).
// Filters by consent: returns null if the tagged member has set the
// relevant allow_*_tags flag to false. Click-through navigates if
// onTaggedMemberClick is provided.
function MemberChip({ memberObj, consentField, onTaggedMemberClick, big }) {
  if (!memberObj) return null
  // Consent gate: undefined or true → show. Explicit false → hide.
  if (memberObj[consentField] === false) return null

  const name = memberObj.display_name || (memberObj.email || '').split('@')[0] || 'Member'
  const initial = (name[0] || '?').toUpperCase()
  const size = big ? 24 : 22

  const inner = (
    <>
      {memberObj.avatar_url
        ? <img src={memberObj.avatar_url} alt="" style={{width:size, height:size, borderRadius:'50%', objectFit:'cover'}}/>
        : <span style={{width:size, height:size, borderRadius:'50%', background:'rgba(255,20,147,.2)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:10, color:'var(--pink)', fontFamily:'var(--font-ui)', fontWeight:700}}>{initial}</span>}
      <span>{name}</span>
    </>
  )

  const baseStyle = {
    display:'inline-flex', alignItems:'center', gap:6,
    padding:'2px 10px 2px 2px', borderRadius:999,
    background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.25)',
    fontSize:12, fontFamily:'var(--font-ui)', color:'var(--cream)',
    cursor: onTaggedMemberClick ? 'pointer' : 'default',
    transition: 'background .15s, border-color .15s',
  }

  if (onTaggedMemberClick) {
    return (
      <button onClick={() => onTaggedMemberClick(memberObj.id)}
        style={baseStyle}
        onMouseEnter={e => { e.currentTarget.style.background='rgba(255,20,147,.16)'; e.currentTarget.style.borderColor='rgba(255,20,147,.45)' }}
        onMouseLeave={e => { e.currentTarget.style.background='rgba(255,20,147,.08)'; e.currentTarget.style.borderColor='rgba(255,20,147,.25)' }}
      >{inner}</button>
    )
  }
  return <span style={baseStyle}>{inner}</span>
}

// Per-program card. Header (icon + name as link), sobriety pill,
// counter line, sponsorship row, home group line, recovery story.
function ProgramCard({
  slot,
  program,
  date,
  recoveryBio,
  sponsorStatus,
  sponseeCount,
  sponsorMember,         // resolved member object or null (post consent filter)
  sponseeMembers,        // array of resolved member objects (post consent filter)
  homeGroup,             // member_home_groups row or null
  onTaggedMemberClick,
}) {
  const stats = sobrietyStats(date)
  const verb  = SOBRIETY_VERB[program] || 'in active recovery'
  const icon  = PROGRAM_ICONS[program] || '🌟'
  const dirUrl = MEETING_DIRECTORY_URLS[program]
  const isMilestoneOnly = PROGRAMS_WITHOUT_HOME_GROUPS.includes(program)

  // Sponsorship row content gating
  const sponsorLabel = SPONSOR_STATUS_LABELS[sponsorStatus]
  const sponseeLabel = SPONSEE_COUNT_LABELS[sponseeCount]
  const showSponsorshipRow = !isMilestoneOnly && (sponsorLabel || sponseeLabel)

  // Home group rendering
  const showHomeGroup = !isMilestoneOnly && homeGroup && homeGroup.home_group_name
  const meetingTime = fmtTime(homeGroup?.meeting_time)
  const isZoom = homeGroup?.format === 'Online (Zoom)'
  const isInPerson = homeGroup?.format === 'In-Person'
  const mapsUrl = homeGroup?.place_id
    ? `https://www.google.com/maps/place/?q=place_id:${homeGroup.place_id}`
    : (homeGroup?.address ? `https://www.google.com/maps/search/${encodeURIComponent(homeGroup.address)}` : null)

  const headerName = (
    <span style={{display:'inline-flex', alignItems:'center', gap:8}}>
      <span style={{fontSize:20}}>{icon}</span>
      <span style={{fontSize:16, fontWeight:700, color:'var(--pink)', letterSpacing:.3}}>{program}</span>
    </span>
  )

  return (
    <div style={{
      padding:'14px 14px 12px',
      borderRadius:12,
      background:'rgba(255,20,147,.04)',
      border:'2px solid rgba(255,20,147,.45)',
      marginBottom:12,
    }}>
      {/* Header row */}
      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', gap:10, marginBottom:8}}>
        {dirUrl
          ? <a href={dirUrl} target="_blank" rel="noopener noreferrer"
              style={{textDecoration:'none', display:'inline-flex', alignItems:'center'}}>
              {headerName}
            </a>
          : headerName}
        {stats && (
          <span style={{
            fontSize:12, fontFamily:'var(--font-ui)', fontWeight:700,
            color:'var(--lime)', whiteSpace:'nowrap',
            padding:'3px 10px', borderRadius:999,
            background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)',
          }}>{stats.label} {verb}</span>
        )}
      </div>

      {/* Counter line */}
      {stats && (
        <p style={{fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginBottom: showSponsorshipRow || showHomeGroup || recoveryBio ? 10 : 0}}>
          {stats.days.toLocaleString()} days{date && ` · since ${new Date(date+'T00:00:00').toLocaleDateString('en-US',{month:'short', day:'numeric', year:'numeric'})}`}
        </p>
      )}

      {/* Sponsorship row — only when there's something to say */}
      {showSponsorshipRow && (
        <div style={{
          padding:'8px 10px',
          borderRadius:8,
          background:'rgba(255,255,255,.03)',
          border:'1px solid rgba(255,255,255,.06)',
          marginBottom: showHomeGroup || recoveryBio ? 10 : 0,
          display:'flex', flexDirection:'column', gap:6,
        }}>
          {sponsorLabel && (
            <div style={{display:'flex', flexWrap:'wrap', gap:8, alignItems:'center'}}>
              <span style={{fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', minWidth:70}}>Sponsor</span>
              {sponsorMember
                ? <MemberChip memberObj={sponsorMember} consentField="allow_sponsor_tags" onTaggedMemberClick={onTaggedMemberClick}/>
                : <span style={{fontSize:12, color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', fontStyle:'italic'}}>{sponsorLabel}</span>}
            </div>
          )}
          {sponseeLabel && (
            <div style={{display:'flex', flexWrap:'wrap', gap:8, alignItems:'center'}}>
              <span style={{fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', minWidth:70}}>Sponsees</span>
              {sponseeMembers && sponseeMembers.length > 0
                ? sponseeMembers.map(m => (
                    <MemberChip key={m.id} memberObj={m} consentField="allow_sponsee_tags" onTaggedMemberClick={onTaggedMemberClick}/>
                  ))
                : <span style={{fontSize:12, color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', fontStyle:'italic'}}>{sponseeLabel}</span>}
            </div>
          )}
        </div>
      )}

      {/* Home group line */}
      {showHomeGroup && (
        <div style={{
          padding:'8px 10px',
          borderRadius:8,
          background:'rgba(255,255,255,.03)',
          border:'1px solid rgba(255,255,255,.06)',
          marginBottom: recoveryBio ? 10 : 0,
        }}>
          <p style={{fontSize:13, color:'var(--cream)', fontWeight:600, marginBottom:3}}>
            🏠 {homeGroup.home_group_name}
          </p>
          <p style={{fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', lineHeight:1.6}}>
            {[homeGroup.day, meetingTime, homeGroup.format].filter(Boolean).join('  ·  ')}
          </p>
          {homeGroup.notes && (
            <p style={{fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginTop:3, fontStyle:'italic'}}>
              {homeGroup.notes}
            </p>
          )}
          {/* Action buttons */}
          {(isZoom && homeGroup.location_or_zoom) && (
            <a href={homeGroup.location_or_zoom} target="_blank" rel="noopener noreferrer"
              style={{display:'inline-block', marginTop:6, fontSize:11, fontFamily:'var(--font-ui)', color:'var(--lime)', padding:'3px 10px', borderRadius:6, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)', textDecoration:'none'}}>
              🎥 Join meeting →
            </a>
          )}
          {(isInPerson && mapsUrl) && (
            <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
              style={{display:'inline-block', marginTop:6, fontSize:11, fontFamily:'var(--font-ui)', color:'var(--lime)', padding:'3px 10px', borderRadius:6, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)', textDecoration:'none'}}>
              📍 View on map →
            </a>
          )}
        </div>
      )}

      {/* Recovery story */}
      {recoveryBio && !isMilestoneOnly && (
        <p style={{fontSize:13, color:'rgba(251,250,244,.7)', lineHeight:1.7, fontStyle:'italic'}}>
          “{recoveryBio}”
        </p>
      )}
    </div>
  )
}

// ────────────────────────────────────────────────────────────────────
// Main component
// ────────────────────────────────────────────────────────────────────

export default function ProfileSnapshot({
  member,
  homeGroups   = { 1: null, 2: null, 3: null },
  sponsorLinks = { 1: null, 2: null, 3: null },
  sponseeLinks = { 1: [], 2: [], 3: [] },
  goalLinks    = {},                       // v9.51 Item 7 — { [topic]: { 1, 2 } }
  membersById  = new Map(), // Map<uuid, memberRow with consent flags>
  approvedHeroes = [],
  womPlaces      = [],
  contributions  = null,
  viewMode       = 'community', // 'preview' | 'community'
  avatarUrlOverride,
  onTaggedMemberClick,
  // Optional embellishments
  showMemberSinceFooter = true,
}) {
  if (!member) return null

  // v9.52 — Recovery Focus chip-expansion state. Tap a wellness topic chip
  // that has links (per goalLinks) to reveal them inline. Tap the same chip
  // again or another link-bearing chip to switch / collapse. One-at-a-time
  // semantics keep the panel tidy and avoid stacking accordions.
  const [expandedTopic, setExpandedTopic] = useState(null)

  // Resolve linked-member chips through the membersById map. Filtering
  // for consent happens inside <MemberChip/> so the legacy DB rows stay
  // intact when consent is later re-enabled.
  function resolveSponsor(slot) {
    const link = sponsorLinks?.[slot]
    if (!link?.sponsor_member_id) return null
    return membersById.get(link.sponsor_member_id) || null
  }
  function resolveSponsees(slot) {
    const links = sponseeLinks?.[slot] || []
    return links.map(l => membersById.get(l.sponsee_member_id)).filter(Boolean)
  }

  const programs = [1,2,3].filter(n => member[`program_${n}`])
  const langs = [...new Set([
    ...parseListLocal(member.spoken_languages),
    ...parseListLocal(member.written_languages),
  ])]
  const pets     = parsePetsLocal(member.pets)
  const wellness = parseListLocal(member.wellness_topics)

  const avatarUrl = avatarUrlOverride
    || member.avatar_url
    || `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88" viewBox="0 0 88 88"><circle cx="44" cy="44" r="44" fill="#01280e"/><circle cx="44" cy="44" r="42" fill="none" stroke="#FF1493" stroke-width="2"/><text x="44" y="52" text-anchor="middle" font-family="Georgia,serif" font-size="28" font-weight="700" fill="#FF1493">YFG</text></svg>')}`

  const displayName = member.display_name || (member.email || '').split('@')[0] || 'Member'
  const age = (member.show_age && member.birth_date)
    ? Math.floor((new Date() - new Date(member.birth_date+'T00:00:00')) / (365.25*86400000))
    : null
  const tzShort = member.timezone ? member.timezone.split('/').pop().replace('_', ' ') : null

  return (
    <div>
      {viewMode === 'preview' && (
        <p style={{fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', lineHeight:1.65, marginBottom:18, fontStyle:'italic'}}>
          This is what other members see when they tap your name.
        </p>
      )}

      <div style={{
        background:'rgba(255,255,255,.04)',
        border:'1px solid rgba(255,20,147,.15)',
        borderRadius:14,
        padding:'24px 18px',
        marginBottom:16,
      }}>

        {/* ── Header: avatar, name, badges, locale ── */}
        <div style={{textAlign:'center', marginBottom:20}}>
          <div style={{
            width:88, height:88, borderRadius:'50%', overflow:'hidden',
            border:'3px solid rgba(255,20,147,.35)',
            margin:'0 auto 12px',
          }}>
            <img src={avatarUrl} alt="" style={{width:88, height:88, objectFit:'cover'}}/>
          </div>
          <h3 style={{fontSize:22, fontWeight:400, marginBottom:6, fontFamily:'var(--font-serif)'}}>{displayName}</h3>
          {member.show_full_name && member.first_name && (
            <p style={{fontSize:13, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)', marginBottom:6}}>
              {member.first_name} {member.last_name || ''}
            </p>
          )}
          <div style={{display:'flex', justifyContent:'center', gap:8, flexWrap:'wrap', marginBottom:8}}>
            <MemberBadges member={member} size="md"/>
          </div>
          {/* Locale block — pronouns / city / timezone / age — only what's shared */}
          <div style={{display:'flex', justifyContent:'center', flexWrap:'wrap', gap:'4px 14px', fontSize:12, fontFamily:'var(--font-ui)'}}>
            {member.show_pronouns !== false && member.pronouns &&
              <span style={{color:'rgba(251,250,244,.5)'}}>{member.pronouns}</span>}
            {member.show_location !== false && member.city &&
              <span style={{color:'rgba(251,250,244,.5)'}}>📍 {member.city}</span>}
            {tzShort &&
              <span style={{color:'rgba(251,250,244,.4)'}}>🕐 {tzShort}</span>}
            {age !== null &&
              <span style={{color:'rgba(251,250,244,.45)'}}>Age {age}</span>}
          </div>
        </div>

        {/* ── Per-program cards ── */}
        {programs.length > 0 && (
          <div style={{marginBottom:18}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>RECOVERY</p>
            {programs.map(slot => (
              <ProgramCard
                key={slot}
                slot={slot}
                program={member[`program_${slot}`]}
                date={member[`program_${slot}_date`]}
                recoveryBio={member[`recovery_bio_${slot}`]}
                sponsorStatus={member[`sponsor_status_${slot}`] || 'none'}
                sponseeCount={member[`sponsee_count_${slot}`] || 'none'}
                sponsorMember={resolveSponsor(slot)}
                sponseeMembers={resolveSponsees(slot)}
                homeGroup={homeGroups[slot]}
                onTaggedMemberClick={onTaggedMemberClick}
              />
            ))}
          </div>
        )}

        {/* ── Identity + Languages — side-by-side via auto-fit grid ──
            v9.52: was two stacked full-width sections. Auto-fit minmax keeps
            them side-by-side on iPad+ and any phone with enough width, but
            gracefully stacks back to full-width on iPhone narrow. */}
        {((member.gender_identity || member.sexual_orientation || member.ethnicity) || langs.length > 0) && (
          <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(160px, 1fr))', gap:14, marginBottom:14}}>
            {(member.gender_identity || member.sexual_orientation || member.ethnicity) && (
              <div>
                <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>IDENTITY</p>
                <div style={{display:'flex', flexWrap:'wrap', gap:6}}>
                  {member.gender_identity && <span style={{padding:'4px 10px', borderRadius:20, fontSize:11, fontFamily:'var(--font-ui)', background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)', color:'rgba(251,250,244,.75)'}}>{member.gender_identity}</span>}
                  {member.sexual_orientation && <span style={{padding:'4px 10px', borderRadius:20, fontSize:11, fontFamily:'var(--font-ui)', background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)', color:'rgba(251,250,244,.75)'}}>{member.sexual_orientation}</span>}
                  {member.ethnicity && <span style={{padding:'4px 10px', borderRadius:20, fontSize:11, fontFamily:'var(--font-ui)', background:'rgba(255,255,255,.06)', border:'1px solid rgba(255,255,255,.1)', color:'rgba(251,250,244,.6)'}}>{member.ethnicity}</span>}
                </div>
              </div>
            )}
            {langs.length > 0 && (
              <div>
                <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>LANGUAGES</p>
                <p style={{fontSize:13, color:'rgba(251,250,244,.65)', lineHeight:1.6}}>{langs.join(' · ')}</p>
              </div>
            )}
          </div>
        )}

        {/* ── Pets — own row, full width so photo cards have room to breathe ── */}
        {pets.length > 0 && (
          <div style={{marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:6}}>PETS 🐾</p>
            <div style={{display:'flex', flexWrap:'wrap', gap:8}}>
              {pets.map((p, i) => {
                const a = p.age ? `${p.age}yo` : ''
                const detail = [a, p.type].filter(Boolean).join(' · ')
                const fallback =
                  p.type === 'Dog' ? '🐶' :
                  p.type === 'Cat' ? '🐱' :
                  p.type === 'Bird' ? '🐦' :
                  p.type === 'Fish' ? '🐠' :
                  p.type === 'Rabbit' ? '🐰' :
                  p.type === 'Horse' ? '🐴' :
                  p.type === 'Reptile' ? '🦎' :
                  '🐾'
                return (
                  <div key={i} style={{
                    display:'flex', alignItems:'center', gap:8,
                    padding:'6px 10px 6px 6px', borderRadius:10,
                    background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.07)',
                  }}>
                    <div style={{
                      width:36, height:36, borderRadius:8, overflow:'hidden', flexShrink:0,
                      background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.2)',
                      display:'flex', alignItems:'center', justifyContent:'center',
                    }}>
                      {p.photo_url
                        ? <img src={p.photo_url} alt="" style={{width:'100%', height:'100%', objectFit:'cover'}}/>
                        : <span style={{fontSize:20}}>{fallback}</span>}
                    </div>
                    <div style={{minWidth:0}}>
                      {p.name && <p style={{fontSize:13, color:'var(--cream)', fontWeight:600, marginBottom:1}}>{p.name}</p>}
                      {detail && <p style={{fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)'}}>{detail}</p>}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* ── Recovery Focus — chips with click-to-expand links inline ──
            v9.52: merged the previous standalone "🔗 RECOMMENDED RESOURCES"
            section into the chip cluster. Topics with links (per goalLinks)
            render as tappable pink chips with a 🔗 prefix; tapping reveals
            the topic's links in an inline panel below. Topics without links
            stay non-interactive lime chips (visual only). One topic
            expanded at a time — taps on a different chip swap the panel,
            tapping the same chip toggles closed. */}
        {wellness.length > 0 && (
          <div style={{marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:8}}>RECOVERY FOCUS</p>
            <div style={{display:'flex', flexWrap:'wrap', gap:6}}>
              {wellness.slice(0, 14).map(t => {
                const slots = goalLinks?.[t]
                const hasLinks = slots && [1, 2].some(s => slots[s]?.url)
                const isExpanded = expandedTopic === t
                if (hasLinks) {
                  return (
                    <button
                      key={t}
                      onClick={() => setExpandedTopic(isExpanded ? null : t)}
                      style={{
                        padding:'4px 10px', borderRadius:20,
                        fontSize:11, fontFamily:'var(--font-ui)',
                        background: isExpanded ? 'rgba(255,20,147,.2)' : 'rgba(255,20,147,.08)',
                        border: `1px solid ${isExpanded ? 'rgba(255,20,147,.55)' : 'rgba(255,20,147,.25)'}`,
                        color: isExpanded ? 'var(--pink)' : 'rgba(251,250,244,.85)',
                        cursor:'pointer',
                        display:'inline-flex', alignItems:'center', gap:4,
                        transition:'background .15s, border-color .15s, color .15s',
                      }}
                    >
                      <span style={{fontSize:9, opacity:.85}}>🔗</span>
                      {t}
                    </button>
                  )
                }
                return (
                  <span key={t} style={{
                    padding:'4px 10px', borderRadius:20,
                    fontSize:11, fontFamily:'var(--font-ui)',
                    background:'rgba(25,229,94,.08)',
                    border:'1px solid rgba(25,229,94,.18)',
                    color:'rgba(251,250,244,.6)',
                  }}>{t}</span>
                )
              })}
              {wellness.length > 14 && <span style={{fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', padding:'4px 6px'}}>+{wellness.length - 14} more</span>}
            </div>

            {/* Expansion panel — shows links for the currently-expanded topic. */}
            {expandedTopic && (() => {
              const slots = goalLinks?.[expandedTopic]
              const items = [1, 2].map(s => slots?.[s]).filter(item => item && item.url)
              if (items.length === 0) return null
              return (
                <div style={{
                  marginTop:10,
                  background:'rgba(255,20,147,.04)',
                  border:'1px solid rgba(255,20,147,.18)',
                  borderRadius:10,
                  padding:'10px 12px',
                }}>
                  <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:6, gap:8}}>
                    <p style={{fontSize:11, color:'var(--pink)', fontWeight:600, fontFamily:'var(--font-ui)', letterSpacing:.4}}>🔗 {expandedTopic}</p>
                    <button onClick={() => setExpandedTopic(null)}
                      style={{fontSize:14, color:'rgba(251,250,244,.4)', background:'none', border:'none', cursor:'pointer', padding:0, lineHeight:1}}
                      aria-label="Close">×</button>
                  </div>
                  <div style={{display:'flex', flexDirection:'column', gap:5}}>
                    {items.map((item, i) => (
                      <a
                        key={i}
                        href={item.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{fontSize:12, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.85)', textDecoration:'none', display:'flex', alignItems:'baseline', gap:6, lineHeight:1.5}}
                      >
                        <span style={{flexShrink:0, color:'rgba(251,250,244,.4)'}}>↗</span>
                        <span style={{flex:1, minWidth:0, wordBreak:'break-word'}}>
                          {item.label
                            ? <><span style={{color:'var(--cream)'}}>{item.label}</span> <span style={{color:'rgba(251,250,244,.35)', fontSize:11}}>· {item.url}</span></>
                            : <span style={{color:'var(--cream)'}}>{item.url}</span>}
                        </span>
                      </a>
                    ))}
                  </div>
                </div>
              )
            })()}
          </div>
        )}

        {/* ── Get in touch ── */}
        {((member.show_email && member.email) || (member.show_phone && member.phone)) && (
          <div style={{marginTop:16, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.07)', marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>💌 GET IN TOUCH</p>
            <div style={{display:'flex', flexDirection:'column', gap:6}}>
              {member.show_email && member.email && (
                <a href={`mailto:${member.email}`} style={{fontSize:13, color:'var(--pink)', textDecoration:'none', fontFamily:'var(--font-ui)'}}>✉️ {member.email}</a>
              )}
              {member.show_phone && member.phone && (
                <a href={`tel:${member.phone}`} style={{fontSize:13, color:'var(--pink)', textDecoration:'none', fontFamily:'var(--font-ui)'}}>📱 {member.phone}</a>
              )}
            </div>
          </div>
        )}

        {/* ── My Heroes — 3-across square thumbnail grid ──
            v9.52: was a vertical row list with 40px icons. Now mirrors the
            HeroGallery card pattern (square 1:1 photo header on top, body
            panel with hero name + type pill below) so the snapshot picks
            up the same visual rhythm members already know from the main
            Heroes gallery. Fixed 3-column grid at all breakpoints per
            Geo's "three across" spec. */}
        {approvedHeroes && approvedHeroes.length > 0 && (
          <div style={{marginTop:16, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.07)', marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>⭐ MY HEROES</p>
            <div style={{display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:8}}>
              {approvedHeroes.map(h => {
                const thumb = h.photos?.[h.thumbnail_index] || h.photos?.[0]
                const typeIcon = h.hero_type === 'person' ? '👤' : h.hero_type === 'place' ? '📍' : '✨'
                const typeLabel = h.hero_type === 'person' ? 'Person' : h.hero_type === 'place' ? 'Place' : 'Thing'
                return (
                  <div key={h.id} style={{
                    overflow:'hidden',
                    display:'flex',
                    flexDirection:'column',
                    background:'rgba(255,20,147,.05)',
                    border:'1px solid rgba(255,20,147,.15)',
                    borderRadius:10,
                  }}>
                    {/* Photo region — square, full-bleed. Gradient + emoji
                        fallback when no photo is set (mirrors MemberTile). */}
                    <div style={{
                      width:'100%',
                      aspectRatio:'1/1',
                      overflow:'hidden',
                      background: thumb
                        ? '#01280e'
                        : 'linear-gradient(135deg, rgba(255,20,147,.18), rgba(25,229,94,.10))',
                      display: thumb ? 'block' : 'flex',
                      alignItems:'center',
                      justifyContent:'center',
                      position:'relative',
                    }}>
                      {thumb
                        ? <img src={thumb} alt="" style={{width:'100%', height:'100%', objectFit:'cover', objectPosition:'center 25%'}}/>
                        : <span style={{fontSize:30}}>{typeIcon}</span>}
                      {h.life_status === 'in_memoriam' && (
                        <span style={{
                          position:'absolute', top:6, right:6,
                          fontSize:11,
                          color:'rgba(200,180,220,.85)',
                          background:'rgba(1,40,14,.85)',
                          padding:'2px 5px',
                          borderRadius:6,
                        }}>🕊️</span>
                      )}
                    </div>
                    {/* Body — name + type pill. Compact for 3-col grid. */}
                    <div style={{padding:'7px 9px', flex:1, display:'flex', flexDirection:'column', gap:3}}>
                      <p style={{
                        fontSize:11, fontWeight:600, color:'var(--cream)', lineHeight:1.3,
                        overflow:'hidden', textOverflow:'ellipsis',
                        display:'-webkit-box', WebkitLineClamp:2, WebkitBoxOrient:'vertical',
                      }}>{h.hero_name}</p>
                      <span style={{fontSize:9, color:'rgba(255,20,147,.7)', fontFamily:'var(--font-ui)', letterSpacing:.5, textTransform:'uppercase'}}>{typeIcon} {typeLabel}</span>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* ── Word of Mouth places ── */}
        {womPlaces && womPlaces.length > 0 && (
          <div style={{marginTop:16, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.07)', marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:10}}>💋 WORD OF MOUTH</p>
            <div style={{display:'flex', flexDirection:'column', gap:8}}>
              {womPlaces.map(p => {
                const mapsUrl = p.place_id
                  ? `https://www.google.com/maps/place/?q=place_id:${p.place_id}`
                  : `https://www.google.com/maps/search/${encodeURIComponent(p.business_name + ' ' + (p.city || ''))}`
                const visitUrl = p.website_url && p.website_url.startsWith('http') ? p.website_url : null
                return (
                  <div key={p.id} style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 12px', borderRadius:8, background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.07)'}}>
                    <div>
                      <p style={{fontSize:13, fontWeight:600, color:'var(--cream)', marginBottom:2}}>{p.business_name}</p>
                      <p style={{fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)'}}>{p.city}</p>
                    </div>
                    <div style={{display:'flex', gap:6, flexShrink:0}}>
                      {visitUrl && (
                        <a href={visitUrl} target="_blank" rel="noopener noreferrer"
                          style={{padding:'5px 10px', borderRadius:6, background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.25)', color:'var(--pink)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none'}}>
                          🌐
                        </a>
                      )}
                      <a href={mapsUrl} target="_blank" rel="noopener noreferrer"
                        style={{padding:'5px 10px', borderRadius:6, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.2)', color:'var(--lime)', fontSize:11, fontFamily:'var(--font-ui)', textDecoration:'none'}}>
                        📍
                      </a>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        )}

        {/* ── Community contributions ── */}
        {contributions && (
          <div style={{marginTop:16, paddingTop:16, borderTop:'1px solid rgba(255,255,255,.07)', marginBottom:14}}>
            <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:1.2, marginBottom:12}}>COMMUNITY CONTRIBUTIONS</p>
            {/* v9.52 — auto-fill grid so the 7-stat layout doesn't leave
                an orphaned 7th cell hanging in a strict 2-col grid. */}
            <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(110px, 1fr))', gap:8}}>
              {[
                ['Friends Referred', contributions.referred],
                ['Friends Joined',   contributions.joined],
                ['Heroes — Person',  contributions.heroes_person],
                ['Heroes — Place',   contributions.heroes_place],
                ['Heroes — Thing',   contributions.heroes_thing],
                ['Reflections',      contributions.blog_posts],
                ['Responses',        contributions.blog_comments],
              ].map(([label, val]) => (
                <div key={label} style={{padding:'10px 12px', borderRadius:8, background:'rgba(255,255,255,.04)', border:'1px solid rgba(255,255,255,.07)'}}>
                  <p style={{fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom:4}}>{label}</p>
                  <p style={{fontSize:20, fontWeight:700, color: val > 0 ? 'var(--pink)' : 'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)'}}>{val ?? 0}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── Member since footer ── */}
        {showMemberSinceFooter && member.membership_start_date && (
          <p style={{fontSize:11, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)', textAlign:'center', marginTop:18}}>
            Member since {new Date(member.membership_start_date).toLocaleDateString('en-US', { month:'long', year:'numeric' })}
          </p>
        )}

      </div>
    </div>
  )
}
