// ─── v9.46-followup Item 7 — Send Cheers modal ───────────────────────────
// Triggered by the "🌟 Send Cheers" pink button on Calendar birthday and
// sobriety-anniversary cards. Renders 5 pre-written templates + a free-text
// field with a live 200-char counter. Submits insert into public.cheers
// (RLS enforces sender_id = current member; CHECK constraint enforces 1–200
// char message and prevents self-cheers).

import { useState } from 'react'
import { supabase } from './supabaseClient'

const TEMPLATES = [
  'Congratulations on the milestone!',
  "So proud of you!",
  "Keep going — you're doing it!",
  'Your courage inspires.',
  'Cheers to you!',
]

const MAX_LEN = 200

/**
 * @param {object}  recipient       Target member ({ id, display_name }).
 * @param {object}  sender          Current member ({ id, display_name }).
 * @param {string}  milestoneType   'birthday' | 'sobriety_anniversary'
 * @param {string}  milestoneLabel  Human label for the milestone (e.g. "Birthday", "5 years in AA").
 * @param {func}    onClose         Closes the modal.
 * @param {func}    onSent          Optional callback after successful insert.
 */
export default function SendCheersModal({ recipient, sender, milestoneType, milestoneLabel, onClose, onSent }) {
  const [message, setMessage]   = useState(TEMPLATES[0])
  const [sending, setSending]   = useState(false)
  const [error,   setError]     = useState('')
  const [success, setSuccess]   = useState(false)

  const charsRemaining = MAX_LEN - message.length
  const overLimit      = charsRemaining < 0
  const empty          = message.trim().length === 0

  async function handleSubmit() {
    if (sending || overLimit || empty) return
    if (!sender?.id || !recipient?.id) {
      setError('Could not identify sender or recipient. Try again.')
      return
    }
    setSending(true)
    setError('')
    const { error: insertErr } = await supabase
      .from('cheers')
      .insert({
        sender_id:      sender.id,
        recipient_id:   recipient.id,
        milestone_type: milestoneType,
        message:        message.trim(),
      })
    setSending(false)
    if (insertErr) {
      console.error('[SendCheersModal] insert error', insertErr)
      // Surface RLS / constraint errors plainly
      setError(insertErr.message || 'Could not send cheers. Try again.')
      return
    }
    setSuccess(true)
    if (onSent) onSent()
    // Auto-close after 1.2s so the success state registers
    setTimeout(() => { onClose() }, 1200)
  }

  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed',
        inset: 0,
        background: 'rgba(1,40,14,.85)',
        backdropFilter: 'blur(4px)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: 16,
        zIndex: 200,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: 'var(--bg)',
          border: '1px solid rgba(255,20,147,.3)',
          borderRadius: 14,
          padding: 24,
          maxWidth: 440,
          width: '100%',
          maxHeight: '90vh',
          overflowY: 'auto',
        }}
      >
        {/* Header */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
          <div>
            <p style={{ fontSize: 11, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: 1.2, textTransform: 'uppercase', marginBottom: 4 }}>
              🌟 Send Cheers
            </p>
            <h3 style={{ fontSize: 18, fontWeight: 600, color: 'var(--cream)', marginBottom: 2 }}>
              To {recipient?.display_name || 'this member'}
            </h3>
            {milestoneLabel && (
              <p style={{ fontSize: 12, color: 'rgba(251,250,244,.5)', fontFamily: 'var(--font-ui)', fontStyle: 'italic' }}>
                {milestoneLabel}
              </p>
            )}
          </div>
          <button
            onClick={onClose}
            disabled={sending}
            style={{ background: 'transparent', border: 'none', color: 'rgba(251,250,244,.5)', fontSize: 22, lineHeight: 1, cursor: sending ? 'default' : 'pointer', padding: 0 }}
          >
            ×
          </button>
        </div>

        {success ? (
          <div style={{ textAlign: 'center', padding: '24px 0' }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>🌟</div>
            <p style={{ fontSize: 15, color: 'var(--lime)', fontFamily: 'var(--font-ui)', fontWeight: 600 }}>
              Cheers sent!
            </p>
            <p style={{ fontSize: 12, color: 'rgba(251,250,244,.5)', fontFamily: 'var(--font-ui)', marginTop: 4 }}>
              {recipient?.display_name || 'They'} will see it on their dashboard.
            </p>
          </div>
        ) : (
          <>
            {/* Templates */}
            <p style={{ fontSize: 11, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: 1, marginBottom: 8 }}>
              QUICK PICKS
            </p>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 16 }}>
              {TEMPLATES.map(t => {
                const selected = message === t
                return (
                  <button
                    key={t}
                    onClick={() => setMessage(t)}
                    disabled={sending}
                    style={{
                      textAlign: 'left',
                      padding: '10px 14px',
                      borderRadius: 8,
                      background: selected ? 'rgba(255,20,147,.1)' : 'rgba(255,255,255,.04)',
                      border: `1px solid ${selected ? 'rgba(255,20,147,.4)' : 'rgba(255,255,255,.08)'}`,
                      color: selected ? 'var(--pink)' : 'rgba(251,250,244,.7)',
                      fontFamily: 'var(--font-ui)',
                      fontSize: 13,
                      cursor: sending ? 'default' : 'pointer',
                      transition: 'background .15s, color .15s, border-color .15s',
                    }}
                  >
                    {t}
                  </button>
                )
              })}
            </div>

            {/* Custom message */}
            <p style={{ fontSize: 11, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', letterSpacing: 1, marginBottom: 8 }}>
              OR WRITE YOUR OWN
            </p>
            <textarea
              value={message}
              onChange={e => setMessage(e.target.value)}
              disabled={sending}
              placeholder="Say something kind…"
              rows={3}
              style={{
                width: '100%',
                resize: 'vertical',
                fontFamily: 'var(--font-ui)',
                fontSize: 14,
                lineHeight: 1.5,
                marginBottom: 4,
              }}
            />
            <div style={{
              fontSize: 11,
              fontFamily: 'var(--font-ui)',
              color: overLimit ? 'var(--pink)' : 'rgba(251,250,244,.4)',
              textAlign: 'right',
              marginBottom: 14,
            }}>
              {charsRemaining} character{Math.abs(charsRemaining) === 1 ? '' : 's'} {overLimit ? 'over limit' : 'remaining'}
            </div>

            {error && (
              <p style={{ fontSize: 12, color: 'var(--pink)', fontFamily: 'var(--font-ui)', marginBottom: 12, padding: '8px 12px', background: 'rgba(255,20,147,.08)', borderRadius: 6 }}>
                {error}
              </p>
            )}

            <button
              onClick={handleSubmit}
              disabled={sending || overLimit || empty}
              className="btn-primary"
              style={{ width: '100%', padding: 14, opacity: (overLimit || empty) ? .4 : 1 }}
            >
              {sending ? 'Sending…' : '🌟 Send Cheers'}
            </button>
            <button
              onClick={onClose}
              disabled={sending}
              style={{
                width: '100%',
                marginTop: 10,
                padding: 10,
                background: 'transparent',
                border: 'none',
                color: 'rgba(251,250,244,.5)',
                fontSize: 13,
                fontFamily: 'var(--font-ui)',
                cursor: sending ? 'default' : 'pointer',
              }}
            >
              Cancel
            </button>
          </>
        )}
      </div>
    </div>
  )
}
