// SpeechToText.js — wrapper around webkitSpeechRecognition for Class B chain.
// Two modes:
//   GATE        — single decision: did the member say yes or no?
//   REFLECTION  — freeform transcription into the NOTES textarea
//
// iOS PWA validated in Phase 2 Step 6 (Handoff v4.19 §6 recently-resolved).
// Permission dialog fires on first use; persists across sessions per origin.
// On denial, callers fall back to tap UI (gate buttons / typed reflection).

// Yes/no word lists locked May 6, 2026 in Player Spec v1.2-FINAL §6 Class B.
// Match-on-substring after lower-casing the transcript. Order matters:
// "no" matchers run first so "no thanks" wins over "thanks", and so a
// transcript like "yes please no wait" is classified by the no.
const NO_WORDS = [
  'nope', 'no thanks', 'not today', 'not now', 'maybe later',
  "i'm good", 'skip', 'pass', 'nah',
  // 'no' last so "nope" / "not" prefix-matches don't interfere
  ' no ', ' no.', ' no,', 'no.', 'no,', 'no!'
]
// 'no' deserves special handling — it's a 2-char substring that lights up
// inside almost any sentence ("not today", "knowledge", "honor"). We bracket
// it with whitespace/punctuation for safety. The bare 'no' as a single-token
// transcript is also classified — see classifyGateResponse below.

const YES_WORDS = [
  'yes', 'yeah', 'yep', 'yup', 'sure', 'okay', 'ok', 'alright',
  'please', "let's do it", 'i would', 'i do', 'go ahead'
]

export function isSpeechRecognitionSupported() {
  return !!(typeof window !== 'undefined' &&
    (window.SpeechRecognition || window.webkitSpeechRecognition))
}

export function classifyGateResponse(transcript) {
  if (!transcript) return null
  const lower = transcript.toLowerCase().trim()
  if (!lower) return null
  // Bare-token "no" as the entire utterance
  if (lower === 'no') return 'no'
  // Padded version of the transcript so leading/trailing 'no' is detectable
  const padded = ' ' + lower + ' '
  for (const w of NO_WORDS) {
    if (padded.includes(w)) return 'no'
  }
  for (const w of YES_WORDS) {
    if (padded.includes(' ' + w + ' ') || padded.includes(' ' + w + '.') ||
        padded.includes(' ' + w + ',') || padded.includes(' ' + w + '!') ||
        lower === w || lower.startsWith(w + ' ') || lower.endsWith(' ' + w)) {
      return 'yes'
    }
  }
  return null
}

// ─── GATE recognizer ─────────────────────────────────────────────────────────
// Listens until a yes/no is heard, the caller stops it, or the browser
// times out. Caller is responsible for the spec's 12-sec wall-clock timeout
// (we don't enforce it here — keeps this module decoupled from the player).
export function createGateRecognizer({ onYes, onNo, onError, onEnd }) {
  const SR = (typeof window !== 'undefined') &&
    (window.SpeechRecognition || window.webkitSpeechRecognition)
  if (!SR) {
    if (onError) onError(new Error('Speech recognition not supported'))
    return null
  }
  let recognition
  try {
    recognition = new SR()
  } catch (err) {
    if (onError) onError(err)
    return null
  }
  recognition.continuous = true
  recognition.interimResults = true
  recognition.lang = 'en-US'
  recognition.maxAlternatives = 1

  let resolved = false

  recognition.onresult = (event) => {
    if (resolved) return
    let combined = ''
    for (let i = 0; i < event.results.length; i++) {
      combined += event.results[i][0].transcript + ' '
    }
    const intent = classifyGateResponse(combined)
    if (intent === 'yes') {
      resolved = true
      try { recognition.stop() } catch {}
      if (onYes) onYes(combined.trim())
    } else if (intent === 'no') {
      resolved = true
      try { recognition.stop() } catch {}
      if (onNo) onNo(combined.trim())
    }
  }
  recognition.onerror = (event) => {
    // Common errors: 'no-speech', 'not-allowed' (permission denied),
    // 'audio-capture', 'network'. Caller decides how to respond.
    if (!resolved && onError) onError(event)
  }
  recognition.onend = () => {
    if (onEnd) onEnd(resolved)
  }

  function start() {
    try { recognition.start() }
    catch (err) { if (onError) onError(err) }
  }
  function stop() {
    resolved = true
    try { recognition.stop() } catch {}
  }
  return { start, stop }
}

// ─── REFLECTION recognizer ───────────────────────────────────────────────────
// Continuous transcription. Caller wires onInterim (live preview) and
// onFinal (committed text). Caller stops it via the returned stop().
export function createReflectionRecognizer({ onInterim, onFinal, onError, onEnd }) {
  const SR = (typeof window !== 'undefined') &&
    (window.SpeechRecognition || window.webkitSpeechRecognition)
  if (!SR) {
    if (onError) onError(new Error('Speech recognition not supported'))
    return null
  }
  let recognition
  try {
    recognition = new SR()
  } catch (err) {
    if (onError) onError(err)
    return null
  }
  recognition.continuous = true
  recognition.interimResults = true
  recognition.lang = 'en-US'

  recognition.onresult = (event) => {
    let interim = ''
    let final = ''
    for (let i = event.resultIndex; i < event.results.length; i++) {
      const t = event.results[i][0].transcript
      if (event.results[i].isFinal) final += t
      else interim += t
    }
    if (final && onFinal) onFinal(final)
    if (interim && onInterim) onInterim(interim)
  }
  recognition.onerror = (event) => {
    if (onError) onError(event)
  }
  recognition.onend = () => {
    if (onEnd) onEnd()
  }

  function start() {
    try { recognition.start() }
    catch (err) { if (onError) onError(err) }
  }
  function stop() {
    try { recognition.stop() } catch {}
  }
  return { start, stop }
}
