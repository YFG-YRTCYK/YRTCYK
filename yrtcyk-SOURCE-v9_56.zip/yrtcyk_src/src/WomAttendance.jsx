// ─── v9.46 Item 8 — Word of Mouth "🪄 I'm Going" toggle ─────────────────────
// Shared component rendered on event-type WoM entries (start_date or end_date set).
// Used in two surfaces: CommunityCalendar.jsx (lgbt_event cards) and WordOfMouth.jsx
// (the WoM listing page, on any card with a date range).
//
// Data model: public.wom_attendance (id, member_id, word_of_mouth_id, created_at)
//   • Read: all authenticated members
//   • Insert: own member_id only
//   • Delete: own row OR is_admin()
//
// Design: pink "🪄 I'm Going" outlined toggle + horizontal avatar pile of attendees
// (max 8 visible, "+N more" overflow). Single-row, fits within existing card padding.

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

const DEFAULT_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><circle cx="16" cy="16" r="16" fill="#01280e"/><circle cx="16" cy="16" r="15" fill="none" stroke="#FF1493" stroke-width="1"/><text x="16" y="20" text-anchor="middle" font-family="Georgia,serif" font-size="11" font-weight="700" fill="#FF1493">YFG</text></svg>')}`

const MAX_PILE = 8

/**
 * Renders the I'm Going toggle + attendee pile for a single WoM event.
 *
 * @param {string}  womId         The word_of_mouth.id this toggle is bound to.
 * @param {object}  member        Current member row ({ id, display_name, avatar_url }).
 *                                Pass null if the user is not yet resolved (component will
 *                                render in a read-only state).
 */
export default function WomAttendance({ womId, member }) {
  const [attendees, setAttendees]   = useState([])  // [{ member_id, display_name, avatar_url }]
  const [loading, setLoading]       = useState(true)
  const [busy, setBusy]             = useState(false)

  useEffect(() => { load() }, [womId])

  async function load() {
    setLoading(true)
    // One query: join wom_attendance to members for the display data we need.
    // Note: PostgREST's foreign-key embed syntax — `members:member_id(...)` —
    // resolves the FK we added to public.members(id) ON DELETE CASCADE.
    const { data, error } = await supabase
      .from('wom_attendance')
      .select('member_id, members:member_id ( id, display_name, email, avatar_url )')
      .eq('word_of_mouth_id', womId)
      .order('created_at', { ascending: true })

    if (error) {
      console.error('[WomAttendance] load error', error)
      setAttendees([])
    } else {
      setAttendees((data || []).map(r => ({
        member_id:    r.member_id,
        display_name: r.members?.display_name || (r.members?.email ? r.members.email.split('@')[0] : 'Member'),
        avatar_url:   r.members?.avatar_url || DEFAULT_AVATAR,
      })))
    }
    setLoading(false)
  }

  const isGoing = !!member && attendees.some(a => a.member_id === member.id)
  const count   = attendees.length

  async function toggle() {
    if (!member || busy) return
    setBusy(true)
    if (isGoing) {
      // Optimistic remove
      const prev = attendees
      setAttendees(attendees.filter(a => a.member_id !== member.id))
      const { error } = await supabase
        .from('wom_attendance')
        .delete()
        .eq('word_of_mouth_id', womId)
        .eq('member_id', member.id)
      if (error) {
        console.error('[WomAttendance] delete error', error)
        setAttendees(prev) // rollback
      }
    } else {
      // Optimistic add — display data may already be loaded on the member object
      const prev = attendees
      setAttendees([...attendees, {
        member_id:    member.id,
        display_name: member.display_name || 'You',
        avatar_url:   member.avatar_url || DEFAULT_AVATAR,
      }])
      const { error } = await supabase
        .from('wom_attendance')
        .insert({ member_id: member.id, word_of_mouth_id: womId })
      if (error) {
        console.error('[WomAttendance] insert error', error)
        setAttendees(prev) // rollback
      } else {
        // Refresh from server so our row picks up authoritative display data
        load()
      }
    }
    setBusy(false)
  }

  if (loading) {
    // Subtle placeholder so the card height doesn't jump
    return (
      <div style={{ marginTop: 12, height: 36, opacity: .3, fontSize: 11, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)' }}>
        …
      </div>
    )
  }

  const pile     = attendees.slice(0, MAX_PILE)
  const overflow = Math.max(0, count - MAX_PILE)

  return (
    <div style={{ marginTop: 12, display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: 12, paddingTop: 12, borderTop: '1px solid rgba(255,255,255,.06)' }}>
      <button
        onClick={toggle}
        disabled={!member || busy}
        title={!member ? 'Sign in to RSVP' : (isGoing ? 'You\'re going — tap to remove' : 'Tap to mark yourself as going')}
        style={{
          padding: '7px 14px',
          borderRadius: 20,
          background:  isGoing ? 'var(--pink)'                     : 'rgba(255,20,147,.08)',
          border:      isGoing ? '1px solid var(--pink)'           : '1px solid rgba(255,20,147,.35)',
          color:       isGoing ? '#fff'                            : 'var(--pink)',
          fontSize: 12,
          fontFamily: 'var(--font-ui)',
          fontWeight: 600,
          cursor: !member || busy ? 'default' : 'pointer',
          opacity: !member ? .5 : 1,
          whiteSpace: 'nowrap',
          transition: 'background .15s, color .15s',
        }}
      >
        🪄 {isGoing ? 'You\'re going' : 'I\'m Going'}
      </button>

      {count > 0 && (
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, minWidth: 0 }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
            {pile.map((a, idx) => (
              <img
                key={a.member_id}
                src={a.avatar_url}
                alt={a.display_name}
                title={a.display_name}
                style={{
                  width: 24, height: 24, borderRadius: '50%',
                  border: '2px solid var(--bg)',
                  marginLeft: idx === 0 ? 0 : -8,
                  background: 'var(--bg)',
                  objectFit: 'cover',
                  zIndex: pile.length - idx,
                }}
                onError={(e) => { e.currentTarget.src = DEFAULT_AVATAR }}
              />
            ))}
          </div>
          <span style={{ fontSize: 11, color: 'rgba(251,250,244,.55)', fontFamily: 'var(--font-ui)', whiteSpace: 'nowrap' }}>
            {count === 1 ? '1 member going' : `${count} members going`}
            {overflow > 0 && <span style={{ color: 'rgba(251,250,244,.35)' }}> · +{overflow} more</span>}
          </span>
        </div>
      )}
    </div>
  )
}
