// src/blocks.js — Block feature data layer (v9.56).
//
// Blocking is MUTUAL and SILENT. The member_blocks RLS lets a member read
// only the blocks THEY created, so "who blocked me" is invisible to the
// client by design. Mutual hiding is therefore enforced at the database via
// the can_see() restrictive policy on members — the directory query already
// comes back filtered in both directions. This module only needs to:
//   - resolve the current member's id from their auth email,
//   - create a block, remove a block,
//   - list the people the current member has blocked (via a SECURITY DEFINER
//     RPC, so their names are visible even though the restrictive policy
//     would otherwise hide them).
import { supabase } from './supabaseClient'

// Resolve the signed-in member's UUID from their auth email.
export async function getMyMemberId(email) {
  if (!email) return null
  const { data, error } = await supabase
    .from('members').select('id').eq('email', email).single()
  if (error) { console.warn('[Block] getMyMemberId:', error.message); return null }
  return data?.id || null
}

// People I have blocked, with display info, newest first.
// Backed by public.get_my_blocked_members() (SECURITY DEFINER, scoped to caller).
export async function fetchMyBlockedMembers() {
  const { data, error } = await supabase.rpc('get_my_blocked_members')
  if (error) { console.warn('[Block] fetchMyBlockedMembers:', error.message); return [] }
  return data || []
}

export async function blockMember(myId, targetId, reason = null) {
  if (!myId || !targetId || myId === targetId) {
    return { error: { message: 'invalid block target' } }
  }
  return await supabase
    .from('member_blocks')
    .insert({ blocker_id: myId, blocked_id: targetId, reason })
}

export async function unblockMember(myId, targetId) {
  if (!myId || !targetId) return { error: { message: 'invalid unblock target' } }
  return await supabase
    .from('member_blocks')
    .delete()
    .eq('blocker_id', myId)
    .eq('blocked_id', targetId)
}
