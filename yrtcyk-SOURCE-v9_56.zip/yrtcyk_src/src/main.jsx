import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode><App /></React.StrictMode>
)

// PWA service worker registration.
// We register only in production-served contexts (HTTPS or localhost).
// On any failure, we swallow the error: a SW registration failure must
// never break the app — the React app continues to work as a regular webapp.
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .catch((err) => {
        // Intentionally silent in production. Log only when DevTools are open.
        if (typeof console !== 'undefined' && console.warn) {
          console.warn('[YRTCYK] Service worker registration deferred:', err)
        }
      })
  })
}
