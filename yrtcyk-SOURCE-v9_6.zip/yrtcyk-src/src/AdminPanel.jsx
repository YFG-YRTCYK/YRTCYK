import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function AdminPanel({ user, onClose }) {
  const [tab, setTab] = useState('members')
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [pendingComments, setPendingComments] = useState([])
  const [commentsLoading, setCommentsLoading] = useState(false)

  useEffect(()=>{ loadAll() },[])

  async function loadAll() {
    const { data } = await supabase.from('members').select('*').order('created_at',{ascending:false})
    setMembers(data||[])
    setLoading(false)
    loadPendingComments()
  }

  async function loadPendingComments() {
    setCommentsLoading(true)
    const { data } = await supabase.from('hero_comments').select('*').eq('status','pending').order('created_at',{ascending:true})
    setPendingComments(data||[])
    setCommentsLoading(false)
  }

  async function approveComment(id) {
    await supabase.from('hero_comments').update({ status:'approved' }).eq('id',id)
    setPendingComments(prev => prev.filter(c => c.id !== id))
  }
  async function rejectComment(id) {
    await supabase.from('hero_comments').update({ status:'rejected' }).eq('id',id)
    setPendingComments(prev => prev.filter(c => c.id !== id))
  }

  async function toggleModerator(id, current) {
    await supabase.from('members').update({is_moderator:!current}).eq('id',id)
    loadAll()
  }
  async function toggleActive(id, current) {
    await supabase.from('members').update({is_active:!current}).eq('id',id)
    loadAll()
  }

  return (
    <div style={{paddingTop:20,paddingBottom:40}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:20}}>
        <h2 style={{fontSize:20,fontWeight:400}}>⚙️ Admin</h2>
        <button onClick={onClose} style={{color:'rgba(251,250,244,.5)',fontSize:13,fontFamily:'system-ui'}}>← Back</button>
      </div>
      {/* Admin tab bar */}
      <div style={{display:'flex',gap:8,marginBottom:20}}>
        {[['members','👥 Members'],['comments','💬 Comments']].map(([t,label])=>(
          <button key={t} onClick={()=>setTab(t)}
            style={{padding:'8px 14px',borderRadius:8,fontSize:12,fontFamily:'var(--font-ui)',cursor:'pointer',position:'relative',
              background:tab===t?'var(--pink)':'rgba(255,255,255,.06)',
              color:tab===t?'#fff':'rgba(251,250,244,.55)',
              border:`1px solid ${tab===t?'var(--pink)':'rgba(255,255,255,.1)'}`}}>
            {label}
            {t==='comments' && pendingComments.length>0 && (
              <span style={{position:'absolute',top:-6,right:-6,background:'#FF1493',color:'#fff',
                borderRadius:10,fontSize:10,fontWeight:700,padding:'1px 5px',fontFamily:'var(--font-ui)'}}>
                {pendingComments.length}
              </span>
            )}
          </button>
        ))}
      </div>

      {tab==='members' && <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'system-ui',letterSpacing:1,marginBottom:16}}>MEMBER MANAGEMENT</p>}
      {loading&&<div className="spinner"/>}
      {members.map(m=>(
        <div key={m.id} className="card" style={{marginBottom:10}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start',marginBottom:8}}>
            <div>
              <p style={{fontSize:14,fontWeight:500}}>{m.display_name||m.email.split('@')[0]}</p>
              <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'system-ui'}}>{m.email}</p>
            </div>
            <span style={{fontSize:10,fontFamily:'system-ui',padding:'2px 8px',borderRadius:20,background:m.is_active?'rgba(25,229,94,.12)':'rgba(255,255,255,.07)',color:m.is_active?'var(--lime)':'rgba(251,250,244,.4)',border:'1px solid '+(m.is_active?'rgba(25,229,94,.25)':'rgba(255,255,255,.1)')}}>
              {m.is_active?'Active':'Inactive'}
            </span>
          </div>
          <div style={{display:'flex',gap:8,flexWrap:'wrap'}}>
            <button onClick={()=>toggleActive(m.id,m.is_active)} style={{fontSize:11,fontFamily:'system-ui',padding:'5px 10px',borderRadius:8,background:'rgba(255,255,255,.07)',border:'1px solid rgba(255,255,255,.12)',color:'rgba(251,250,244,.6)',cursor:'pointer'}}>
              {m.is_active?'Deactivate':'Activate'}
            </button>
            {m.email!==user.email&&<button onClick={()=>toggleModerator(m.id,m.is_moderator)} style={{fontSize:11,fontFamily:'system-ui',padding:'5px 10px',borderRadius:8,background:m.is_moderator?'rgba(25,229,94,.1)':'rgba(255,255,255,.07)',border:'1px solid '+(m.is_moderator?'rgba(25,229,94,.2)':'rgba(255,255,255,.1)'),color:m.is_moderator?'var(--lime)':'rgba(251,250,244,.5)',cursor:'pointer'}}>
              {m.is_moderator?'Remove Mod':'Make Mod'}
            </button>}
          </div>
        </div>
      ))}

      {/* ── COMMENTS TAB ── */}
      {tab==='comments' && (
        <div>
          <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:16}}>
            PENDING COMMENT REVIEW
          </p>
          {commentsLoading && <div className="spinner"/>}
          {!commentsLoading && pendingComments.length===0 && (
            <div className="card" style={{textAlign:'center',padding:40}}>
              <p style={{fontSize:28,marginBottom:8}}>✨</p>
              <p style={{color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',fontSize:14}}>All caught up — no pending comments.</p>
            </div>
          )}
          {pendingComments.map(c=>(
            <div key={c.id} className="card" style={{marginBottom:12}}>
              <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:8}}>
                {c.reaction && <span style={{fontSize:20}}>{c.reaction}</span>}
                <div style={{flex:1}}>
                  <p style={{fontSize:13,fontWeight:600,color:'var(--pink)'}}>{c.member_display_name}</p>
                  <p style={{fontSize:11,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)'}}>
                    On hero: <strong>{c.hero_name}</strong> · {new Date(c.created_at).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}
                  </p>
                </div>
              </div>
              {c.comment_text && (
                <p style={{fontSize:13,color:'rgba(251,250,244,.8)',lineHeight:1.65,marginBottom:12,
                  padding:'10px 14px',background:'rgba(255,255,255,.04)',borderRadius:8,
                  borderLeft:'3px solid rgba(255,20,147,.3)'}}>
                  "{c.comment_text}"
                </p>
              )}
              <div style={{display:'flex',gap:8}}>
                <button onClick={()=>approveComment(c.id)}
                  style={{flex:1,padding:'8px',borderRadius:8,background:'rgba(25,229,94,.15)',
                    border:'1px solid rgba(25,229,94,.3)',color:'var(--lime)',
                    fontSize:12,fontFamily:'var(--font-ui)',cursor:'pointer',fontWeight:600}}>
                  ✅ Approve
                </button>
                <button onClick={()=>rejectComment(c.id)}
                  style={{flex:1,padding:'8px',borderRadius:8,background:'rgba(255,20,147,.1)',
                    border:'1px solid rgba(255,20,147,.2)',color:'var(--pink)',
                    fontSize:12,fontFamily:'var(--font-ui)',cursor:'pointer'}}>
                  ❌ Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

    </div>
  )
}