// ========================================================================
// AdminAnalytics.jsx — v9.7 (April 18, 2026)
//
// Reads from Supabase views v_analytics_snapshot, v_analytics_dau,
// v_analytics_new_members_weekly, v_analytics_cancellations,
// v_analytics_referral_velocity, v_analytics_content_submissions,
// v_analytics_mod_queue.
//
// Kept intentionally dependency-free — renders simple bar charts in pure CSS
// rather than pulling Recharts for a dashboard only admin ever sees.
// (If Geo later wants richer charts, swap in Recharts on the bar components.)
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

function Bar({ label, value, max, color = 'var(--pink)', rightText }) {
  const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0
  return (
    <div style={{ marginBottom:10 }}>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:11, fontFamily:'var(--font-ui)',
        color:'rgba(251,250,244,.55)', marginBottom:4 }}>
        <span>{label}</span>
        <span>{rightText ?? value}</span>
      </div>
      <div style={{ height:8, background:'rgba(255,255,255,.05)', borderRadius:4, overflow:'hidden' }}>
        <div style={{ width:`${pct}%`, height:'100%', background:color, transition:'width .3s ease' }}/>
      </div>
    </div>
  )
}

function Stat({ label, value, color = 'var(--cream)' }) {
  return (
    <div className="card" style={{ padding:12, textAlign:'center' }}>
      <p style={{ fontSize:22, fontWeight:700, color, fontFamily:'var(--font-ui)', lineHeight:1.1 }}>{value}</p>
      <p style={{ fontSize:10, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1, marginTop:4, textTransform:'uppercase' }}>{label}</p>
    </div>
  )
}

export default function AdminAnalytics() {
  const [snap, setSnap] = useState(null)
  const [dau, setDau] = useState([])
  const [weekly, setWeekly] = useState([])
  const [referrals, setReferrals] = useState([])
  const [content, setContent] = useState([])
  const [modQueue, setModQueue] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    const [snapRes, dauRes, weeklyRes, refRes, contentRes, queueRes] = await Promise.all([
      supabase.from('v_analytics_snapshot').select('*').maybeSingle(),
      supabase.from('v_analytics_dau').select('*'),
      supabase.from('v_analytics_new_members_weekly').select('*'),
      supabase.from('v_analytics_referral_velocity').select('*'),
      supabase.from('v_analytics_content_submissions').select('*'),
      supabase.from('v_analytics_mod_queue').select('*')
    ])
    setSnap(snapRes.data)
    setDau(dauRes.data || [])
    setWeekly(weeklyRes.data || [])
    setReferrals(refRes.data || [])
    setContent(contentRes.data || [])
    setModQueue(queueRes.data || [])
    setLoading(false)
  }

  if (loading) return <div className="spinner"/>
  if (!snap) return <p style={{ color:'rgba(251,250,244,.4)', padding:20 }}>No data available yet.</p>

  const maxDau = Math.max(1, ...dau.map(d => d.active_members))
  const maxWeekly = Math.max(1, ...weekly.map(w => w.new_members))
  const maxContent = Math.max(1,
    ...content.map(c =>
      (c.heroes_submitted || 0) + (c.reflections_submitted || 0) +
      (c.comments_submitted || 0) + (c.word_of_mouth_submitted || 0)
    )
  )

  return (
    <div>
      {/* ── SNAPSHOT ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>PLATFORM SNAPSHOT</p>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(3, 1fr)', gap:8, marginBottom:20 }}>
        <Stat label="Active Members" value={snap.active_members} color="var(--lime)"/>
        <Stat label="New This Week" value={snap.new_this_week} color="var(--pink)"/>
        <Stat label="New This Month" value={snap.new_this_month} color="var(--pink)"/>
        <Stat label="Churned (30d)" value={snap.churned_this_month}
          color={snap.churned_this_month > 0 ? 'var(--pink)' : 'rgba(251,250,244,.4)'}/>
        <Stat label="Outstanding Invites" value={snap.referrals_outstanding}/>
        <Stat label="Deletion Requests" value={snap.deletion_requests_pending}
          color={snap.deletion_requests_pending > 0 ? 'var(--pink)' : 'rgba(251,250,244,.4)'}/>
      </div>

      {/* ── MODERATOR QUEUE DEPTH ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>MODERATION QUEUE</p>
      <div className="card" style={{ marginBottom:20 }}>
        {modQueue.map(q => (
          <div key={q.queue_name} style={{
            display:'flex', justifyContent:'space-between', alignItems:'center',
            padding:'8px 0', borderBottom:'1px solid rgba(255,255,255,.05)'
          }}>
            <div>
              <p style={{ fontSize:13, fontWeight:500, textTransform:'capitalize' }}>{q.queue_name.replace('_', ' ')}</p>
              <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
                Last 7d: {q.approved_last_7d || 0} approved · {q.rejected_last_7d || 0} returned
              </p>
            </div>
            <span style={{
              fontSize:18, fontWeight:700, fontFamily:'var(--font-ui)',
              color: q.pending_count > 0 ? 'var(--pink)' : 'var(--lime)'
            }}>
              {q.pending_count || 0}
            </span>
          </div>
        ))}
      </div>

      {/* ── DAU ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>DAILY ACTIVE MEMBERS (LAST 30 DAYS)</p>
      <div className="card" style={{ marginBottom:20 }}>
        {dau.length === 0 && <p style={{ fontSize:12, color:'rgba(251,250,244,.35)',
          fontFamily:'var(--font-ui)', textAlign:'center', padding:16 }}>No activity recorded yet.</p>}
        {dau.slice(0, 14).map(d => (
          <Bar key={d.activity_date}
            label={new Date(d.activity_date).toLocaleDateString('en-US', { month:'short', day:'numeric' })}
            value={d.active_members}
            max={maxDau}/>
        ))}
      </div>

      {/* ── NEW MEMBERS WEEKLY ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>NEW MEMBERS PER WEEK</p>
      <div className="card" style={{ marginBottom:20 }}>
        {weekly.length === 0 && <p style={{ fontSize:12, color:'rgba(251,250,244,.35)',
          fontFamily:'var(--font-ui)', textAlign:'center', padding:16 }}>No new members yet.</p>}
        {weekly.map(w => (
          <Bar key={w.week_start}
            label={`Week of ${new Date(w.week_start).toLocaleDateString('en-US', { month:'short', day:'numeric' })}`}
            value={w.new_members}
            max={maxWeekly}
            color="var(--lime)"
            rightText={`${w.new_members} new · ${w.still_active} active`}/>
        ))}
      </div>

      {/* ── REFERRAL FUNNEL ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>🌈 WIDEN THE CIRCLE FUNNEL</p>
      <div className="card" style={{ marginBottom:20 }}>
        {referrals.length === 0 && <p style={{ fontSize:12, color:'rgba(251,250,244,.35)',
          fontFamily:'var(--font-ui)', textAlign:'center', padding:16 }}>No referrals yet — invite your first friend.</p>}
        {referrals.map(r => (
          <div key={r.week_start} style={{ marginBottom:14, paddingBottom:10, borderBottom:'1px solid rgba(255,255,255,.05)' }}>
            <p style={{ fontSize:12, fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.55)', marginBottom:6 }}>
              Week of {new Date(r.week_start).toLocaleDateString('en-US', { month:'short', day:'numeric' })}
            </p>
            <div style={{ display:'flex', gap:4, alignItems:'center', fontSize:10,
              fontFamily:'var(--font-ui)', color:'rgba(251,250,244,.5)' }}>
              <span>📨 {r.invited}</span><span style={{ opacity:.3 }}>→</span>
              <span>🎉 {r.joined}</span><span style={{ opacity:.3 }}>→</span>
              <span>📅 {r.month_1}</span><span style={{ opacity:.3 }}>→</span>
              <span>📅 {r.month_2}</span><span style={{ opacity:.3 }}>→</span>
              <span style={{ color:'var(--lime)' }}>🎁 {r.rewarded}</span>
            </div>
          </div>
        ))}
      </div>

      {/* ── CONTENT ── */}
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>CONTENT SUBMISSIONS (LAST 14 DAYS)</p>
      <div className="card">
        {content.slice(0, 14).map(c => {
          const total = (c.heroes_submitted || 0) + (c.reflections_submitted || 0) +
                        (c.comments_submitted || 0) + (c.word_of_mouth_submitted || 0)
          return (
            <Bar key={c.day}
              label={new Date(c.day).toLocaleDateString('en-US', { month:'short', day:'numeric' })}
              value={total}
              max={maxContent}
              color="var(--pink)"
              rightText={total > 0
                ? `🌟${c.heroes_submitted} 📝${c.reflections_submitted} 💬${c.comments_submitted} 💋${c.word_of_mouth_submitted}`
                : '—'}/>
          )
        })}
      </div>
    </div>
  )
}
