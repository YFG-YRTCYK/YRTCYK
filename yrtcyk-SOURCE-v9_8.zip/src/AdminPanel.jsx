// ========================================================================
// AdminPanel.jsx — v9.7 (April 18, 2026)
//
// Full admin cockpit. Six tabs:
//   👥 Members       — activate/deactivate, Moderator toggle, Trailblazer toggle,
//                      set membership_end_reason (including deceased + date)
//   📝 Reflections   — post + comment review queue (embeds ModeratorPanel)
//   🕊️ Heroes        — mark a Hero as In Loving Memory
//   💬 Hero Comments — existing hero-comment approval queue
//   🗑️ Deletions     — GDPR/CCPA deletion queue (cancel pending on member's behalf)
//   📊 Analytics     — platform dashboard
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'
import ModeratorPanel from './ModeratorPanel'
import HeroMemorialAdmin from './HeroMemorialAdmin'
import DeletionQueueAdmin from './DeletionQueueAdmin'
import AdminAnalytics from './AdminAnalytics'

export default function AdminPanel({ user, onClose }) {
  const [tab, setTab] = useState('members')
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(true)
  const [pendingHeroComments, setPendingHeroComments] = useState([])
  const [expandedMember, setExpandedMember] = useState(null)
  const [msg, setMsg] = useState('')

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    const [mRes, hcRes] = await Promise.all([
      supabase.from('members').select('*').order('member_number', { ascending: true, nullsFirst: false }),
      supabase.from('hero_comments').select('*').eq('status', 'pending').order('created_at')
    ])
    setMembers(mRes.data || [])
    setPendingHeroComments(hcRes.data || [])
    setLoading(false)
  }

  async function toggleModerator(id, current) {
    await supabase.from('members').update({ is_moderator: !current }).eq('id', id)
    loadAll()
  }
  async function toggleTrailblazer(id, current) {
    await supabase.from('members').update({ is_trailblazer: !current }).eq('id', id)
    loadAll()
  }
  async function toggleActive(id, current) {
    await supabase.from('members').update({ is_active: !current }).eq('id', id)
    loadAll()
  }

  async function setEndReason(id, reason, dateOfPassing = null) {
    const payload = { membership_end_reason: reason }
    if (reason === 'deceased' && dateOfPassing) payload.date_of_passing = dateOfPassing
    if (reason === null) payload.date_of_passing = null
    const { error } = await supabase.from('members').update(payload).eq('id', id)
    if (error) { setMsg('Error: ' + error.message); return }
    setMsg('Updated.'); setTimeout(() => setMsg(''), 2000)
    loadAll()
  }

  async function approveHeroComment(id) {
    await supabase.from('hero_comments').update({ status: 'approved' }).eq('id', id)
    setPendingHeroComments(prev => prev.filter(c => c.id !== id))
  }
  async function rejectHeroComment(id) {
    await supabase.from('hero_comments').update({ status: 'rejected' }).eq('id', id)
    setPendingHeroComments(prev => prev.filter(c => c.id !== id))
  }

  return (
    <div style={{ padding:'20px 16px 40px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>⚙️ Admin</h2>
        <button onClick={onClose} style={{ color:'rgba(251,250,244,.5)', fontSize:13, fontFamily:'var(--font-ui)' }}>
          ← Back
        </button>
      </div>

      <div style={{ display:'flex', gap:6, marginBottom:20, overflowX:'auto', flexWrap:'nowrap', paddingBottom:4 }}>
        {[
          ['members', '👥 Members'],
          ['reflections', '📝 Reflections'],
          ['heroes', '🕊️ Heroes'],
          ['herocomments', `💬 Hero Comments${pendingHeroComments.length ? ` (${pendingHeroComments.length})` : ''}`],
          ['deletions', '🗑️ Deletions'],
          ['analytics', '📊 Analytics']
        ].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)}
            style={{
              padding:'8px 12px', borderRadius:8, fontSize:11, fontFamily:'var(--font-ui)', cursor:'pointer',
              background: tab === t ? 'var(--pink)' : 'rgba(255,255,255,.06)',
              color: tab === t ? '#fff' : 'rgba(251,250,244,.55)',
              border: `1px solid ${tab === t ? 'var(--pink)' : 'rgba(255,255,255,.1)'}`,
              whiteSpace:'nowrap', flexShrink:0
            }}>
            {label}
          </button>
        ))}
      </div>

      {msg && <p style={{
        fontSize:12, fontFamily:'var(--font-ui)', textAlign:'center', marginBottom:12,
        color: msg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)'
      }}>{msg}</p>}

      {/* ── MEMBERS TAB ── */}
      {tab === 'members' && (
        <>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1, marginBottom:16 }}>MEMBER MANAGEMENT · {members.length} TOTAL</p>
          {loading && <div className="spinner"/>}
          {members.map(m => {
            const isSelf = m.email === user.email
            const isExpanded = expandedMember === m.id
            return (
              <div key={m.id} className="card" style={{ marginBottom:10 }}>
                <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:8, gap:8 }}>
                  <div style={{ flex:1, minWidth:0 }}>
                    <p style={{ fontSize:14, fontWeight:500 }}>
                      {m.display_name || m.email.split('@')[0]}
                      {m.member_number && (
                        <span style={{ fontSize:11, color:'rgba(251,250,244,.35)',
                          fontFamily:'var(--font-ui)', marginLeft:8 }}>#{m.member_number}</span>
                      )}
                    </p>
                    <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      overflow:'hidden', textOverflow:'ellipsis' }}>{m.email}</p>
                    <div style={{ marginTop:6 }}>
                      <MemberBadges member={m} size="sm"/>
                    </div>
                  </div>
                  <span style={{
                    fontSize:10, fontFamily:'var(--font-ui)', padding:'2px 8px', borderRadius:20,
                    background: m.is_active ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.07)',
                    color: m.is_active ? 'var(--lime)' : 'rgba(251,250,244,.4)',
                    border:'1px solid ' + (m.is_active ? 'rgba(25,229,94,.25)' : 'rgba(255,255,255,.1)'),
                    flexShrink:0
                  }}>
                    {m.is_active ? 'Active' : 'Inactive'}
                  </span>
                </div>
                <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
                  <button onClick={() => toggleActive(m.id, m.is_active)}
                    style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                      background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.12)',
                      color:'rgba(251,250,244,.6)' }}>
                    {m.is_active ? 'Deactivate' : 'Activate'}
                  </button>
                  {!isSelf && (
                    <button onClick={() => toggleModerator(m.id, m.is_moderator)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background: m.is_moderator ? 'rgba(255,20,147,.12)' : 'rgba(255,255,255,.07)',
                        border:'1px solid ' + (m.is_moderator ? 'rgba(255,20,147,.25)' : 'rgba(255,255,255,.1)'),
                        color: m.is_moderator ? 'var(--pink)' : 'rgba(251,250,244,.5)' }}>
                      {m.is_moderator ? '✓ Mod' : '💜 Make Mod'}
                    </button>
                  )}
                  {!isSelf && (
                    <button onClick={() => toggleTrailblazer(m.id, m.is_trailblazer)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background: m.is_trailblazer ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.07)',
                        border:'1px solid ' + (m.is_trailblazer ? 'rgba(25,229,94,.25)' : 'rgba(255,255,255,.1)'),
                        color: m.is_trailblazer ? 'var(--lime)' : 'rgba(251,250,244,.5)' }}>
                      {m.is_trailblazer ? '✓ Trailblazer' : '✨ Trailblazer'}
                    </button>
                  )}
                  {!isSelf && (
                    <button onClick={() => setExpandedMember(isExpanded ? null : m.id)}
                      style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                        background:'rgba(255,255,255,.05)', border:'1px solid rgba(255,255,255,.1)',
                        color:'rgba(251,250,244,.5)' }}>
                      {isExpanded ? '↑ Less' : 'End Reason…'}
                    </button>
                  )}
                </div>
                {isExpanded && !isSelf && (
                  <div style={{ marginTop:14, paddingTop:14, borderTop:'1px solid rgba(255,255,255,.05)' }}>
                    <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      letterSpacing:1.2, marginBottom:6 }}>MEMBERSHIP END REASON</p>
                    <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:10 }}>
                      {[
                        [null, 'None'],
                        ['cancelled', 'Cancelled'],
                        ['lapsed', 'Lapsed'],
                        ['deceased', '🕊️ Deceased']
                      ].map(([val, label]) => (
                        <button key={String(label)} onClick={() => setEndReason(m.id, val)}
                          style={{ fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 10px', borderRadius:8,
                            background: m.membership_end_reason === val ? 'rgba(255,20,147,.15)' : 'rgba(255,255,255,.06)',
                            border:'1px solid ' + (m.membership_end_reason === val ? 'rgba(255,20,147,.3)' : 'rgba(255,255,255,.1)'),
                            color: m.membership_end_reason === val ? 'var(--pink)' : 'rgba(251,250,244,.55)' }}>
                          {label}
                        </button>
                      ))}
                    </div>
                    {m.membership_end_reason === 'deceased' && (
                      <div style={{ marginTop:4 }}>
                        <p style={{ fontSize:10, color:'rgba(200,180,220,.7)', fontFamily:'var(--font-ui)',
                          letterSpacing:1.2, marginBottom:6 }}>DATE OF PASSING</p>
                        <input type="date" value={m.date_of_passing || ''}
                          onChange={e => setEndReason(m.id, 'deceased', e.target.value)}/>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )
          })}
        </>
      )}

      {/* ── REFLECTIONS QUEUE ── */}
      {tab === 'reflections' && <ModeratorPanel user={user} embedded={true}/>}

      {/* ── HERO MEMORIAL ── */}
      {tab === 'heroes' && <HeroMemorialAdmin/>}

      {/* ── HERO COMMENTS ── */}
      {tab === 'herocomments' && (
        <div>
          <p style={{ fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1, marginBottom:16 }}>PENDING HERO COMMENTS</p>
          {pendingHeroComments.length === 0 && (
            <div className="card" style={{ textAlign:'center', padding:40 }}>
              <p style={{ fontSize:28, marginBottom:8 }}>✨</p>
              <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14 }}>All caught up.</p>
            </div>
          )}
          {pendingHeroComments.map(c => (
            <div key={c.id} className="card" style={{ marginBottom:12 }}>
              <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                {c.reaction && <span style={{ fontSize:20 }}>{c.reaction}</span>}
                <div style={{ flex:1 }}>
                  <p style={{ fontSize:13, fontWeight:600, color:'var(--pink)' }}>{c.member_display_name}</p>
                  <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
                    On hero: <strong>{c.hero_name}</strong> · {new Date(c.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                  </p>
                </div>
              </div>
              {c.comment_text && (
                <p style={{ fontSize:13, color:'rgba(251,250,244,.8)', lineHeight:1.65, marginBottom:12,
                  padding:'10px 14px', background:'rgba(255,255,255,.04)', borderRadius:8,
                  borderLeft:'3px solid rgba(255,20,147,.3)' }}>
                  "{c.comment_text}"
                </p>
              )}
              <div style={{ display:'flex', gap:8 }}>
                <button onClick={() => approveHeroComment(c.id)}
                  style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(25,229,94,.15)',
                    border:'1px solid rgba(25,229,94,.3)', color:'var(--lime)', fontSize:12,
                    fontFamily:'var(--font-ui)', fontWeight:600 }}>
                  ✅ Approve
                </button>
                <button onClick={() => rejectHeroComment(c.id)}
                  style={{ flex:1, padding:'8px', borderRadius:8, background:'rgba(255,20,147,.1)',
                    border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontSize:12,
                    fontFamily:'var(--font-ui)' }}>
                  ❌ Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* ── DELETIONS ── */}
      {tab === 'deletions' && <DeletionQueueAdmin user={user}/>}

      {/* ── ANALYTICS ── */}
      {tab === 'analytics' && <AdminAnalytics/>}
    </div>
  )
}
