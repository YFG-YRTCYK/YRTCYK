import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'

export default function Dashboard({ user }) {
  const [member, setMember]         = useState(null)
  const [dayContent, setDayContent] = useState(null)
  const [dayNum, setDayNum]         = useState(1)
  const [actions, setActions]       = useState({})
  const [kpi, setKpi]               = useState({ total_members:0, active_today:0, community_completion_pct:0, total_days_completed:0 })
  const [myStats, setMyStats]       = useState({ today_pct:0, month_pct:0, overall_pct:0, days_active:0 })
  const [myResponses, setMyResponses]   = useState(0)
  const [commResponses, setCommResponses] = useState(0)
  const [practice, setPractice]     = useState(null)
  const [saving, setSaving]         = useState({})

  useEffect(() => { init() }, [])

  async function init() {
    const { data: m } = await supabase.from('members').select('*').eq('email', user.email).single()
    if (!m) return
    setMember(m)
    const start = new Date(m.membership_start_date + 'T00:00:00')
    const today = new Date(); start.setHours(0,0,0,0); today.setHours(0,0,0,0)
    const dn = Math.max(1, Math.min(365, Math.floor((today - start) / 86400000) + 1))
    setDayNum(dn)

    const [dcRes, daRes, kpiRes, statsRes, myRespRes, commRespRes] = await Promise.all([
      supabase.from('day_content').select('*').eq('day_number', dn).single(),
      supabase.from('daily_actions').select('*').eq('member_id', m.id).eq('day_number', dn),
      supabase.rpc('get_community_kpi'),
      supabase.rpc('get_my_stats'),
      supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('member_id', m.id).eq('item_type', 'text').not('text_value', 'is', null),
      supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('item_type', 'text').not('text_value', 'is', null),
    ])

    if (dcRes.data) setDayContent(dcRes.data)
    if (daRes.data) {
      const a = {}
      daRes.data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    }
    if (kpiRes.data) setKpi(kpiRes.data)
    if (statsRes.data) setMyStats(statsRes.data)
    if (myRespRes.count !== null) setMyResponses(myRespRes.count)
    if (commRespRes.count !== null) setCommResponses(commRespRes.count)
  }

  async function save(section, itemKey, itemType, value) {
    if (!member) return
    const k = `${section}::${itemKey}`
    setSaving(p => ({ ...p, [k]: true }))
    const isCompleted = itemType === 'checkbox' ? value : !!value?.trim()
    const row = {
      member_id: member.id, day_number: dayNum,
      section, item_key: itemKey, item_type: itemType,
      is_checked: itemType === 'checkbox' ? value : false,
      text_value: itemType === 'text' ? value : null,
      is_completed: isCompleted,
      completed_at: isCompleted ? new Date().toISOString() : null,
      updated_at: new Date().toISOString()
    }
    await supabase.from('daily_actions').upsert(row, { onConflict: 'member_id,day_number,section,item_key' })
    setActions(p => ({ ...p, [k]: row }))
    setSaving(p => ({ ...p, [k]: false }))
    // Refresh response count if text was saved
    if (itemType === 'text') {
      const { count } = await supabase.from('daily_actions').select('id', { count: 'exact', head: true })
        .eq('member_id', member.id).eq('item_type', 'text').not('text_value', 'is', null)
      if (count !== null) setMyResponses(count)
    }
  }

  async function reloadActions() {
    if (!member) return
    const { data } = await supabase.from('daily_actions').select('*').eq('member_id', member.id).eq('day_number', dayNum)
    if (data) {
      const a = {}
      data.forEach(x => { a[`${x.section}::${x.item_key}`] = x })
      setActions(a)
    }
  }

  const isChecked = (s, k) => !!actions[`${s}::${k}`]?.is_checked
  const textVal   = (s, k) => actions[`${s}::${k}`]?.text_value || ''
  const isSaving  = (s, k) => !!saving[`${s}::${k}`]

  const hour = new Date().getHours()
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening'
  const name = member?.display_name || user.email.split('@')[0]
  const dateStr = new Date().toLocaleDateString('en-US', { weekday:'long', month:'long', day:'numeric', year:'numeric' })

  if (practice) return (
    <PracticeView period={practice} dayNum={dayNum} dayContent={dayContent}
      memberId={member?.id}
      isChecked={isChecked} textVal={textVal} isSaving={isSaving} save={save}
      actions={actions} onBack={() => setPractice(null)}
      onSwitchPeriod={(p) => setPractice(p)}
      reloadActions={reloadActions} />
  )

  return (
    <div style={{ paddingTop: 20 }}>

      {/* Day 1 Welcome — shows for first 24 hours only */}
      {dayNum === 1 && (
        <div style={{ background: 'linear-gradient(135deg, #01280e, #01380e)', border: '1px solid #19e55e', borderRadius: 12, padding: 24, marginBottom: 24, textAlign: 'center' }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🪄</div>
          <h2 style={{ color: 'var(--pink)', fontSize: 20, fontWeight: 700, marginBottom: 8, fontFamily: 'var(--font-ui)' }}>Welcome. This is your Day 1 here.</h2>
          <p style={{ color: 'var(--cream)', fontSize: 15, lineHeight: 1.6, marginBottom: 12, fontFamily: 'var(--font-ui)' }}>That took courage. You showed up. Now let's do the work.</p>
          <p style={{ color: 'var(--lime)', fontSize: 14, fontFamily: 'var(--font-ui)' }}>Start with your Morning Practice below ↓</p>
        </div>
      )}

      <div style={{ marginBottom: 24 }}>
        <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginBottom: 4 }}>{greeting}, {name}</p>
        {member && (
          <div style={{ marginBottom: 8 }}>
            <MemberBadges member={member} size="md"/>
          </div>
        )}
        <div style={{ fontSize: 42, fontWeight: 700, color: 'var(--pink)', fontFamily: 'var(--font-ui)', lineHeight: 1 }}>Day {dayNum}</div>
        <p style={{ fontSize: 13, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginTop: 4 }}>{dateStr}</p>
      </div>

      {dayContent && (
        <div className="card" style={{ marginBottom: 20, background: 'rgba(255,20,147,.04)', border: '1px solid rgba(255,20,147,.1)' }}>
          <p className="section-label" style={{ marginBottom: 8 }}>Day {dayNum} — Today</p>
          <h3 style={{ fontSize: 18, fontWeight: 400, marginBottom: 6 }}>{dayContent.title}</h3>
          {dayContent.spiritual_principle && <p style={{ fontSize: 12, color: 'var(--pink)', fontFamily: 'var(--font-ui)', letterSpacing: .5 }}>{dayContent.spiritual_principle}</p>}
        </div>
      )}

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
        <button onClick={() => setPractice('morning')} style={{ background: 'rgba(255,20,147,.08)', border: '1px solid rgba(255,20,147,.2)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌅</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--pink)', fontSize: 14, marginBottom: 2 }}>Morning Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Upon awakening</div>
        </button>
        <button onClick={() => setPractice('evening')} style={{ background: 'rgba(25,229,94,.06)', border: '1px solid rgba(25,229,94,.15)', borderRadius: 10, padding: '20px 12px', textAlign: 'center', cursor: 'pointer' }}>
          <div style={{ fontSize: 30, marginBottom: 8 }}>🌙</div>
          <div style={{ fontFamily: 'var(--font-ui)', fontWeight: 600, color: 'var(--lime)', fontSize: 14, marginBottom: 2 }}>Evening Practice</div>
          <div style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)' }}>Before sleep</div>
        </button>
      </div>

      <p className="section-label">My Progress</p>
      <div className="kpi-grid" style={{ marginBottom: 28 }}>
        {[
          { val:`${Math.round(myStats.today_pct||0)}%`,   label:'Today' },
          { val:`${Math.round(myStats.month_pct||0)}%`,   label:'This Month' },
          { val:`${Math.round(myStats.overall_pct||0)}%`, label:'Overall' },
          { val:`${myStats.days_active||0}/365`,           label:'Days Active' },
          { val: myResponses,                              label:'Responses Saved', green: true },
        ].map(s => <div key={s.label} className="kpi-cell"><div className={`kpi-value${s.green?' green':''}`}>{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>

      <p className="section-label">Our Community</p>
      <div className="kpi-grid" style={{ marginBottom: 8 }}>
        {[
          { val:kpi.total_members||0,                               label:'Members' },
          { val:`${Math.round(kpi.community_completion_pct||0)}%`,  label:'Avg Completion' },
          { val:kpi.active_today||0,                                label:'Active Today' },
          { val:kpi.total_days_completed||0,                        label:'Days Completed' },
          { val: commResponses,                                     label:'Responses Saved', green: true },
        ].map(s => <div key={s.label} className="kpi-cell"><div className={`kpi-value green`}>{s.val}</div><div className="kpi-label">{s.label}</div></div>)}
      </div>
      <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.3)', fontStyle:'italic', marginBottom:28 }}>The company you keep is showing up. 🌈</p>

      {/* Disclaimer */}
      <div style={{ borderTop:'1px solid rgba(255,255,255,.06)', paddingTop:20, marginBottom:8 }}>
        <p style={{ fontSize:11, color:'rgba(251,250,244,.2)', fontFamily:'var(--font-ui)', lineHeight:1.7, textAlign:'center' }}>
          YRTCYK — You aRe The Company You Keep — has always been associated exclusively with Your Fairy Godfather and GPV Consulting, LLC. In the spirit of AA&apos;s Tradition Six, we are not affiliated with, endorsed by, or representative of Alcoholics Anonymous or any AA group. The 12 Steps and 12 Traditions belong to AA World Services, Inc. We practice them with gratitude and respect their integrity.
        </p>
      </div>
    </div>
  )
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function SectionBlock({ emoji, title, children }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 12, paddingBottom: 8, borderBottom: '1px solid rgba(255,255,255,.06)' }}>
        <span style={{ fontSize: 18 }}>{emoji}</span>
        <h2 style={{ fontSize: 15, fontWeight: 600, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.85)' }}>{title}</h2>
      </div>
      {children}
    </div>
  )
}

function RichText({ text }) {
  if (!text) return null
  const cleaned = text
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*\*/g, '')
    .replace(/\\\s*\n/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/\\/g, '')
    .trim()
  const lines = cleaned.split('\n')
  return (
    <div style={{ fontSize: 14, lineHeight: 1.85, color: 'rgba(251,250,244,.78)' }}>
      {lines.map((line, i) => {
        const t = line.trim()
        if (!t) return <div key={i} style={{ height: 6 }}/>
        if (t.startsWith('•') || t.startsWith('- ') || t.startsWith('* ')) {
          return <div key={i} style={{ paddingLeft: 16, marginBottom: 4 }}>{t.replace(/^[-•*]\s+/, '')}</div>
        }
        return <p key={i} style={{ marginBottom: 6 }}>{t}</p>
      })}
    </div>
  )
}

// Single Notes text box — used for sections 4, 5, 6, 11, 12
function NotesBox({ section, itemKey, value, onSave, saving }) {
  const [local, setLocal] = useState(value)
  useEffect(() => setLocal(value), [value])
  return (
    <div style={{ marginTop: 12 }}>
      <p style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)', letterSpacing: 1, marginBottom: 6 }}>NOTES</p>
      <textarea rows={3} value={local} onChange={e => setLocal(e.target.value)}
        style={{ resize: 'vertical', marginBottom: 8 }}
        placeholder="Write your response here…"/>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button className="btn-primary" style={{ fontSize: 12, padding: '7px 14px' }}
          onClick={() => onSave(section, itemKey, 'text', local)} disabled={saving}>
          {saving ? 'Saving…' : value ? 'Update' : 'Save'}
        </button>
        {value && <span style={{ fontSize: 11, color: 'var(--lime)', fontFamily: 'var(--font-ui)' }}>✓ Saved</span>}
      </div>
    </div>
  )
}

function CheckRow({ label, section, itemKey, checked, onSave, saving }) {
  return (
    <div className="card" style={{ marginBottom: 10, marginTop: 10 }}>
      <label className="check-row">
        <input type="checkbox" checked={checked}
          onChange={e => onSave(section, itemKey, 'checkbox', e.target.checked)}
          style={{ width: 18, height: 18, accentColor: 'var(--pink)', flexShrink: 0 }} />
        <span className={`check-label${checked ? ' done' : ''}`}>{label}</span>
        {saving && <span style={{ fontSize: 11, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginLeft: 'auto' }}>…</span>}
      </label>
    </div>
  )
}

// ─── Practice View ────────────────────────────────────────────────────────────

function PracticeView({ period, dayNum, dayContent: dc, memberId, isChecked, textVal, isSaving, save, actions, onBack, onSwitchPeriod, reloadActions }) {
  const isMorning = period === 'morning'

  useEffect(() => { reloadActions() }, [])

  // Scoring — checkboxes only
  const dailyKeys  = [['pattern','completed'],['opposite_action','completed'],['prayer','completed'],['act_of_service','completed'],['bonus_challenge','completed']]
  const morningKeys = [['morning_practice','completed'],['grounding','breathing'],['grounding','grounding'],['affirmation','spoken'],['meditation','completed']]
  const eveningKeys = [['evening_practice','completed'],['step10','completed'],['visualization','completed'],['gratitude','completed']]

  const checkKeys = isMorning ? [...dailyKeys, ...morningKeys] : eveningKeys
  const totalItems = checkKeys.length
  const doneItems  = checkKeys.filter(([s,k]) => isChecked(s,k)).length
  const pct = totalItems > 0 ? Math.round(doneItems / totalItems * 100) : 0

  // Engagement: count saved text responses for today
  const commentsToday = Object.values(actions).filter(a => a.item_type === 'text' && a.text_value?.trim()).length

  return (
    <div style={{ paddingTop: 20, paddingBottom: 48 }}>
      <button onClick={onBack} style={{ color:'rgba(251,250,244,.45)', fontSize:13, fontFamily:'var(--font-ui)', marginBottom:20 }}>← Back</button>

      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', marginBottom:20 }}>
        <h2 style={{ fontSize:20, fontWeight:400 }}>{isMorning ? '🌅 Morning Practice' : '🌙 Evening Practice'}</h2>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:22, fontWeight:700, fontFamily:'var(--font-ui)', color:pct===100?'var(--lime)':'var(--pink)' }}>{pct}%</div>
          <div style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)' }}>{doneItems}/{totalItems}</div>
        </div>
      </div>

      {/* Day header */}
      {dc && (
        <div className="card" style={{ marginBottom:24, background:'rgba(255,20,147,.04)', border:'1px solid rgba(255,20,147,.1)' }}>
          <p className="section-label">Day {dayNum}</p>
          <h3 style={{ fontSize:18, fontWeight:400, marginBottom:6 }}>{dc.title}</h3>
          {dc.spiritual_principle && <p style={{ fontSize:12, color:'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom: dc.pattern ? 8 : 0 }}>{dc.spiritual_principle}</p>}
          {dc.pattern && <p style={{ fontSize:13, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>Pattern: {dc.pattern}</p>}
        </div>
      )}

      {/* ── MORNING VIEW ── */}
      {isMorning && dc && <>

        {/* Sources — read only */}
        {(dc.source_big_book || dc.source_twelve_twelve || dc.source_drop_rock || dc.source_ripple_effect) && (
          <SectionBlock emoji="📚" title="Today's Sources">
            {dc.source_big_book      && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📖 BIG BOOK</p><RichText text={dc.source_big_book}/></div>}
            {dc.source_twelve_twelve && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📗 TWELVE STEPS & TRADITIONS</p><RichText text={dc.source_twelve_twelve}/></div>}
            {dc.source_drop_rock     && <div style={{ marginBottom:12 }}><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📘 DROP THE ROCK</p><RichText text={dc.source_drop_rock}/></div>}
            {dc.source_ripple_effect && <div><p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', letterSpacing:1, marginBottom:4 }}>📙 RIPPLE EFFECT</p><RichText text={dc.source_ripple_effect}/></div>}
          </SectionBlock>
        )}

        {/* 1. Pattern — read + checkbox */}
        {dc.pattern_detail && (
          <SectionBlock emoji="💙" title="Today's Pattern">
            <RichText text={dc.pattern_detail}/>
            <NotesBox section="pattern" itemKey="notes"
              value={textVal('pattern','notes')} onSave={save} saving={isSaving('pattern','notes')}/>
            <CheckRow label="Completed — Today's Pattern (1)" section="pattern" itemKey="completed"
              checked={isChecked('pattern','completed')} onSave={save} saving={isSaving('pattern','completed')}/>
          </SectionBlock>
        )}

        {/* 2. Opposite Action — read + checkbox */}
        {dc.opposite_action && (
          <SectionBlock emoji="🟩" title="Opposite Action">
            <RichText text={dc.opposite_action}/>
            <NotesBox section="opposite_action" itemKey="notes"
              value={textVal('opposite_action','notes')} onSave={save} saving={isSaving('opposite_action','notes')}/>
            <CheckRow label="Completed — Opposite Action (2)" section="opposite_action" itemKey="completed"
              checked={isChecked('opposite_action','completed')} onSave={save} saving={isSaving('opposite_action','completed')}/>
          </SectionBlock>
        )}

        {/* 3. Prayer of the Day — read + checkbox */}
        {dc.step7_prayer && (
          <SectionBlock emoji="💛" title="Prayer of the Day">
            <div style={{ background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.1)', borderRadius:8, padding:16, marginBottom:4 }}>
              <RichText text={dc.step7_prayer}/>
            </div>
            <NotesBox section="prayer" itemKey="notes"
              value={textVal('prayer','notes')} onSave={save} saving={isSaving('prayer','notes')}/>
            <CheckRow label="Said my prayer today (3)" section="prayer" itemKey="completed"
              checked={isChecked('prayer','completed')} onSave={save} saving={isSaving('prayer','completed')}/>
          </SectionBlock>
        )}

        {/* 4. Act of Service — read + notes box + checkbox */}
        {dc.act_of_service && (
          <SectionBlock emoji="🌟" title="Act of Service">
            <RichText text={dc.act_of_service}/>
            <NotesBox section="act_of_service" itemKey="notes"
              value={textVal('act_of_service','notes')} onSave={save} saving={isSaving('act_of_service','notes')}/>
            <CheckRow label="Completed act of service (4)" section="act_of_service" itemKey="completed"
              checked={isChecked('act_of_service','completed')} onSave={save} saving={isSaving('act_of_service','completed')}/>
          </SectionBlock>
        )}

        {/* 5. Bonus Challenge — read + notes box + checkbox */}
        {dc.bonus_challenge && (
          <SectionBlock emoji="🎯" title="Bonus Challenge">
            <RichText text={dc.bonus_challenge}/>
            <NotesBox section="bonus_challenge" itemKey="notes"
              value={textVal('bonus_challenge','notes')} onSave={save} saving={isSaving('bonus_challenge','notes')}/>
            <CheckRow label="Completed bonus challenge (5)" section="bonus_challenge" itemKey="completed"
              checked={isChecked('bonus_challenge','completed')} onSave={save} saving={isSaving('bonus_challenge','completed')}/>
          </SectionBlock>
        )}

        {/* 6. Morning Practice — questions displayed as text + notes box + checkbox */}
        <SectionBlock emoji="🌅" title="Morning Practice">
          {(dc.morning_questions||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.morning_questions||[]).map((q, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {q.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          {dc.morning_intention && (
            <div className="card" style={{ marginBottom:8, background:'rgba(255,255,255,.03)', border:'1px solid rgba(255,255,255,.06)' }}>
              <p style={{ fontSize:12, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', letterSpacing:.5, marginBottom:6 }}>INTENTION</p>
              <p style={{ fontSize:14, fontStyle:'italic', color:'rgba(251,250,244,.7)', lineHeight:1.7 }}>"{dc.morning_intention}"</p>
            </div>
          )}
          <NotesBox section="morning_practice" itemKey="notes"
            value={textVal('morning_practice','notes')} onSave={save} saving={isSaving('morning_practice','notes')}/>
          <CheckRow label="Morning practice completed (6)" section="morning_practice" itemKey="completed"
            checked={isChecked('morning_practice','completed')} onSave={save} saving={isSaving('morning_practice','completed')}/>
        </SectionBlock>

        {/* 7. Breathing — read + checkbox */}
        {dc.breathing && (
          <SectionBlock emoji="🌬" title="Breathing Practice">
            <RichText text={dc.breathing}/>
            <NotesBox section="grounding" itemKey="breathing_notes"
              value={textVal('grounding','breathing_notes')} onSave={save} saving={isSaving('grounding','breathing_notes')}/>
            <CheckRow label="Completed breathing exercise (7)" section="grounding" itemKey="breathing"
              checked={isChecked('grounding','breathing')} onSave={save} saving={isSaving('grounding','breathing')}/>
          </SectionBlock>
        )}

        {/* 8. Grounding — read + checkbox */}
        {dc.grounding && (
          <SectionBlock emoji="🌳" title="Grounding Statement">
            <RichText text={dc.grounding}/>
            <NotesBox section="grounding" itemKey="grounding_notes"
              value={textVal('grounding','grounding_notes')} onSave={save} saving={isSaving('grounding','grounding_notes')}/>
            <CheckRow label="Completed grounding exercise (8)" section="grounding" itemKey="grounding"
              checked={isChecked('grounding','grounding')} onSave={save} saving={isSaving('grounding','grounding')}/>
          </SectionBlock>
        )}

        {/* 9. Affirmation — read + checkbox */}
        {dc.affirmation && (
          <SectionBlock emoji="🌈" title="Affirmation of the Day">
            <div style={{ textAlign:'center', padding:'12px 16px', background:'rgba(255,20,147,.06)', border:'1px solid rgba(255,20,147,.12)', borderRadius:8, marginBottom:4 }}>
              <p style={{ fontSize:17, fontStyle:'italic', color:'var(--pink)', lineHeight:1.65 }}>"{dc.affirmation}"</p>
            </div>
            <NotesBox section="affirmation" itemKey="notes"
              value={textVal('affirmation','notes')} onSave={save} saving={isSaving('affirmation','notes')}/>
            <CheckRow label="Spoke this affirmation aloud (9)" section="affirmation" itemKey="spoken"
              checked={isChecked('affirmation','spoken')} onSave={save} saving={isSaving('affirmation','spoken')}/>
          </SectionBlock>
        )}

        {/* 10. Meditation — read + checkbox */}
        {dc.meditation && (
          <SectionBlock emoji="🙏" title="Short Meditation">
            <RichText text={dc.meditation}/>
            <NotesBox section="meditation" itemKey="notes"
              value={textVal('meditation','notes')} onSave={save} saving={isSaving('meditation','notes')}/>
            <CheckRow label="Completed meditation (10)" section="meditation" itemKey="completed"
              checked={isChecked('meditation','completed')} onSave={save} saving={isSaving('meditation','completed')}/>
          </SectionBlock>
        )}

      </>}

      {/* ── EVENING VIEW ── */}
      {!isMorning && dc && <>

        {/* 11. Evening Practice — questions as text + notes box + checkbox */}
        <SectionBlock emoji="✏️" title="Evening Practice">
          {(dc.evening_questions||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.evening_questions||[]).map((q, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {q.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          <NotesBox section="evening_practice" itemKey="notes"
            value={textVal('evening_practice','notes')} onSave={save} saving={isSaving('evening_practice','notes')}/>
          <CheckRow label="Evening practice completed (11)" section="evening_practice" itemKey="completed"
            checked={isChecked('evening_practice','completed')} onSave={save} saving={isSaving('evening_practice','completed')}/>
        </SectionBlock>

        {/* 12. Step 10 Mini-Inventory — items as text + notes box + ONE checkbox */}
        <SectionBlock emoji="📘" title="Step 10 Mini-Inventory">
          {(dc.step10_items||[]).length > 0 && (
            <div style={{ marginBottom:12 }}>
              {(dc.step10_items||[]).map((item, i) => (
                <p key={i} style={{ fontSize:14, color:'rgba(251,250,244,.78)', lineHeight:1.85, marginBottom:8 }}>
                  {item.replace(/\*\*/g,'').replace(/\\/g,'')}
                </p>
              ))}
            </div>
          )}
          <NotesBox section="step10" itemKey="notes"
            value={textVal('step10','notes')} onSave={save} saving={isSaving('step10','notes')}/>
          <CheckRow label="Step 10 inventory complete (12)" section="step10" itemKey="completed"
            checked={isChecked('step10','completed')} onSave={save} saving={isSaving('step10','completed')}/>
        </SectionBlock>

        {/* 13. Visualization — read + checkbox */}
        {dc.visualization && (
          <SectionBlock emoji="✨" title="Visualization">
            <RichText text={dc.visualization}/>
            <NotesBox section="visualization" itemKey="notes"
              value={textVal('visualization','notes')} onSave={save} saving={isSaving('visualization','notes')}/>
            <CheckRow label="Completed visualization (13)" section="visualization" itemKey="completed"
              checked={isChecked('visualization','completed')} onSave={save} saving={isSaving('visualization','completed')}/>
          </SectionBlock>
        )}

        {/* 14. Gratitude — read + checkbox only */}
        {dc.gratitude && (
          <SectionBlock emoji="🧡" title="Gratitude for Today">
            <RichText text={dc.gratitude}/>
            <NotesBox section="gratitude" itemKey="notes"
              value={textVal('gratitude','notes')} onSave={save} saving={isSaving('gratitude','notes')}/>
            <CheckRow label="Gratitude completed (14)" section="gratitude" itemKey="completed"
              checked={isChecked('gratitude','completed')} onSave={save} saving={isSaving('gratitude','completed')}/>
          </SectionBlock>
        )}


      </>}

      {/* Attestation Score Panel */}
      <AttestationPanel dc={dc} isChecked={isChecked} textVal={textVal}
        isMorning={isMorning} onBack={onBack} onSwitchPeriod={onSwitchPeriod}
        commentsToday={commentsToday}/>
    </div>
  )
}

// ─── Attestation Score Panel ──────────────────────────────────────────────────

function AttestationPanel({ dc, isChecked, textVal, isMorning, onBack, onSwitchPeriod, commentsToday }) {
  // Daily score: sections 1-5 checkboxes
  const dailyDone  = [
    isChecked('pattern','completed'),
    isChecked('opposite_action','completed'),
    isChecked('prayer','completed'),
    isChecked('act_of_service','completed'),
    isChecked('bonus_challenge','completed'),
  ].filter(Boolean).length
  const dailyTotal = 5

  // Morning score: sections 6-10 checkboxes
  const morningDone  = [
    isChecked('morning_practice','completed'),
    isChecked('grounding','breathing'),
    isChecked('grounding','grounding'),
    isChecked('affirmation','spoken'),
    isChecked('meditation','completed'),
  ].filter(Boolean).length
  const morningTotal = 5

  // Evening score: sections 11-14 checkboxes
  const eveningDone  = [
    isChecked('evening_practice','completed'),
    isChecked('step10','completed'),
    isChecked('visualization','completed'),
    isChecked('gratitude','completed'),
  ].filter(Boolean).length
  const eveningTotal = 4

  const totalAll = dailyTotal + morningTotal + eveningTotal
  const doneAll  = dailyDone + morningDone + eveningDone
  const pct      = Math.round(doneAll / totalAll * 100)
  const complete = pct === 100

  return (
    <div style={{ marginTop:24, marginBottom:16 }}>
      <div style={{
        background: complete ? 'rgba(25,229,94,.08)' : 'rgba(255,20,147,.04)',
        border: `1px solid ${complete ? 'rgba(25,229,94,.2)' : 'rgba(255,20,147,.15)'}`,
        borderRadius:12, padding:20
      }}>
        <p style={{ fontSize:11, color:complete?'var(--lime)':'var(--pink)', fontFamily:'var(--font-ui)', letterSpacing:1.5, textAlign:'center', marginBottom:16 }}>
          ✓ DAILY ATTESTATION — Contract with My HP & I
        </p>

        {/* 4 score boxes: Daily, Morning, Evening, Comments */}
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr 1fr', gap:8, marginBottom:16 }}>
          {[
            { label:'Daily',    done:dailyDone,   total:dailyTotal,   sub:'checks 1–5'   },
            { label:'Morning',  done:morningDone, total:morningTotal, sub:'checks 6–10'  },
            { label:'Evening',  done:isMorning?null:eveningDone, total:isMorning?null:eveningTotal, sub:'checks 11–14' },
            { label:'Responses', done:commentsToday, total:null, sub:'saved today', isComments:true },
          ].map(({ label, done, total, sub, isComments }) => (
            <div key={label} style={{ textAlign:'center', padding:'10px 6px', background:'rgba(0,0,0,.2)', borderRadius:8 }}>
              <p style={{ fontSize:16, fontWeight:700, fontFamily:'var(--font-ui)',
                color: isComments ? 'var(--lime)' : (done!==null&&done===total)?'var(--lime)':'var(--pink)',
                marginBottom:2 }}>
                {done !== null ? (total !== null ? `${done}/${total}` : done) : '—'}
              </p>
              <p style={{ fontSize:11, color:'rgba(251,250,244,.5)', fontFamily:'var(--font-ui)' }}>{label}</p>
              <p style={{ fontSize:9, color:'rgba(251,250,244,.25)', fontFamily:'var(--font-ui)' }}>{sub}</p>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        <div style={{ height:6, borderRadius:3, background:'rgba(255,255,255,.1)', marginBottom:12, overflow:'hidden' }}>
          <div style={{ height:'100%', width:`${pct}%`, borderRadius:3, background:complete?'var(--lime)':'var(--pink)', transition:'width .4s ease' }}/>
        </div>

        <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.45)', fontFamily:'var(--font-ui)', marginBottom:4 }}>
          Today's Total Completion
        </p>
        <p style={{ textAlign:'center', fontSize:26, fontWeight:700, fontFamily:'var(--font-ui)', color:complete?'var(--lime)':'var(--pink)', marginBottom:4 }}>
          {pct}%
        </p>

        {isMorning && !complete && (
          <p style={{ textAlign:'center', fontSize:11, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)', fontStyle:'italic' }}>
            Evening practice updates when you complete it tonight
          </p>
        )}
        {complete && (
          <p style={{ textAlign:'center', fontSize:13, color:'rgba(251,250,244,.6)', fontFamily:'var(--font-ui)', fontStyle:'italic', marginTop:8, lineHeight:1.6 }}>
            "We are not a glum lot. We absolutely insist on enjoying life." 🌈
          </p>
        )}
      </div>

      {/* Nav buttons */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12, marginTop:16 }}>
        <button onClick={onBack}
          style={{ padding:'14px', borderRadius:10, background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.15)', color:'rgba(251,250,244,.7)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
          Dashboard
        </button>
        {isMorning ? (
          <button onClick={() => onSwitchPeriod('evening')}
            style={{ padding:'14px', borderRadius:10, background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)', color:'var(--lime)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
            Evening →
          </button>
        ) : (
          <button onClick={() => onSwitchPeriod('morning')}
            style={{ padding:'14px', borderRadius:10, background:'rgba(255,20,147,.08)', border:'1px solid rgba(255,20,147,.2)', color:'var(--pink)', fontFamily:'var(--font-ui)', fontSize:15, fontWeight:600, cursor:'pointer' }}>
            ← Morning
          </button>
        )}
      </div>
    </div>
  )
}
