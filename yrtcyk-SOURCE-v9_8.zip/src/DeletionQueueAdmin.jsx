// ========================================================================
// DeletionQueueAdmin.jsx — v9.7 (April 18, 2026)
//
// Admin view of GDPR deletion_requests table. Shows pending (with time
// remaining in grace period) and executed (audit trail). Admin can cancel
// a pending deletion on a member's behalf if they ask to reverse course.
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function DeletionQueueAdmin({ user }) {
  const [requests, setRequests] = useState([])
  const [loading, setLoading] = useState(true)
  const [msg, setMsg] = useState('')

  useEffect(() => { load() }, [])

  async function load() {
    setLoading(true)
    const { data } = await supabase.from('deletion_requests')
      .select('*')
      .order('requested_at', { ascending: false })
      .limit(50)
    setRequests(data || [])
    setLoading(false)
  }

  async function adminCancel(req) {
    setMsg('')
    const { error } = await supabase.rpc('cancel_account_deletion', {
      p_email: req.email,
      p_token: req.cancellation_token
    })
    if (error) { setMsg('Error: ' + error.message); return }
    setMsg(`Deletion cancelled for ${req.email}.`)
    await load()
    setTimeout(() => setMsg(''), 3000)
  }

  function remaining(iso) {
    const now = Date.now()
    const then = new Date(iso).getTime()
    const diff = then - now
    if (diff <= 0) return 'Due now'
    const days = Math.floor(diff / 86400000)
    const hours = Math.floor((diff % 86400000) / 3600000)
    if (days > 0) return `${days}d ${hours}h remaining`
    return `${hours}h remaining`
  }

  const pending = requests.filter(r => r.status === 'pending')
  const executed = requests.filter(r => r.status === 'executed')
  const cancelled = requests.filter(r => r.status === 'cancelled')

  return (
    <div>
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>DELETION REQUESTS · GDPR/CCPA</p>

      <p style={{ fontSize:12, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)',
        lineHeight:1.6, marginBottom:16 }}>
        Members can request account deletion from their Profile. A 7-day grace period
        allows them to reconsider. Deletion executes automatically at 3am PT daily.
      </p>

      {msg && <p style={{
        fontSize:12, fontFamily:'var(--font-ui)', marginBottom:12,
        color: msg.startsWith('Error') ? 'var(--pink)' : 'var(--lime)'
      }}>{msg}</p>}

      {loading && <div className="spinner"/>}

      {!loading && requests.length === 0 && (
        <div className="card" style={{ textAlign:'center', padding:30 }}>
          <p style={{ fontSize:24, marginBottom:8 }}>🗑️</p>
          <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:13 }}>
            No deletion requests on file.
          </p>
        </div>
      )}

      {pending.length > 0 && (
        <>
          <p style={{ fontSize:10, color:'var(--pink)', fontFamily:'var(--font-ui)',
            letterSpacing:1.5, marginBottom:10 }}>⏳ PENDING</p>
          {pending.map(r => (
            <div key={r.id} className="card" style={{ marginBottom:10 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start' }}>
                <div>
                  <p style={{ fontSize:13, fontWeight:500 }}>{r.email}</p>
                  <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
                    Requested {new Date(r.requested_at).toLocaleDateString('en-US', {
                      month:'short', day:'numeric', year:'numeric', hour:'numeric', minute:'2-digit'
                    })}
                  </p>
                  <p style={{ fontSize:11, color:'var(--pink)', fontFamily:'var(--font-ui)', marginTop:2 }}>
                    {remaining(r.scheduled_for)}
                  </p>
                </div>
                <button onClick={() => adminCancel(r)}
                  style={{
                    fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 12px', borderRadius:8,
                    background:'rgba(25,229,94,.1)', border:'1px solid rgba(25,229,94,.25)',
                    color:'var(--lime)'
                  }}>
                  Cancel
                </button>
              </div>
            </div>
          ))}
          <div style={{ height:16 }}/>
        </>
      )}

      {executed.length > 0 && (
        <>
          <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1.5, marginBottom:10 }}>✓ EXECUTED</p>
          {executed.slice(0, 10).map(r => (
            <div key={r.id} style={{
              display:'flex', justifyContent:'space-between', padding:'10px 0',
              borderBottom:'1px solid rgba(255,255,255,.04)', fontSize:12, fontFamily:'var(--font-ui)'
            }}>
              <span style={{ color:'rgba(251,250,244,.5)' }}>{r.email}</span>
              <span style={{ color:'rgba(251,250,244,.3)' }}>
                {new Date(r.executed_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
              </span>
            </div>
          ))}
          <div style={{ height:16 }}/>
        </>
      )}

      {cancelled.length > 0 && (
        <>
          <p style={{ fontSize:10, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
            letterSpacing:1.5, marginBottom:10 }}>✗ CANCELLED</p>
          {cancelled.slice(0, 10).map(r => (
            <div key={r.id} style={{
              display:'flex', justifyContent:'space-between', padding:'10px 0',
              borderBottom:'1px solid rgba(255,255,255,.04)', fontSize:12, fontFamily:'var(--font-ui)'
            }}>
              <span style={{ color:'rgba(251,250,244,.5)' }}>{r.email}</span>
              <span style={{ color:'rgba(251,250,244,.3)' }}>
                {new Date(r.cancelled_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
              </span>
            </div>
          ))}
        </>
      )}
    </div>
  )
}
