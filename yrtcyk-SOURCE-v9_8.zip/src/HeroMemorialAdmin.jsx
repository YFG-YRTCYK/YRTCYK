// ========================================================================
// HeroMemorialAdmin.jsx — v9.7 (April 18, 2026)
//
// Admin-only tool to mark a Hero as In Loving Memory. Shows all approved
// Heroes in a searchable list; clicking one opens an inline form to set
// life_status, date_of_birth, date_of_death, obituary_url, memorial_note.
//
// UX principle: RESTRAINT. No black armbands. No funeral aesthetic.
// The quiet cream italic variant on /heroes/ is the only public surface.
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function HeroMemorialAdmin() {
  const [heroes, setHeroes] = useState([])
  const [search, setSearch] = useState('')
  const [editing, setEditing] = useState(null)
  const [form, setForm] = useState({})
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  useEffect(() => { load() }, [])

  async function load() {
    const { data } = await supabase.from('hero_showcases')
      .select('id, hero_name, hero_type, member_display_name, life_status, date_of_birth, date_of_death, obituary_url, memorial_note, created_at')
      .eq('status', 'approved')
      .order('hero_name')
    setHeroes(data || [])
  }

  function openEditor(h) {
    setEditing(h.id)
    setForm({
      life_status: h.life_status || 'living',
      date_of_birth: h.date_of_birth || '',
      date_of_death: h.date_of_death || '',
      obituary_url: h.obituary_url || '',
      memorial_note: h.memorial_note || ''
    })
    setMsg('')
  }

  function closeEditor() {
    setEditing(null); setForm({}); setMsg('')
  }

  async function save(heroId) {
    if (form.life_status === 'in_memoriam' && !form.date_of_death) {
      setMsg('A date of passing is required to mark as In Loving Memory.')
      return
    }
    if (form.memorial_note && form.memorial_note.length > 280) {
      setMsg('Memorial note must be 280 characters or fewer.'); return
    }
    setSaving(true)
    const payload = {
      life_status: form.life_status,
      date_of_birth: form.date_of_birth || null,
      date_of_death: form.date_of_death || null,
      obituary_url: form.obituary_url?.trim() || null,
      memorial_note: form.memorial_note?.trim() || null
    }
    const { error } = await supabase.from('hero_showcases').update(payload).eq('id', heroId)
    setSaving(false)
    if (error) { setMsg('Error: ' + error.message); return }
    setMsg('Saved.')
    await load()
    setTimeout(() => closeEditor(), 900)
  }

  const filtered = heroes.filter(h => {
    if (!search) return true
    const q = search.toLowerCase()
    return (h.hero_name || '').toLowerCase().includes(q) ||
           (h.member_display_name || '').toLowerCase().includes(q)
  })

  const inMemoriam = filtered.filter(h => h.life_status === 'in_memoriam')
  const living = filtered.filter(h => h.life_status !== 'in_memoriam')

  return (
    <div>
      <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:12 }}>HERO MEMORIAL MANAGEMENT</p>

      <p style={{ fontSize:12, color:'rgba(251,250,244,.55)', fontFamily:'var(--font-ui)',
        lineHeight:1.6, marginBottom:16 }}>
        Use this with care. When a Hero passes, their work and honoring post <strong>remain visible</strong>.
        Marking them In Loving Memory adds a quiet inline tribute on their Hero page. Nothing is hidden or archived.
      </p>

      <input type="text" placeholder="Search Heroes by name…"
        value={search} onChange={e => setSearch(e.target.value)}
        style={{ marginBottom:16 }}/>

      {inMemoriam.length > 0 && (
        <>
          <p style={{ fontSize:10, color:'rgba(200,180,220,.55)', fontFamily:'var(--font-ui)',
            letterSpacing:1.5, marginBottom:10, fontStyle:'italic' }}>🕊️ IN LOVING MEMORY</p>
          {inMemoriam.map(h => renderHero(h))}
          <div style={{ height:16 }}/>
        </>
      )}

      <p style={{ fontSize:10, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)',
        letterSpacing:1.5, marginBottom:10 }}>🌟 LIVING HEROES</p>
      {living.map(h => renderHero(h))}
      {filtered.length === 0 && (
        <p style={{ fontSize:12, color:'rgba(251,250,244,.3)', fontFamily:'var(--font-ui)',
          textAlign:'center', padding:20 }}>No matching heroes.</p>
      )}
    </div>
  )

  function renderHero(h) {
    const isEditing = editing === h.id
    const isMemoriam = h.life_status === 'in_memoriam'
    return (
      <div key={h.id} className="card" style={{
        marginBottom:10,
        background: isMemoriam ? 'rgba(200,180,220,.05)' : 'var(--card-bg)',
        border: isMemoriam ? '1px solid rgba(200,180,220,.25)' : '1px solid var(--border)'
      }}>
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'flex-start', gap:8 }}>
          <div>
            <p style={{ fontSize:14, fontWeight:500 }}>
              {isMemoriam && <span style={{ marginRight:6 }}>🕊️</span>}
              {h.hero_name}
            </p>
            <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)' }}>
              Honored by {h.member_display_name || 'A member'}
            </p>
            {isMemoriam && h.date_of_death && (
              <p style={{ fontSize:11, color:'rgba(200,180,220,.7)', fontFamily:'var(--font-ui)',
                fontStyle:'italic', marginTop:4 }}>
                {h.date_of_birth ? new Date(h.date_of_birth + 'T00:00:00').toLocaleDateString('en-US', { year:'numeric' }) : '?'}
                {' — '}
                {new Date(h.date_of_death + 'T00:00:00').toLocaleDateString('en-US', { month:'long', year:'numeric' })}
              </p>
            )}
          </div>
          {!isEditing && (
            <button onClick={() => openEditor(h)}
              style={{
                fontSize:11, fontFamily:'var(--font-ui)', padding:'5px 12px', borderRadius:8,
                background:'rgba(255,255,255,.07)', border:'1px solid rgba(255,255,255,.12)',
                color:'rgba(251,250,244,.65)'
              }}>
              {isMemoriam ? 'Edit memorial' : 'Mark as memorial'}
            </button>
          )}
        </div>
        {isEditing && (
          <div style={{ marginTop:14, paddingTop:14, borderTop:'1px solid rgba(255,255,255,.05)' }}>
            <div style={{ marginBottom:10 }}>
              <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                letterSpacing:1.2, marginBottom:6 }}>STATUS</p>
              <div style={{ display:'flex', gap:8 }}>
                {['living', 'in_memoriam'].map(s => (
                  <button key={s} onClick={() => setForm(f => ({ ...f, life_status: s }))}
                    style={{
                      flex:1, padding:'8px', borderRadius:8, fontSize:12, fontFamily:'var(--font-ui)',
                      background: form.life_status === s ? 'rgba(255,20,147,.18)' : 'rgba(255,255,255,.06)',
                      color: form.life_status === s ? 'var(--pink)' : 'rgba(251,250,244,.6)',
                      border: `1px solid ${form.life_status === s ? 'rgba(255,20,147,.35)' : 'rgba(255,255,255,.1)'}`
                    }}>
                    {s === 'living' ? '🌟 Living' : '🕊️ In Loving Memory'}
                  </button>
                ))}
              </div>
            </div>

            {form.life_status === 'in_memoriam' && (
              <>
                <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:10 }}>
                  <div>
                    <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      letterSpacing:1.2, marginBottom:6 }}>DATE OF BIRTH</p>
                    <input type="date" value={form.date_of_birth || ''}
                      onChange={e => setForm(f => ({ ...f, date_of_birth: e.target.value }))}/>
                  </div>
                  <div>
                    <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                      letterSpacing:1.2, marginBottom:6 }}>DATE OF PASSING *</p>
                    <input type="date" value={form.date_of_death || ''}
                      onChange={e => setForm(f => ({ ...f, date_of_death: e.target.value }))}/>
                  </div>
                </div>

                <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                  letterSpacing:1.2, marginBottom:6 }}>OBITUARY LINK (OPTIONAL)</p>
                <input type="url" placeholder="https://…" value={form.obituary_url || ''}
                  onChange={e => setForm(f => ({ ...f, obituary_url: e.target.value }))}
                  style={{ marginBottom:10 }}/>

                <p style={{ fontSize:10, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)',
                  letterSpacing:1.2, marginBottom:6 }}>
                  MEMORIAL NOTE (OPTIONAL · {(form.memorial_note || '').length}/280)
                </p>
                <textarea rows={3} maxLength={280} value={form.memorial_note || ''}
                  onChange={e => setForm(f => ({ ...f, memorial_note: e.target.value }))}
                  placeholder="A quiet tribute — shared with the care the person would have wanted."
                  style={{ resize:'none', marginBottom:10 }}/>
              </>
            )}

            {msg && <p style={{
              fontSize:12, fontFamily:'var(--font-ui)', marginBottom:10,
              color: msg.startsWith('Error') || msg.includes('required') ? 'var(--pink)' : 'var(--lime)'
            }}>{msg}</p>}

            <div style={{ display:'flex', gap:8 }}>
              <button onClick={() => save(h.id)} disabled={saving}
                style={{
                  flex:1, padding:'9px', borderRadius:8, fontSize:13, fontFamily:'var(--font-ui)',
                  background:'var(--pink)', color:'#fff', fontWeight:600
                }}>
                {saving ? 'Saving…' : 'Save'}
              </button>
              <button onClick={closeEditor} disabled={saving}
                style={{
                  padding:'9px 16px', borderRadius:8, fontSize:13, fontFamily:'var(--font-ui)',
                  background:'rgba(255,255,255,.05)', border:'1px solid var(--border)',
                  color:'rgba(251,250,244,.6)'
                }}>
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    )
  }
}
