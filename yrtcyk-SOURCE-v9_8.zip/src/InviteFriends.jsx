import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function InviteFriends({ user }) {
  const [member, setMember]   = useState(null)
  const [code, setCode]       = useState('')
  const [referrals, setReferrals] = useState([])
  const [copied, setCopied]   = useState(false)

  useEffect(() => { load() }, [])

  async function load() {
    const { data: m } = await supabase.from('members').select('id').eq('email', user.email).single()
    if (!m) return
    setMember(m)
    // v18 uses referral_codes table
    const { data: rc } = await supabase.from('referral_codes').select('code').eq('member_id', m.id).single()
    if (rc) setCode(rc.code)
    const { data: r } = await supabase.from('referrals').select('*').eq('referrer_id', m.id).order('created_at', { ascending: false })
    setReferrals(r || [])
  }

  const link = code ? `https://yourfairygodfather.com/join?ref=${code}` : ''
  const emailBody = encodeURIComponent(`Hey,\n\nI've been using YRTCYK — "You aRe The Company You Keep" — a private LGBTQ+ affirming recovery community built around the 12 Steps.\n\nEvery day there's a morning and evening practice — about 15 minutes total. It keeps me connected and accountable.\n\nYour first month is completely free:\n${link}\n\nCome keep me company. 🪄`)

  function copy() {
    if (!link) return
    navigator.clipboard.writeText(link)
    setCopied(true); setTimeout(() => setCopied(false), 2500)
  }

  const joined     = referrals.filter(r => r.status !== 'invited').length
  const freeMonths = referrals.filter(r => r.status === 'rewarded').length

  return (
    <div style={{ paddingTop: 20, paddingBottom: 40 }}>
      <h2 style={{ fontSize: 22, fontWeight: 400, marginBottom: 8 }}>🌈 Widen the Circle</h2>
      <p style={{ fontSize: 14, color: 'rgba(251,250,244,.6)', lineHeight: 1.75, marginBottom: 24, fontFamily: 'var(--font-ui)' }}>
        Share your personal link. Your friend gets their <span style={{ color: 'var(--pink)', fontStyle: 'italic' }}>first month free</span>. After they complete 2 paying months, you earn a free month. That's the company we keep.
      </p>

      {/* Link box */}
      <div className="card" style={{ marginBottom: 20, border: '1px solid rgba(255,20,147,.2)', background: 'rgba(255,20,147,.04)' }}>
        <p className="section-label" style={{ color: 'var(--pink)', marginBottom: 10 }}>Your Invite Link</p>
        <div style={{ display: 'flex', gap: 8 }}>
          <input value={link || 'Loading…'} readOnly style={{ fontSize: 13, background: 'rgba(255,255,255,.06)', color: link ? 'var(--cream)' : 'rgba(251,250,244,.3)' }}/>
          <button className="btn-primary" onClick={copy} disabled={!link} style={{ whiteSpace: 'nowrap', padding: '10px 16px' }}>
            {copied ? '✓ Copied!' : 'Copy Link'}
          </button>
        </div>
        <p style={{ fontSize: 11, color: 'rgba(251,250,244,.35)', fontFamily: 'var(--font-ui)', marginTop: 8 }}>Anyone who clicks this link gets their first month free.</p>
      </div>

      {/* Share buttons */}
      {link && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 24 }}>
          <a href={`mailto:?subject=${encodeURIComponent('You should check this out')}&body=${emailBody}`}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(255,20,147,.1)', border: '1px solid rgba(255,20,147,.2)', color: 'var(--pink)', fontSize: 13, fontFamily: 'var(--font-ui)', textAlign: 'center', display: 'block' }}>
            ✉️ Email
          </a>
          <a href={`sms:?&body=${encodeURIComponent(`Join me in YRTCYK — first month free: ${link}`)}`}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(25,229,94,.08)', border: '1px solid rgba(25,229,94,.15)', color: 'var(--lime)', fontSize: 13, fontFamily: 'var(--font-ui)', textAlign: 'center', display: 'block' }}>
            💬 Text
          </a>
          <button onClick={() => navigator.share ? navigator.share({ url: link }) : copy()}
            style={{ flex: 1, padding: '10px', borderRadius: 8, background: 'rgba(255,255,255,.06)', border: '1px solid var(--border)', color: 'rgba(251,250,244,.6)', fontSize: 13, fontFamily: 'var(--font-ui)', cursor: 'pointer' }}>
            ↗ Share
          </button>
        </div>
      )}

      {/* Stats */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10, marginBottom: 24 }}>
        {[
          { val: referrals.length, label: 'Total Invited' },
          { val: joined,           label: 'Joined' },
          { val: freeMonths,       label: 'Free Months Earned' },
        ].map(s => (
          <div key={s.label} className="card" style={{ textAlign: 'center' }}>
            <div style={{ fontSize: 26, fontWeight: 700, color: 'var(--pink)', fontFamily: 'var(--font-ui)' }}>{s.val}</div>
            <div style={{ fontSize: 10, color: 'rgba(251,250,244,.4)', fontFamily: 'var(--font-ui)', marginTop: 3, textTransform: 'uppercase', letterSpacing: .5 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Referral history */}
      {referrals.length > 0 && (
        <div style={{ marginBottom: 24 }}>
          <p className="section-label" style={{ marginBottom: 12 }}>Your Referrals</p>
          {referrals.map(r => (
            <div key={r.id} className="card" style={{ marginBottom: 10, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)' }}>{r.referred_email || 'Member'}</p>
                <p style={{ fontSize: 11, color: 'rgba(251,250,244,.3)', fontFamily: 'var(--font-ui)', marginTop: 2 }}>{new Date(r.created_at).toLocaleDateString()}</p>
              </div>
              <span style={{ fontSize: 11, fontFamily: 'var(--font-ui)', padding: '3px 10px', borderRadius: 20, background: r.status === 'rewarded' ? 'rgba(25,229,94,.12)' : 'rgba(255,255,255,.06)', color: r.status === 'rewarded' ? 'var(--lime)' : 'rgba(251,250,244,.45)', border: '1px solid ' + (r.status === 'rewarded' ? 'rgba(25,229,94,.25)' : 'var(--border)') }}>
                {r.status === 'rewarded' ? '🎁 Rewarded' : r.status === 'month_2' ? 'Month 2 ✓' : r.status === 'month_1' ? 'Month 1 ✓' : r.status === 'joined' ? 'Joined ✓' : 'Invited'}
              </span>
            </div>
          ))}
        </div>
      )}

      {/* How it works */}
      <div style={{ marginTop: 8, background: 'rgba(255,255,255,0.04)', border: '1px solid var(--border)', borderRadius: 10, padding: 16 }}>
        <p className="section-label" style={{ marginBottom: 12 }}>How It Works</p>
        {[
          '1 Copy your link above and text or email it to someone.',
          '2 They click your link and get their first month free.',
          '3 After 2 paying months, you earn one free month.',
          "4 Your credit is applied automatically — next invoice $0.00, no coupon needed.",
        ].map((s, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start', marginBottom: i < 3 ? 10 : 0 }}>
            <div style={{ width: 22, height: 22, borderRadius: '50%', background: 'var(--pink)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 11, fontFamily: 'var(--font-ui)', fontWeight: 700, color: '#fff', flexShrink: 0, marginTop: 1 }}>{i+1}</div>
            <p style={{ fontSize: 13, fontFamily: 'var(--font-ui)', color: 'rgba(251,250,244,.65)', lineHeight: 1.6 }}>{s.slice(2)}</p>
          </div>
        ))}
      </div>

      <p style={{ textAlign: 'center', fontSize: 14, color: 'var(--pink)', fontStyle: 'italic', marginTop: 28 }}>You aRe The Company You Keep.</p>
    </div>
  )
}
