// ========================================================================
// MemberBadges.jsx — v9.7 (April 18, 2026)
//
// Renders the stack of status badges for a given member:
//   👑 Admin          — hardcoded to gvitrano@icloud.com
//   ✨ Trailblazer    — member.is_trailblazer = true (admin-assigned)
//   🌈 Founding       — member.member_number ≤ 100 (auto)
//   💜 Moderator      — member.is_moderator = true AND NOT admin
//   🕊️ In Loving Memory — member.membership_end_reason = 'deceased'
//
// Max visible = 3. Stacking priority: Admin → Trailblazer → Founding → Moderator.
// Moderator hidden when Admin shown (admin is implicitly a moderator).
// Memorial renders alongside — never replaces — other badges.
//
// Props:
//   member  — object with { email, is_trailblazer, is_moderator, member_number,
//                           membership_start_date, membership_end_reason }
//   size    — 'sm' | 'md' (default 'sm')
//   layout  — 'inline' | 'stack' (default 'inline')
// ========================================================================

export default function MemberBadges({ member, size = 'sm', layout = 'inline' }) {
  if (!member) return null

  const isAdmin       = member.email === 'gvitrano@icloud.com'
  const isTrailblazer = !!member.is_trailblazer
  const isFounding    = typeof member.member_number === 'number' && member.member_number >= 1 && member.member_number <= 100
  const isModerator   = !!member.is_moderator && !isAdmin
  const isDeceased    = member.membership_end_reason === 'deceased'

  const sinceDate = member.membership_start_date
    ? new Date(member.membership_start_date + 'T00:00:00')
        .toLocaleDateString('en-US', { month: 'long', year: 'numeric' })
    : null

  const px = size === 'md' ? 10 : 7
  const py = size === 'md' ? 4 : 2
  const fs = size === 'md' ? 12 : 10

  const base = {
    display:'inline-flex', alignItems:'center', gap:4,
    padding:`${py}px ${px}px`, borderRadius:20,
    fontSize:fs, fontFamily:'var(--font-ui)',
    fontWeight:600, lineHeight:1.2, whiteSpace:'nowrap',
    letterSpacing:0.2
  }

  const styles = {
    admin: { ...base,
      background:'rgba(200,120,255,.18)', color:'#d9a8ff',
      border:'1px solid rgba(200,120,255,.4)' },
    trailblazer: { ...base,
      fontSize: fs + 0.5,
      background:'linear-gradient(135deg, rgba(1,40,14,.95), rgba(25,229,94,.12))',
      color:'var(--cream)',
      border:'1px solid rgba(25,229,94,.55)',
      boxShadow:'0 0 8px rgba(25,229,94,.25), inset 0 0 6px rgba(25,229,94,.08)' },
    founding: { ...base,
      background:'linear-gradient(90deg, #ff6b9d 0%, #ffa06a 25%, #ffd86a 50%, #7bd6ff 75%, #c56bff 100%)',
      color:'#fff',
      border:'1px solid rgba(255,255,255,.25)',
      textShadow:'0 1px 2px rgba(0,0,0,.35)' },
    moderator: { ...base,
      background:'rgba(255,20,147,.16)', color:'var(--pink)',
      border:'1px solid rgba(255,20,147,.35)' },
    memoriam: { ...base,
      background:'rgba(251,250,244,.06)', color:'var(--cream)',
      border:'1px solid rgba(200,180,220,.35)',
      fontStyle:'italic', fontWeight:500 }
  }

  const wrap = {
    display: layout === 'stack' ? 'flex' : 'inline-flex',
    flexDirection: layout === 'stack' ? 'column' : 'row',
    flexWrap: layout === 'stack' ? 'nowrap' : 'wrap',
    alignItems: layout === 'stack' ? 'flex-start' : 'center',
    gap: 6
  }

  return (
    <span style={wrap}>
      {isAdmin && (
        <span style={styles.admin} title="Admin">👑 Admin</span>
      )}
      {isTrailblazer && (
        <span style={styles.trailblazer} title="Trailblazer — one of the original">
          ✨ Trailblazer{size === 'md' ? ' · One of the Original' : ''}
        </span>
      )}
      {isFounding && (
        <span style={styles.founding}
          title={`Founding Member #${member.member_number}${sinceDate ? ' · Since ' + sinceDate : ''}`}>
          🌈 Founding Member #{member.member_number}
          {size === 'md' && sinceDate ? ` · Since ${sinceDate}` : ''}
        </span>
      )}
      {isModerator && (
        <span style={styles.moderator} title="Moderator">
          💜 Moderator
        </span>
      )}
      {isDeceased && (
        <span style={styles.memoriam} title="In loving memory">
          🕊️ In Loving Memory
        </span>
      )}
    </span>
  )
}
