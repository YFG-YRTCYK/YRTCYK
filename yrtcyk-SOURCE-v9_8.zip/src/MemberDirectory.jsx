import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'
import MemberBadges from './MemberBadges'

const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December']
const PROGRAMS = ['AA','NA','Al-Anon','OA','SLAA','GA','SMART Recovery','Refuge Recovery','Other']
const DEFAULT_AVATAR = `data:image/svg+xml;utf8,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88" viewBox="0 0 88 88"><circle cx="44" cy="44" r="44" fill="#01280e"/><circle cx="44" cy="44" r="42" fill="none" stroke="#FF1493" stroke-width="2"/><text x="44" y="52" text-anchor="middle" font-family="Georgia,serif" font-size="28" font-weight="700" fill="#FF1493">YFG</text></svg>')}`

function sobrietyStats(dateStr) {
  if (!dateStr) return null
  const start = new Date(dateStr + 'T00:00:00')
  const diffMs = new Date() - start
  if (diffMs < 0) return null
  const days = Math.floor(diffMs / 86400000)
  const years = days / 365.25
  let label = ''
  if (days < 30) label = `${days} day${days!==1?'s':''}`
  else if (days < 365) label = `${Math.floor(days/30)} month${Math.floor(days/30)!==1?'s':''}`
  else { const y=Math.floor(years); const m=Math.floor((days-Math.floor(y*365.25))/30); label=`${y} yr${y!==1?'s':''}${m>0?` ${m} mo`:''}` }
  return { days, label }
}
function parseListLocal(val) {
  if (!val) return []
  if (Array.isArray(val)) return val
  try { const p=JSON.parse(val); if(Array.isArray(p)) return p } catch {}
  return val.split(',').map(s=>s.trim()).filter(Boolean)
}
function parsePetsLocal(val) {
  if (!val) return []
  try { const p=JSON.parse(val); if(Array.isArray(p)) return p.length===0?[]:typeof p[0]==='object'&&p[0].type?p:p.map(v=>({type:v,name:''})) } catch {}
  return []
}

export default function MemberDirectory({ user, isAdmin }) {
  const [members, setMembers]     = useState([])
  const [search, setSearch]       = useState('')
  const [selected, setSelected]   = useState(null)
  const [loading, setLoading]     = useState(true)
  const [showFilters, setShowFilters] = useState(false)

  // Filters
  const [filterType, setFilterType]     = useState('all')     // all | moderators
  const [filterProgram, setFilterProgram] = useState('')
  const [filterCity, setFilterCity]     = useState('')
  const [filterTimezone, setFilterTimezone] = useState('')
  const [filterBdayMonth, setFilterBdayMonth] = useState('')
  const [filterAnnivMonth, setFilterAnnivMonth] = useState('')

  useEffect(() => { load() }, [])

  async function load() {
    const { data } = await supabase
      .from('members')
      .select('id,display_name,first_name,last_name,show_full_name,show_email,email,avatar_url,city,timezone,pronouns,show_phone,phone,show_age,birth_date,is_moderator,is_trailblazer,member_number,membership_start_date,membership_end_reason,program_1,program_1_date,program_2,program_2_date,program_3,program_3_date,recovery_bio,sexual_orientation,gender_identity,ethnicity,spoken_languages,written_languages,pets,wellness_topics')
      .eq('is_active', true)
      .order('display_name')
    setMembers(data || [])
    setLoading(false)
  }

  // Build unique city and timezone lists from actual data
  const cities     = [...new Set(members.filter(m=>m.city&&m.show_location).map(m=>m.city))].sort()
  const timezones  = [...new Set(members.filter(m=>m.timezone).map(m=>m.timezone))].sort()

  const activeFilters = [filterProgram,filterCity,filterTimezone,filterBdayMonth,filterAnnivMonth].filter(Boolean).length

  const filtered = members.filter(m => {
    const q = (search||'').toLowerCase()
    if (q && !(m.display_name||m.email||'').toLowerCase().includes(q)) return false
    if (filterType==='moderators' && !m.is_moderator && !(isAdmin && m.email===user.email)) return false
    if (filterProgram && ![m.program_1,m.program_2,m.program_3].includes(filterProgram)) return false
    if (filterCity && m.city !== filterCity) return false
    if (filterTimezone && m.timezone !== filterTimezone) return false
    if (filterBdayMonth) {
      if (!m.birth_date || !m.show_birthday) return false
      const mo = new Date(m.birth_date+'T00:00:00').getMonth()
      if (String(mo) !== filterBdayMonth) return false
    }
    if (filterAnnivMonth) {
      const dates = [m.program_1_date,m.program_2_date,m.program_3_date].filter(Boolean)
      if (!dates.length) return false
      const matches = dates.some(d => String(new Date(d+'T00:00:00').getMonth()) === filterAnnivMonth)
      if (!matches) return false
    }
    return true
  })

  function clearFilters() {
    setFilterType('all'); setFilterProgram(''); setFilterCity('')
    setFilterTimezone(''); setFilterBdayMonth(''); setFilterAnnivMonth('')
  }

  const isAdmin_ = m => m.email === 'gvitrano@icloud.com'
  const isMe     = m => m.email === user.email

  function initials(m) {
    const n = m.display_name || m.email
    return n.split(' ').slice(0,2).map(w=>w[0]).join('').toUpperCase().slice(0,2)
  }
  function memberSince(m) {
    if (!m.membership_start_date) return ''
    return new Date(m.membership_start_date).toLocaleDateString('en-US',{month:'long',year:'numeric'})
  }
  function tzLabel(tz) {
    const map = {
      'America/Los_Angeles':'Pacific','America/Denver':'Mountain','America/Chicago':'Central',
      'America/New_York':'Eastern','America/Anchorage':'Alaska','Pacific/Honolulu':'Hawaii',
      'Europe/London':'London','Europe/Paris':'Central Europe','Asia/Tokyo':'Tokyo',
      'Australia/Sydney':'Sydney','UTC':'UTC'
    }
    return map[tz] || tz
  }

  // ── DETAIL VIEW ──
  if (selected) {
    const m = selected
    const programs = [1,2,3].filter(n=>m[`program_${n}`]).map(n=>({
      name: m[`program_${n}`], date: m[`program_${n}_date`], stats: sobrietyStats(m[`program_${n}_date`])
    }))
    const langs   = [...new Set([...parseListLocal(m.spoken_languages),...parseListLocal(m.written_languages)])]
    const pets    = parsePetsLocal(m.pets)
    const wellness = parseListLocal(m.wellness_topics)
    const avatarSrc = m.avatar_url || DEFAULT_AVATAR
    const age = m.show_age && m.birth_date ? Math.floor((new Date()-new Date(m.birth_date+'T00:00:00'))/(365.25*86400000)) : null

    return (
      <div style={{paddingTop:20,paddingBottom:40}}>
        <button onClick={()=>setSelected(null)} style={{color:'rgba(251,250,244,.45)',fontSize:13,fontFamily:'var(--font-ui)',marginBottom:24}}>← Back to Members</button>

        {/* Avatar + name */}
        <div style={{textAlign:'center',marginBottom:24}}>
          <div style={{width:84,height:84,borderRadius:'50%',border:'3px solid rgba(255,20,147,.3)',margin:'0 auto 14px',overflow:'hidden'}}>
            <img src={avatarSrc} alt="" style={{width:84,height:84,objectFit:'cover'}}/>
          </div>
          <h2 style={{fontSize:22,fontWeight:400,marginBottom:6}}>{m.display_name||m.email.split('@')[0]}</h2>
          {m.show_full_name&&m.first_name&&<p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom:4}}>{m.first_name} {m.last_name}</p>}
          <div style={{display:'flex',justifyContent:'center',gap:8,flexWrap:'wrap',marginBottom:8}}>
            <MemberBadges member={m} size="md"/>
            {isMe(m)&&<span style={{background:'rgba(25,229,94,.1)',border:'1px solid rgba(25,229,94,.22)',color:'var(--lime)',fontSize:10,fontFamily:'var(--font-ui)',fontWeight:700,padding:'2px 8px',borderRadius:20}}>You</span>}
          </div>
          {m.pronouns&&<p style={{fontSize:13,color:'rgba(251,250,244,.5)',fontFamily:'var(--font-ui)',marginBottom:4}}>{m.pronouns}</p>}
          {m.city&&<p style={{fontSize:13,color:'rgba(251,250,244,.45)',fontFamily:'var(--font-ui)',marginBottom:2}}>📍 {m.city}</p>}
          {m.timezone&&<p style={{fontSize:12,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginBottom:2}}>🕐 {m.timezone.split('/').pop().replace('_',' ')}</p>}
          {age!==null&&<p style={{fontSize:12,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)'}}>Age {age}</p>}
          {m.show_phone&&m.phone&&<p style={{fontSize:12,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:2}}>📱 {m.phone}</p>}
          {m.show_email&&m.email&&<p style={{fontSize:12,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',marginTop:2}}>✉️ {m.email}</p>}
        </div>

        {memberSince(m)&&<div className="card" style={{marginBottom:12,textAlign:'center',background:'rgba(255,20,147,.03)',border:'1px solid rgba(255,20,147,.1)'}}><p style={{fontSize:12,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>Member since {memberSince(m)}</p></div>}

        {/* Programs with sobriety stats */}
        {programs.length>0&&(
          <div className="card" style={{marginBottom:12}}>
            <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>RECOVERY</p>
            {programs.map((pg,i)=>(
              <div key={i} style={{padding:'12px',borderRadius:10,background:'rgba(25,229,94,.06)',border:'1px solid rgba(25,229,94,.15)',marginBottom:i<programs.length-1?8:0}}>
                <div style={{display:'flex',justifyContent:'space-between',alignItems:'flex-start'}}>
                  <span style={{fontSize:14,color:'rgba(251,250,244,.85)',fontWeight:600}}>{pg.name}</span>
                  {pg.stats&&<span style={{fontSize:13,color:'var(--lime)',fontFamily:'var(--font-ui)',fontWeight:700}}>{pg.stats.label}</span>}
                </div>
                {pg.stats&&(
                  <div style={{display:'flex',gap:16,marginTop:6}}>
                    <span style={{fontSize:11,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>{pg.stats.days.toLocaleString()} days</span>
                    {pg.date&&<span style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)'}}>Since {new Date(pg.date+'T00:00:00').toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</span>}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {m.recovery_bio&&<div className="card" style={{marginBottom:12}}><p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>ABOUT</p><p style={{fontSize:14,color:'rgba(251,250,244,.75)',lineHeight:1.8,fontStyle:'italic'}}>"{m.recovery_bio}"</p></div>}

        {(m.gender_identity||m.sexual_orientation||m.ethnicity)&&(
          <div className="card" style={{marginBottom:12}}>
            <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>IDENTITY</p>
            <div style={{display:'flex',flexWrap:'wrap',gap:8}}>
              {m.gender_identity&&<span style={{padding:'6px 14px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.2)',color:'rgba(251,250,244,.75)'}}>{m.gender_identity}</span>}
              {m.sexual_orientation&&<span style={{padding:'6px 14px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.2)',color:'rgba(251,250,244,.75)'}}>{m.sexual_orientation}</span>}
              {m.ethnicity&&<span style={{padding:'6px 14px',borderRadius:20,fontSize:12,fontFamily:'var(--font-ui)',background:'rgba(255,255,255,.06)',border:'1px solid rgba(255,255,255,.1)',color:'rgba(251,250,244,.6)'}}>{m.ethnicity}</span>}
            </div>
          </div>
        )}

        {langs.length>0&&<div className="card" style={{marginBottom:12}}><p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:8}}>LANGUAGES</p><p style={{fontSize:13,color:'rgba(251,250,244,.65)'}}>{langs.join(' · ')}</p></div>}
        {pets.length>0&&<div className="card" style={{marginBottom:12}}><p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:8}}>PETS 🐾</p><p style={{fontSize:13,color:'rgba(251,250,244,.65)'}}>{pets.map(p=>p.name?`${p.type} named ${p.name}`:p.type).join(', ')}</p></div>}

        {wellness.length>0&&(
          <div className="card" style={{marginBottom:12}}>
            <p style={{fontSize:10,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',letterSpacing:1.2,marginBottom:10}}>RECOVERY FOCUS</p>
            <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
              {wellness.slice(0,12).map(t=><span key={t} style={{padding:'4px 10px',borderRadius:20,fontSize:11,fontFamily:'var(--font-ui)',background:'rgba(25,229,94,.08)',border:'1px solid rgba(25,229,94,.18)',color:'rgba(251,250,244,.6)'}}>{t}</span>)}
              {wellness.length>12&&<span style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',padding:'4px 6px'}}>+{wellness.length-12} more</span>}
            </div>
          </div>
        )}

        {isAdmin_(m)&&<div className="card" style={{background:'rgba(255,20,147,.04)',border:'1px solid rgba(255,20,147,.1)',marginTop:12}}><p style={{fontSize:13,color:'rgba(251,250,244,.55)',fontFamily:'var(--font-ui)',lineHeight:1.75,fontStyle:'italic'}}>"When someone shows you who they are, believe them the first time." — Maya Angelou. Your Fairy Godfather shows up every day without fail. 🪄</p></div>}
      </div>
    )
  }

  // ── DIRECTORY ──
  return (
    <div style={{paddingTop:20,paddingBottom:40}}>
      <h2 style={{fontSize:20,fontWeight:400,marginBottom:16}}>Members 👥</h2>

      {/* Search + filter toggle row */}
      <div style={{display:'flex',gap:8,marginBottom:12}}>
        <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search members…" style={{flex:1}}/>
        <button onClick={()=>setShowFilters(f=>!f)}
          style={{padding:'10px 14px',borderRadius:8,fontFamily:'var(--font-ui)',fontSize:12,cursor:'pointer',whiteSpace:'nowrap',
            background:showFilters||activeFilters>0?'rgba(255,20,147,.15)':'rgba(255,255,255,.07)',
            border:`1px solid ${showFilters||activeFilters>0?'rgba(255,20,147,.3)':'rgba(255,255,255,.1)'}`,
            color:showFilters||activeFilters>0?'var(--pink)':'rgba(251,250,244,.55)'}}>
          Filters{activeFilters>0?` (${activeFilters})`:''} {showFilters?'▲':'▾'}
        </button>
      </div>

      {/* Quick type filters */}
      <div style={{display:'flex',gap:8,marginBottom:showFilters?0:16}}>
        {[['all','All Members'],['moderators','🪄 Moderators']].map(([val,label])=>(
          <button key={val} onClick={()=>setFilterType(val)}
            style={{padding:'6px 14px',borderRadius:20,fontFamily:'var(--font-ui)',fontSize:12,cursor:'pointer',
              background:filterType===val?'var(--pink)':'rgba(255,255,255,.07)',
              color:filterType===val?'#fff':'rgba(251,250,244,.55)',
              border:`1px solid ${filterType===val?'var(--pink)':'rgba(255,255,255,.1)'}`}}>
            {label}
          </button>
        ))}
      </div>

      {/* Expanded filter panel */}
      {showFilters&&(
        <div className="card" style={{marginTop:12,marginBottom:16,background:'rgba(255,255,255,.03)'}}>
          <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:10,marginBottom:10}}>

            <div>
              <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:5}}>PROGRAM</p>
              <select value={filterProgram} onChange={e=>setFilterProgram(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {PROGRAMS.map(p=><option key={p} value={p}>{p}</option>)}
              </select>
            </div>

            <div>
              <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:5}}>CITY</p>
              <select value={filterCity} onChange={e=>setFilterCity(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {cities.map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:5}}>TIMEZONE</p>
              <select value={filterTimezone} onChange={e=>setFilterTimezone(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {timezones.map(t=><option key={t} value={t}>{tzLabel(t)}</option>)}
              </select>
            </div>

            <div>
              <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:5}}>BIRTHDAY MONTH</p>
              <select value={filterBdayMonth} onChange={e=>setFilterBdayMonth(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {MONTHS.map((m,i)=><option key={i} value={String(i)}>{m}</option>)}
              </select>
            </div>

            <div>
              <p style={{fontSize:10,color:'rgba(251,250,244,.35)',fontFamily:'var(--font-ui)',letterSpacing:1,marginBottom:5}}>SOBRIETY ANNIVERSARY MONTH</p>
              <select value={filterAnnivMonth} onChange={e=>setFilterAnnivMonth(e.target.value)} style={{fontSize:12}}>
                <option value="">Any</option>
                {MONTHS.map((m,i)=><option key={i} value={String(i)}>{m}</option>)}
              </select>
            </div>

          </div>

          {activeFilters>0&&(
            <button onClick={clearFilters}
              style={{fontSize:12,fontFamily:'var(--font-ui)',color:'rgba(251,250,244,.45)',background:'none',border:'none',cursor:'pointer',padding:0,marginTop:4}}>
              ✕ Clear all filters
            </button>
          )}
        </div>
      )}

      {loading&&<div className="spinner"/>}

      {!loading&&(
        <p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)',marginBottom:12}}>
          {filtered.length} member{filtered.length!==1?'s':''}
          {activeFilters>0||search?' matching':' total'}
        </p>
      )}

      {!loading&&filtered.length===0&&(
        <p style={{color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)',fontSize:14,textAlign:'center',paddingTop:30}}>No members found.</p>
      )}

      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        {filtered.map(m=>(
          <div key={m.id} onClick={()=>setSelected(m)} className="card" style={{display:'flex',gap:14,alignItems:'center',cursor:'pointer'}}>
            <div style={{width:46,height:46,borderRadius:'50%',background:'rgba(255,20,147,.1)',border:'1px solid rgba(255,20,147,.2)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:16,fontFamily:'var(--font-ui)',fontWeight:700,color:'var(--pink)',flexShrink:0,overflow:'hidden'}}>
              {m.avatar_url?<img src={m.avatar_url} alt="" style={{width:46,height:46,objectFit:'cover'}}/>:initials(m)}
            </div>
            <div style={{flex:1,minWidth:0}}>
              <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap',marginBottom:2}}>
                <span style={{fontSize:14,fontWeight:isAdmin_(m)?600:400}}>{m.display_name||m.email.split('@')[0]}</span>
                <MemberBadges member={m} size="sm"/>
                {isMe(m)&&<span style={{background:'rgba(25,229,94,.1)',border:'1px solid rgba(25,229,94,.18)',color:'var(--lime)',fontSize:9,fontFamily:'var(--font-ui)',padding:'1px 6px',borderRadius:20}}>You</span>}
              </div>
              <div style={{display:'flex',gap:10,flexWrap:'wrap'}}>
                {m.show_pronouns&&m.pronouns&&<p style={{fontSize:11,color:'rgba(251,250,244,.4)',fontFamily:'var(--font-ui)'}}>{m.pronouns}</p>}
                {m.show_location&&m.city&&<p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)'}}>📍 {m.city}</p>}
                {m.program_1&&<p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)'}}>{m.program_1}</p>}
                {!m.show_pronouns&&!m.show_location&&!m.program_1&&memberSince(m)&&<p style={{fontSize:11,color:'rgba(251,250,244,.3)',fontFamily:'var(--font-ui)'}}>Since {memberSince(m)}</p>}
              </div>
            </div>
            <span style={{color:'rgba(251,250,244,.2)',fontSize:18}}>›</span>
          </div>
        ))}
      </div>
    </div>
  )
}
