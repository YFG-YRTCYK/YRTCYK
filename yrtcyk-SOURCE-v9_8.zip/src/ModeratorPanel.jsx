// ========================================================================
// ModeratorPanel.jsx — v9.7 (April 18, 2026)
//
// Reflections review queue. Handles BOTH posts and comments in one UI.
// Used in two contexts:
//   1. Admin (embedded as a tab in AdminPanel)
//   2. Moderator (rendered as a standalone overlay from App.jsx)
//
// Props:
//   user      — session.user
//   onClose   — optional; when present, renders a "← Back" header
//   embedded  — true when rendered inside AdminPanel tab (no header chrome)
// ========================================================================

import { useState, useEffect } from 'react'
import { supabase } from './supabaseClient'

export default function ModeratorPanel({ user, onClose, embedded = false }) {
  const [tab, setTab] = useState('posts') // posts | comments
  const [pendingPosts, setPendingPosts] = useState([])
  const [pendingComments, setPendingComments] = useState([])
  const [expandedPost, setExpandedPost] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => { loadAll() }, [])

  async function loadAll() {
    setLoading(true)
    const [postsRes, commentsRes] = await Promise.all([
      supabase.from('blog_posts')
        .select('*, members:author_id(display_name, email)')
        .eq('status', 'submitted')
        .order('created_at', { ascending: true }),
      supabase.from('blog_comments')
        .select('*, members:author_id(display_name, email), blog_posts:post_id(title)')
        .eq('status', 'submitted')
        .order('created_at', { ascending: true })
    ])
    setPendingPosts(postsRes.data || [])
    setPendingComments(commentsRes.data || [])
    setLoading(false)
  }

  async function reviewPost(id, status) {
    await supabase.from('blog_posts')
      .update({ status, reviewed_at: new Date().toISOString() })
      .eq('id', id)
    setPendingPosts(prev => prev.filter(p => p.id !== id))
    if (expandedPost === id) setExpandedPost(null)
  }

  async function reviewComment(id, status) {
    await supabase.from('blog_comments')
      .update({ status, reviewed_at: new Date().toISOString() })
      .eq('id', id)
    setPendingComments(prev => prev.filter(c => c.id !== id))
  }

  const postCount = pendingPosts.length
  const commentCount = pendingComments.length

  return (
    <div style={{ paddingTop: embedded ? 0 : 20, paddingBottom: 40 }}>
      {!embedded && (
        <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:20 }}>
          <h2 style={{ fontSize:20, fontWeight:400 }}>🛡️ Moderator Queue</h2>
          {onClose && (
            <button onClick={onClose} style={{ color:'rgba(251,250,244,.5)', fontSize:13, fontFamily:'var(--font-ui)' }}>← Back</button>
          )}
        </div>
      )}

      <div style={{ display:'flex', gap:8, marginBottom:20 }}>
        {[['posts', `📝 Reflections${postCount > 0 ? ` (${postCount})` : ''}`],
          ['comments', `💬 Responses${commentCount > 0 ? ` (${commentCount})` : ''}`]].map(([t, label]) => (
          <button key={t} onClick={() => setTab(t)}
            style={{
              padding:'8px 14px', borderRadius:8, fontSize:12, fontFamily:'var(--font-ui)', cursor:'pointer',
              background: tab === t ? 'var(--pink)' : 'rgba(255,255,255,.06)',
              color: tab === t ? '#fff' : 'rgba(251,250,244,.55)',
              border: `1px solid ${tab === t ? 'var(--pink)' : 'rgba(255,255,255,.1)'}`
            }}>
            {label}
          </button>
        ))}
      </div>

      {loading && <div className="spinner"/>}

      {/* ── POSTS TAB ── */}
      {!loading && tab === 'posts' && (
        <>
          {pendingPosts.length === 0 && (
            <div className="card" style={{ textAlign:'center', padding:40 }}>
              <p style={{ fontSize:28, marginBottom:8 }}>✨</p>
              <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14 }}>All caught up — no pending Reflections.</p>
            </div>
          )}
          {pendingPosts.map(p => {
            const isExpanded = expandedPost === p.id
            const preview = p.body.length > 280 ? p.body.slice(0, 280) + '…' : p.body
            return (
              <div key={p.id} className="card" style={{ marginBottom:12 }}>
                <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:6 }}>
                  {p.members?.display_name || p.members?.email?.split('@')[0] || 'A member'} ·{' '}
                  {new Date(p.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
                </p>
                <h4 style={{ fontSize:16, fontWeight:500, marginBottom:10 }}>{p.title}</h4>
                <p style={{
                  fontSize:13, color:'rgba(251,250,244,.7)', lineHeight:1.7,
                  whiteSpace:'pre-wrap', marginBottom:12
                }}>
                  {isExpanded ? p.body : preview}
                </p>
                {p.body.length > 280 && (
                  <button onClick={() => setExpandedPost(isExpanded ? null : p.id)}
                    style={{ fontSize:11, fontFamily:'var(--font-ui)', color:'var(--pink)', marginBottom:12 }}>
                    {isExpanded ? '↑ Collapse' : '↓ Read full post'}
                  </button>
                )}
                <div style={{ display:'flex', gap:8 }}>
                  <button onClick={() => reviewPost(p.id, 'approved')}
                    style={{
                      flex:1, padding:'8px', borderRadius:8,
                      background:'rgba(25,229,94,.15)', border:'1px solid rgba(25,229,94,.3)',
                      color:'var(--lime)', fontSize:12, fontFamily:'var(--font-ui)', cursor:'pointer', fontWeight:600
                    }}>
                    ✓ Approve
                  </button>
                  <button onClick={() => reviewPost(p.id, 'rejected')}
                    style={{
                      flex:1, padding:'8px', borderRadius:8,
                      background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)',
                      color:'var(--pink)', fontSize:12, fontFamily:'var(--font-ui)', cursor:'pointer'
                    }}>
                    ✕ Return
                  </button>
                </div>
              </div>
            )
          })}
        </>
      )}

      {/* ── COMMENTS TAB ── */}
      {!loading && tab === 'comments' && (
        <>
          {pendingComments.length === 0 && (
            <div className="card" style={{ textAlign:'center', padding:40 }}>
              <p style={{ fontSize:28, marginBottom:8 }}>✨</p>
              <p style={{ color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', fontSize:14 }}>All caught up — no pending responses.</p>
            </div>
          )}
          {pendingComments.map(c => (
            <div key={c.id} className="card" style={{ marginBottom:12 }}>
              <p style={{ fontSize:11, color:'rgba(251,250,244,.35)', fontFamily:'var(--font-ui)', marginBottom:6 }}>
                {c.members?.display_name || c.members?.email?.split('@')[0] || 'A member'} ·{' '}
                {new Date(c.created_at).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' })}
              </p>
              {c.blog_posts?.title && (
                <p style={{ fontSize:11, color:'rgba(251,250,244,.4)', fontFamily:'var(--font-ui)', marginBottom:8 }}>
                  On: <strong style={{ color:'rgba(251,250,244,.6)' }}>{c.blog_posts.title}</strong>
                </p>
              )}
              <p style={{
                fontSize:13, color:'rgba(251,250,244,.8)', lineHeight:1.7,
                padding:'10px 14px', background:'rgba(255,255,255,.04)', borderRadius:8,
                borderLeft:'3px solid rgba(255,20,147,.3)', marginBottom:12, whiteSpace:'pre-wrap'
              }}>
                {c.body}
              </p>
              <div style={{ display:'flex', gap:8 }}>
                <button onClick={() => reviewComment(c.id, 'approved')}
                  style={{
                    flex:1, padding:'8px', borderRadius:8,
                    background:'rgba(25,229,94,.15)', border:'1px solid rgba(25,229,94,.3)',
                    color:'var(--lime)', fontSize:12, fontFamily:'var(--font-ui)', cursor:'pointer', fontWeight:600
                  }}>
                  ✓ Approve
                </button>
                <button onClick={() => reviewComment(c.id, 'rejected')}
                  style={{
                    flex:1, padding:'8px', borderRadius:8,
                    background:'rgba(255,20,147,.1)', border:'1px solid rgba(255,20,147,.2)',
                    color:'var(--pink)', fontSize:12, fontFamily:'var(--font-ui)', cursor:'pointer'
                  }}>
                  ✕ Reject
                </button>
              </div>
            </div>
          ))}
        </>
      )}
    </div>
  )
}
