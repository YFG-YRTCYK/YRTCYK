import { createClient } from '@supabase/supabase-js'
export const supabase = createClient(
  'https://fdpcaqzwvophryosnmlh.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZkcGNhcXp3dm9waHJ5b3NubWxoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzU4ODYwNzUsImV4cCI6MjA5MTQ2MjA3NX0.rPW6TSh6ykj-MUo7kgo_9G_oKRLCURV_foAgQxx_3Q8'
)
